# Einzelübertritte ARE Automatisierung

Dieses Projekt erzeugt aus einer bestehenden XLSM-Datei automatisch die gesellschaftsbezogenen **ARE-Blätter** für Einzelübertritte.

## Schnellstart

1. Den gesamten Projektordner entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. Die zu verarbeitende `.xlsm`-Datei auswählen.
4. Das Tool erstellt neben der Quelldatei eine neue Datei mit dem Zusatz `_ARE_Auswertung.xlsm`.
5. Die erzeugte Datei bleibt nach Abschluss in Excel geöffnet.

Die Quelldatei wird bei der VBS-Ausführung **nicht verändert**.

## Alternative Ausführung direkt in Excel

Im Ordner `macro` liegt das Modul `modAREGenerator.bas`.

1. XLSM-Datei öffnen.
2. `Alt + F11` drücken.
3. Im VBA-Editor `Datei > Datei importieren` wählen.
4. `macro/modAREGenerator.bas` importieren.
5. `Alt + F8` drücken.
6. `Erstelle_ARE_Blaetter` starten.

Bei der direkten VBA-Ausführung wird die aktuell geöffnete Arbeitsmappe verarbeitet. Bereits erzeugte Blätter mit dem Namensmuster `ARE ... (LTRG ...)` werden darin gelöscht und neu aufgebaut.

## Projektstruktur

```text
Einzeluebertritte_ARE_Automatisierung/
├── ARE_Generator_starten.vbs
├── README.md
├── VERSION.txt
├── macro/
│   └── modAREGenerator.bas
└── docs/
    ├── 01_Bedienung.md
    ├── 02_Fachlogik.md
    ├── 03_Technischer_Ablauf.md
    ├── 04_Datenanforderungen.md
    ├── 05_Grenzen_und_Nicht_Ziele.md
    ├── 06_Fehlersuche.md
    └── 07_Abgleich_Input_Output.md
```

## Voraussetzungen

- Windows
- Microsoft Excel Desktop
- Eingabedatei im Format `.xlsm`
- Blätter `Übersicht` und `Gesellschaften` im erwarteten Aufbau
- Schreibrecht im Ordner der ausgewählten Excel-Datei

Weitere Details stehen im Ordner `docs`.
