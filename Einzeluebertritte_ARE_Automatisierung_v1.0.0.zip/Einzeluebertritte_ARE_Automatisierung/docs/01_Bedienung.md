# Bedienung

## Empfohlener Weg: VBS starten

1. ZIP-Datei vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. Im Excel-Dateidialog die Quelldatei auswählen.
4. Warten, bis die Erfolgsmeldung erscheint.
5. Die neue Ausgabedatei prüfen und anschließend normal schließen.

## Ausgabedatei

Die Ausgabe wird im selben Ordner wie die Quelle gespeichert:

```text
<Name der Quelle>_ARE_Auswertung.xlsm
```

Existiert dieser Name bereits, ergänzt das Tool einen Zeitstempel. Vorhandene Dateien werden nicht überschrieben.

## Sicherheitsverhalten

Die VBS-Datei öffnet die Quelle schreibgeschützt und erstellt zuerst eine Kopie. Nur diese Kopie wird bearbeitet. Die ursprüngliche Datei bleibt unverändert.

## Direkte Nutzung des Makros

Das Modul `macro/modAREGenerator.bas` kann in eine XLSM-Datei importiert werden. Danach stehen zwei Makros zur Verfügung:

- `Erstelle_ARE_Blaetter`: erzeugt die ARE-Auswertung neu.
- `Loesche_ARE_Blaetter`: entfernt automatisch erzeugte ARE-Blätter.

Bei dieser Variante arbeitet das Makro direkt in der geöffneten Arbeitsmappe. Vorher sollte eine Sicherungskopie erstellt werden.
