# Datenanforderungen

## Erforderliche Blätter

Die Arbeitsmappe muss enthalten:

- `Übersicht`
- `Gesellschaften`

Das Blatt `CHECK` darf vorhanden sein, wird aber nicht zwingend für die Erzeugung benötigt.

## Erwarteter Aufbau von Übersicht

Die Überschriften stehen in Zeile 2. Mindestens die ersten vier Überschriften müssen exakt erkennbar sein:

```text
A2: PNR neu
B2: Ltrg neu
C2: PNR alt
D2: Ltrg alt
```

Die Daten beginnen in Zeile 3.

Die Transformation erwartet die Beträge in:

```text
H: BSAV
I: Pensionen (alt)
J: Summe
```

## Erwarteter Aufbau von Gesellschaften

Die Stammdaten beginnen in Zeile 2:

```text
D: LTRG
E: ARE
F: Name
```

Für jede LTRG, die in `Übersicht` als alte oder neue LTRG vorkommt, muss eine Zeile mit Gesellschaftsname vorhanden sein.

## Datentypen

- LTRG muss numerisch interpretierbar sein.
- Beträge dürfen Zahlen, Formelergebnisse, leere Zellen oder Nullwerte sein.
- Nicht numerische Beträge werden als `0` behandelt.
- Datumswerte können echte Excel-Datumswerte oder bereits vorhandene Textwerte sein.

## Dateiformat

Die externe VBS-Ausführung akzeptiert bewusst nur `.xlsm`, damit `SaveCopyAs` das Dateiformat ohne Konvertierung beibehält.
