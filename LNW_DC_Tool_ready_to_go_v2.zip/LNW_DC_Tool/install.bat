@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Intel LNW DC Tool - Installation

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PIP_REQUIRE_HASHES="
set "PIP_CONSTRAINT="
set "PIP_CONFIG_FILE=NUL"
set "PYTHON_CMD="

REM Bevorzugt bewaehrte Versionen. Python 3.14 wird nur als letzter Fallback genutzt.
for %%V in (3.13 3.12 3.11 3.14) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo ============================================================
    echo FEHLER: Kein geeignetes Python wurde gefunden.
    echo Bitte Python 3.11, 3.12 oder 3.13 64-Bit installieren.
    echo Beim Setup "Add python.exe to PATH" aktivieren.
    echo ============================================================
    pause
    exit /b 1
)

echo ============================================================
echo  Intel LNW DC Tool - Installation
echo ============================================================
echo Verwende: %PYTHON_CMD%
%PYTHON_CMD% -c "import sys,platform; print('Python:', sys.version); print('Architektur:', platform.architecture()[0])"
if errorlevel 1 goto :failed

echo.
echo Entferne eine eventuell unvollstaendige Laufzeitumgebung ...
if exist runtime rmdir /s /q runtime

echo Erstelle lokale Laufzeitumgebung ...
%PYTHON_CMD% -m venv runtime
if errorlevel 1 goto :failed

set "VENV_PY=%CD%\runtime\Scripts\python.exe"
if not exist "%VENV_PY%" goto :failed

echo.
echo Installiere Abhaengigkeiten isoliert und ohne Paket-Cache ...
"%VENV_PY%" -m pip --isolated install --disable-pip-version-check --no-cache-dir -r requirements.txt
if errorlevel 1 goto :retry

goto :verify

:retry
echo.
echo Erster Installationsversuch fehlgeschlagen.
echo Wiederhole mit direktem offiziellen PyPI-Index ...
"%VENV_PY%" -m pip --isolated install --disable-pip-version-check --no-cache-dir --index-url https://pypi.org/simple -r requirements.txt
if errorlevel 1 goto :failed

:verify
echo.
echo Pruefe Installation ...
"%VENV_PY%" -c "import pandas, openpyxl, pythoncom, win32com.client; print('Pakete erfolgreich geladen.')"
if errorlevel 1 goto :failed

echo.
echo ============================================================
echo Installation erfolgreich.
echo Starte das Tool zukuenftig mit start.bat.
echo ============================================================
pause
exit /b 0

:failed
echo.
echo ============================================================
echo Installation fehlgeschlagen.
echo Empfohlen: Python 3.12 oder 3.13 64-Bit installieren und
echo install.bat danach erneut starten.
echo ============================================================
pause
exit /b 1
