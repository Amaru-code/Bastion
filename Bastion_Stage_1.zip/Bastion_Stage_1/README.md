# Bastion – Entwicklungsstufe 1

Lokaler Browser-Prototyp ohne Installation. Starte `Start_Game.ps1`, `Start_Game.bat` oder `index.html`.

## Spielziel
Erobere die rote Burg. Klicke eine eigene Burg, danach ein verbundenes Ziel und sende 25/50/75 Prozent deiner Soldaten.

## Systeme
- Burg: produziert Soldaten bis zur Kapazität
- Farm: produziert Nahrung; Soldatenproduktion verbraucht Nahrung
- Mine: erzeugt Gold bis zur lokalen Gesamtkapazität; Upgrades kosten 15 Gold
- Akademie: erzeugt Wissen; bei 30 Wissen erscheint eine zufällige 1-aus-3-Forschung
- Jahreszeiten verändern Produktionsraten
- KI greift selbstständig an
- Speichern/Laden über LocalStorage
