$p=Split-Path -Parent $MyInvocation.MyCommand.Path
Start-Process (Join-Path $p 'index.html')
