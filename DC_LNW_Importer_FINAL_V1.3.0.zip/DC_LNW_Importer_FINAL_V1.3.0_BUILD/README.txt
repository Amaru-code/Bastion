DC LNW Importer – Finale Version 1.3.0
======================================

START
-----
1. ZIP vollständig entpacken.
2. start.bat doppelklicken.
3. Template-Datei auswählen.
4. DU-Datei auswählen.

ERGEBNIS
--------
Das ausgewählte Template wird unverändert als separate XLSM-Ausgabedatei kopiert.
Nur das Sheet "Import DC LNW" wird in der Kopie bearbeitet.

Importlogik:
- AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Input-Templates, exakt 1:1.
- BI:BN = aggregierte DU-Werte für Fondsportfolioanpassung.
- CL:CU = bestätigte Endbestände aus der Datenaufbereitung.

Wichtig:
- Die Werte aus 03_final_import.csv werden in AJ:AS, BI:BN und CL:CU immer geschrieben.
- Vorhandene Formeln innerhalb dieser konkreten Importzellen werden durch die geprüften CSV-Werte ersetzt.
- Formeln außerhalb der Importzellen bleiben erhalten.
- Leere, im XLSM-XML noch nicht angelegte Zellen werden automatisch erzeugt.
- Vor dem Speichern verifiziert das Tool jede Zielzelle gegen den berechneten CSV-Wert.
- Bei einer Abweichung wird kein erfolgreicher Import gemeldet.

AUSGABEN
--------
Unter output/Auswertung_YYYYMMDD_HHMMSS entstehen:
- 03_final_import.csv
- 04_kontrolle.csv
- *_DC_LNW_Output.xlsm
- ZUSAMMENFASSUNG.txt
- processing.log

VORAUSSETZUNGEN
---------------
- Windows 10 oder Windows 11
- Keine Go-, Python- oder PowerShell-Installation erforderlich
  (Windows PowerShell wird nur für native Dateiauswahldialoge verwendet.)
