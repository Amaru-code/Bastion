Option Explicit

' ============================================================================
' Einzeluebertritte ARE Generator - externe Ausfuehrung
' Version 1.0.2
'
' Ablauf:
'   1. Excel-Datei per Dateiauswahl bestimmen.
'   2. Sichere Ausgabekopie im Format der Quelle anlegen.
'   3. ARE-Blaetter in der Kopie neu erzeugen.
'   4. Ergebnis speichern und in Excel geoeffnet lassen.
'
' Die Quelldatei wird nicht veraendert.
' ============================================================================

Const xlCalculationAutomatic = -4105
Const xlCalculationManual = -4135
Const xlCenter = -4108
Const xlLeft = -4131
Const xlRight = -4152
Const xlContinuous = 1
Const xlThin = 2
Const xlDouble = -4119
Const xlEdgeLeft = 7
Const xlEdgeTop = 8
Const xlEdgeBottom = 9
Const xlEdgeRight = 10
Const xlCellValue = 1
Const xlEqual = 3
Const xlNotEqual = 4
Const xlLandscape = 2
Const xlUp = -4162

Const SHEET_OVERVIEW = "�bersicht"
Const SHEET_COMPANIES = "Gesellschaften"
Const GENERATED_PREFIX = "ARE "
Const FIRST_DATA_ROW = 3
Const CENTRAL_LTRG = 100
Const INCLUDE_ZERO_ON_RECEIVER_SIDE = False
Const VB_ERROR_TYPE = 10

Dim gExcel
Dim gWorkbook
Dim gOutputPath
Dim gSuccess
Dim gStage
Dim errNumber
Dim errDescription
Dim errSource

gStage = "Initialisierung"

On Error Resume Next
RunGenerator
errNumber = Err.Number
errDescription = Err.Description
errSource = Err.Source
On Error GoTo 0

If errNumber <> 0 Then
    On Error Resume Next
    If IsObject(gWorkbook) Then
        If Not gWorkbook Is Nothing Then gWorkbook.Close False
    End If
    If IsObject(gExcel) Then
        If Not gExcel Is Nothing Then
            gExcel.ScreenUpdating = True
            gExcel.EnableEvents = True
            gExcel.DisplayAlerts = True
            gExcel.StatusBar = False
            gExcel.Quit
        End If
    End If
    On Error GoTo 0

    MsgBox "Die ARE-Auswertung konnte nicht erstellt werden." & vbCrLf & vbCrLf & _
           "Phase: " & gStage & vbCrLf & _
           "Fehler " & CStr(errNumber) & ": " & errDescription & vbCrLf & _
           "Quelle: " & errSource & vbCrLf & vbCrLf & _
           "Hinweise stehen im Ordner docs, insbesondere in 06_Fehlersuche.md.", _
           vbCritical, "ARE Generator"
    WScript.Quit 1
End If

Sub RunGenerator()
    Dim fso
    Dim sourcePath
    Dim sourceWorkbook
    Dim oldCalculation
    Dim sourceExtension

    gStage = "Excel starten"
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set gExcel = CreateObject("Excel.Application")

    gExcel.Visible = True
    gExcel.DisplayAlerts = False

    gStage = "Quelldatei ausw�hlen"
    sourcePath = gExcel.GetOpenFilename( _
        "Excel-Dateien (*.xlsm;*.xlsx),*.xlsm;*.xlsx", _
        1, _
        "Quelldatei mit �bersicht und Gesellschaften ausw�hlen" _
    )

    If VarType(sourcePath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    sourceExtension = LCase(fso.GetExtensionName(CStr(sourcePath)))

    If sourceExtension <> "xlsm" And sourceExtension <> "xlsx" Then
        Err.Raise -2147221504 + 2000, "ARE Generator", _
                  "Bitte eine XLSM- oder XLSX-Datei ausw�hlen."
    End If

    gStage = "Ausgabepfad vorbereiten"
    gOutputPath = BuildOutputPath(fso, CStr(sourcePath))

    gStage = "Ausgabekopie erstellen"
    gExcel.StatusBar = "Sichere Ausgabekopie wird erstellt ..."
    Set sourceWorkbook = gExcel.Workbooks.Open(CStr(sourcePath), 0, True)
    sourceWorkbook.SaveCopyAs gOutputPath
    sourceWorkbook.Close False
    Set sourceWorkbook = Nothing

    gStage = "Ausgabedatei �ffnen"
    Set gWorkbook = gExcel.Workbooks.Open(gOutputPath, 0, False)

    oldCalculation = gExcel.Calculation
    gExcel.ScreenUpdating = False
    gExcel.EnableEvents = False
    gExcel.DisplayAlerts = False

    ' Vor dem Auslesen vorhandene Formeln aktualisieren.
    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gExcel.Calculation = xlCalculationManual

    gStage = "ARE-Bl�tter erzeugen"
    GenerateARESheets gExcel, gWorkbook

    gStage = "Ergebnis berechnen und speichern"

    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gWorkbook.Save

    gExcel.StatusBar = False
    gExcel.ScreenUpdating = True
    gExcel.EnableEvents = True
    gExcel.DisplayAlerts = True
    gExcel.Calculation = oldCalculation
    gExcel.Visible = True

    gStage = "Abgeschlossen"
    gSuccess = True

    MsgBox "Die ARE-Auswertung wurde erfolgreich erstellt." & vbCrLf & vbCrLf & _
           "Ausgabedatei:" & vbCrLf & gOutputPath & vbCrLf & vbCrLf & _
           "Die Quelldatei wurde nicht ver�ndert.", _
           vbInformation, "ARE Generator"
End Sub

Sub GenerateARESheets(ByVal xlApp, ByVal wb)
    Dim wsOverview
    Dim wsCompanies
    Dim companies
    Dim targets
    Dim transferData
    Dim targetKeys
    Dim lastTransferRow
    Dim i

    Set wsOverview = GetWorksheetOrNothing(wb, SHEET_OVERVIEW)
    Set wsCompanies = GetWorksheetOrNothing(wb, SHEET_COMPANIES)

    If wsOverview Is Nothing Then
        Err.Raise -2147221504 + 2010, "ARE Generator", _
                  "Das Blatt '" & SHEET_OVERVIEW & "' wurde nicht gefunden."
    End If

    If wsCompanies Is Nothing Then
        Err.Raise -2147221504 + 2011, "ARE Generator", _
                  "Das Blatt '" & SHEET_COMPANIES & "' wurde nicht gefunden."
    End If

    gStage = "Quellbl�tter pr�fen"
    ValidateOverviewLayout wsOverview

    lastTransferRow = LastTransferRow(wsOverview)
    If lastTransferRow < FIRST_DATA_ROW Then
        Err.Raise -2147221504 + 2012, "ARE Generator", _
                  "Im Blatt '" & SHEET_OVERVIEW & "' wurden keine �bertritte gefunden."
    End If

    transferData = wsOverview.Range( _
        wsOverview.Cells(FIRST_DATA_ROW, 1), _
        wsOverview.Cells(lastTransferRow, 10) _
    ).Value2

    gStage = "Gesellschaften und LTRG einlesen"
    Set companies = LoadCompanies(wsCompanies)
    Set targets = BuildTargetLtrgs(transferData)

    gStage = "LTRG-Zuordnungen pr�fen"
    ValidateCompanyAssignments targets, companies
    gStage = "Alte ARE-Bl�tter entfernen"
    DeleteGeneratedSheets wb

    targetKeys = targets.Keys
    SortNumericKeys targetKeys

    For i = 0 To UBound(targetKeys)
        gStage = "ARE-Blatt f�r LTRG " & FormatLtrg(CLng(targetKeys(i))) & " erstellen"
        xlApp.StatusBar = "ARE-Blatt f�r LTRG " & _
                          FormatLtrg(CLng(targetKeys(i))) & " wird erstellt ..."
        CreateARESheet xlApp, wb, wsOverview, companies, transferData, CLng(targetKeys(i))
    Next
End Sub

Sub CreateARESheet(ByVal xlApp, ByVal wb, ByVal wsOverview, ByVal companies, _
                   ByRef transferData, ByVal targetLtrg)
    Dim ws
    Dim groups
    Dim targetInfo
    Dim counterpartyInfo
    Dim groupKeys
    Dim rowsInGroup
    Dim descriptor
    Dim targetName
    Dim targetShortName
    Dim sheetName
    Dim newLtrg
    Dim oldLtrg
    Dim validNew
    Dim validOld
    Dim sourceIndex
    Dim direction
    Dim signedPension
    Dim signedBsav
    Dim signedTotal
    Dim currentRow
    Dim sectionRow
    Dim headerRow
    Dim dataStartRow
    Dim dataEndRow
    Dim subtotalRow
    Dim subtotalRefs
    Dim pass
    Dim i
    Dim j
    Dim amount
    Dim shouldWrite
    Dim counterpartyKey
    Dim overviewNameEscaped

    targetInfo = companies.Item(CStr(targetLtrg))
    targetName = CStr(targetInfo(1))
    targetShortName = ShortCompanyName(targetName)

    sheetName = UniqueSheetName(wb, BuildSheetName(targetLtrg, targetInfo(0)))
    Set ws = wb.Worksheets.Add(Empty, wb.Worksheets(wb.Worksheets.Count))
    ws.Name = sheetName

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = 1

    For i = LBound(transferData, 1) To UBound(transferData, 1)
        validNew = TryGetLong(transferData(i, 2), newLtrg)
        validOld = TryGetLong(transferData(i, 4), oldLtrg)

        If validNew And validOld Then
            If newLtrg <> oldLtrg Then
                amount = NzNumber(transferData(i, 10))

                If newLtrg = targetLtrg Then
                    If amount <> 0 Or INCLUDE_ZERO_ON_RECEIVER_SIDE Then
                        AddGroupRecord groups, CStr(oldLtrg), i, 1
                    End If
                End If

                If oldLtrg = targetLtrg Then
                    AddGroupRecord groups, CStr(newLtrg), i, -1
                End If
            End If
        End If
    Next

    ws.Range("A1:F1").Merge
    ws.Range("A3:F3").Merge
    ws.Range("A4:F4").Merge

    ws.Range("A1").Value = "�bertragene R�ckstellungen bei Einzel�bertritten"
    ws.Range("A3").Value = "Positive Betr�ge erh�lt die " & targetShortName & _
                           " von der genannten Gesellschaft,"
    ws.Range("A4").Value = "negative Betr�ge gibt die " & targetShortName & _
                           " an die genannte Gesellschaft ab."

    ws.Range("H1").Value = "CHECK"
    ws.Range("I1").Value = "ORZ, OK"
    ws.Range("H2").Value = targetLtrg
    ws.Range("I2").Value = targetInfo(0)
    ws.Range("J2").Value = targetName
    ws.Range("H3").Value = "CHECK"

    overviewNameEscaped = Replace(wsOverview.Name, "'", "''")
    ws.Range("H4").Formula = _
        "=SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$B:$B,$H$2)-" & _
        "SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$D:$D,$H$2)"

    currentRow = 7
    subtotalRefs = ""

    If groups.Count > 0 Then
        groupKeys = groups.Keys
        SortGroupKeys groupKeys, groups, transferData, targetLtrg

        For i = 0 To UBound(groupKeys)
            counterpartyKey = CStr(groupKeys(i))
            counterpartyInfo = companies.Item(counterpartyKey)
            Set rowsInGroup = groups.Item(counterpartyKey)

            sectionRow = currentRow
            headerRow = sectionRow + 1
            dataStartRow = headerRow + 1

            ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
            ws.Cells(sectionRow, 1).Value = _
                ShortCompanyName(CStr(counterpartyInfo(1))) & _
                " (ARE " & DisplayValue(counterpartyInfo(0)) & _
                ", LTRG " & FormatLtrg(CLng(counterpartyKey)) & ")"

            ws.Cells(sectionRow, 8).Value = CLng(counterpartyKey)
            ws.Cells(sectionRow, 9).Value = counterpartyInfo(0)
            ws.Cells(sectionRow, 10).Value = CStr(counterpartyInfo(1))

            ws.Cells(headerRow, 1).Value = "PNR" & vbLf
            ws.Cells(headerRow, 2).Value = "alte PNR" & vbLf
            ws.Cells(headerRow, 3).Value = "�bertritt" & vbLf
            ws.Cells(headerRow, 4).Value = "Pensionen (alt)" & vbLf & "(Euro)"
            ws.Cells(headerRow, 5).Value = "BSAV" & vbLf & "(Euro)"
            ws.Cells(headerRow, 6).Value = "Summe" & vbLf & "(Euro)"

            currentRow = dataStartRow

            For pass = 1 To 2
                For j = 0 To rowsInGroup.Count - 1
                    descriptor = rowsInGroup.Item(CStr(j))
                    sourceIndex = CLng(descriptor(0))
                    direction = CLng(descriptor(1))
                    signedTotal = direction * NzNumber(transferData(sourceIndex, 10))

                    shouldWrite = _
                        (pass = 1 And signedTotal > 0) Or _
                        (pass = 2 And signedTotal <= 0)

                    If shouldWrite Then
                        signedPension = direction * NzNumber(transferData(sourceIndex, 9))
                        signedBsav = direction * NzNumber(transferData(sourceIndex, 8))

                        ws.Cells(currentRow, 1).Value = transferData(sourceIndex, 1)
                        ws.Cells(currentRow, 2).Value = transferData(sourceIndex, 3)
                        ws.Cells(currentRow, 3).Value = transferData(sourceIndex, 5)
                        ws.Cells(currentRow, 4).Value = signedPension
                        ws.Cells(currentRow, 5).Value = signedBsav
                        ws.Cells(currentRow, 6).Value = signedTotal

                        currentRow = currentRow + 1
                    End If
                Next
            Next

            dataEndRow = currentRow - 1
            subtotalRow = currentRow

            ws.Cells(subtotalRow, 4).Formula = _
                "=SUM(D" & CStr(dataStartRow) & ":D" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 5).Formula = _
                "=SUM(E" & CStr(dataStartRow) & ":E" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 6).Formula = _
                "=SUM(F" & CStr(dataStartRow) & ":F" & CStr(dataEndRow) & ")"

            subtotalRefs = subtotalRefs & "," & _
                           ws.Cells(subtotalRow, 6).Address(False, False)

            FormatSection ws, sectionRow, headerRow, dataStartRow, dataEndRow, subtotalRow
            currentRow = subtotalRow + 2
        Next
    End If

    If Len(subtotalRefs) > 0 Then
        ws.Range("I4").Formula = "=H4-SUM(" & Mid(subtotalRefs, 2) & ")"
    Else
        ws.Range("I4").Formula = "=H4"
    End If

    FormatARESheet xlApp, ws, currentRow - 1
End Sub

Function LoadCompanies(ByVal ws)
    Dim dict
    Dim lastRow
    Dim r
    Dim ltrg
    Dim isValid
    Dim companyName
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    lastRow = ws.Cells(ws.Rows.Count, 4).End(xlUp).Row

    For r = 2 To lastRow
        isValid = TryGetLong(ws.Cells(r, 4).Value2, ltrg)
        If isValid Then
            companyName = SafeString(ws.Cells(r, 6).Value)
            If Len(Trim(companyName)) > 0 Then
                key = CStr(ltrg)
                If dict.Exists(key) Then
                    dict.Item(key) = Array(ws.Cells(r, 5).Value2, companyName)
                Else
                    dict.Add key, Array(ws.Cells(r, 5).Value2, companyName)
                End If
            End If
        End If
    Next

    If dict.Count = 0 Then
        Err.Raise -2147221504 + 2020, "ARE Generator", _
                  "Im Blatt '" & SHEET_COMPANIES & "' wurden keine Gesellschaften gefunden."
    End If

    Set LoadCompanies = dict
End Function

Function BuildTargetLtrgs(ByRef transferData)
    Dim dict
    Dim i
    Dim ltrg
    Dim isValid
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    For i = LBound(transferData, 1) To UBound(transferData, 1)
        isValid = TryGetLong(transferData(i, 2), ltrg)
        If isValid Then
            key = CStr(ltrg)
            If Not dict.Exists(key) Then dict.Add key, True
        End If

        isValid = TryGetLong(transferData(i, 4), ltrg)
        If isValid Then
            key = CStr(ltrg)
            If Not dict.Exists(key) Then dict.Add key, True
        End If
    Next

    Set BuildTargetLtrgs = dict
End Function

Sub ValidateCompanyAssignments(ByVal targets, ByVal companies)
    Dim key
    Dim missing

    missing = ""
    For Each key In targets.Keys
        If Not companies.Exists(CStr(key)) Then
            missing = missing & vbCrLf & "- LTRG " & FormatLtrg(CLng(key))
        End If
    Next

    If Len(missing) > 0 Then
        Err.Raise -2147221504 + 2021, "ARE Generator", _
                  "F�r folgende LTRG fehlt eine Zuordnung im Blatt '" & _
                  SHEET_COMPANIES & "':" & missing
    End If
End Sub

Sub AddGroupRecord(ByVal groups, ByVal counterpartyKey, ByVal sourceIndex, ByVal direction)
    Dim rowsInGroup

    If Not groups.Exists(counterpartyKey) Then
        Set rowsInGroup = CreateObject("Scripting.Dictionary")
        rowsInGroup.CompareMode = 1
        groups.Add counterpartyKey, rowsInGroup
    Else
        Set rowsInGroup = groups.Item(counterpartyKey)
    End If

    rowsInGroup.Add CStr(rowsInGroup.Count), Array(sourceIndex, direction)
End Sub

Sub SortNumericKeys(ByRef keys)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If CLng(keys(i)) > CLng(keys(j)) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Sub SortGroupKeys(ByRef keys, ByVal groups, ByRef transferData, ByVal targetLtrg)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If GroupKeyComesAfter(CStr(keys(i)), CStr(keys(j)), _
                                  groups, transferData, targetLtrg) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Function GroupKeyComesAfter(ByVal firstKey, ByVal secondKey, ByVal groups, _
                            ByRef transferData, ByVal targetLtrg)
    Dim firstRows
    Dim secondRows
    Dim firstHasPositive
    Dim secondHasPositive

    If targetLtrg = CENTRAL_LTRG Then
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
        Exit Function
    End If

    Set firstRows = groups.Item(firstKey)
    Set secondRows = groups.Item(secondKey)

    firstHasPositive = GroupHasPositive(firstRows, transferData)
    secondHasPositive = GroupHasPositive(secondRows, transferData)

    If firstHasPositive <> secondHasPositive Then
        GroupKeyComesAfter = (Not firstHasPositive And secondHasPositive)
    Else
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
    End If
End Function

Function GroupHasPositive(ByVal rowsInGroup, ByRef transferData)
    Dim i
    Dim descriptor
    Dim sourceIndex
    Dim direction

    GroupHasPositive = False

    For i = 0 To rowsInGroup.Count - 1
        descriptor = rowsInGroup.Item(CStr(i))
        sourceIndex = CLng(descriptor(0))
        direction = CLng(descriptor(1))

        If direction * NzNumber(transferData(sourceIndex, 10)) > 0 Then
            GroupHasPositive = True
            Exit Function
        End If
    Next
End Function

Sub FormatARESheet(ByVal xlApp, ByVal ws, ByVal lastContentRow)
    Dim maxRow
    Dim fc

    maxRow = MaxLong(lastContentRow, 4)

    With ws.Cells
        .Font.Name = "Calibri"
        .Font.Size = 10
        .VerticalAlignment = xlCenter
    End With

    With ws.Range("A1:F1")
        .Interior.Color = RGBColor(31, 78, 121)
        .Font.Color = RGBColor(255, 255, 255)
        .Font.Bold = True
        .Font.Size = 14
        .HorizontalAlignment = xlLeft
    End With
    ws.Rows(1).RowHeight = 24

    With ws.Range("A3:F4")
        .Font.Italic = True
        .WrapText = True
    End With

    With ws.Range("H1")
        .Interior.Color = RGBColor(255, 242, 204)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
    End With

    With ws.Range("I1")
        .Interior.Color = RGBColor(255, 242, 204)
        .Font.Italic = True
    End With

    With ws.Range("H2:J2")
        .Interior.Color = RGBColor(226, 239, 218)
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With

    With ws.Range("H3:I4")
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With

    ws.Range("H3").Font.Bold = True
    ws.Range("H4:I4").NumberFormat = "#,##0;[Red]-#,##0"
    ws.Range("H4:I4").Font.Bold = True

    ws.Range("I4").FormatConditions.Delete

    Set fc = ws.Range("I4").FormatConditions.Add(xlCellValue, xlEqual, "0")
    fc.Interior.Color = RGBColor(198, 239, 206)
    fc.Font.Color = RGBColor(0, 97, 0)

    Set fc = ws.Range("I4").FormatConditions.Add(xlCellValue, xlNotEqual, "0")
    fc.Interior.Color = RGBColor(255, 199, 206)
    fc.Font.Color = RGBColor(156, 0, 6)

    ws.Columns("A").ColumnWidth = 15
    ws.Columns("B").ColumnWidth = 15
    ws.Columns("C").ColumnWidth = 13
    ws.Columns("D:F").ColumnWidth = 18
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 12
    ws.Columns("I").ColumnWidth = 14
    ws.Columns("J").ColumnWidth = 48

    ws.Columns("A:B").NumberFormat = "0"
    ws.Columns("C").NumberFormat = "dd.mm.yyyy"
    ws.Columns("D:F").NumberFormat = "#,##0;[Red]-#,##0"
    ws.Columns("H").NumberFormat = "0"

    ws.Range("A1:J" & CStr(maxRow)).WrapText = False
    ws.Range("A3:F4").WrapText = True

    With ws.PageSetup
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftMargin = xlApp.CentimetersToPoints(0.8)
        .RightMargin = xlApp.CentimetersToPoints(0.8)
        .TopMargin = xlApp.CentimetersToPoints(1)
        .BottomMargin = xlApp.CentimetersToPoints(1)
        .PrintArea = "$A$1:$J$" & CStr(maxRow)
    End With
End Sub

Sub FormatSection(ByVal ws, ByVal sectionRow, ByVal headerRow, _
                  ByVal dataStartRow, ByVal dataEndRow, ByVal subtotalRow)
    With ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6))
        .Interior.Color = RGBColor(217, 225, 242)
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With

    With ws.Range(ws.Cells(sectionRow, 8), ws.Cells(sectionRow, 10))
        .Interior.Color = RGBColor(226, 239, 218)
        .Font.Bold = True
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With

    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6))
        .Interior.Color = RGBColor(68, 114, 196)
        .Font.Color = RGBColor(255, 255, 255)
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With
    ws.Rows(headerRow).RowHeight = 34

    With ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 6))
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlThin
    End With

    ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 2)).HorizontalAlignment = xlCenter
    ws.Range(ws.Cells(dataStartRow, 3), ws.Cells(dataEndRow, 3)).HorizontalAlignment = xlCenter
    ws.Range(ws.Cells(dataStartRow, 4), ws.Cells(dataEndRow, 6)).HorizontalAlignment = xlRight

    With ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6))
        .Font.Bold = True
        .Interior.Color = RGBColor(242, 242, 242)
        .Borders(xlEdgeTop).LineStyle = xlDouble
        .Borders(xlEdgeBottom).LineStyle = xlContinuous
        .Borders(xlEdgeLeft).LineStyle = xlContinuous
        .Borders(xlEdgeRight).LineStyle = xlContinuous
    End With
End Sub

Sub ValidateOverviewLayout(ByVal ws)
    If LCase(Trim(SafeString(ws.Cells(2, 1).Value))) <> "pnr neu" Or _
       LCase(Trim(SafeString(ws.Cells(2, 2).Value))) <> "ltrg neu" Or _
       LCase(Trim(SafeString(ws.Cells(2, 3).Value))) <> "pnr alt" Or _
       LCase(Trim(SafeString(ws.Cells(2, 4).Value))) <> "ltrg alt" Then

        Err.Raise -2147221504 + 2030, "ARE Generator", _
                  "Die Spalten A bis D im Blatt '" & SHEET_OVERVIEW & _
                  "' entsprechen nicht dem erwarteten Aufbau."
    End If
End Sub

Function LastTransferRow(ByVal ws)
    Dim lastA
    Dim lastB
    Dim lastC
    Dim lastD

    lastA = ws.Cells(ws.Rows.Count, 1).End(xlUp).Row
    lastB = ws.Cells(ws.Rows.Count, 2).End(xlUp).Row
    lastC = ws.Cells(ws.Rows.Count, 3).End(xlUp).Row
    lastD = ws.Cells(ws.Rows.Count, 4).End(xlUp).Row

    LastTransferRow = MaxLong(MaxLong(lastA, lastB), MaxLong(lastC, lastD))
End Function

Function GetWorksheetOrNothing(ByVal wb, ByVal sheetName)
    Dim ws
    Set ws = Nothing

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    Set GetWorksheetOrNothing = ws
End Function

Sub DeleteGeneratedSheets(ByVal wb)
    Dim i
    Dim sheetName

    For i = wb.Worksheets.Count To 1 Step -1
        sheetName = wb.Worksheets(i).Name
        If Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", 1) > 0 Then
            wb.Worksheets(i).Delete
        End If
    Next
End Sub

Function BuildSheetName(ByVal ltrg, ByVal areValue)
    BuildSheetName = SafeSheetName( _
        "ARE " & DisplayValue(areValue) & _
        " (LTRG " & FormatLtrg(ltrg) & ")" _
    )
End Function

Function UniqueSheetName(ByVal wb, ByVal requestedName)
    Dim baseName
    Dim candidate
    Dim suffix
    Dim counter

    baseName = SafeSheetName(requestedName)
    candidate = baseName
    counter = 2

    Do While WorksheetExists(wb, candidate)
        suffix = "_" & CStr(counter)
        candidate = Left(baseName, 31 - Len(suffix)) & suffix
        counter = counter + 1
    Loop

    UniqueSheetName = candidate
End Function

Function WorksheetExists(ByVal wb, ByVal sheetName)
    Dim ws
    Set ws = Nothing

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    WorksheetExists = Not (ws Is Nothing)
End Function

Function SafeSheetName(ByVal value)
    Dim forbidden
    Dim item

    forbidden = Array("\", "/", ":", "*", "?", "[", "]")

    For Each item In forbidden
        value = Replace(value, CStr(item), "-")
    Next

    value = Trim(value)
    If Len(value) = 0 Then value = "ARE-Auswertung"
    If Len(value) > 31 Then value = Left(value, 31)

    SafeSheetName = value
End Function

Function FormatLtrg(ByVal ltrg)
    Dim value
    value = CStr(ltrg)
    If Len(value) < 4 Then value = Right("0000" & value, 4)
    FormatLtrg = value
End Function

Function ShortCompanyName(ByVal fullName)
    Dim commaPosition

    fullName = Trim(fullName)
    commaPosition = InStr(1, fullName, ",", 1)

    If commaPosition > 0 Then
        ShortCompanyName = Trim(Left(fullName, commaPosition - 1))
    Else
        ShortCompanyName = fullName
    End If
End Function

Function DisplayValue(ByVal value)
    If IsNull(value) Or IsEmpty(value) Or IsVariantError(value) Then
        DisplayValue = "n.v."
    ElseIf Len(Trim(CStr(value))) = 0 Then
        DisplayValue = "n.v."
    Else
        DisplayValue = Trim(CStr(value))
    End If
End Function

Function SafeString(ByVal value)
    If IsNull(value) Or IsEmpty(value) Or IsVariantError(value) Then
        SafeString = ""
    Else
        SafeString = CStr(value)
    End If
End Function

Function IsVariantError(ByVal value)
    IsVariantError = (VarType(value) = VB_ERROR_TYPE)
End Function

Function NzNumber(ByVal value)
    If IsNull(value) Or IsEmpty(value) Or IsVariantError(value) Then
        NzNumber = 0
    ElseIf Len(Trim(CStr(value))) = 0 Then
        NzNumber = 0
    ElseIf IsNumeric(value) Then
        NzNumber = CDbl(value)
    Else
        NzNumber = 0
    End If
End Function

Function TryGetLong(ByVal value, ByRef result)
    TryGetLong = False

    If IsNull(value) Or IsEmpty(value) Or IsVariantError(value) Then Exit Function
    If Len(Trim(CStr(value))) = 0 Then Exit Function
    If Not IsNumeric(value) Then Exit Function

    result = CLng(value)
    TryGetLong = True
End Function

Function RGBColor(ByVal redValue, ByVal greenValue, ByVal blueValue)
    RGBColor = CLng(redValue) + CLng(greenValue) * 256 + CLng(blueValue) * 65536
End Function

Function MaxLong(ByVal firstValue, ByVal secondValue)
    If CLng(firstValue) >= CLng(secondValue) Then
        MaxLong = CLng(firstValue)
    Else
        MaxLong = CLng(secondValue)
    End If
End Function

Function BuildOutputPath(ByVal fso, ByVal sourcePath)
    Dim folder
    Dim baseName
    Dim extension
    Dim candidate
    Dim stamp

    folder = fso.GetParentFolderName(sourcePath)
    baseName = fso.GetBaseName(sourcePath)
    extension = LCase(fso.GetExtensionName(sourcePath))

    candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung." & extension)

    If fso.FileExists(candidate) Then
        stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
                "_" & TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & TwoDigits(Second(Now))
        candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung_" & stamp & "." & extension)
    End If

    BuildOutputPath = candidate
End Function

Function TwoDigits(ByVal value)
    TwoDigits = Right("0" & CStr(value), 2)
End Function
