# Changelog

## 1.0.2 – 2026-07-29

- Fehler 500 `Variable is undefined` in der VBS-Ausführung behoben.
- Die VBA-spezifische Funktion `IsError(...)` wurde durch die VBScript-kompatible Prüfung `VarType(...)=10` ersetzt.
- Fehlermeldungen nennen jetzt zusätzlich die Verarbeitungsphase und die Fehlerquelle.
- Der Starter wurde statisch auf nicht deklarierte Variablen und verbleibende `IsError`-Aufrufe geprüft.

## 1.0.1 – 2026-07-29

- Dateiauswahl unterstützt jetzt `.xlsm` und `.xlsx`.
- Die Ausgabedatei behält automatisch das Format der Quelldatei bei.
- Fehlermeldungen und Dokumentation wurden entsprechend angepasst.

## 1.0.0

- Erste Projektversion mit VBS-Ausführung, VBA-Modul und Dokumentation.
