Presence Toolbox v0.3 - Busy Prototype
=======================================

Start:
  Presence Toolbox.VBS doppelklicken.

Modi:
  Normal
    Keine Aktivitätssimulation. Wenn Busy zuvor aktiv war, sendet die Toolbox
    den offiziellen Teams-Befehl /reset.

  Available
    Führt alle 60 Sekunden einen doppelten Scroll-Lock-Tap aus.

  Busy (experimental)
    Aktiviert das Teams-Fenster kurz und sendet über das Teams-Suchfeld:
      Ctrl+E
      /busy
      Enter

    Danach wird das vorherige Fenster wieder aktiviert. Die Toolbox kann den
    sichtbaren Teams-Status ohne Graph-Berechtigungen nicht unabhängig auslesen.
    Kontrolliere deshalb beim ersten Test dein Profilbild in Teams.

Dauer:
  Unlimited, 30 minutes, 1 hour, 2 hours, Until end of day.
  Nach Ablauf wechselt die Toolbox zu Normal. Bei Busy wird /reset gesendet.

Testablauf:
  1. Teams Desktop öffnen und vollständig anmelden.
  2. Presence Toolbox starten.
  3. Duration -> 30 minutes auswählen.
  4. Mode -> Busy (experimental) auswählen.
  5. Prüfen, ob Teams kurz in den Vordergrund kommt.
  6. Im Terminal nach "Teams-Befehl gesendet: /busy" suchen.
  7. In Teams prüfen, ob der Profilstatus rot/Beschäftigt ist.
  8. Mode -> Normal auswählen und prüfen, ob /reset ausgeführt wird.

Hinweise:
  - Der Prototyp unterstützt die Teams-Desktop-App, nicht sicher die Web-App.
  - Unternehmensrichtlinien können Slash-Befehle deaktivieren.
  - Beim Schließen über das Tray-Menü Exit wird ein aktiver Busy-Status mit
    /reset zurückgesetzt. Beim harten Schließen des Terminalfensters kann
    Windows den Prozess beenden, bevor /reset gesendet werden kann.
  - DND und In a Meeting bleiben in dieser Version deaktiviert.

Eigenes Tray-Icon:
  assets\icons\Tray_Icon.ico
