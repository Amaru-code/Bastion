# ============================================================================
# Presence Toolbox v0.3
# ============================================================================
# Prototype modes:
#   - Normal: Teams and Windows behave normally.
#   - Available: Sends a double Scroll Lock tap every 60 seconds.
#   - Busy: Sends the official Teams slash command /busy.
#
# The PowerShell terminal stays visible. Closing it ends the whole program.
# ============================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

try {
    $Host.UI.RawUI.WindowTitle = "Presence Toolbox v0.3 - Runtime Log"
} catch {
    # RawUI is not available in every host.
}

try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
} catch {
    # Ignore hosts without a normal console.
}

Clear-Host
Write-Host ""
Write-Host "============================================================"
Write-Host " Presence Toolbox v0.3"
Write-Host "============================================================"
Write-Host ""
Write-Host "Das Programm läuft, solange dieses Terminal geöffnet ist."
Write-Host "Schließe dieses Fenster, um das Programm zu beenden."
Write-Host ""

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class PresenceKeyboard
{
    [DllImport("user32.dll")]
    public static extern void keybd_event(
        byte bVk,
        byte bScan,
        uint dwFlags,
        UIntPtr dwExtraInfo
    );
}

public static class PresenceNativeIcon
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool DestroyIcon(IntPtr hIcon);
}

public static class PresenceWindow
{
    [DllImport("user32.dll")]
    public static extern IntPtr GetForegroundWindow();

    [DllImport("user32.dll")]
    public static extern bool SetForegroundWindow(IntPtr hWnd);

    [DllImport("user32.dll")]
    public static extern bool IsWindow(IntPtr hWnd);
}
"@

# ----------------------------------------------------------------------------
# Application state
# ----------------------------------------------------------------------------

$script:AppName = "Presence Toolbox"
$script:Version = "0.3"
$script:TapIntervalSeconds = 60
$script:LogRetentionDays = 5

$script:CurrentMode = "Normal"
$script:SelectedDuration = "Unlimited"
$script:ModeEndsAt = $null
$script:NextTapAt = $null
$script:LastTapAt = $null
$script:TapCount = 0
$script:LastTeamsCommand = $null
$script:LastTeamsCommandAt = $null
$script:IsShuttingDown = $false

$script:ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$script:LogDirectory = Join-Path $script:ProjectRoot "Logs"

$script:Mutex = $null
$script:NotifyIcon = $null
$script:Timer = $null
$script:Menu = $null
$script:BaseIcon = $null
$script:NormalIcon = $null
$script:AvailableIcon = $null
$script:BusyIcon = $null

$script:StatusItem = $null
$script:RemainingItem = $null
$script:LastTapItem = $null
$script:LastTeamsCommandItem = $null
$script:ModeMenu = $null
$script:NormalModeItem = $null
$script:AvailableModeItem = $null
$script:BusyModeItem = $null
$script:DndModeItem = $null
$script:MeetingModeItem = $null
$script:DurationMenu = $null
$script:UnlimitedDurationItem = $null
$script:ThirtyMinuteDurationItem = $null
$script:OneHourDurationItem = $null
$script:TwoHourDurationItem = $null
$script:EndOfDayDurationItem = $null
$script:RunOnceItem = $null
$script:RestartItem = $null
$script:ExitItem = $null

# ----------------------------------------------------------------------------
# Logging
# ----------------------------------------------------------------------------

function Initialize-LogDirectory {
    if (-not (Test-Path -LiteralPath $script:LogDirectory -PathType Container)) {
        New-Item -ItemType Directory -Path $script:LogDirectory -Force | Out-Null
    }
}

function Remove-OldLogFiles {
    try {
        if (-not (Test-Path -LiteralPath $script:LogDirectory -PathType Container)) {
            return
        }

        $cutoff = (Get-Date).AddDays(-[double]$script:LogRetentionDays)
        Get-ChildItem -LiteralPath $script:LogDirectory -Filter "*.log" -File -ErrorAction Stop |
            Where-Object { $_.LastWriteTime -lt $cutoff } |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch {
        # Log cleanup must never stop the application.
    }
}

function Write-AppLog {
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Message,

        [ValidateSet("INFO", "SUCCESS", "WARNING", "ERROR")]
        [string]$Level = "INFO"
    )

    $now = Get-Date
    $line = "[{0}] [{1}] {2}" -f $now.ToString("yyyy-MM-dd HH:mm:ss"), $Level, $Message

    try {
        switch ($Level) {
            "SUCCESS" { Write-Host $line -ForegroundColor DarkGreen }
            "WARNING" { Write-Host $line -ForegroundColor DarkYellow }
            "ERROR"   { Write-Host $line -ForegroundColor Red }
            default   { Write-Host $line -ForegroundColor Gray }
        }
    } catch {
        # Terminal output is optional.
    }

    try {
        Initialize-LogDirectory
        Remove-OldLogFiles

        $logName = "Presence-Toolbox-{0}.log" -f $now.ToString("yyyy-MM-dd")
        $logPath = Join-Path $script:LogDirectory $logName
        Add-Content -LiteralPath $logPath -Value $line -Encoding UTF8
    } catch {
        try {
            Write-Host ("Logdatei konnte nicht geschrieben werden: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
        } catch {
            # No further fallback is available.
        }
    }
}

# ----------------------------------------------------------------------------
# Single instance
# ----------------------------------------------------------------------------

$createdNew = $false
$mutexName = "Local\PresenceToolbox-v03"
$script:Mutex = New-Object System.Threading.Mutex($true, $mutexName, [ref]$createdNew)

if (-not $createdNew) {
    Write-AppLog -Message "Eine andere Instanz läuft bereits. Diese Instanz wird beendet." -Level "WARNING"
    Start-Sleep -Seconds 2
    return
}

# ----------------------------------------------------------------------------
# Duration handling
# ----------------------------------------------------------------------------

function Get-DurationLabel {
    param(
        [Parameter(Mandatory = $true)]
        [string]$DurationKey
    )

    switch ($DurationKey) {
        "30m"      { return "30 Minuten" }
        "1h"       { return "1 Stunde" }
        "2h"       { return "2 Stunden" }
        "EndOfDay" { return "bis Tagesende" }
        default    { return "unbegrenzt" }
    }
}

function Get-ModeEndAt {
    param(
        [Parameter(Mandatory = $true)]
        [string]$DurationKey
    )

    $now = Get-Date

    switch ($DurationKey) {
        "30m"      { return $now.AddMinutes(30) }
        "1h"       { return $now.AddHours(1) }
        "2h"       { return $now.AddHours(2) }
        "EndOfDay" { return $now.Date.AddDays(1) }
        default    { return $null }
    }
}

function Set-SelectedDuration {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Unlimited", "30m", "1h", "2h", "EndOfDay")]
        [string]$DurationKey
    )

    $script:SelectedDuration = $DurationKey

    if ($script:CurrentMode -in @("Available", "Busy")) {
        $script:ModeEndsAt = Get-ModeEndAt -DurationKey $DurationKey
        Write-AppLog -Message ("Dauer geändert: {0}. Sie gilt sofort für {1}." -f (Get-DurationLabel -DurationKey $DurationKey), $script:CurrentMode)
    } else {
        Write-AppLog -Message ("Dauer geändert: {0}. Sie gilt beim nächsten Moduswechsel." -f (Get-DurationLabel -DurationKey $DurationKey))
    }

    Update-Tray
}

# ----------------------------------------------------------------------------
# Icons
# ----------------------------------------------------------------------------

function Get-BaseIcon {
    $iconPath = Join-Path $script:ProjectRoot "assets\icons\Tray_Icon.ico"

    if (Test-Path -LiteralPath $iconPath -PathType Leaf) {
        try {
            return New-Object System.Drawing.Icon($iconPath)
        } catch {
            Write-AppLog -Message ("Tray-Icon konnte nicht geladen werden: {0}" -f $_.Exception.Message) -Level "WARNING"
        }
    }

    return [System.Drawing.SystemIcons]::Application
}

function New-StatusIcon {
    param(
        [Parameter(Mandatory = $true)]
        [System.Drawing.Icon]$BaseIcon,

        [Parameter(Mandatory = $true)]
        [System.Drawing.Color]$StatusColor
    )

    $bitmap = New-Object System.Drawing.Bitmap -ArgumentList 32, 32
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)

    try {
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $graphics.Clear([System.Drawing.Color]::Transparent)

        $rectangle = New-Object System.Drawing.Rectangle -ArgumentList 0, 0, 32, 32
        $graphics.DrawIcon($BaseIcon, $rectangle)

        $outlineBrush = New-Object System.Drawing.SolidBrush -ArgumentList ([System.Drawing.Color]::White)
        $statusBrush = New-Object System.Drawing.SolidBrush -ArgumentList $StatusColor

        try {
            $graphics.FillEllipse($outlineBrush, 18, 18, 13, 13)
            $graphics.FillEllipse($statusBrush, 20, 20, 9, 9)
        } finally {
            $outlineBrush.Dispose()
            $statusBrush.Dispose()
        }

        $handle = [IntPtr]::Zero

        try {
            $handle = $bitmap.GetHicon()
            $temporaryIcon = [System.Drawing.Icon]::FromHandle($handle)
            return $temporaryIcon.Clone()
        } finally {
            if ($handle -ne [IntPtr]::Zero) {
                [PresenceNativeIcon]::DestroyIcon($handle) | Out-Null
            }
        }
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

# ----------------------------------------------------------------------------
# Teams desktop automation
# ----------------------------------------------------------------------------

function Get-TeamsMainProcess {
    $candidateNames = @("ms-teams", "Teams", "MSTeams")

    foreach ($name in $candidateNames) {
        $process = Get-Process -Name $name -ErrorAction SilentlyContinue |
            Where-Object { $_.MainWindowHandle -ne 0 } |
            Sort-Object StartTime |
            Select-Object -Last 1

        if ($null -ne $process) {
            return $process
        }
    }

    return $null
}

function Start-TeamsAndWait {
    $teamsProcess = Get-TeamsMainProcess
    if ($null -ne $teamsProcess) {
        return $teamsProcess
    }

    Write-AppLog -Message "Teams-Fenster wurde nicht gefunden. Teams wird über msteams: geöffnet."

    try {
        Start-Process -FilePath "msteams:" | Out-Null
    } catch {
        throw "Teams konnte nicht über msteams: gestartet werden: $($_.Exception.Message)"
    }

    $deadline = (Get-Date).AddSeconds(20)
    do {
        Start-Sleep -Milliseconds 500
        $teamsProcess = Get-TeamsMainProcess
        if ($null -ne $teamsProcess) {
            return $teamsProcess
        }
    } while ((Get-Date) -lt $deadline)

    throw "Teams wurde gestartet, aber innerhalb von 20 Sekunden wurde kein bedienbares Teams-Fenster gefunden."
}

function Invoke-TeamsSlashCommand {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("/busy", "/available", "/reset")]
        [string]$Command
    )

    $previousWindow = [PresenceWindow]::GetForegroundWindow()
    $teamsProcess = Start-TeamsAndWait
    $shell = New-Object -ComObject WScript.Shell

    try {
        $activated = $shell.AppActivate([int]$teamsProcess.Id)
        if (-not $activated) {
            $activated = [PresenceWindow]::SetForegroundWindow($teamsProcess.MainWindowHandle)
        }

        if (-not $activated) {
            throw "Das Teams-Fenster konnte nicht in den Vordergrund gebracht werden."
        }

        Start-Sleep -Milliseconds 700

        # Official Teams desktop shortcut: Ctrl+E focuses the search box.
        [System.Windows.Forms.SendKeys]::SendWait("^e")
        Start-Sleep -Milliseconds 350
        [System.Windows.Forms.SendKeys]::SendWait("^a")
        Start-Sleep -Milliseconds 100
        [System.Windows.Forms.SendKeys]::SendWait($Command)
        Start-Sleep -Milliseconds 250
        [System.Windows.Forms.SendKeys]::SendWait("{ENTER}")
        Start-Sleep -Milliseconds 900

        $script:LastTeamsCommand = $Command
        $script:LastTeamsCommandAt = Get-Date

        Write-AppLog -Message ("Teams-Befehl gesendet: {0}. Bitte den sichtbaren Teams-Status beim ersten Test kontrollieren." -f $Command) -Level "SUCCESS"
        return $true
    } catch {
        Write-AppLog -Message ("Teams-Befehl {0} fehlgeschlagen: {1}" -f $Command, $_.Exception.Message) -Level "ERROR"
        return $false
    } finally {
        try {
            if ($previousWindow -ne [IntPtr]::Zero -and [PresenceWindow]::IsWindow($previousWindow)) {
                [PresenceWindow]::SetForegroundWindow($previousWindow) | Out-Null
            }
        } catch {
            # Restoring the previous window is optional.
        }
    }
}

# ----------------------------------------------------------------------------
# Presence tap
# ----------------------------------------------------------------------------

function Invoke-PresenceTap {
    param(
        [string]$Reason = "timer"
    )

    try {
        $scrollLockKey = [byte]0x91
        $keyUpFlag = [uint32]0x0002

        [PresenceKeyboard]::keybd_event($scrollLockKey, 0, 0, [UIntPtr]::Zero)
        [PresenceKeyboard]::keybd_event($scrollLockKey, 0, $keyUpFlag, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 60
        [PresenceKeyboard]::keybd_event($scrollLockKey, 0, 0, [UIntPtr]::Zero)
        [PresenceKeyboard]::keybd_event($scrollLockKey, 0, $keyUpFlag, [UIntPtr]::Zero)

        $script:TapCount++
        $script:LastTapAt = Get-Date
        $script:NextTapAt = $script:LastTapAt.AddSeconds($script:TapIntervalSeconds)

        Write-AppLog -Message ("Presence tap abgeschlossen. Grund={0}; Anzahl={1}; Nächster Lauf={2}" -f $Reason, $script:TapCount, $script:NextTapAt.ToString("HH:mm:ss")) -Level "SUCCESS"
    } catch {
        Write-AppLog -Message ("Presence tap fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

# ----------------------------------------------------------------------------
# Modes
# ----------------------------------------------------------------------------

function Set-PresenceMode {
    param(
        [Parameter(Mandatory = $true)]
        [ValidateSet("Normal", "Available", "Busy")]
        [string]$Mode,

        [string]$Reason = "menu"
    )

    $previousMode = $script:CurrentMode

    if ($Mode -eq $previousMode -and $Reason -ne "startup") {
        Write-AppLog -Message ("Modus {0} ist bereits aktiv." -f $Mode)
        return
    }

    if ($Mode -eq "Busy") {
        $commandSucceeded = Invoke-TeamsSlashCommand -Command "/busy"
        if (-not $commandSucceeded) {
            Write-AppLog -Message "Busy wurde nicht aktiviert, weil der Teams-Befehl nicht erfolgreich gesendet werden konnte." -Level "ERROR"
            Update-Tray
            return
        }

        $script:CurrentMode = "Busy"
        $script:ModeEndsAt = Get-ModeEndAt -DurationKey $script:SelectedDuration
        $script:NextTapAt = $null

        $endText = if ($null -eq $script:ModeEndsAt) {
            "unbegrenzt"
        } else {
            $script:ModeEndsAt.ToString("dd.MM.yyyy HH:mm:ss")
        }

        Write-AppLog -Message ("Modus geändert: {0} -> Busy; Dauer={1}; Ende={2}; Grund={3}" -f $previousMode, (Get-DurationLabel -DurationKey $script:SelectedDuration), $endText, $Reason) -Level "SUCCESS"
        Update-Tray
        return
    }

    if ($Mode -eq "Available") {
        if ($previousMode -eq "Busy") {
            $null = Invoke-TeamsSlashCommand -Command "/available"
        }

        $script:CurrentMode = "Available"
        $script:ModeEndsAt = Get-ModeEndAt -DurationKey $script:SelectedDuration
        $script:NextTapAt = (Get-Date).AddSeconds($script:TapIntervalSeconds)

        $endText = if ($null -eq $script:ModeEndsAt) {
            "unbegrenzt"
        } else {
            $script:ModeEndsAt.ToString("dd.MM.yyyy HH:mm:ss")
        }

        Write-AppLog -Message ("Modus geändert: {0} -> Available; Dauer={1}; Ende={2}; Grund={3}" -f $previousMode, (Get-DurationLabel -DurationKey $script:SelectedDuration), $endText, $Reason) -Level "SUCCESS"
        Update-Tray
        return
    }

    # Normal mode
    if ($previousMode -eq "Busy") {
        $resetSucceeded = Invoke-TeamsSlashCommand -Command "/reset"
        if (-not $resetSucceeded) {
            Write-AppLog -Message "Normal wurde lokal ausgewählt, aber Teams konnte nicht mit /reset zurückgesetzt werden." -Level "WARNING"
        }
    }

    $script:CurrentMode = "Normal"
    $script:ModeEndsAt = $null
    $script:NextTapAt = $null
    Write-AppLog -Message ("Modus geändert: {0} -> Normal; Grund={1}" -f $previousMode, $Reason)
    Update-Tray
}

# ----------------------------------------------------------------------------
# Tray display
# ----------------------------------------------------------------------------

function Format-RemainingTime {
    param(
        [Parameter(Mandatory = $true)]
        [TimeSpan]$Remaining
    )

    if ($Remaining.TotalSeconds -le 0) {
        return "0s"
    }

    if ($Remaining.TotalHours -ge 1) {
        return "{0}h {1}m {2}s" -f [int]$Remaining.TotalHours, $Remaining.Minutes, $Remaining.Seconds
    }

    if ($Remaining.TotalMinutes -ge 1) {
        return "{0}m {1}s" -f [int]$Remaining.TotalMinutes, $Remaining.Seconds
    }

    return "{0}s" -f [int][Math]::Ceiling($Remaining.TotalSeconds)
}

function Update-Tray {
    if ($null -eq $script:NotifyIcon) {
        return
    }

    switch ($script:CurrentMode) {
        "Available" {
            $script:NotifyIcon.Icon = $script:AvailableIcon
            $script:NotifyIcon.Text = "Presence Toolbox - Available"
            $script:StatusItem.Text = "Status: Available"
        }
        "Busy" {
            $script:NotifyIcon.Icon = $script:BusyIcon
            $script:NotifyIcon.Text = "Presence Toolbox - Busy"
            $script:StatusItem.Text = "Status: Busy"
        }
        default {
            $script:NotifyIcon.Icon = $script:NormalIcon
            $script:NotifyIcon.Text = "Presence Toolbox - Normal"
            $script:StatusItem.Text = "Status: Normal"
        }
    }

    if ($script:CurrentMode -in @("Available", "Busy")) {
        if ($null -ne $script:ModeEndsAt) {
            $script:RemainingItem.Text = "Remaining: {0}" -f (Format-RemainingTime -Remaining ($script:ModeEndsAt - (Get-Date)))
        } else {
            $script:RemainingItem.Text = "Remaining: unlimited"
        }
    } else {
        $script:RemainingItem.Text = "Remaining: inactive"
    }

    if ($null -ne $script:LastTapAt) {
        $script:LastTapItem.Text = "Last tap: {0}" -f $script:LastTapAt.ToString("HH:mm:ss")
    } else {
        $script:LastTapItem.Text = "Last tap: never"
    }

    if ($null -ne $script:LastTeamsCommandAt) {
        $script:LastTeamsCommandItem.Text = "Teams command: {0} at {1}" -f $script:LastTeamsCommand, $script:LastTeamsCommandAt.ToString("HH:mm:ss")
    } else {
        $script:LastTeamsCommandItem.Text = "Teams command: none"
    }

    $script:NormalModeItem.Checked = ($script:CurrentMode -eq "Normal")
    $script:AvailableModeItem.Checked = ($script:CurrentMode -eq "Available")
    $script:BusyModeItem.Checked = ($script:CurrentMode -eq "Busy")

    $script:UnlimitedDurationItem.Checked = ($script:SelectedDuration -eq "Unlimited")
    $script:ThirtyMinuteDurationItem.Checked = ($script:SelectedDuration -eq "30m")
    $script:OneHourDurationItem.Checked = ($script:SelectedDuration -eq "1h")
    $script:TwoHourDurationItem.Checked = ($script:SelectedDuration -eq "2h")
    $script:EndOfDayDurationItem.Checked = ($script:SelectedDuration -eq "EndOfDay")

    $script:DurationMenu.Text = "Duration: {0}" -f (Get-DurationLabel -DurationKey $script:SelectedDuration)
    $script:RunOnceItem.Enabled = ($script:CurrentMode -eq "Available")
}

# ----------------------------------------------------------------------------
# Exit and restart
# ----------------------------------------------------------------------------

function Release-AppMutex {
    if ($null -eq $script:Mutex) {
        return
    }

    try {
        $script:Mutex.ReleaseMutex()
    } catch {
        # It may already have been released.
    }

    try {
        $script:Mutex.Dispose()
    } catch {
        # Ignore disposal errors.
    }

    $script:Mutex = $null
}

function Exit-App {
    if ($script:IsShuttingDown) {
        return
    }

    $script:IsShuttingDown = $true

    if ($script:CurrentMode -eq "Busy") {
        Write-AppLog -Message "Busy ist aktiv. Vor dem regulären Beenden wird Teams mit /reset zurückgesetzt."
        $null = Invoke-TeamsSlashCommand -Command "/reset"
    }

    Write-AppLog -Message "Presence Toolbox wird beendet."
    [System.Windows.Forms.Application]::Exit()
}

function Restart-App {
    try {
        $launcherPath = Join-Path $script:ProjectRoot "Presence Toolbox.VBS"

        if (-not (Test-Path -LiteralPath $launcherPath -PathType Leaf)) {
            Write-AppLog -Message ("Neustart fehlgeschlagen. Launcher fehlt: {0}" -f $launcherPath) -Level "ERROR"
            return
        }

        if ($script:CurrentMode -eq "Busy") {
            $null = Invoke-TeamsSlashCommand -Command "/reset"
        }

        Write-AppLog -Message "Neustart wurde angefordert."
        Release-AppMutex
        Start-Process -FilePath "wscript.exe" -ArgumentList ('"{0}"' -f $launcherPath) -WorkingDirectory $script:ProjectRoot | Out-Null
        [System.Windows.Forms.Application]::Exit()
    } catch {
        Write-AppLog -Message ("Neustart fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

# ----------------------------------------------------------------------------
# Build tray interface
# ----------------------------------------------------------------------------

$script:BaseIcon = Get-BaseIcon
$script:NormalIcon = New-StatusIcon -BaseIcon $script:BaseIcon -StatusColor ([System.Drawing.Color]::FromArgb(120, 120, 120))
$script:AvailableIcon = New-StatusIcon -BaseIcon $script:BaseIcon -StatusColor ([System.Drawing.Color]::FromArgb(46, 125, 78))
$script:BusyIcon = New-StatusIcon -BaseIcon $script:BaseIcon -StatusColor ([System.Drawing.Color]::FromArgb(196, 43, 28))

$script:NotifyIcon = New-Object System.Windows.Forms.NotifyIcon
$script:NotifyIcon.Icon = $script:NormalIcon
$script:NotifyIcon.Text = $script:AppName
$script:NotifyIcon.Visible = $true

$script:Menu = New-Object System.Windows.Forms.ContextMenuStrip
$script:Menu.ShowImageMargin = $false

$script:StatusItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Status: Normal"
$script:StatusItem.Enabled = $false
$script:RemainingItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Remaining: inactive"
$script:RemainingItem.Enabled = $false
$script:LastTapItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Last tap: never"
$script:LastTapItem.Enabled = $false
$script:LastTeamsCommandItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Teams command: none"
$script:LastTeamsCommandItem.Enabled = $false

$script:ModeMenu = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Mode"
$script:NormalModeItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Normal"
$script:AvailableModeItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Available"
$script:BusyModeItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Busy (experimental)"
$script:DndModeItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Do Not Disturb (planned)"
$script:MeetingModeItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "In a Meeting (planned)"
$script:DndModeItem.Enabled = $false
$script:MeetingModeItem.Enabled = $false

$script:DurationMenu = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Duration: unlimited"
$script:UnlimitedDurationItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Unlimited"
$script:ThirtyMinuteDurationItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "30 minutes"
$script:OneHourDurationItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "1 hour"
$script:TwoHourDurationItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "2 hours"
$script:EndOfDayDurationItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Until end of day"

$script:RunOnceItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Run Available Tap Now"
$script:RestartItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Restart"
$script:ExitItem = New-Object System.Windows.Forms.ToolStripMenuItem -ArgumentList "Exit"

$script:NormalModeItem.Add_Click({
    try {
        Set-PresenceMode -Mode "Normal" -Reason "menu"
    } catch {
        Write-AppLog -Message ("Moduswechsel auf Normal fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
})

$script:AvailableModeItem.Add_Click({
    try {
        Set-PresenceMode -Mode "Available" -Reason "menu"
    } catch {
        Write-AppLog -Message ("Moduswechsel auf Available fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
})

$script:BusyModeItem.Add_Click({
    try {
        Set-PresenceMode -Mode "Busy" -Reason "menu"
    } catch {
        Write-AppLog -Message ("Moduswechsel auf Busy fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
})

$script:UnlimitedDurationItem.Add_Click({ Set-SelectedDuration -DurationKey "Unlimited" })
$script:ThirtyMinuteDurationItem.Add_Click({ Set-SelectedDuration -DurationKey "30m" })
$script:OneHourDurationItem.Add_Click({ Set-SelectedDuration -DurationKey "1h" })
$script:TwoHourDurationItem.Add_Click({ Set-SelectedDuration -DurationKey "2h" })
$script:EndOfDayDurationItem.Add_Click({ Set-SelectedDuration -DurationKey "EndOfDay" })

$script:RunOnceItem.Add_Click({
    try {
        Invoke-PresenceTap -Reason "manual"
        Update-Tray
    } catch {
        Write-AppLog -Message ("Manueller Lauf fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
})

$script:RestartItem.Add_Click({ Restart-App })
$script:ExitItem.Add_Click({ Exit-App })

$separatorMode = New-Object System.Windows.Forms.ToolStripSeparator
$separatorMain1 = New-Object System.Windows.Forms.ToolStripSeparator
$separatorMain2 = New-Object System.Windows.Forms.ToolStripSeparator

[void]$script:ModeMenu.DropDownItems.Add($script:NormalModeItem)
[void]$script:ModeMenu.DropDownItems.Add($script:AvailableModeItem)
[void]$script:ModeMenu.DropDownItems.Add($script:BusyModeItem)
[void]$script:ModeMenu.DropDownItems.Add($separatorMode)
[void]$script:ModeMenu.DropDownItems.Add($script:DndModeItem)
[void]$script:ModeMenu.DropDownItems.Add($script:MeetingModeItem)

[void]$script:DurationMenu.DropDownItems.Add($script:UnlimitedDurationItem)
[void]$script:DurationMenu.DropDownItems.Add($script:ThirtyMinuteDurationItem)
[void]$script:DurationMenu.DropDownItems.Add($script:OneHourDurationItem)
[void]$script:DurationMenu.DropDownItems.Add($script:TwoHourDurationItem)
[void]$script:DurationMenu.DropDownItems.Add($script:EndOfDayDurationItem)

[void]$script:Menu.Items.Add($script:StatusItem)
[void]$script:Menu.Items.Add($script:RemainingItem)
[void]$script:Menu.Items.Add($script:LastTapItem)
[void]$script:Menu.Items.Add($script:LastTeamsCommandItem)
[void]$script:Menu.Items.Add($separatorMain1)
[void]$script:Menu.Items.Add($script:ModeMenu)
[void]$script:Menu.Items.Add($script:DurationMenu)
[void]$script:Menu.Items.Add($script:RunOnceItem)
[void]$script:Menu.Items.Add($separatorMain2)
[void]$script:Menu.Items.Add($script:RestartItem)
[void]$script:Menu.Items.Add($script:ExitItem)

$script:NotifyIcon.ContextMenuStrip = $script:Menu

# ----------------------------------------------------------------------------
# Timer
# ----------------------------------------------------------------------------

$script:Timer = New-Object System.Windows.Forms.Timer
$script:Timer.Interval = 1000
$script:Timer.Add_Tick({
    try {
        if ($script:IsShuttingDown) {
            return
        }

        $now = Get-Date

        if ($script:CurrentMode -in @("Available", "Busy")) {
            if ($null -ne $script:ModeEndsAt -and $now -ge $script:ModeEndsAt) {
                Write-AppLog -Message ("Zeit für Modus {0} ist abgelaufen. Rückkehr zu Normal." -f $script:CurrentMode)
                Set-PresenceMode -Mode "Normal" -Reason "duration-expired"
                return
            }
        }

        if ($script:CurrentMode -eq "Available") {
            if ($null -ne $script:NextTapAt -and $now -ge $script:NextTapAt) {
                Invoke-PresenceTap -Reason "timer"
            }
        }

        Update-Tray
    } catch {
        Write-AppLog -Message ("Timerfehler: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
})
$script:Timer.Start()

# ----------------------------------------------------------------------------
# Cleanup
# ----------------------------------------------------------------------------

[System.Windows.Forms.Application]::Add_ApplicationExit({
    try {
        if ($null -ne $script:Timer) {
            $script:Timer.Stop()
            $script:Timer.Dispose()
        }

        if ($null -ne $script:NotifyIcon) {
            $script:NotifyIcon.Visible = $false
            $script:NotifyIcon.Dispose()
        }

        if ($null -ne $script:NormalIcon) {
            $script:NormalIcon.Dispose()
        }

        if ($null -ne $script:AvailableIcon) {
            $script:AvailableIcon.Dispose()
        }

        if ($null -ne $script:BusyIcon) {
            $script:BusyIcon.Dispose()
        }

        if ($null -ne $script:BaseIcon) {
            $script:BaseIcon.Dispose()
        }

        Release-AppMutex
    } catch {
        # Cleanup errors must not open another dialog.
    }
})

# ----------------------------------------------------------------------------
# Start
# ----------------------------------------------------------------------------

try {
    Write-AppLog -Message ("Presence Toolbox v{0} gestartet. Intervall={1}s; Startmodus=Normal" -f $script:Version, $script:TapIntervalSeconds) -Level "SUCCESS"
    Write-AppLog -Message "Verfügbar: Normal, Available, Busy und zeitgesteuerte Rückkehr zu Normal."
    Write-AppLog -Message "Busy verwendet Teams Desktop: Ctrl+E, /busy, Enter. Das Teams-Fenster kann dabei kurz sichtbar werden."

    Set-PresenceMode -Mode "Normal" -Reason "startup"
    Update-Tray
    [System.Windows.Forms.Application]::Run()
} catch {
    Write-AppLog -Message ("Unerwarteter Programmfehler: {0}" -f $_.Exception.Message) -Level "ERROR"
    Write-Host ""
    Read-Host "Drücke Enter zum Schließen"
} finally {
    try {
        if ($null -ne $script:NotifyIcon) {
            $script:NotifyIcon.Visible = $false
        }
    } catch {
        # Ignore final cleanup failures.
    }
}
