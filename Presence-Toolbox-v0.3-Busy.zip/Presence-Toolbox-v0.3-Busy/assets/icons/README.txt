Optional: Lege dein bisheriges Tray-Icon als Tray_Icon.ico in diesen Ordner.
