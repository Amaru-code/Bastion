# Stage 1.3
- Auswahlfehler durch DOM-Neurendering behoben (Pointer-Down).
- Hover-Vibration beseitigt.
- Temporäre gestrichelte Marschrouten für Spieler und KI ergänzt.

# Changelog

Bastion Stage 1 – Arbeitsdokument 24. Dieses Dokument dient als modulare Grundlage für spätere Entwicklungsstufen.

## Stage 1.2
- Auswahl lässt sich per erneutem Klick, leerer Karte, Rechtsklick, Escape oder Abbrechen lösen.
- Feste Routen entfernt; Armeen bewegen sich frei und umgehen Gebäude automatisch.
- Feldarmeen können ausgewählt und erneut bewegt werden.
- Globale Versorgungsgrenze verhindert unbegrenzte Soldatenproduktion; Farmen erhöhen das Limit.
- KI bewirtschaftet alle Gebäudetypen, verbessert Gebäude, forscht und greift nach der Expansion aktiv an.
- Jahreszeiteneffekte sind als Multiplikatoren, Produktionsraten, Kartenfärbung und Wechselbanner sichtbar.
