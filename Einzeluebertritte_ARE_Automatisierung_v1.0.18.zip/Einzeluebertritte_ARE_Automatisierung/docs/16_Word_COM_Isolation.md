# Word-COM-Isolation – Version 1.0.17

Der Fehler `-2147417848` entsteht, wenn ein COM-Objekt technisch noch referenziert wird, die dahinterliegende Word-Instanz aber nicht mehr erreichbar ist.

Version 1.0.17 fuehrt zwei Schutzmechanismen ein:

1. `EnsureWordApplication` liest testweise `Word.Application.Version`. Nur eine antwortende Instanz wird wiederverwendet.
2. Der Word-Fallback fuer das Zusammenfuehren von ARE-PDF und Anschreiben laeuft in einer eigenen lokalen Word-Instanz. Diese wird nach jedem Merge vollstaendig geschlossen.

Damit kann die PDF-Konvertierung die Word-Instanz des Serienbriefs nicht mehr trennen.
