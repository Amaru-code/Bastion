# PDF-Kopierweg ohne Screen-Overlay

## Problem

Die reine ARE-PDF aus Excel war sauber. Erst beim spaeteren Anhaengen des Anschreibens konnte ein graues `Not Peer Reviewed`-Feld zusammen mit einem blauen Rahmen erscheinen.

## Ursache

Bis Version 1.0.14 wurde die ARE-Uebersicht fuer das kombinierte Word-/PDF-Dokument mit `Range.CopyPicture xlScreen, xlPicture` kopiert. `xlScreen` orientiert sich an der sichtbaren Bildschirmdarstellung. Damit koennen Overlays, die nicht zum eigentlichen Zellinhalt gehoeren, Bestandteil der Grafik werden.

## Loesung ab 1.0.15

Der Bereich `A1:F<letzte Zeile>` wird mit normalem `Range.Copy` kopiert. Word uebernimmt diesen Inhalt danach als Enhanced Metafile. Damit basiert die Grafik auf dem Excel-Zellbereich statt auf der sichtbaren Bildschirmdarstellung.

Die Reihenfolge bleibt:

1. ARE-Uebersicht
2. zugehoeriges Anschreiben

Alle anderen Ausgabe- und Formatierungsregeln bleiben unveraendert.


## Hinweis ab Version 1.0.16

Der Ansatz aus 1.0.15 war in der konkreten Peer-Review-Umgebung noch nicht ausreichend, weil weiterhin eine zweite Word-Darstellung der ARE-Seite erzeugt wurde. Version 1.0.16 ersetzt diesen Weg vollstaendig durch einen PDF-zu-PDF-Merge. Siehe `15_PDF_Merge_ohne_ARE_Neurendering.md`.
