# Fehlersuche

## Fehler 500 „Variable is undefined“

Dieser Fehler konnte in Version 1.0.1 auftreten, weil die VBA-Funktion `IsError(...)` im externen VBScript nicht verfügbar ist.

**Lösung:** Version 1.0.5 oder neuer verwenden. Dort werden Excel-Fehlerwerte über `VarType(value) = 10` erkannt. Der Wert `10` entspricht dem Variant-Untertyp `vbError`.

Ab Version 1.0.5 nennt die Fehlermeldung zusätzlich die aktuelle `Phase`, damit die Fehlerstelle leichter eingegrenzt werden kann.

## „Das Blatt Übersicht wurde nicht gefunden“

Bevorzugter Blattname ist `Übersicht`. Version 1.0.11 erkennt zusätzlich `Uebersicht`, `Overview` und `Übersicht Daten`.

## „Das Blatt Gesellschaften wurde nicht gefunden“

Bevorzugter Blattname ist `Gesellschaften`. Version 1.0.11 akzeptiert zusätzlich `Gesellschaft`, `Companies`, `Company` und `Stammdaten`.

## „Benötigte Spalten konnten nicht vollständig erkannt werden“

Ab Version 1.0.11 sind weder feste Spaltenbuchstaben noch eine feste Reihenfolge erforderlich. Prüfen Sie lediglich, ob innerhalb der ersten 30 Zeilen diese fachlichen Überschriften vorhanden sind: PNR neu, LTRG neu, PNR alt, LTRG alt, Übertrittsdatum, BSAV und Pensionen (alt). `Summe` ist optional. Zusätzliche Felder wie `ARE neu` und `ARE alt` sind zulässig.

Das Diagnoseprotokoll nennt die erkannte Kopfzeile und die Zuordnung, beispielsweise `ltrg_new=B | pnr_old=D | ltrg_old=E`.

## „Für folgende LTRG fehlt eine Zuordnung“

Mindestens eine LTRG aus `Übersicht` ist im Blatt `Gesellschaften` nicht mit einem Namen verknüpft. Die Position der Spalten ist ab Version 1.0.11 beliebig; erkannt werden LTRG, ARE und Name anhand der Überschriften. Die fehlenden LTRG werden in der Meldung genannt.

## Die VBS-Datei startet nicht

Mögliche Ursachen:

- Windows Script Host ist durch die Unternehmensrichtlinie deaktiviert.
- Excel Desktop ist nicht installiert.
- Die ZIP-Datei wurde nicht vollständig entpackt.
- Sicherheitssoftware blockiert `.vbs`-Dateien.

In diesem Fall kann alternativ das VBA-Modul aus dem Ordner `macro` direkt in Excel importiert werden.

## Die Ausgabedatei kann nicht gespeichert werden

Prüfen Sie:

- Schreibrechte im entpackten Projektordner beziehungsweise im Ordner `Output`
- ob die Datei bereits exklusiv geöffnet ist
- ob der Pfad zu lang ist
- ob OneDrive oder ein Netzlaufwerk gerade synchronisiert bzw. nicht erreichbar ist

## CHECK in I4 ist nicht 0

Dann stimmen die erzeugten Abschnittssummen nicht mit dem Nettosaldo aus `Übersicht` überein. Prüfen Sie insbesondere:

- nicht numerische LTRG
- fehlende oder ungewöhnliche Betragswerte
- nachträgliche Änderungen nach der Generierung
- manuell veränderte Detailzeilen oder Summenformeln

## Excel bleibt nach einem Fehler geöffnet

Das Skript versucht Excel bei einem Fehler zu schließen. Falls Excel oder ein Dialog nicht reagiert, schließen Sie die betroffene Excel-Instanz manuell und starten Sie das Skript erneut.

## Fehler 13 „Type mismatch“ bei „Quellblätter prüfen“

Version 1.0.5 ersetzt den gesamten bisher zusammengefassten Prüfschritt. Die Ursache konnte nicht nur in der Überschriftenprüfung liegen, sondern auch in der Excel-COM-Übergabe der letzten Zeile oder des kompletten Datenbereichs.

Die aktuelle Version:

- sucht die Kopfzeile automatisch innerhalb der ersten 30 Zeilen,
- erkennt die benötigten Felder unabhängig von ihren Spaltenpositionen,
- ignoriert zusätzliche Spalten wie `ARE neu` und `ARE alt`,
- liest die Daten Zelle für Zelle und behandelt Excel-Fehlerwerte kontrolliert als leer,
- verwendet für ARE und Gesellschaftsname die LTRG-Zuordnung aus `Gesellschaften`,
- schreibt die erkannte Spaltenzuordnung in `ARE_Generator_Diagnose.log`.

Das Protokoll liegt direkt im Projektordner neben der VBS-Datei. Bei einem neuen Fehler bitte die letzten Zeilen dieses Protokolls zusammen mit der Fehlermeldung bereitstellen.

## Fehler 1004 beim Erstellen eines ARE-Blatts

**Meldung:** „Die Add-Eigenschaft des Sheets-Objektes kann nicht zugeordnet werden.“

Dieser Fehler wurde bis Version 1.0.4 durch den VBScript-/COM-Aufruf `Worksheets.Add(Empty, ...)` ausgelöst. Version 1.0.5 verwendet keine `Empty`-Platzhalter mehr, sondern erstellt das Blatt zunächst parameterlos.

Falls der Fehler in Version 1.0.5 weiterhin auftritt, prüfen Sie in Excel unter **Überprüfen → Arbeitsmappe schützen**, ob die **Struktur** der Arbeitsmappe geschützt ist. Das Erstellen und Löschen von Blättern ist bei aktivem Strukturschutz technisch nicht möglich.


## Microsoft Word konnte nicht gestartet werden

Microsoft Word Desktop muss installiert sein. Word Online oder ein Viewer reicht nicht.

## Keine MERGEFIELD-Felder gefunden

Sichtbare Platzhalter wie `{Vorname}` oder `<<Vorname>>` sind keine echten Word-Felder.

In Word:

1. `Sendungen` öffnen.
2. `Seriendruckfeld einfügen` wählen.
3. Felder mit Namen der Excel-Kopfzeilen einfügen.
4. Vorlage als `.docx` speichern.

## Serienbrieffeld bleibt leer

Prüfen:

- Feldname passt zur Excel-Kopfzeile
- Kopfzeile steht in Zeile 1
- Wert steht im ersten Arbeitsblatt
- Datenzeile ist nicht leer

Nicht zugeordnete Felder stehen als Warnung im Diagnoseprotokoll.

## PDF kann nicht gespeichert werden

Prüfen:

- Schreibrechte
- Datei nicht in einem anderen Programm gesperrt
- Pfadlänge
- freier Speicherplatz
- Excel oder Word nicht durch einen Dialog blockiert


## Falsches Bild oder Unterschrift erscheint oben links

Ab Version 1.0.10 wird die DOCX nicht mehr als Logoquelle verwendet. Prüfen Sie:

- `Bild 1.png`, `Bild 1.jpg` oder `Bild 1.jpeg` liegt im Unterordner `docs`
- die Datei enthält tatsächlich nur das Mercer-Logo
- im Erfolgsdialog steht bei `Logoquelle` die erwartete Bilddatei
- im Fenstertitel steht `ARE Generator 1.0.10`

Fehlt die lokale Datei, wählen Sie im automatisch geöffneten Dateidialog das korrekte Logo aus.

## Serienbrief weicht von der Vorlage ab

Version 1.0.10 verwendet zuerst den nativen Word-Seriendruck. Im Diagnoseprotokoll sollte stehen:

```text
SERIENBRIEF-MODUS | Nativer Microsoft-Word-Seriendruck
```

Steht dort stattdessen eine Warnung zum Fallback, konnte Word die temporäre Excel-Datenquelle nicht nativ verbinden. Die Ausgabe wird dann mit dem kompatiblen bisherigen Feldmodus erstellt.

## `Anlage` steht weiterhin auf Seite 2

Das Tool entfernt vor und nach Absätzen, die mit `Anlage` beginnen, zusätzlichen Absatzabstand. Passt der Brief dennoch nicht auf eine Seite, enthält die Vorlage oder ein eingesetzter Datenwert mehr Inhalt als die Idealversion. In diesem Fall sind insbesondere lange Namens-/Adressfelder und zusätzliche Leerzeilen in der DOCX zu prüfen.

## Fehler `-2147417848` nach Person X von X

Dieser Fehler bedeutet, dass Microsoft Word die COM-Verbindung während der abschließenden Dokumentbereinigung getrennt hat. Häufig sind die Dateien zu diesem Zeitpunkt bereits vollständig erstellt.

Version 1.0.10 prüft deshalb automatisch:

- Ist `Anschreiben_ARE_Gesamt.docx` vorhanden?
- Ist `Anschreiben_ARE_Gesamt.pdf` vorhanden?
- Entspricht die Zahl der Einzel-PDFs mindestens der Zahl der Personendatensätze?

Sind alle Ergebnisse vorhanden, endet der Lauf mit einer Erfolgsmeldung. Der Word-Bereinigungsfehler wird nur im Diagnoseprotokoll als Warnung vermerkt. Sind Dateien unvollständig, startet weiterhin der kompatible Serienbrief-Fallback.

## Keine betroffene LTRG in der Serienbriefdatei gefunden

Version 1.0.12 erzeugt Anschreiben nur für LTRG, die in `Übersicht` tatsächlich als `LTRG neu` oder `LTRG alt` vorkommen. Prüfen Sie in der Serienbriefdatei:

- Ist eine Spalte mit Überschrift `LTRG`, `LTGR`, `LGTR` oder `LTRGR` vorhanden?
- Sind die Werte numerisch beziehungsweise als numerischer Text gespeichert?
- Entsprechen die Werte den betroffenen LTRG der ARE-Quelle?

Die erkannte Betroffenenliste und übersprungene ungültige Zeilen stehen im Diagnoseprotokoll.

## Übersichtsvorlage ungültig

Die Datei `templates/ARE_Uebersicht_Template.xlsx` muss die Blätter `ARE_TEMPLATE` und `CONFIG` enthalten. Wurde die Vorlage beschädigt, schließen Sie Excel, sichern Sie die Datei bei Bedarf und löschen oder benennen Sie sie um. Beim nächsten Start erstellt das Tool eine neue Standardvorlage.

## Übersicht konnte nicht an Word angehängt werden

Das Tool kopiert den Bereich A:F des zugehörigen ARE-Blatts als Vektorgrafik. Schließen Sie offene Zwischenablage- oder Office-Dialoge und starten Sie den Lauf erneut. Die Zuordnung erfolgt über LTRG, nicht über den sichtbaren ARE-Dateinamen.


## `Not Peer Reviewed` und blauer Rahmen im ARE-PDF

Ab Version 1.0.14 wird das lokale Logo weiterhin direkt per Excel `Shapes.AddPicture` aus `docs/Bild 1.png/.jpg/.jpeg` eingefuegt. Es wird nicht ueber eine andere Excel-Datei oder die DOCX-Vorlage kopiert.

In Mercer-Excel-Umgebungen kann ein Peer-Review-Add-in Druckausgaben mit einem `Not Peer Reviewed`-Hinweis und einem aeusseren Rahmen markieren. Vor jedem ARE-PDF-Export setzt Version 1.0.14 deshalb mehrere Schutzmassnahmen um: alle Shapes ausser dem Marsh-Logo entfernen, Kopf-/Fusszeilen neutralisieren, eindeutigen Peer-Review-Zelltext entfernen und ein erkanntes Peer-Review-COM-Add-in fuer den Export temporaer deaktivieren. Danach wird das Add-in wieder aktiviert.

Im Diagnoseprotokoll steht, ob ein passendes COM-Add-in erkannt und temporaer deaktiviert wurde.


## `Not Peer Reviewed` / blauer Rahmen trotz bereinigtem ARE-Blatt

**Finaler Fix ab Version 1.0.16.**

Die reine ARE-PDF wird direkt aus Excel erzeugt und war bereits sauber. Das Problem entstand erst danach, weil die ARE-Seite fuer `ARE -> Anschreiben` ein zweites Mal ueber Word aufgebaut wurde. Version 1.0.15 entfernte zwar `CopyPicture xlScreen`, liess aber weiterhin einen Excel-zu-Word-Neurendering-Schritt bestehen. In der lokalen Peer-Review-Umgebung reichte auch dieser Weg noch aus, damit der Stempel bzw. Rahmen wieder auftauchte.

Version 1.0.16 rendert die ARE-Seite deshalb **ueberhaupt nicht mehr neu**. Die vorhandene saubere ARE-PDF bleibt bestehen; das Anschreiben wird separat als PDF erzeugt und auf PDF-Seitenebene angehaengt. Primaer verwendet das Tool Adobe Acrobat OLE/PDDoc. Erst wenn dieser Merge lokal nicht verfuegbar ist, wird ein Word-Fallback versucht, der aber nur die bereits exportierte PDF oeffnet und nicht mehr auf Excel zugreift.

Im Diagnoseprotokoll steht fuer jede LTRG die verwendete Merge-Methode.


## Fehler -2147417848 beim Serienbrief-/PDF-Fallback

Dieser Fehler bedeutet, dass eine Word-COM-Referenz noch im Skript vorhanden ist, die zugehoerige Word-Instanz aber bereits beendet oder intern neu gestartet wurde. Ab Version 1.0.17 prueft das Tool Word vor jeder Wiederverwendung aktiv und trennt den PDF-Import-Fallback vollstaendig von der Word-Instanz des Serienbriefs.

Der ARE-PDF-Merge ueber Word verwendet eine eigene kurzlebige Word-Instanz. Ein Word-Neustart waehrend der PDF-Konvertierung kann daher den eigentlichen Serienbrief nicht mehr unterbrechen.


## Word fragt beim Oeffnen einer PDF nach der Konvertierung

Ab Version 1.0.18 wird diese Meldung im isolierten Word-PDF-Fallback automatisch unterdrueckt. Das Tool verwendet dafuer temporaer den Word-Benutzerwert `DisableConvertPdfWarning` und stellt den vorherigen Zustand anschliessend wieder her. Wenn Unternehmensrichtlinien Registry-Aenderungen blockieren, erscheint die Meldung weiterhin; im Diagnoseprotokoll steht dann ein Eintrag `PDF-WARNUNG | Registry-Wert konnte nicht gesetzt werden`.
