@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW DU Importer - Portable

if not exist "output" mkdir "output"

echo Starte DC LNW DU Importer ...
echo Das Fenster zeigt waehrend der Verarbeitung jeden Arbeitsschritt an.
echo.

powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0DC_LNW_DU_Importer.ps1"
set "EXITCODE=%ERRORLEVEL%"

if not "%EXITCODE%"=="0" (
    echo.
    echo Das Tool wurde mit einem Fehler beendet.
    pause
)
exit /b %EXITCODE%
