package main

import (
	"bufio"
	"errors"
	"fmt"
	"io"
	"math"
	"os"
	"os/exec"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"time"

	"github.com/xuri/excelize/v2"
)

const (
	targetSheet = "Import DC LNW"
)

var movementTypes = map[string]bool{
	normalize("Wiederanlage Ertragsaussc"): true,
	normalize("Fondsportfolioanpassung"):   true,
	normalize("Verkauf wegen Vorabpausch"): true,
}

const reallocationType = "fondsportfolioanpassung"

type Fund struct {
	DUName       string
	StartUnits   string
	StartValue   string
	EndUnits     string
	EndValue     string
	ReallocUnits string
	ReallocValue string
}

var funds = []Fund{
	{"DWSI-EUR.EQ.HI.CO.FC", "AJ", "AK", "CL", "CM", "BI", "BJ"},
	{"DWS EURORENTA", "AL", "AM", "CN", "CO", "BK", "BL"},
	{"DWS INS.-ESG EO MO.M.IC", "AN", "AO", "CP", "CQ", "BM", "BN"},
	{"SIEMENS EUROINVEST AKTIEN", "AP", "AQ", "CR", "CS", "", ""},
	{"SIEMENS EUROINVEST RENTEN", "AR", "AS", "CT", "CU", "", ""},
}

type DUColumns struct {
	Sheet, WWID, Fund, Type, Units, Value string
	HeaderRow                             int
}

type Totals struct {
	MovementUnits, MovementValue float64
	ReallocUnits, ReallocValue   float64
}

type Aggregate map[string]map[string]*Totals

type Stats struct {
	TargetRows, RowsWithWWID, RowsWithDU, RowsWithoutDU int
	DURows, IgnoredDURows, NonNumericStartValues        int
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintf(os.Stderr, "\nFEHLER: %v\n", err)
		pause()
		os.Exit(1)
	}
	fmt.Println("\nFertig.")
	pause()
}

func run() error {
	fmt.Println("============================================================")
	fmt.Println(" DC LNW – DU Importer")
	fmt.Println("============================================================")

	template, err := selectExcelFile("Template-Datei auswählen")
	if err != nil {
		return err
	}
	du, err := selectExcelFile("DU-Datei auswählen")
	if err != nil {
		return err
	}

	exe, _ := os.Executable()
	baseDir := filepath.Dir(exe)
	outDir := filepath.Join(baseDir, "output")
	if err := os.MkdirAll(outDir, 0755); err != nil {
		return err
	}

	stamp := time.Now().Format("20060102_150405")
	base := strings.TrimSuffix(filepath.Base(template), filepath.Ext(template))
	output := filepath.Join(outDir, fmt.Sprintf("%s_DU_Import_%s.xlsm", sanitizeFilename(base), stamp))

	fmt.Printf("\nTemplate: %s\nDU-Datei: %s\nOutput:   %s\n", template, du, output)

	if err := copyFile(template, output); err != nil {
		return fmt.Errorf("Template konnte nicht kopiert werden: %w", err)
	}

	wb, err := excelize.OpenFile(output, excelize.Options{RawCellValue: true})
	if err != nil {
		return fmt.Errorf("Output konnte nicht geöffnet werden: %w", err)
	}
	defer wb.Close()

	duWB, err := excelize.OpenFile(du, excelize.Options{RawCellValue: true})
	if err != nil {
		return fmt.Errorf("DU-Datei konnte nicht geöffnet werden: %w", err)
	}
	defer duWB.Close()

	sheetIndex, err := wb.GetSheetIndex(targetSheet)
	if err != nil || sheetIndex == -1 {
		return fmt.Errorf("Sheet %q wurde im Template nicht gefunden", targetSheet)
	}

	targetHeaderRow, targetWWIDCol, err := findHeader(wb, targetSheet, []string{"WWID"})
	if err != nil {
		return fmt.Errorf("Zielheader: %w", err)
	}
	lastTargetRow, err := lastDataRow(wb, targetSheet, targetWWIDCol, targetHeaderRow+1)
	if err != nil {
		return err
	}
	if lastTargetRow < targetHeaderRow+1 {
		return errors.New("keine Ziel-Datenzeilen gefunden")
	}

	duCols, err := detectDUColumns(duWB)
	if err != nil {
		return err
	}
	agg, stats, err := aggregateDU(duWB, duCols)
	if err != nil {
		return err
	}

	// CL:CU vor dem Leeren sichern.
	snapshot, err := snapshotValues(wb, targetSheet, "CL", "CU", targetHeaderRow+1, lastTargetRow)
	if err != nil {
		return err
	}

	// Ab AJ bis zur letzten verwendeten Spalte nur konstante Werte löschen.
	if err := clearConstantsFromAJ(wb, targetSheet, targetHeaderRow+1, lastTargetRow); err != nil {
		return err
	}

	// Gesicherte CL:CU-Werte nach AJ:AS schreiben.
	if err := writeSnapshot(wb, targetSheet, snapshot, "AJ", targetHeaderRow+1); err != nil {
		return err
	}

	stats.TargetRows = lastTargetRow - targetHeaderRow
	for row := targetHeaderRow + 1; row <= lastTargetRow; row++ {
		wwid, _ := wb.GetCellValue(targetSheet, cell(targetWWIDCol, row))
		key := normalizeWWID(wwid)
		if key == "" {
			continue
		}
		stats.RowsWithWWID++
		byFund, found := agg[key]
		if found {
			stats.RowsWithDU++
		} else {
			stats.RowsWithoutDU++
		}

		for _, f := range funds {
			t := Totals{}
			if found {
				if x := byFund[normalize(f.DUName)]; x != nil {
					t = *x
				}
			}
			if f.ReallocUnits != "" {
				if err := wb.SetCellValue(targetSheet, f.ReallocUnits+strconv.Itoa(row), cleanZero(t.ReallocUnits)); err != nil {
					return err
				}
				if err := wb.SetCellValue(targetSheet, f.ReallocValue+strconv.Itoa(row), cleanZero(t.ReallocValue)); err != nil {
					return err
				}
			}
			su, ok1, err := numericCell(wb, targetSheet, f.StartUnits+strconv.Itoa(row))
			if err != nil {
				return err
			}
			sv, ok2, err := numericCell(wb, targetSheet, f.StartValue+strconv.Itoa(row))
			if err != nil {
				return err
			}
			if !ok1 {
				stats.NonNumericStartValues++
			}
			if !ok2 {
				stats.NonNumericStartValues++
			}
			if err := wb.SetCellValue(targetSheet, f.EndUnits+strconv.Itoa(row), cleanZero(su+t.MovementUnits)); err != nil {
				return err
			}
			if err := wb.SetCellValue(targetSheet, f.EndValue+strconv.Itoa(row), cleanZero(sv+t.MovementValue)); err != nil {
				return err
			}
		}
	}

	// Als XLSM speichern. Bei XLSM-Templates bleiben eingebettete VBA-Projekte erhalten.
	if err := wb.SaveAs(output); err != nil {
		return fmt.Errorf("Speichern fehlgeschlagen: %w", err)
	}

	fmt.Printf("\nVerarbeitete DU-Zeilen: %d\nIgnorierte DU-Zeilen: %d\nZielzeilen mit WWID: %d\nMit DU-Treffern: %d\nOhne DU-Treffer: %d\nNichtnumerische Startwerte: %d\n", stats.DURows, stats.IgnoredDURows, stats.RowsWithWWID, stats.RowsWithDU, stats.RowsWithoutDU, stats.NonNumericStartValues)
	fmt.Printf("\nErgebnis erstellt:\n%s\n", output)
	_ = exec.Command("explorer.exe", "/select,", output).Start()
	return nil
}

func selectExcelFile(title string) (string, error) {
	ps := fmt.Sprintf(`Add-Type -AssemblyName System.Windows.Forms; $d=New-Object System.Windows.Forms.OpenFileDialog; $d.Title='%s'; $d.Filter='Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'; $d.Multiselect=$false; if($d.ShowDialog() -eq 'OK'){[Console]::OutputEncoding=[Text.Encoding]::UTF8; Write-Output $d.FileName}`, strings.ReplaceAll(title, "'", "''"))
	cmd := exec.Command("powershell.exe", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-Command", ps)
	out, err := cmd.Output()
	if err != nil {
		return "", fmt.Errorf("Dateidialog konnte nicht geöffnet werden: %w", err)
	}
	p := strings.TrimSpace(string(out))
	if p == "" {
		return "", errors.New("Dateiauswahl wurde abgebrochen")
	}
	ext := strings.ToLower(filepath.Ext(p))
	if ext != ".xlsx" && ext != ".xlsm" {
		return "", fmt.Errorf("nicht unterstütztes Format: %s", ext)
	}
	return p, nil
}

func detectDUColumns(wb *excelize.File) (DUColumns, error) {
	aliases := map[string][]string{
		"wwid":  {"WWID"},
		"fund":  {"Fondsname", "Fonds Name", "Fonds"},
		"type":  {"Umsatzart", "Umsatz Art"},
		"units": {"UmsatzStuecke", "Umsatzstücke", "Umsatz Stuecke", "Umsatz Stücke"},
		"value": {"ZahlBetrag", "Zahl Betrag"},
	}
	for _, sheet := range wb.GetSheetList() {
		rows, err := wb.GetRows(sheet)
		if err != nil {
			continue
		}
		limit := len(rows)
		if limit > 100 {
			limit = 100
		}
		for r := 0; r < limit; r++ {
			found := map[string]string{}
			for c, v := range rows[r] {
				n := normalize(v)
				for key, names := range aliases {
					for _, a := range names {
						if n == normalize(a) {
							found[key] = columnName(c + 1)
						}
					}
				}
			}
			if len(found) == 5 {
				return DUColumns{sheet, found["wwid"], found["fund"], found["type"], found["units"], found["value"], r + 1}, nil
			}
		}
	}
	return DUColumns{}, errors.New("DU-Header WWID/Fondsname/Umsatzart/UmsatzStuecke/ZahlBetrag nicht vollständig gefunden")
}

func aggregateDU(wb *excelize.File, c DUColumns) (Aggregate, Stats, error) {
	out := Aggregate{}
	st := Stats{}
	rows, err := wb.GetRows(c.Sheet)
	if err != nil {
		return nil, st, err
	}
	for r := c.HeaderRow + 1; r <= len(rows); r++ {
		wwid, _ := wb.GetCellValue(c.Sheet, c.WWID+strconv.Itoa(r))
		fund, _ := wb.GetCellValue(c.Sheet, c.Fund+strconv.Itoa(r))
		typ, _ := wb.GetCellValue(c.Sheet, c.Type+strconv.Itoa(r))
		wk, fk, tk := normalizeWWID(wwid), normalize(fund), normalize(typ)
		if wk == "" || fk == "" || tk == "" {
			st.IgnoredDURows++
			continue
		}
		units, _, err := numericCell(wb, c.Sheet, c.Units+strconv.Itoa(r))
		if err != nil {
			return nil, st, err
		}
		value, _, err := numericCell(wb, c.Sheet, c.Value+strconv.Itoa(r))
		if err != nil {
			return nil, st, err
		}
		if out[wk] == nil {
			out[wk] = map[string]*Totals{}
		}
		if out[wk][fk] == nil {
			out[wk][fk] = &Totals{}
		}
		t := out[wk][fk]
		if movementTypes[tk] {
			t.MovementUnits += units
			t.MovementValue += value
		}
		if tk == reallocationType {
			t.ReallocUnits += units
			t.ReallocValue += value
		}
		st.DURows++
	}
	return out, st, nil
}

func findHeader(wb *excelize.File, sheet string, names []string) (int, int, error) {
	rows, err := wb.GetRows(sheet)
	if err != nil {
		return 0, 0, err
	}
	limit := len(rows)
	if limit > 100 {
		limit = 100
	}
	for r := 0; r < limit; r++ {
		for c, v := range rows[r] {
			for _, name := range names {
				if normalize(v) == normalize(name) {
					return r + 1, c + 1, nil
				}
			}
		}
	}
	return 0, 0, fmt.Errorf("Header %v nicht gefunden", names)
}

func lastDataRow(wb *excelize.File, sheet string, col, start int) (int, error) {
	rows, err := wb.GetRows(sheet)
	if err != nil {
		return 0, err
	}
	last := start - 1
	for r := start; r <= len(rows); r++ {
		v, _ := wb.GetCellValue(sheet, cell(col, r))
		if strings.TrimSpace(v) != "" {
			last = r
		}
	}
	return last, nil
}

func snapshotValues(wb *excelize.File, sheet, first, last string, fromRow, toRow int) ([][]interface{}, error) {
	fc, _ := excelize.ColumnNameToNumber(first)
	lc, _ := excelize.ColumnNameToNumber(last)
	out := make([][]interface{}, 0, toRow-fromRow+1)
	for r := fromRow; r <= toRow; r++ {
		row := make([]interface{}, 0, lc-fc+1)
		for c := fc; c <= lc; c++ {
			addr := cell(c, r)
			formula, _ := wb.GetCellFormula(sheet, addr)
			if formula != "" {
				row = append(row, "="+formula)
			} else {
				raw, _ := wb.GetCellValue(sheet, addr, excelize.Options{RawCellValue: true})
				if n, ok := parseNumber(raw); ok {
					row = append(row, n)
				} else {
					row = append(row, raw)
				}
			}
		}
		out = append(out, row)
	}
	return out, nil
}

func writeSnapshot(wb *excelize.File, sheet string, data [][]interface{}, firstCol string, startRow int) error {
	fc, _ := excelize.ColumnNameToNumber(firstCol)
	for ri, row := range data {
		for ci, v := range row {
			addr := cell(fc+ci, startRow+ri)
			if s, ok := v.(string); ok && strings.HasPrefix(s, "=") {
				if err := wb.SetCellFormula(sheet, addr, strings.TrimPrefix(s, "=")); err != nil {
					return err
				}
			} else if err := wb.SetCellValue(sheet, addr, v); err != nil {
				return err
			}
		}
	}
	return nil
}

func clearConstantsFromAJ(wb *excelize.File, sheet string, fromRow, toRow int) error {
	rows, err := wb.GetRows(sheet)
	if err != nil {
		return err
	}
	maxCol := 0
	for _, row := range rows {
		if len(row) > maxCol {
			maxCol = len(row)
		}
	}
	aj, _ := excelize.ColumnNameToNumber("AJ")
	if maxCol < aj {
		return nil
	}
	for r := fromRow; r <= toRow; r++ {
		for c := aj; c <= maxCol; c++ {
			addr := cell(c, r)
			formula, err := wb.GetCellFormula(sheet, addr)
			if err != nil {
				return err
			}
			if formula == "" {
				if err := wb.SetCellValue(sheet, addr, nil); err != nil {
					return err
				}
			}
		}
	}
	return nil
}

func numericCell(wb *excelize.File, sheet, addr string) (float64, bool, error) {
	formula, err := wb.GetCellFormula(sheet, addr)
	if err != nil {
		return 0, false, err
	}
	v, err := wb.GetCellValue(sheet, addr, excelize.Options{RawCellValue: true})
	if err != nil {
		return 0, false, err
	}
	if formula != "" && strings.TrimSpace(v) == "" {
		return 0, false, nil
	}
	n, ok := parseNumber(v)
	return n, ok, nil
}

func parseNumber(s string) (float64, bool) {
	s = strings.TrimSpace(strings.ReplaceAll(s, "\u00a0", ""))
	if s == "" {
		return 0, true
	}
	s = strings.ReplaceAll(s, " ", "")
	if strings.Contains(s, ",") && strings.Contains(s, ".") {
		if strings.LastIndex(s, ",") > strings.LastIndex(s, ".") {
			s = strings.ReplaceAll(s, ".", "")
			s = strings.ReplaceAll(s, ",", ".")
		} else {
			s = strings.ReplaceAll(s, ",", "")
		}
	} else if strings.Contains(s, ",") {
		s = strings.ReplaceAll(s, ",", ".")
	}
	n, err := strconv.ParseFloat(s, 64)
	return n, err == nil
}

func normalize(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	r := strings.NewReplacer("ä", "ae", "ö", "oe", "ü", "ue", "ß", "ss", "é", "e", "è", "e", "á", "a", "à", "a")
	s = r.Replace(s)
	re := regexp.MustCompile(`[^a-z0-9]+`)
	return re.ReplaceAllString(s, "")
}
func normalizeWWID(s string) string {
	s = strings.TrimSpace(s)
	if n, ok := parseNumber(s); ok && math.Trunc(n) == n {
		return strconv.FormatInt(int64(n), 10)
	}
	return strings.ToUpper(strings.ReplaceAll(s, " ", ""))
}
func cleanZero(v float64) float64 {
	if math.Abs(v) < 1e-12 {
		return 0
	}
	return v
}
func cell(col, row int) string  { a, _ := excelize.CoordinatesToCellName(col, row); return a }
func columnName(col int) string { a, _ := excelize.ColumnNumberToName(col); return a }
func sanitizeFilename(s string) string {
	bad := regexp.MustCompile(`[<>:"/\\|?*]+`)
	s = strings.TrimSpace(bad.ReplaceAllString(s, "_"))
	if s == "" {
		return "DC_LNW_Output"
	}
	return s
}
func copyFile(src, dst string) error {
	in, err := os.Open(src)
	if err != nil {
		return err
	}
	defer in.Close()
	out, err := os.Create(dst)
	if err != nil {
		return err
	}
	if _, err = io.Copy(out, in); err != nil {
		out.Close()
		return err
	}
	return out.Close()
}
func pause() {
	fmt.Print("\nDrücke Enter zum Schließen ...")
	_, _ = bufio.NewReader(os.Stdin).ReadString('\n')
}
