@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW DU Importer - Einrichtung

if not exist "output" mkdir "output"

echo ============================================================
echo  DC LNW DU Importer - Portable Einrichtung
echo ============================================================
echo.
echo Keine Go-Installation und keine Kompilierung erforderlich.
echo.
echo Voraussetzung:
echo   - Windows PowerShell 5.1
echo   - Microsoft Excel Desktop
echo.
echo Die Einrichtung ist abgeschlossen.
echo Starte das Programm mit start.bat.
echo.
pause
exit /b 0
