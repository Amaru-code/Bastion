Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$TargetSheet = 'Import DC LNW'
$MovementTypes = @(
    'wiederanlage ertragsaussc',
    'fondsportfolioanpassung',
    'verkauf wegen vorabpausch'
)
$ReallocationType = 'fondsportfolioanpassung'

$Funds = @(
    [pscustomobject]@{ DUName='DWSI-EUR.EQ.HI.CO.FC'; StartUnits='AJ'; StartValue='AK'; EndUnits='CL'; EndValue='CM'; ReallocUnits='BI'; ReallocValue='BJ' },
    [pscustomobject]@{ DUName='DWS EURORENTA'; StartUnits='AL'; StartValue='AM'; EndUnits='CN'; EndValue='CO'; ReallocUnits='BK'; ReallocValue='BL' },
    [pscustomobject]@{ DUName='DWS INS.-ESG EO MO.M.IC'; StartUnits='AN'; StartValue='AO'; EndUnits='CP'; EndValue='CQ'; ReallocUnits='BM'; ReallocValue='BN' },
    [pscustomobject]@{ DUName='SIEMENS EUROINVEST AKTIEN'; StartUnits='AP'; StartValue='AQ'; EndUnits='CR'; EndValue='CS'; ReallocUnits=''; ReallocValue='' },
    [pscustomobject]@{ DUName='SIEMENS EUROINVEST RENTEN'; StartUnits='AR'; StartValue='AS'; EndUnits='CT'; EndValue='CU'; ReallocUnits=''; ReallocValue='' }
)

function Write-Step([string]$Text) {
    Write-Host ("[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Text)
}

function Normalize-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value).Trim().ToLowerInvariant()
    $s = $s -replace '[\s\-_]+', ' '
    return $s.Trim()
}

function Normalize-WWID([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value).Trim()
    if ($s -match '^\d+([\.,]0+)?$') {
        $s = ($s -replace '[\.,]0+$','').TrimStart('0')
        if ($s -eq '') { return '0' }
        return $s
    }
    return $s.ToUpperInvariant()
}

function Select-ExcelFile([string]$Title) {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = $Title
    $dialog.Filter = 'Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'
    $dialog.Multiselect = $false
    $dialog.CheckFileExists = $true
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        throw 'Dateiauswahl wurde abgebrochen.'
    }
    return $dialog.FileName
}

function Column-ToNumber([string]$Column) {
    $n = 0
    foreach ($c in $Column.ToUpperInvariant().ToCharArray()) {
        $n = $n * 26 + ([int][char]$c - [int][char]'A' + 1)
    }
    return $n
}

function Get-ArrayValue($Array, [int]$Row, [int]$Col) {
    if ($Array -is [System.Array] -and $Array.Rank -eq 2) {
        return $Array.GetValue($Row, $Col)
    }
    if ($Row -eq 1 -and $Col -eq 1) { return $Array }
    return $null
}

function Set-ArrayValue($Array, [int]$Row, [int]$Col, [object]$Value) {
    $Array.SetValue($Value, $Row, $Col)
}

function Find-Header($Sheet, [string[]]$Aliases, [int]$MaxRows = 200) {
    $used = $Sheet.UsedRange
    $firstRow = [int]$used.Row
    $firstCol = [int]$used.Column
    $rowCount = [Math]::Min([int]$used.Rows.Count, $MaxRows)
    $colCount = [int]$used.Columns.Count
    $values = $Sheet.Range(
        $Sheet.Cells.Item($firstRow, $firstCol),
        $Sheet.Cells.Item($firstRow + $rowCount - 1, $firstCol + $colCount - 1)
    ).Value2
    $normAliases = @($Aliases | ForEach-Object { Normalize-Text $_ })
    for ($r = 1; $r -le $rowCount; $r++) {
        for ($c = 1; $c -le $colCount; $c++) {
            $x = Normalize-Text (Get-ArrayValue $values $r $c)
            if ($normAliases -contains $x) {
                return [pscustomobject]@{ Row=($firstRow + $r - 1); Col=($firstCol + $c - 1) }
            }
        }
    }
    return $null
}

function Find-DUColumns($Workbook) {
    $aliases = @{
        WWID  = @('WWID')
        Fund  = @('Fondsname','Fonds Name','Fonds')
        Type  = @('Umsatzart','Umsatz Art')
        Units = @('UmsatzStuecke','Umsatzstücke','Umsatz Stuecke','Umsatz Stücke')
        Value = @('ZahlBetrag','Zahl Betrag')
    }
    $normalizedAliases = @{}
    foreach ($key in $aliases.Keys) {
        $normalizedAliases[$key] = @($aliases[$key] | ForEach-Object { Normalize-Text $_ })
    }

    foreach ($sheet in @($Workbook.Worksheets)) {
        $used = $sheet.UsedRange
        $firstRow = [int]$used.Row
        $firstCol = [int]$used.Column
        $rowCount = [Math]::Min([int]$used.Rows.Count, 100)
        $colCount = [int]$used.Columns.Count
        if ($rowCount -lt 1 -or $colCount -lt 1) { continue }

        $values = $sheet.Range(
            $sheet.Cells.Item($firstRow, $firstCol),
            $sheet.Cells.Item($firstRow + $rowCount - 1, $firstCol + $colCount - 1)
        ).Value2

        for ($r = 1; $r -le $rowCount; $r++) {
            $found = @{}
            for ($c = 1; $c -le $colCount; $c++) {
                $text = Normalize-Text (Get-ArrayValue $values $r $c)
                foreach ($key in $normalizedAliases.Keys) {
                    if ($normalizedAliases[$key] -contains $text) {
                        $found[$key] = $firstCol + $c - 1
                    }
                }
            }
            if ($found.Count -eq 5) {
                return [pscustomobject]@{
                    Sheet=$sheet
                    HeaderRow=($firstRow + $r - 1)
                    WWID=$found.WWID
                    Fund=$found.Fund
                    Type=$found.Type
                    Units=$found.Units
                    Value=$found.Value
                }
            }
        }
    }
    throw 'Die DU-Spalten WWID, Fondsname, Umsatzart, UmsatzStuecke und ZahlBetrag wurden nicht gemeinsam gefunden.'
}

function To-Double([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return 0.0 }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [int] -or $Value -is [long]) { return [double]$Value }
    $s = ([string]$Value).Trim().Replace([char]0xA0, '')
    $cultures = @(
        [Globalization.CultureInfo]::GetCultureInfo('de-DE'),
        [Globalization.CultureInfo]::InvariantCulture
    )
    foreach ($culture in $cultures) {
        $result = 0.0
        if ([double]::TryParse($s, [Globalization.NumberStyles]::Any, $culture, [ref]$result)) {
            return $result
        }
    }
    return 0.0
}

function Get-Aggregates($DUColumns) {
    $agg = @{}
    $sheet = $DUColumns.Sheet
    $lastRow = [int]$sheet.Cells.Item($sheet.Rows.Count, $DUColumns.WWID).End(-4162).Row
    $firstRow = $DUColumns.HeaderRow + 1
    if ($lastRow -lt $firstRow) { return $agg }

    $minCol = @($DUColumns.WWID, $DUColumns.Fund, $DUColumns.Type, $DUColumns.Units, $DUColumns.Value) | Measure-Object -Minimum | Select-Object -ExpandProperty Minimum
    $maxCol = @($DUColumns.WWID, $DUColumns.Fund, $DUColumns.Type, $DUColumns.Units, $DUColumns.Value) | Measure-Object -Maximum | Select-Object -ExpandProperty Maximum
    $values = $sheet.Range($sheet.Cells.Item($firstRow, $minCol), $sheet.Cells.Item($lastRow, $maxCol)).Value2
    $rows = $lastRow - $firstRow + 1

    $wwidIndex = $DUColumns.WWID - $minCol + 1
    $fundIndex = $DUColumns.Fund - $minCol + 1
    $typeIndex = $DUColumns.Type - $minCol + 1
    $unitsIndex = $DUColumns.Units - $minCol + 1
    $valueIndex = $DUColumns.Value - $minCol + 1

    for ($r = 1; $r -le $rows; $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $values $r $wwidIndex)
        $fund = Normalize-Text (Get-ArrayValue $values $r $fundIndex)
        $type = Normalize-Text (Get-ArrayValue $values $r $typeIndex)
        if ([string]::IsNullOrWhiteSpace($wwid) -or [string]::IsNullOrWhiteSpace($fund)) { continue }

        if (-not $agg.ContainsKey($wwid)) { $agg[$wwid] = @{} }
        if (-not $agg[$wwid].ContainsKey($fund)) {
            $agg[$wwid][$fund] = [pscustomobject]@{
                MovementUnits=0.0
                MovementValue=0.0
                ReallocUnits=0.0
                ReallocValue=0.0
            }
        }

        $units = To-Double (Get-ArrayValue $values $r $unitsIndex)
        $value = To-Double (Get-ArrayValue $values $r $valueIndex)
        $item = $agg[$wwid][$fund]
        if ($MovementTypes -contains $type) {
            $item.MovementUnits += $units
            $item.MovementValue += $value
        }
        if ($type -eq $ReallocationType) {
            $item.ReallocUnits += $units
            $item.ReallocValue += $value
        }
    }
    return $agg
}

$excel = $null
$templateBook = $null
$duBook = $null
$target = $null
$oldCalculation = $null

try {
    Write-Host '============================================================'
    Write-Host ' DC LNW - DU Importer (portable, ohne Go)'
    Write-Host '============================================================'
    Write-Host ''

    $template = Select-ExcelFile 'Template-Datei auswählen'
    $du = Select-ExcelFile 'DU-Datei auswählen'
    Write-Step 'Dateien ausgewählt.'

    if ([IO.Path]::GetFullPath($template) -eq [IO.Path]::GetFullPath($du)) {
        throw 'Template-Datei und DU-Datei dürfen nicht identisch sein.'
    }

    $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $outputDir = Join-Path $baseDir 'output'
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    $baseName = [IO.Path]::GetFileNameWithoutExtension($template)
    $safeName = $baseName -replace '[<>:"/\\|?*]', '_'
    $output = Join-Path $outputDir ("{0}_DU_Import_{1}.xlsm" -f $safeName, (Get-Date -Format 'yyyyMMdd_HHmmss'))

    Write-Step 'Microsoft Excel wird im Hintergrund gestartet ...'
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    $excel.EnableEvents = $false
    $excel.ScreenUpdating = $false
    $oldCalculation = $excel.Calculation
    $excel.Calculation = -4135 # xlCalculationManual

    Write-Step 'Template wird geöffnet und als neue XLSM-Ausgabedatei angelegt ...'
    $templateBook = $excel.Workbooks.Open($template, 0, $false, 5, '', '', $true)
    # 52 = xlOpenXMLWorkbookMacroEnabled (.xlsm)
    $templateBook.SaveAs($output, 52)

    Write-Step 'DU-Datei wird geöffnet ...'
    $duBook = $excel.Workbooks.Open($du, 0, $true, 5, '', '', $true)

    try {
        $target = $templateBook.Worksheets.Item($TargetSheet)
    }
    catch {
        throw "Sheet '$TargetSheet' wurde im Template nicht gefunden."
    }

    Write-Step "Header im Sheet '$TargetSheet' werden gesucht ..."
    $wwidHeader = Find-Header $target @('WWID') 200
    if ($null -eq $wwidHeader) {
        throw "WWID-Header wurde im Sheet '$TargetSheet' nicht gefunden."
    }

    $lastRow = [int]$target.Cells.Item($target.Rows.Count, $wwidHeader.Col).End(-4162).Row
    if ($lastRow -le $wwidHeader.Row) { throw 'Keine Ziel-Datenzeilen gefunden.' }
    $firstDataRow = $wwidHeader.Row + 1
    $rowCount = $lastRow - $firstDataRow + 1
    Write-Step ("Zielbereich erkannt: {0} Datenzeilen." -f $rowCount)

    Write-Step 'DU-Spalten werden erkannt ...'
    $duColumns = Find-DUColumns $duBook
    Write-Step ("DU-Sheet erkannt: '{0}', Headerzeile {1}." -f $duColumns.Sheet.Name, $duColumns.HeaderRow)

    Write-Step 'DU-Daten werden blockweise eingelesen und aggregiert ...'
    $aggregates = Get-Aggregates $duColumns
    Write-Step ("Aggregation abgeschlossen: {0} unterschiedliche WWIDs." -f $aggregates.Count)

    $aj = Column-ToNumber 'AJ'
    $as = Column-ToNumber 'AS'
    $bi = Column-ToNumber 'BI'
    $bn = Column-ToNumber 'BN'
    $cl = Column-ToNumber 'CL'
    $cu = Column-ToNumber 'CU'

    Write-Step 'Bisherige Stichtagswerte CL:CU werden gesichert ...'
    $snapshot = $target.Range(
        $target.Cells.Item($firstDataRow, $cl),
        $target.Cells.Item($lastRow, $cu)
    ).Value2

    Write-Step 'Konstante Zellwerte ab AJ werden blockweise gelöscht; Formeln bleiben erhalten ...'
    $lastUsedCol = [Math]::Max([int]$target.UsedRange.Column + [int]$target.UsedRange.Columns.Count - 1, $cu)
    $clearRange = $target.Range(
        $target.Cells.Item($firstDataRow, $aj),
        $target.Cells.Item($lastRow, $lastUsedCol)
    )
    try {
        # 2 = xlCellTypeConstants. Sehr viel schneller als Zell-für-Zell-Verarbeitung.
        $constants = $clearRange.SpecialCells(2)
        $constants.ClearContents()
        [void][Runtime.InteropServices.Marshal]::ReleaseComObject($constants)
    }
    catch {
        # SpecialCells wirft einen Fehler, wenn keine Konstanten vorhanden sind.
        if ($_.Exception.Message -notmatch 'No cells were found|Keine Zellen gefunden') {
            throw
        }
    }

    Write-Step 'Startbestände werden von CL:CU nach AJ:AS übernommen ...'
    $target.Range(
        $target.Cells.Item($firstDataRow, $aj),
        $target.Cells.Item($lastRow, $as)
    ).Value2 = $snapshot

    Write-Step 'WWIDs und Startbestände werden blockweise eingelesen ...'
    $wwidValues = $target.Range(
        $target.Cells.Item($firstDataRow, $wwidHeader.Col),
        $target.Cells.Item($lastRow, $wwidHeader.Col)
    ).Value2
    $startValues = $target.Range(
        $target.Cells.Item($firstDataRow, $aj),
        $target.Cells.Item($lastRow, $as)
    ).Value2

    $reallocOutput = New-Object 'object[,]' $rowCount, 6
    $endOutput = New-Object 'object[,]' $rowCount, 10
    $matchedRows = 0

    Write-Step 'Neue Werte werden im Arbeitsspeicher berechnet ...'
    for ($r = 1; $r -le $rowCount; $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $wwidValues $r 1)
        $fundMap = @{}
        if (-not [string]::IsNullOrWhiteSpace($wwid) -and $aggregates.ContainsKey($wwid)) {
            $fundMap = $aggregates[$wwid]
            $matchedRows++
        }

        for ($fIndex = 0; $fIndex -lt $Funds.Count; $fIndex++) {
            $f = $Funds[$fIndex]
            $key = Normalize-Text $f.DUName
            $t = [pscustomobject]@{ MovementUnits=0.0; MovementValue=0.0; ReallocUnits=0.0; ReallocValue=0.0 }
            if ($fundMap.ContainsKey($key)) { $t = $fundMap[$key] }

            $startUnits = To-Double (Get-ArrayValue $startValues $r ($fIndex * 2 + 1))
            $startValue = To-Double (Get-ArrayValue $startValues $r ($fIndex * 2 + 2))
            Set-ArrayValue $endOutput $r ($fIndex * 2 + 1) ($startUnits + $t.MovementUnits)
            Set-ArrayValue $endOutput $r ($fIndex * 2 + 2) ($startValue + $t.MovementValue)

            if ($fIndex -lt 3) {
                Set-ArrayValue $reallocOutput $r ($fIndex * 2 + 1) $t.ReallocUnits
                Set-ArrayValue $reallocOutput $r ($fIndex * 2 + 2) $t.ReallocValue
            }
        }
    }

    Write-Step 'Umschichtungswerte werden blockweise nach BI:BN geschrieben ...'
    $target.Range(
        $target.Cells.Item($firstDataRow, $bi),
        $target.Cells.Item($lastRow, $bn)
    ).Value2 = $reallocOutput

    Write-Step 'Neue Stichtagswerte werden blockweise nach CL:CU geschrieben ...'
    $target.Range(
        $target.Cells.Item($firstDataRow, $cl),
        $target.Cells.Item($lastRow, $cu)
    ).Value2 = $endOutput

    Write-Step 'Ausgabedatei wird gespeichert ...'
    $templateBook.Save()

    $duBook.Close($false)
    $duBook = $null
    $templateBook.Close($true)
    $templateBook = $null

    if ($null -ne $oldCalculation) { $excel.Calculation = $oldCalculation }
    $excel.Quit()
    $excel = $null

    Write-Host ''
    Write-Host '============================================================'
    Write-Host ' ERFOLGREICH ABGESCHLOSSEN'
    Write-Host '============================================================'
    Write-Host ("Verarbeitete Zielzeilen: {0}" -f $rowCount)
    Write-Host ("Zielzeilen mit passender DU-WWID: {0}" -f $matchedRows)
    Write-Host 'Ergebnis:'
    Write-Host $output

    Start-Process explorer.exe -ArgumentList "/select,`"$output`""
    [System.Windows.Forms.MessageBox]::Show(
        "Die Datei wurde erfolgreich erstellt:`n`n$output",
        'DC LNW DU Importer',
        'OK',
        'Information'
    ) | Out-Null
    exit 0
}
catch {
    $message = $_.Exception.Message
    Write-Host ''
    Write-Host "FEHLER: $message" -ForegroundColor Red
    [System.Windows.Forms.MessageBox]::Show(
        $message,
        'DC LNW DU Importer - Fehler',
        'OK',
        'Error'
    ) | Out-Null
    exit 1
}
finally {
    if ($null -ne $excel -and $null -ne $oldCalculation) {
        try { $excel.Calculation = $oldCalculation } catch {}
    }
    if ($null -ne $duBook) { try { $duBook.Close($false) } catch {} }
    if ($null -ne $templateBook) { try { $templateBook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }

    foreach ($obj in @($target, $duBook, $templateBook, $excel)) {
        if ($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($obj) } catch {}
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
