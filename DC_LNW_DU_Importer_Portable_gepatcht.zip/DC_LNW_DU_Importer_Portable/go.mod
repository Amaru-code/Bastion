module dc-lnw-du-importer

go 1.23

require github.com/xuri/excelize/v2 v2.9.1
