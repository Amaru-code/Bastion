# DC LNW DU Importer – Portable

## Voraussetzungen

- Windows 10 oder Windows 11
- Microsoft Excel Desktop
- Keine Go-Installation erforderlich
- Keine Python-Installation erforderlich

## Start

1. ZIP vollständig entpacken.
2. Alle geöffneten Excel-Dateien möglichst schließen.
3. `start.bat` doppelklicken.
4. Zuerst das Template auswählen.
5. Danach die DU-Datei auswählen.
6. Den Fortschritt im Konsolenfenster verfolgen.

Die neue Datei wird im Unterordner `output` als `.xlsm` erstellt.

## Performance-Patch

Die Version verarbeitet Excel-Daten blockweise. Sie führt keine hunderttausenden Zellzugriffe mehr einzeln aus. Konstanten werden über Excels `SpecialCells` in einem Schritt gelöscht, während Formeln bestehen bleiben.

## Fachliche Verarbeitung

- Ziel-Sheet: `Import DC LNW`
- Header bleiben erhalten.
- Ab Spalte `AJ` werden in den Datenzeilen nur konstante Werte gelöscht; Formeln bleiben bestehen.
- Die bisherigen Werte aus `CL:CU` werden nach `AJ:AS` übernommen.
- `BI:BN` wird aus der DU-Datei nach WWID, Fonds und `Fondsportfolioanpassung` aggregiert.
- `CL:CU` ergibt sich aus `AJ:AS` plus den signierten DU-Bewegungen der dokumentierten Umsatzarten.

## Bei einem Fehler

Das Konsolenfenster zeigt den letzten begonnenen Verarbeitungsschritt. Dadurch ist erkennbar, ob das Problem beim Öffnen, bei der Headererkennung, Aggregation oder Speicherung liegt.
