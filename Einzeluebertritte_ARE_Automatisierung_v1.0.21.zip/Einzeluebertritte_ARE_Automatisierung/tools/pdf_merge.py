#!/usr/bin/env python3
"""Merge existing PDF files without re-rendering their page content.

Usage:
    python pdf_merge.py OUTPUT.pdf BASE.pdf APPEND1.pdf [APPEND2.pdf ...]

The bundled pypdf package is loaded from tools/vendor, so no pip install is
required. The script only concatenates existing PDF pages; it does not open or
reflow them through Word.
"""
from __future__ import annotations

import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
VENDOR = HERE / "vendor"
sys.path.insert(0, str(VENDOR))

from pypdf import PdfReader, PdfWriter  # noqa: E402


def main() -> int:
    if len(sys.argv) < 4:
        return 2

    output = Path(sys.argv[1]).resolve()
    inputs = [Path(arg).resolve() for arg in sys.argv[2:]]

    for path in inputs:
        if not path.is_file() or path.stat().st_size <= 0:
            return 3

    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_name(output.stem + ".__writing__.pdf")
    if temp.exists():
        temp.unlink()

    writer = PdfWriter()
    try:
        for path in inputs:
            reader = PdfReader(str(path), strict=False)
            for page in reader.pages:
                writer.add_page(page)

        with temp.open("wb") as fh:
            writer.write(fh)

        if not temp.is_file() or temp.stat().st_size <= 0:
            return 4
        temp.replace(output)
        return 0
    finally:
        try:
            writer.close()
        except Exception:
            pass
        if temp.exists() and temp != output:
            try:
                temp.unlink()
            except OSError:
                pass


if __name__ == "__main__":
    raise SystemExit(main())
