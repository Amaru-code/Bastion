# PDF merge helper

`pdf_merge.py` concatenates existing PDF pages without sending them through Microsoft Word. This preserves the exact page layout of the original ARE PDFs, including column positions, sums and logo sizing.

The project includes the pure-Python `pypdf` package under `tools/vendor`, so no additional pip installation is required. A local Python 3 installation is still required. The VBS starter tries `py -3`, `python` and `python3` automatically. If Python is unavailable, the existing Adobe Acrobat PDDoc method is tried instead.

The bundled `pypdf` license is in `tools/vendor/pypdf_LICENSE.txt`.
