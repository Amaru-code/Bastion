# PDF-Merge ohne ARE-Neurendering – Version 1.0.16

## Ursache des Peer-Review-Artefakts

Die ARE-Blätter wurden zunächst korrekt direkt aus Excel als PDF exportiert. Für die spätere Kombination mit den Anschreiben wurde die ARE-Seite in älteren Versionen jedoch erneut in Word aufgebaut. Damit entstand ein zweiter Rendering-Pfad, über den sichtbare Peer-Review-Markierungen wieder Bestandteil der finalen PDF werden konnten.

## Neue Logik

1. Excel exportiert das ARE-Blatt einmal als PDF.
2. Diese PDF wird danach nicht erneut aus Excel kopiert.
3. Die zugehörigen Anschreiben werden separat als PDFs erzeugt.
4. Adobe Acrobat OLE (`AcroExch.PDDoc`) fügt die Anschreiben-Seiten direkt hinter die vorhandenen ARE-Seiten ein.
5. Erst nach erfolgreichem Merge ersetzt die kombinierte Datei die ursprüngliche ARE-PDF.

Adobe dokumentiert `PDDoc.InsertPages` als seitenbasiertes Einfügen aus einem anderen PDF-Dokument. Dadurch werden bestehende PDF-Seiten übernommen, ohne Excel neu zu rendern.

## Fallback

Wenn Acrobat lokal keine PDF-Bearbeitung über OLE erlaubt, öffnet Word die bereits exportierte ARE-PDF und hängt die DOCX-Anschreiben an. Auch dieser Fallback greift nicht mehr auf Excel-Zellen oder eine Bildschirmdarstellung zu.

## Diagnose

Im `ARE_Generator_Diagnose.log` steht pro LTRG die verwendete Methode:

- `Methode=Adobe Acrobat PDDoc`
- ab 1.0.21 bevorzugt `Bundled Python pypdf`; alternativ `Adobe Acrobat PDDoc`. Ein Word-Reflow-Fallback wird für finale PDFs nicht mehr verwendet.
