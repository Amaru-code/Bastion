# Version 1.0.21 – layouttreuer PDF-Merge und Footer

## Problem 1: rechtlicher Footer auf eigener Seite

Die Marsh-Vorlage enthält einen kleinen rechtlichen Firmenblock am Seitenende. Bei längeren Empfänger-/Firmennamen kann dieser Block als normaler Dokumentinhalt auf eine zweite Seite rutschen. Das VBS erkennt den Block anhand von `Mercer Deutschland GmbH`/`Sitz` und verschiebt ihn in die echte Fußzeile der ersten Word-Seite.

## Problem 2: ARE-Layout verändert sich beim Anhängen

Microsoft Word kann beim Öffnen einer PDF deren Inhalt in ein editierbares Word-Dokument konvertieren. Dabei können Spaltenpositionen, Summen und Bilder verschoben werden. Deshalb werden finale Anschreiben/ARE-Pakete nicht mehr über Word neu gerendert.

`tools/pdf_merge.py` verwendet die gebündelte `pypdf`-Bibliothek und übernimmt die vorhandenen PDF-Seiten direkt. Die Reihenfolge bleibt:

1. Anschreiben-PDF
2. zugehörige ARE-PDF

Die Seiteninhalte werden nicht neu gesetzt.

## Logo-Synchronisierung

Solange `LOGO_HEIGHT` im ARE-CONFIG noch auf dem Standardwert steht, versucht das Tool die Höhe des Marsh-Logos aus der gewählten Word-Vorlage zu erkennen und für das ARE-Logo zu übernehmen. Eigene CONFIG-Werte haben Vorrang.
