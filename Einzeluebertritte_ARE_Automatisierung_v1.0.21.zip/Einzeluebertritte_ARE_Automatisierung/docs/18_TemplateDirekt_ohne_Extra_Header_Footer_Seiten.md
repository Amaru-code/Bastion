# Template-direkter Serienbrief – Version 1.0.20

## Problem

Beim nativen Word-Seriendruck konnte die verwendete Marsh-Vorlage zusätzliche Word-Sektionen erzeugen. Im resultierenden Einzel-PDF erschien das eigentliche Anschreiben korrekt auf Seite 1, anschließend jedoch eine fast leere Seite nur mit Logo/Absender und eine weitere Seite nur mit Footer.

## Lösung

Pro betroffener Gesellschaft wird die originale DOCX-Vorlage separat geöffnet. Die Serienbrieffelder werden direkt im Dokument, in Kopf-/Fußzeilen und in Text-Shapes ersetzt und anschließend entkoppelt. Das Dokument wird danach unmittelbar als DOCX und PDF gespeichert.

Erst nach diesem Export wird die bereits erzeugte ARE-PDF angehängt.

## Soll-Reihenfolge

1. Anschreiben mit Marsh-Logo, Absenderblock, Inhalt, Unterschriften und Footer auf der ursprünglichen Seite.
2. Zugehörige ARE-Übersicht.

Der native Word-Seriendruck bleibt nur als Notfallmodus erhalten, falls der template-direkte Modus technisch scheitert.
