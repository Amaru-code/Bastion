Die Datei ARE_Uebersicht_Template.xlsx wird beim ersten Start des Generators automatisch erzeugt.

Danach kann sie in Excel angepasst werden. Eine genaue Anleitung steht unter:
..\docs\12_Uebersichtsvorlage_anpassen.md

Wichtig: ARE_TEMPLATE und CONFIG nicht umbenennen.
