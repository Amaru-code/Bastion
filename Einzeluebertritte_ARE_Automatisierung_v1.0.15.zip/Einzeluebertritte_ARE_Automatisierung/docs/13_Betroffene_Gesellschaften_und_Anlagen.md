# Filterung auf betroffene Gesellschaften und Anlagen

## Betroffenenliste

Die Betroffenenliste wird aus jeder gültigen Übertrittszeile gebildet. Sowohl `LTRG neu` als auch `LTRG alt` werden aufgenommen, sofern beide Werte numerisch sind und voneinander abweichen.

## Abgleich mit der Serienbriefdatei

Das Tool erkennt die LTRG-Spalte anhand der Kopfzeile. Jeder Datensatz wird nur übernommen, wenn seine normalisierte numerische LTRG in der Betroffenenliste enthalten ist. Führende Nullen sind unschädlich: `0100` und `100` werden als dieselbe LTRG behandelt.

Ungültige oder leere LTRG-Werte werden protokolliert und übersprungen.

## Mehrere Zeilen je LTRG

Enthält die Serienbriefdatei mehrere Datensätze für dieselbe betroffene LTRG, wird für jeden Datensatz ein eigenes Anschreiben erzeugt. Die Dateinamen erhalten bei Bedarf automatisch einen Zähler, damit keine Datei überschrieben wird.

## Zuordnung der Übersicht

Die passende Übersicht wird nicht über ARE oder Dateinamen geraten, sondern über die numerische LTRG gesucht. Damit bleibt die Zuordnung korrekt, auch wenn ARE-Felder in der Serienbriefdatei leer sind oder anders formatiert wurden.
