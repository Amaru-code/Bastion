# PDF-, DOCX- und Serienbriefausgabe

## Betroffene Gesellschaften

Die Serienbriefdatei wird nicht mehr vollständig verarbeitet. Das Tool bildet zunächst aus `LTRG neu` und `LTRG alt` der ARE-Quelle eine Betroffenenliste. Nur Serienbriefzeilen mit einer LTRG aus dieser Liste werden übernommen.

Die LTRG-Spalte wird über ihre Überschrift erkannt. Unterstützt werden unter anderem `LTRG`, `LTGR`, `LGTR`, `LTRGR` und `Leistungsträger`. Für ältere Dateien bleibt Spalte A als Fallback erhalten. Die ARE-Spalte wird ebenfalls dynamisch erkannt; Spalte B ist der Fallback.

## Ordnerstruktur

```text
Output/<Quelle>_ARE_Export_<Zeitstempel>/
├── 00_Excel/
├── 01_ARE_PDF/
├── 02_Serienbrief_Gesamt/
└── 03_Serienbrief_Einzel/
```

## ARE-PDFs

```text
ERG_VWÜ_{sheet_name}.pdf
```

## Einzelanschreiben

```text
Anschrieben_ARE_{ARE}_LTRG_{LTRG}.docx
Anschrieben_ARE_{ARE}_LTRG_{LTRG}.pdf
```

Jede Einzeldatei enthält:

1. das ausgefüllte Word-Anschreiben,
2. einen Seitenumbruch,
3. die zu dieser LTRG gehörende ARE-Übersicht.

Die Übersicht wird aus `A1:F<letzte Inhaltszeile>` des generierten ARE-Blatts als erweiterte Metadatei in Word eingefügt. Das sorgt für scharfe Linien und Schrift im PDF. In Word ist die Übersicht ein Bild und nicht als Word-Tabelle editierbar.

## Gesamtserienbrief

```text
Anschreiben_ARE_Gesamt.docx
Anschreiben_ARE_Gesamt.pdf
```

Die Gesamtdateien bestehen nur aus betroffenen Gesellschaften. Die Reihenfolge lautet jeweils:

```text
Anschreiben Gesellschaft 1
ARE-Übersicht Gesellschaft 1
Anschreiben Gesellschaft 2
ARE-Übersicht Gesellschaft 2
...
```

## Word-Felder

Die DOCX-Vorlage muss echte Felder aus `Sendungen > Seriendruckfeld einfügen` enthalten. Der Feldname muss einer Kopfzeile der Serienbriefdatei entsprechen.

## Anlage

Absätze, die mit `Anlage` beginnen, erhalten keinen zusätzlichen Abstand. Die tatsächliche ARE-Übersicht wird unabhängig davon auf der Folgeseite angehängt.


## Finale ARE-PDFs ab Version 1.0.13

Nach Erstellung der Anschreiben werden die Dateien in `01_ARE_PDF` vervollstaendigt. Die Reihenfolge lautet:

1. ARE-Uebersicht der betroffenen LTRG
2. Seitenumbruch / neuer Abschnitt
3. zugehoeriges Anschreiben

Wenn mehrere Personendatensaetze dieselbe LTRG betreffen, werden alle zugeordneten Anschreiben hinter derselben ARE-Uebersicht eingefuegt. Die separaten Serienbriefdateien in `02_Serienbrief_Gesamt` und `03_Serienbrief_Einzel` bleiben bestehen.
