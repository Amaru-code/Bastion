# Logo und Vorlagenlayout

## Eindeutige lokale Logoquelle

Das Logo wird nicht aus der DOCX-Vorlage extrahiert. Eine Word-Vorlage kann mehrere Bilder enthalten, beispielsweise Logo und Unterschrift; eine automatische Auswahl wäre daher nicht eindeutig.

Das Tool sucht zuerst im Unterordner `docs` in dieser Reihenfolge:

1. `Bild 1.png`
2. `Bild 1.jpg`
3. `Bild 1.jpeg`
4. `Mercer Logo.png/.jpg/.jpeg`
5. `Mercer_Logo.png/.jpg/.jpeg`

Der Projektstamm wird nur aus Gründen der Abwärtskompatibilität als zweite Suchposition geprüft. Fehlt eine lokale Datei, öffnet sich ein Bildauswahldialog.

## Logo in der Übersicht anpassen

Die Bilddatei selbst bleibt unter `docs`. Position und Größe werden im Blatt `CONFIG` der Datei `templates/ARE_Uebersicht_Template.xlsx` eingestellt:

- `LOGO_ANCHOR`
- `LOGO_HEIGHT`
- `LOGO_LEFT_OFFSET`
- `LOGO_TOP_OFFSET`

Vor dem Einfügen werden alte Bilder im reservierten Logo-Bereich entfernt, sodass keine Unterschrift aus früheren Ausgaben bestehen bleibt.

## Word-Seriendruck

Bevorzugt wird Words native Seriendruckfunktion. Dadurch bleiben insbesondere Name, Anschrift, leere Adresszeilen, Kopf-/Fußzeilen, Bilder und Abschnittseinstellungen nah an der DOCX-Vorlage.

Ab Version 1.0.12 wird jedes betroffene Anschreiben einzeln zusammengeführt. Danach wird die zugehörige ARE-Übersicht als Vektorgrafik angehängt und das vollständige Paket als DOCX und PDF gespeichert.


## Logo-Groesse ab 1.0.13

Der Standardwert `LOGO_HEIGHT` betraegt jetzt **34 pt** statt 42 pt. Die Einstellung liegt im Blatt `CONFIG` der Datei `templates/ARE_Uebersicht_Template.xlsx`. Fuer eine eigene Groesse kann dort beispielsweise 30, 32, 34 oder 36 eingetragen werden. Das Seitenverhaeltnis bleibt automatisch erhalten. Ein noch vorhandener unveraenderter Alt-Standardwert 42 wird vom Skript automatisch als 34 behandelt.
