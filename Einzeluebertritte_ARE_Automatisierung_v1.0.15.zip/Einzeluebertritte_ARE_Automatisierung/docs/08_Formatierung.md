# Formatierung der ARE-Blätter

## Steuerung über die Excel-Vorlage

Ab Version 1.0.12 wird das sichtbare Layout aus folgender Datei übernommen:

```text
templates/ARE_Uebersicht_Template.xlsx
```

Beim ersten Start wird die Datei automatisch mit dem bisherigen Standardlayout erzeugt. Danach kann sie direkt in Excel angepasst werden. Details stehen in `12_Uebersichtsvorlage_anpassen.md`.

## Standardlayout

### Berichtskopf

- Portraitformat
- Mercer-Logo oben links
- rechts oben `Einzelübertritte <Zeitraum>`
- darunter `ARE <ARE> (LTRG <LTRG>)`
- Haupttitel zentriert und fett
- Beschreibungstext mit Abstand unter dem Haupttitel

### Tabellenbereich A:F

- Arial, 10 pt
- Abschnittsüberschriften fett, zentriert und kräftig eingerahmt
- Tabellenköpfe immer fett und zweizeilig
- Detailzeilen normal
- Beträge D:F rechtsbündig
- Zwischensummen immer fett mit oberer Trennlinie
- negative Beträge schwarz

### Kontrollbereich H:J

- Kontrollüberschriften und Kontrollsummen fett
- keine Farbfüllung und keine Rahmen
- außerhalb des Druckbereichs
- wird nicht aus der sichtbaren Vorlage übernommen, da dieser Bereich technisch bleibt

## Druck und PDF

- Druckbereich A:F bis zur letzten Inhaltszeile
- Seitenformat, Ränder und Skalierung werden aus der Vorlage übernommen
- eine Seite breit
- keine Gitternetzlinien im PDF
- Dateiname `ERG_VWÜ_{sheet_name}.pdf`

## Word-Anlage

Für Einzel-DOCX und Einzel-PDF wird derselbe Bereich A:F als Vektorgrafik nach dem Anschreiben eingefügt. Änderungen an der Excel-Vorlage wirken daher sowohl auf die ARE-PDF als auch auf die angehängte Übersicht im Anschreiben.


## Version 1.0.13 – lange Gesellschaftsnamen

Die dynamisch befuellten Erlaeuterungssaetze in den Zeilen 6 und 7 koennen bei langen Gesellschaftsnamen mehr Platz benoetigen. Deshalb setzt das Tool nach der Vorlagenuebernahme zwingend:

- `A6:F7` Schriftgroesse 9 pt
- `WrapText = True`
- `ShrinkToFit = False`
- Zeilenhoehe 28 pt
- Schriftfarbe RGB(0,15,71)
- Spalte D auf Breite 17,5

Diese Nachformatierung gilt auch dann, wenn eine bereits vorhandene `ARE_Uebersicht_Template.xlsx` benutzt wird.
