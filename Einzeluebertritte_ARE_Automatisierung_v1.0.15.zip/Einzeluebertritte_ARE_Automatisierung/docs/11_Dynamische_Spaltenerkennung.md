# Dynamische Spaltenerkennung

## Zweck

Version 1.0.11 löst die ARE-Logik vollständig von festen Excel-Spaltenbuchstaben. Maßgeblich sind die fachlichen Überschriften, nicht ihre Position.

## Unterstützte Beispiele für `Übersicht`

Bisheriger Aufbau:

```text
PNR neu | LTRG neu | PNR alt | LTRG alt | Datum ... | ... | BSAV | Pensionen (alt) | Summe
```

Neuer Aufbau mit zusätzlichen ARE-Spalten:

```text
PNR neu | LTRG neu | ARE neu | PNR alt | LTRG alt | ARE alt | Datum ... | ... | BSAV | Pensionen (alt) | Summe
```

Auch eine vollständig andere Reihenfolge ist zulässig, solange die benötigten Überschriften innerhalb derselben Kopfzeile stehen.

## Interne Standardstruktur

Nach der Erkennung werden die Werte intern immer in diese Reihenfolge gebracht:

1. PNR neu
2. LTRG neu
3. PNR alt
4. LTRG alt
5. Übertrittsdatum
6. letzter Stichtag +1, falls vorhanden
7. Monate bis Übertritt, falls vorhanden
8. BSAV
9. Pensionen (alt)
10. Summe

Damit bleibt die weitere Gruppierungs-, Vorzeichen-, Summen- und PDF-Logik unabhängig vom Aufbau der Quelldatei.

## ARE-Zuordnung

Die Felder `ARE neu` und `ARE alt` in `Übersicht` werden bewusst nicht als Stammdatenquelle verwendet. Das Tool nimmt die jeweilige LTRG und sucht dazu im Blatt `Gesellschaften`:

- ARE
- Gesellschaftsname

Damit existiert nur eine zentrale Zuordnung.

## Erkannte Schreibvarianten

Unter anderem werden erkannt:

- `LTRG neu`, `LTGR neu`, `LGTR neu`, `LTRGR neu`
- `LTRG alt`, `LTGR alt`, `LGTR alt`, `LTRGR alt`
- `Datum des Einzelübertritts`, `Übertritt`, `Übertrittsdatum`
- `Übertragungswert BSAV`, `BSAV`
- `Übertragungswert Pensionen (alt)`, `Pensionen (alt)`
- `Name`, `Gesellschaft`, `Gesellschaftsname`

Groß-/Kleinschreibung, Zeilenumbrüche, Bindestriche und Klammern werden bei der Erkennung normalisiert.

## Diagnose

Im `ARE_Generator_Diagnose.log` werden die erkannten Spalten protokolliert, beispielsweise:

```text
Übersichtskopf in Zeile 2 erkannt | pnr_new=A | ltrg_new=B | pnr_old=D | ltrg_old=E | transfer_date=G | bsav=J | pension=K | total=L
Gesellschaftskopf in Zeile 1 erkannt | ltrg=D | are=E | name=F
```
