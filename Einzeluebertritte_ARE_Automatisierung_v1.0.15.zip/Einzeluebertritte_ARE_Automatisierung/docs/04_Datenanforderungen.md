# Datenanforderungen

## ARE-Quelldatei

Unterstützt:

- `.xlsx`
- `.xlsm`

Erforderliche Blätter:

- `Übersicht`
- `Gesellschaften`

## Dynamisch erkannte Spalten in `Übersicht`

Die Position und Reihenfolge der Spalten ist beliebig. Zusätzliche Spalten wie `ARE neu` und `ARE alt` werden ignoriert. Erkannt werden:

- `PNR neu`
- `LTRG neu`, `LTGR neu`, `LGTR neu` oder `LTRGR neu`
- `PNR alt`
- `LTRG alt`, `LTGR alt`, `LGTR alt` oder `LTRGR alt`
- `Datum des Einzelübertritts` beziehungsweise `Übertritt`
- `Übertragungswert BSAV` beziehungsweise `BSAV`
- `Übertragungswert Pensionen (alt)` beziehungsweise `Pensionen (alt)`
- optional `Summe`; fehlt sie, berechnet das Tool BSAV plus Pensionen (alt)

Die Kopfzeile darf innerhalb der ersten 30 Zeilen stehen.

## Dynamisch erkannte Spalten in `Gesellschaften`

Auch hier ist die Reihenfolge beliebig. Benötigt werden die Überschriften:

- `LTRG`, `LTGR`, `LGTR` oder `LTRGR`
- `ARE`
- `Name` beziehungsweise `Gesellschaftsname`

Die ARE-Werte in den Ergebnisblättern werden grundsätzlich über die LTRG-Zuordnung aus `Gesellschaften` bezogen. Spalten `ARE neu`/`ARE alt` in `Übersicht` sind dafür nicht erforderlich.

## Word-Serienbriefvorlage

Unterstützt:

- `.docx`

Die Vorlage muss echte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten. Feldnamen müssen zu den Excel-Spaltenüberschriften passen.

Felder in Haupttext, Kopf-/Fußzeilen und Textfeldern werden berücksichtigt.

## Personendatei

Unterstützt:

- `.xlsx`
- `.xlsm`
- `.xls`

Aufbau:

- erstes Arbeitsblatt ist Datenquelle
- Zeile 1 enthält Spaltenüberschriften
- Daten beginnen in Zeile 2
- vollständig leere Zeilen werden übersprungen
- mindestens eine LTRG-Spalte muss erkennbar sein; ARE wird nach Möglichkeit ebenfalls über die Überschrift erkannt

## LTRG- und ARE-Spalten der Serienbriefdatei

Bevorzugt erkennt das Tool die Spalten anhand ihrer Überschriften:

- LTRG: `LTRG`, `LTGR`, `LGTR`, `LTRGR`, `Leistungsträger` und Varianten
- ARE: `ARE`, `ARE Nummer`, `ARE Code`, `ARE Wert` und Varianten

Nur Datensätze mit einer LTRG, die in der ARE-Quelldatei tatsächlich betroffen ist, werden verarbeitet. Falls keine passenden Überschriften erkannt werden, gilt aus Gründen der Abwärtskompatibilität:

- Spalte A = LTRG
- Spalte B = ARE

Die Dateinamen lauten:

```text
Anschrieben_ARE_{ARE}_LTRG_{LTRG}.docx
Anschrieben_ARE_{ARE}_LTRG_{LTRG}.pdf
```

## Dateinamen

Diese Zeichen werden durch `-` ersetzt:

```text
\ / : * ? " < > |
```

Bei gleichen Namen werden `_2`, `_3` usw. ergänzt.
