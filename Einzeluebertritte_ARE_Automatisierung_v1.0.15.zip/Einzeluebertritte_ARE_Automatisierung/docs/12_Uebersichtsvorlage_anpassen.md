# Übersichtsvorlage anpassen

## Speicherort

Beim ersten erfolgreichen Start legt das Tool automatisch folgende Datei an:

```text
templates/ARE_Uebersicht_Template.xlsx
```

Die Vorlage wird bei späteren Läufen nur gelesen und nicht überschrieben. Eine eigene Gestaltung bleibt daher erhalten.

## Bearbeitung

1. Tool und erzeugte Ausgabedateien schließen.
2. `templates/ARE_Uebersicht_Template.xlsx` in Excel öffnen.
3. Blatt `ARE_TEMPLATE` gestalten.
4. Datei speichern und schließen.
5. Generator erneut starten.

## Bereiche im Blatt ARE_TEMPLATE

- **Zeilen 1–7:** Kopfbereich, Metadaten, Haupttitel und Erläuterung
- **Zeile 10:** Muster für die Überschrift einer Gegenpartei
- **Zeile 11:** Muster für Tabellenköpfe
- **Zeile 12:** Muster für Detaildaten
- **Zeile 13:** Muster für die fett gedruckte Summe
- **Zeile 14:** Muster für den Abstand zum nächsten Block

Das Tool kopiert die Formate dieser Musterzeilen auf alle dynamisch erzeugten Blöcke.

## Was frei angepasst werden kann

- Schriftart, Schriftgröße und Fettung
- Schrift- und Hintergrundfarben
- Rahmen und Linienstärken
- horizontale und vertikale Ausrichtung
- Zeilenhöhen und Spaltenbreiten A:F
- Seitenformat, Ränder, Skalierung und Zentrierung
- Texte des Berichtskopfs und der Tabellenköpfe

## Platzhalter

In den Textzellen können folgende Platzhalter stehen:

| Platzhalter | Ersetzung |
|---|---|
| `{{ZEITRAUM}}` | z. B. `2025/26` |
| `{{ARE}}` | ARE der betrachteten Gesellschaft |
| `{{LTRG}}` | LTRG der betrachteten Gesellschaft |
| `{{GESELLSCHAFT_KURZ}}` | verkürzter Name der betrachteten Gesellschaft |
| `{{GEGENPARTEI_KURZ}}` | verkürzter Name der Gegenpartei |
| `{{GEGENPARTEI_ARE}}` | ARE der Gegenpartei |
| `{{GEGENPARTEI_LTRG}}` | LTRG der Gegenpartei |

Beispiel für Zeile 10:

```text
{{GEGENPARTEI_KURZ}} (ARE {{GEGENPARTEI_ARE}}, LTRG {{GEGENPARTEI_LTRG}})
```

## Logo konfigurieren

Das Bild selbst liegt weiterhin unter `docs/Bild 1.png`. Im Blatt `CONFIG` der Vorlage können folgende Werte geändert werden:

| Einstellung | Standard | Bedeutung |
|---|---:|---|
| `LOGO_ANCHOR` | `A1` | Zelle, an der das Logo ausgerichtet wird |
| `LOGO_HEIGHT` | `42` | Höhe des Logos in Punkten |
| `LOGO_LEFT_OFFSET` | `0` | horizontaler Versatz in Punkten |
| `LOGO_TOP_OFFSET` | `2` | vertikaler Versatz in Punkten |

## Nicht verändern

- Blattname `ARE_TEMPLATE`
- Blattname `CONFIG`
- Musterzeilen 10–14 nicht löschen oder zusammenlegen
- Spalten A:F nicht aus dem Blatt entfernen

Wer die Vorlage beschädigt hat, kann sie umbenennen oder löschen. Beim nächsten Start erzeugt das Tool wieder eine neue Standardvorlage. Die alte Datei vorher sichern, falls Teile der Gestaltung übernommen werden sollen.
