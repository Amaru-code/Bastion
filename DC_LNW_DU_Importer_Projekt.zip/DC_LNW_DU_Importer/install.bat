@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW DU Importer - Installation

echo ============================================================
echo  DC LNW DU Importer - Installation
echo ============================================================
echo.

where go.exe >nul 2>&1
if errorlevel 1 (
    echo FEHLER: Go wurde nicht gefunden.
    echo.
    echo Bitte Go 1.23 oder neuer installieren:
    echo https://go.dev/dl/
    echo Danach dieses Installationsskript erneut starten.
    pause
    exit /b 1
)

for /f "tokens=3" %%V in ('go version') do set "GO_VERSION=%%V"
echo Gefunden: %GO_VERSION%
echo.

echo Lade Abhaengigkeiten...
go mod download
if errorlevel 1 goto :error

echo Baue Windows-Anwendung...
go build -trimpath -ldflags="-s -w" -o "DC_LNW_DU_Importer.exe" .
if errorlevel 1 goto :error

if not exist "output" mkdir "output"

echo.
echo ============================================================
echo  Installation erfolgreich
echo ============================================================
echo Starte das Tool kuenftig ueber start.bat.
echo Outputs werden im Ordner output gespeichert.
echo.
pause
exit /b 0

:error
echo.
echo FEHLER: Installation oder Build ist fehlgeschlagen.
echo Bitte die Meldungen oberhalb pruefen.
pause
exit /b 1
