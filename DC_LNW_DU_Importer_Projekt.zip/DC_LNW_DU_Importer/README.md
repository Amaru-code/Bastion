# DC LNW – DU Importer

Windows-Tool zum Übernehmen und Fortschreiben der Bestände im Sheet **Import DC LNW**.

## Installation

1. Projektordner vollständig entpacken.
2. Go 1.23 oder neuer installieren, falls noch nicht vorhanden.
3. `install.bat` doppelt anklicken.
4. Danach das Tool über `start.bat` starten.

## Bedienung

Beim Start erscheinen zwei Windows-Dateidialoge:

1. Template-Datei auswählen (`.xlsx` oder `.xlsm`).
2. DU-Datei auswählen (`.xlsx` oder `.xlsm`).

Das Ergebnis wird automatisch als `.xlsm` im Unterordner `output` abgelegt. Der Dateiname enthält einen Zeitstempel.

## Verarbeitungslogik

- Ziel-Sheet: `Import DC LNW`
- Die Headerzeile wird automatisch anhand von `WWID` gefunden.
- Vor dem Leeren werden die bisherigen Werte aus `CL:CU` gespeichert.
- Ab Spalte `AJ` werden in Datenzeilen nur konstante Zellwerte gelöscht; Formeln und Header bleiben erhalten.
- Die gesicherten Werte aus `CL:CU` werden nach `AJ:AS` übernommen.
- DU-Daten werden nach `WWID`, `Fondsname` und `Umsatzart` aggregiert.
- `BI:BN` enthält die Umschichtungen mit `Umsatzart = Fondsportfolioanpassung`.
- `CL:CU` wird als Startbestand plus signierte DU-Bewegungen berechnet.

Berücksichtigte Bewegungsarten für `CL:CU`:

- `Wiederanlage Ertragsaussc`
- `Fondsportfolioanpassung`
- `Verkauf wegen Vorabpausch`

## Erwartete DU-Header

Die DU-Datei muss folgende Spalten enthalten. Kleine Schreibvarianten werden toleriert:

- `WWID`
- `Fondsname`
- `Umsatzart`
- `UmsatzStuecke` beziehungsweise `Umsatzstücke`
- `ZahlBetrag`

## Wichtiger Hinweis zu Makros

Bei einem `.xlsm`-Template bleibt das eingebettete VBA-Projekt erhalten. Wird ein `.xlsx`-Template gewählt, besitzt die erzeugte `.xlsm`-Datei naturgemäß kein vorhandenes VBA-Projekt, da im Ausgangstemplate keines enthalten war.

## Projektstruktur

```text
DC_LNW_DU_Importer/
├── main.go
├── go.mod
├── go.sum
├── install.bat
├── start.bat
├── README.md
└── output/
```
