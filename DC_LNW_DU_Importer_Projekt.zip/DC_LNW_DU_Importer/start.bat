@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW DU Importer

if not exist "DC_LNW_DU_Importer.exe" (
    echo Die Anwendung wurde noch nicht gebaut.
    echo install.bat wird jetzt gestartet.
    call install.bat
    if errorlevel 1 exit /b 1
)

if not exist "output" mkdir "output"
"DC_LNW_DU_Importer.exe"
