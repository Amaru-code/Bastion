﻿# DC LNW Gesamtprozess v1.1.0 - Datenaufbereitung und Template-Integration
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutputRoot = Join-Path $Root 'output'
$LogPath = Join-Path $Root 'processing.log'
$TargetSheetName = 'Import DC LNW'
$CultureDE = [Globalization.CultureInfo]::GetCultureInfo('de-DE')
$Utf8Bom = New-Object System.Text.UTF8Encoding($true)

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
[IO.File]::WriteAllText($LogPath, '', $Utf8Bom)

function Write-Log([string]$Text) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Text
    Write-Host $line
    [IO.File]::AppendAllText($LogPath, $line + [Environment]::NewLine, $Utf8Bom)
}

function Stop-WithError([string]$Text) { throw $Text }

function Select-ExcelFile([string]$Title) {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = $Title
    $dialog.Filter = 'Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'
    $dialog.Multiselect = $false
    $dialog.CheckFileExists = $true
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Stop-WithError 'Dateiauswahl wurde abgebrochen.'
    }
    return $dialog.FileName
}

function Normalize-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    return (([string]$Value).Trim().ToLowerInvariant() -replace '[\s\-_]+', ' ').Trim()
}

function Normalize-WWID([object]$Value) {
    if ($null -eq $Value) { return '' }
    $text = ([string]$Value).Trim()
    if ($text -match '^\d+([\.,]0+)?$') {
        $text = $text -replace '[\.,]0+$', ''
        $text = $text.TrimStart('0')
        if ($text -eq '') { return '0' }
        return $text
    }
    return $text.ToUpperInvariant()
}

function Get-ArrayValue($Array, [int]$Row, [int]$Column) {
    if ($Array -is [System.Array] -and $Array.Rank -eq 2) {
        return $Array.GetValue($Row, $Column)
    }
    if ($Row -eq 1 -and $Column -eq 1) { return $Array }
    return $null
}

function Convert-ToNumber([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return 0.0 }
    if ($Value -is [byte] -or $Value -is [int16] -or $Value -is [int32] -or $Value -is [int64] -or
        $Value -is [single] -or $Value -is [double] -or $Value -is [decimal]) {
        return [double]$Value
    }
    $text = ([string]$Value).Trim().Replace([char]0xA0, '')
    $number = 0.0
    foreach ($culture in @($CultureDE, [Globalization.CultureInfo]::InvariantCulture)) {
        if ([double]::TryParse($text, [Globalization.NumberStyles]::Any, $culture, [ref]$number)) {
            return $number
        }
    }
    return 0.0
}

function Is-NumericOrEmpty([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return $true }
    if ($Value -is [ValueType]) { return $true }
    $text = ([string]$Value).Trim().Replace([char]0xA0, '')
    $number = 0.0
    return [double]::TryParse($text, [Globalization.NumberStyles]::Any, $CultureDE, [ref]$number) -or
           [double]::TryParse($text, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$number)
}

function Format-CsvValue([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [double] -or $Value -is [single] -or $Value -is [decimal]) {
        return ([double]$Value).ToString('0.#################', $CultureDE)
    }
    if ($Value -is [byte] -or $Value -is [int16] -or $Value -is [int32] -or $Value -is [int64]) {
        return ([string]$Value)
    }
    return ([string]$Value).Trim()
}

function Escape-Csv([object]$Value) {
    $text = Format-CsvValue $Value
    if ($text.Contains('"')) { $text = $text.Replace('"', '""') }
    if ($text.Contains(';') -or $text.Contains('"') -or $text.Contains("`r") -or $text.Contains("`n")) {
        return '"' + $text + '"'
    }
    return $text
}

function Write-CsvLine([IO.StreamWriter]$Writer, [object[]]$Values) {
    $cells = foreach ($value in $Values) { Escape-Csv $value }
    $Writer.WriteLine(($cells -join ';'))
}

function Find-HeaderCell($Sheet, [string[]]$Aliases, [int]$MaxRows = 200) {
    $used = $Sheet.UsedRange
    $firstRow = [int]$used.Row
    $firstColumn = [int]$used.Column
    $rowCount = [Math]::Min([int]$used.Rows.Count, $MaxRows)
    $columnCount = [int]$used.Columns.Count
    if ($rowCount -lt 1 -or $columnCount -lt 1) { return $null }

    $values = $Sheet.Range(
        $Sheet.Cells.Item($firstRow, $firstColumn),
        $Sheet.Cells.Item($firstRow + $rowCount - 1, $firstColumn + $columnCount - 1)
    ).Value2
    $wanted = @($Aliases | ForEach-Object { Normalize-Text $_ })

    for ($r = 1; $r -le $rowCount; $r++) {
        for ($c = 1; $c -le $columnCount; $c++) {
            if ($wanted -contains (Normalize-Text (Get-ArrayValue $values $r $c))) {
                return [pscustomobject]@{ Row = $firstRow + $r - 1; Column = $firstColumn + $c - 1 }
            }
        }
    }
    return $null
}

function Find-DUColumns($Workbook) {
    $aliases = @{
        WWID  = @('WWID')
        Fund  = @('Fondsname', 'Fonds Name', 'Fonds')
        Type  = @('Umsatzart', 'Umsatz Art')
        Units = @('UmsatzStuecke', 'Umsatzstücke', 'Umsatz Stuecke', 'Umsatz Stücke')
        Value = @('ZahlBetrag', 'Zahl Betrag')
    }

    foreach ($sheet in @($Workbook.Worksheets)) {
        $used = $sheet.UsedRange
        $firstRow = [int]$used.Row
        $firstColumn = [int]$used.Column
        $rowCount = [Math]::Min([int]$used.Rows.Count, 100)
        $columnCount = [int]$used.Columns.Count
        if ($rowCount -lt 1 -or $columnCount -lt 1) { continue }

        $values = $sheet.Range(
            $sheet.Cells.Item($firstRow, $firstColumn),
            $sheet.Cells.Item($firstRow + $rowCount - 1, $firstColumn + $columnCount - 1)
        ).Value2

        for ($r = 1; $r -le $rowCount; $r++) {
            $found = @{}
            for ($c = 1; $c -le $columnCount; $c++) {
                $cellText = Normalize-Text (Get-ArrayValue $values $r $c)
                foreach ($key in $aliases.Keys) {
                    $normalizedAliases = @($aliases[$key] | ForEach-Object { Normalize-Text $_ })
                    if ($normalizedAliases -contains $cellText) { $found[$key] = $firstColumn + $c - 1 }
                }
            }
            if ($found.Count -eq 5) {
                return [pscustomobject]@{
                    Sheet = $sheet; HeaderRow = $firstRow + $r - 1
                    WWID = $found.WWID; Fund = $found.Fund; Type = $found.Type
                    Units = $found.Units; Value = $found.Value
                }
            }
        }
    }
    Stop-WithError 'In der DU-Datei wurden die Spalten WWID, Fondsname, Umsatzart, UmsatzStuecke und ZahlBetrag nicht gemeinsam gefunden.'
}

function Read-DUAggregates($Columns) {
    $result = @{}
    $sheet = $Columns.Sheet
    $firstDataRow = $Columns.HeaderRow + 1
    $lastDataRow = [int]$sheet.Cells.Item($sheet.Rows.Count, $Columns.WWID).End(-4162).Row
    if ($lastDataRow -lt $firstDataRow) { return $result }

    $neededColumns = @($Columns.WWID, $Columns.Fund, $Columns.Type, $Columns.Units, $Columns.Value)
    $minimumColumn = ($neededColumns | Measure-Object -Minimum).Minimum
    $maximumColumn = ($neededColumns | Measure-Object -Maximum).Maximum
    $values = $sheet.Range(
        $sheet.Cells.Item($firstDataRow, $minimumColumn),
        $sheet.Cells.Item($lastDataRow, $maximumColumn)
    ).Value2

    $relevantTypes = @(
        Normalize-Text 'Wiederanlage Ertragsaussc'
        Normalize-Text 'Fondsportfolioanpassung'
        Normalize-Text 'Verkauf wegen Vorabpausch'
    )
    $reallocationType = Normalize-Text 'Fondsportfolioanpassung'
    $processedRows = 0

    for ($r = 1; $r -le ($lastDataRow - $firstDataRow + 1); $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $values $r ($Columns.WWID - $minimumColumn + 1))
        $fund = Normalize-Text (Get-ArrayValue $values $r ($Columns.Fund - $minimumColumn + 1))
        $type = Normalize-Text (Get-ArrayValue $values $r ($Columns.Type - $minimumColumn + 1))
        if ($wwid -eq '' -or $fund -eq '') { continue }
        $processedRows++

        if (-not $result.ContainsKey($wwid)) { $result[$wwid] = @{} }
        if (-not $result[$wwid].ContainsKey($fund)) {
            $result[$wwid][$fund] = [pscustomobject]@{
                MoveUnits = 0.0; MoveValue = 0.0; ReallocationUnits = 0.0; ReallocationValue = 0.0
            }
        }

        $units = Convert-ToNumber (Get-ArrayValue $values $r ($Columns.Units - $minimumColumn + 1))
        $value = Convert-ToNumber (Get-ArrayValue $values $r ($Columns.Value - $minimumColumn + 1))
        $aggregate = $result[$wwid][$fund]

        # DU-Werte werden mit ihrem vorhandenen Vorzeichen summiert. Es wird kein Vorzeichen erfunden oder umgedreht.
        if ($relevantTypes -contains $type) {
            $aggregate.MoveUnits += $units
            $aggregate.MoveValue += $value
        }
        if ($type -eq $reallocationType) {
            $aggregate.ReallocationUnits += $units
            $aggregate.ReallocationValue += $value
        }
    }

    return [pscustomobject]@{ Data = $result; ProcessedRows = $processedRows; FirstRow = $firstDataRow; LastRow = $lastDataRow }
}

function Get-FundAggregate($FundMap, [string]$FundName) {
    $empty = [pscustomobject]@{ MoveUnits = 0.0; MoveValue = 0.0; ReallocationUnits = 0.0; ReallocationValue = 0.0 }
    if ($null -eq $FundMap) { return $empty }
    $key = Normalize-Text $FundName
    if ($FundMap.ContainsKey($key)) { return $FundMap[$key] }
    return $empty
}


function Convert-CsvCell([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return $null }
    if (Is-NumericOrEmpty $Value) { return [double](Convert-ToNumber $Value) }
    return ([string]$Value).Trim()
}

function Write-ImportBlock(
    $Sheet,
    [int]$FirstRow,
    [int]$LastRow,
    [int]$WWIDColumn,
    [int]$StartColumn,
    [string[]]$CsvColumns,
    [hashtable]$CsvByWWID
) {
    $rowCount = $LastRow - $FirstRow + 1
    $columnCount = $CsvColumns.Count
    $targetRange = $Sheet.Range(
        $Sheet.Cells.Item($FirstRow, $StartColumn),
        $Sheet.Cells.Item($LastRow, $StartColumn + $columnCount - 1)
    )
    $formulaValues = $targetRange.Formula
    $wwidValues = $Sheet.Range(
        $Sheet.Cells.Item($FirstRow, $WWIDColumn),
        $Sheet.Cells.Item($LastRow, $WWIDColumn)
    ).Value2

    $output = [Array]::CreateInstance([object], @($rowCount, $columnCount))
    $matched = 0
    $formulaCells = 0

    for ($r = 0; $r -lt $rowCount; $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $wwidValues ($r + 1) 1)
        $csvRow = $null
        if ($wwid -ne '' -and $CsvByWWID.ContainsKey($wwid)) {
            $csvRow = $CsvByWWID[$wwid]
            $matched++
        }

        for ($c = 0; $c -lt $columnCount; $c++) {
            $existingFormula = Get-ArrayValue $formulaValues ($r + 1) ($c + 1)
            if ($existingFormula -is [string] -and $existingFormula.StartsWith('=')) {
                $output.SetValue($existingFormula, $r, $c)
                $formulaCells++
            }
            elseif ($null -ne $csvRow) {
                $output.SetValue((Convert-CsvCell $csvRow.($CsvColumns[$c])), $r, $c)
            }
            else {
                $output.SetValue($null, $r, $c)
            }
        }
    }

    $targetRange.Formula = $output
    return [pscustomobject]@{ MatchedRows = $matched; PreservedFormulaCells = $formulaCells }
}

$excel = $null
$templateBook = $null
$duBook = $null
$templateSheet = $null
$outputBook = $null
$outputSheet = $null
$writers = @()

try {
    Write-Log 'Dateiauswahl wird geöffnet.'
    $templatePath = Select-ExcelFile '1/2 – Template-Datei auswählen'
    Write-Log ('Template gewählt: ' + $templatePath)
    $duPath = Select-ExcelFile '2/2 – DU-Datei auswählen'
    Write-Log ('DU-Datei gewählt: ' + $duPath)

    if ([IO.Path]::GetFullPath($templatePath) -eq [IO.Path]::GetFullPath($duPath)) {
        Stop-WithError 'Template und DU-Datei dürfen nicht dieselbe Datei sein.'
    }

    $runName = 'Auswertung_{0}' -f (Get-Date -Format 'yyyyMMdd_HHmmss')
    $runDir = Join-Path $OutputRoot $runName
    New-Item -ItemType Directory -Path $runDir -Force | Out-Null

    Write-Log 'Microsoft Excel wird ausschließlich zum blockweisen Lesen der Dateien gestartet.'
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    $excel.EnableEvents = $false
    $excel.ScreenUpdating = $false
    try { $excel.AutomationSecurity = 3 } catch {}
    try { $excel.Calculation = -4135 } catch {}

    Write-Log 'Template wird schreibgeschützt geöffnet.'
    $templateBook = $excel.Workbooks.Open($templatePath, 0, $true)
    try { $templateSheet = $templateBook.Worksheets.Item($TargetSheetName) }
    catch { Stop-WithError "Das Sheet '$TargetSheetName' wurde im Template nicht gefunden." }

    $wwidHeader = Find-HeaderCell $templateSheet @('WWID')
    if ($null -eq $wwidHeader) { Stop-WithError "Der WWID-Header wurde im Sheet '$TargetSheetName' nicht gefunden." }

    $firstTemplateRow = $wwidHeader.Row + 1
    $lastTemplateRow = [int]$templateSheet.Cells.Item($templateSheet.Rows.Count, $wwidHeader.Column).End(-4162).Row
    if ($lastTemplateRow -lt $firstTemplateRow) { Stop-WithError 'Im Template wurden unterhalb des WWID-Headers keine Datenzeilen gefunden.' }
    $templateRowCount = $lastTemplateRow - $firstTemplateRow + 1
    Write-Log ("Template-Datenbereich erkannt: $templateRowCount Zeilen.")

    # CL:CU = Excel-Spalten 90 bis 99. Sie werden nur gelesen, nie verändert.
    $wwidValues = $templateSheet.Range(
        $templateSheet.Cells.Item($firstTemplateRow, $wwidHeader.Column),
        $templateSheet.Cells.Item($lastTemplateRow, $wwidHeader.Column)
    ).Value2
    $originalCLCU = $templateSheet.Range(
        $templateSheet.Cells.Item($firstTemplateRow, 90),
        $templateSheet.Cells.Item($lastTemplateRow, 99)
    ).Value2
    Write-Log 'Originalwerte CL:CU wurden unverändert aus dem Input-Template gelesen.'

    Write-Log 'DU-Datei wird schreibgeschützt geöffnet.'
    $duBook = $excel.Workbooks.Open($duPath, 0, $true)
    $duColumns = Find-DUColumns $duBook
    Write-Log ("DU-Header erkannt: Sheet '$($duColumns.Sheet.Name)', Zeile $($duColumns.HeaderRow).")
    $duResult = Read-DUAggregates $duColumns
    $aggregates = $duResult.Data
    Write-Log ("DU-Aggregation abgeschlossen: $($duResult.ProcessedRows) Datenzeilen, $($aggregates.Count) WWIDs.")

    $startPath = Join-Path $runDir '01_template_startbestand.csv'
    $duDetailPath = Join-Path $runDir '02_du_aggregation.csv'
    $finalPath = Join-Path $runDir '03_final_import.csv'
    $checkPath = Join-Path $runDir '04_kontrolle.csv'

    $startWriter = New-Object IO.StreamWriter($startPath, $false, $Utf8Bom)
    $duWriter = New-Object IO.StreamWriter($duDetailPath, $false, $Utf8Bom)
    $finalWriter = New-Object IO.StreamWriter($finalPath, $false, $Utf8Bom)
    $checkWriter = New-Object IO.StreamWriter($checkPath, $false, $Utf8Bom)
    $writers = @($startWriter, $duWriter, $finalWriter, $checkWriter)

    $startHeaders = @('WWID','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS')
    $duHeaders = @(
        'WWID',
        'BI_DWSI_Umschichtung_Anteile','BJ_DWSI_Umschichtung_Wert',
        'BK_Eurorenta_Umschichtung_Anteile','BL_Eurorenta_Umschichtung_Wert',
        'BM_Geldmarkt_Umschichtung_Anteile','BN_Geldmarkt_Umschichtung_Wert',
        'DWSI_Bewegung_Anteile','DWSI_Bewegung_Wert',
        'Eurorenta_Bewegung_Anteile','Eurorenta_Bewegung_Wert',
        'Geldmarkt_Bewegung_Anteile','Geldmarkt_Bewegung_Wert',
        'Aktienfonds_Bewegung_Anteile','Aktienfonds_Bewegung_Wert',
        'Rentenfonds_Bewegung_Anteile','Rentenfonds_Bewegung_Wert'
    )
    $finalHeaders = @('WWID','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','BI','BJ','BK','BL','BM','BN','CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU')
    $checkHeaders = @('WWID','Template_Zeile','DU_Daten_gefunden','Startwerte_nichtnumerisch','Hinweis')

    Write-CsvLine $startWriter $startHeaders
    Write-CsvLine $duWriter $duHeaders
    Write-CsvLine $finalWriter $finalHeaders
    Write-CsvLine $checkWriter $checkHeaders

    $fundNames = @(
        'DWSI-EUR.EQ.HI.CO.FC',
        'DWS EURORENTA',
        'DWS INS.-ESG EO MO.M.IC',
        'SIEMENS EUROINVEST AKTIEN',
        'SIEMENS EUROINVEST RENTEN'
    )

    $rowsWithWWID = 0
    $rowsWithDU = 0
    $nonNumericRows = 0

    Write-Log 'CSV-Dateien werden zeilenweise erzeugt.'
    for ($r = 1; $r -le $templateRowCount; $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $wwidValues $r 1)
        if ($wwid -eq '') { continue }
        $rowsWithWWID++

        # EXAKTE 1:1-KOPIE: AJ:AS erhält in der CSV ausschließlich die ursprünglichen Werte CL:CU.
        $start = @()
        for ($c = 1; $c -le 10; $c++) { $start += (Get-ArrayValue $originalCLCU $r $c) }
        Write-CsvLine $startWriter (@($wwid) + $start)

        $fundMap = $null
        $duFound = $aggregates.ContainsKey($wwid)
        if ($duFound) { $fundMap = $aggregates[$wwid]; $rowsWithDU++ }

        $fundAgg = @()
        foreach ($fundName in $fundNames) { $fundAgg += (Get-FundAggregate $fundMap $fundName) }

        $biBn = @(
            $fundAgg[0].ReallocationUnits, $fundAgg[0].ReallocationValue,
            $fundAgg[1].ReallocationUnits, $fundAgg[1].ReallocationValue,
            $fundAgg[2].ReallocationUnits, $fundAgg[2].ReallocationValue
        )
        $movements = @()
        foreach ($aggregate in $fundAgg) { $movements += @($aggregate.MoveUnits, $aggregate.MoveValue) }
        Write-CsvLine $duWriter (@($wwid) + $biBn + $movements)

        $end = @()
        $nonNumeric = @()
        for ($i = 0; $i -lt 10; $i++) {
            $rawStart = $start[$i]
            $movement = [double]$movements[$i]
            if (-not (Is-NumericOrEmpty $rawStart)) { $nonNumeric += @($i + 1) }

            if (($null -eq $rawStart -or [string]::IsNullOrWhiteSpace([string]$rawStart)) -and [Math]::Abs($movement) -lt 0.0000000000001) {
                $end += ''
            }
            else {
                $end += ((Convert-ToNumber $rawStart) + $movement)
            }
        }

        $hint = ''
        if ($nonNumeric.Count -gt 0) {
            $nonNumericRows++
            $hint = 'Nichtnumerische Startwerte an Position(en): ' + ($nonNumeric -join ',')
        }
        elseif (-not $duFound) { $hint = 'Keine passende WWID in der DU-Datei; Endbestand entspricht Startbestand.' }

        Write-CsvLine $finalWriter (@($wwid) + $start + $biBn + $end)
        Write-CsvLine $checkWriter @($wwid, ($firstTemplateRow + $r - 1), $(if ($duFound) {'JA'} else {'NEIN'}), $nonNumeric.Count, $hint)
    }

    foreach ($writer in $writers) { $writer.Flush(); $writer.Close() }
    $writers = @()

    Write-Log 'CSV-Auswertung ist fertig. Die 03_final_import.csv wird jetzt in eine Kopie des Templates integriert.'

    $csvRows = @(Import-Csv -LiteralPath $finalPath -Delimiter ';' -Encoding UTF8)
    $csvByWWID = @{}
    foreach ($csvRow in $csvRows) {
        $csvWWID = Normalize-WWID $csvRow.WWID
        if ($csvWWID -eq '') { continue }
        if ($csvByWWID.ContainsKey($csvWWID)) {
            Stop-WithError "Die 03_final_import.csv enthält die WWID '$csvWWID' mehrfach."
        }
        $csvByWWID[$csvWWID] = $csvRow
    }
    Write-Log ("03_final_import.csv eingelesen: $($csvByWWID.Count) eindeutige WWIDs.")

    $duBook.Close($false); $duBook = $null
    $templateBook.Close($false); $templateBook = $null
    $templateSheet = $null

    $templateBaseName = [IO.Path]::GetFileNameWithoutExtension($templatePath)
    $outputPath = Join-Path $runDir ($templateBaseName + '_DC_LNW_Output.xlsm')
    $templateExtension = [IO.Path]::GetExtension($templatePath).ToLowerInvariant()

    if ($templateExtension -eq '.xlsm') {
        Copy-Item -LiteralPath $templatePath -Destination $outputPath -Force
        Write-Log 'Das ausgewählte XLSM-Template wurde 1:1 kopiert.'
    }
    else {
        Write-Log 'Das ausgewählte XLSX-Template wird als XLSM-Ausgabe gespeichert.'
        $convertBook = $excel.Workbooks.Open($templatePath, 0, $true)
        try { $convertBook.SaveAs($outputPath, 52) }
        finally {
            $convertBook.Close($false)
            if ([Runtime.InteropServices.Marshal]::IsComObject($convertBook)) {
                [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($convertBook)
            }
        }
    }

    Write-Log 'Die Output-XLSM-Datei wird geöffnet.'
    $outputBook = $excel.Workbooks.Open($outputPath, 0, $false)
    try { $outputSheet = $outputBook.Worksheets.Item($TargetSheetName) }
    catch { Stop-WithError "Das Sheet '$TargetSheetName' wurde in der Output-Datei nicht gefunden." }

    $outputWWIDHeader = Find-HeaderCell $outputSheet @('WWID')
    if ($null -eq $outputWWIDHeader) { Stop-WithError "Der WWID-Header wurde im Output-Sheet '$TargetSheetName' nicht gefunden." }
    $outputFirstRow = $outputWWIDHeader.Row + 1
    $outputLastRow = [int]$outputSheet.Cells.Item($outputSheet.Rows.Count, $outputWWIDHeader.Column).End(-4162).Row
    if ($outputLastRow -lt $outputFirstRow) { Stop-WithError 'In der Output-Datei wurden keine Datenzeilen gefunden.' }

    $used = $outputSheet.UsedRange
    $lastUsedColumn = [Math]::Max(99, [int]$used.Column + [int]$used.Columns.Count - 1)
    $clearRange = $outputSheet.Range(
        $outputSheet.Cells.Item($outputFirstRow, 36),
        $outputSheet.Cells.Item($outputLastRow, $lastUsedColumn)
    )
    try {
        $constantCells = $clearRange.SpecialCells(2)
        $constantCells.ClearContents()
        if ([Runtime.InteropServices.Marshal]::IsComObject($constantCells)) {
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($constantCells)
        }
        Write-Log 'Konstante Daten ab AJ wurden gelöscht; Header und Formeln blieben erhalten.'
    }
    catch {
        Write-Log 'Ab AJ waren keine löschbaren Konstanten vorhanden; Formeln blieben erhalten.'
    }

    $ajColumns = @('AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS')
    $biColumns = @('BI','BJ','BK','BL','BM','BN')
    $clColumns = @('CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU')

    Write-Log 'AJ:AS wird aus 03_final_import.csv eingefügt.'
    $ajResult = Write-ImportBlock $outputSheet $outputFirstRow $outputLastRow $outputWWIDHeader.Column 36 $ajColumns $csvByWWID
    Write-Log 'BI:BN wird aus 03_final_import.csv eingefügt.'
    $biResult = Write-ImportBlock $outputSheet $outputFirstRow $outputLastRow $outputWWIDHeader.Column 61 $biColumns $csvByWWID
    Write-Log 'CL:CU wird aus 03_final_import.csv eingefügt.'
    $clResult = Write-ImportBlock $outputSheet $outputFirstRow $outputLastRow $outputWWIDHeader.Column 90 $clColumns $csvByWWID

    $outputWWIDValues = $outputSheet.Range(
        $outputSheet.Cells.Item($outputFirstRow, $outputWWIDHeader.Column),
        $outputSheet.Cells.Item($outputLastRow, $outputWWIDHeader.Column)
    ).Value2
    $templateWWIDs = @{}
    for ($r = 1; $r -le ($outputLastRow - $outputFirstRow + 1); $r++) {
        $id = Normalize-WWID (Get-ArrayValue $outputWWIDValues $r 1)
        if ($id -ne '') { $templateWWIDs[$id] = $true }
    }
    $csvOnly = @($csvByWWID.Keys | Where-Object { -not $templateWWIDs.ContainsKey($_) })
    $templateOnly = @($templateWWIDs.Keys | Where-Object { -not $csvByWWID.ContainsKey($_) })

    $outputBook.Save()
    Write-Log 'Output-XLSM wurde gespeichert.'

    $importProtocolPath = Join-Path $runDir '05_importprotokoll.txt'
    $importProtocol = @"
DC LNW IMPORTPROTOKOLL
======================

Output-Datei:
$outputPath

Ziel-Sheet:
$TargetSheetName

Importquelle:
$finalPath

- Input-Template unverändert gelassen.
- Im Datenbereich ab AJ nur konstante Zellinhalte gelöscht.
- Header und Formeln erhalten.
- AJ:AS, BI:BN und CL:CU aus 03_final_import.csv eingefügt.
- Zuordnung ausschließlich über WWID.

Eindeutige WWIDs in CSV: $($csvByWWID.Count)
Eindeutige WWIDs im Output-Template: $($templateWWIDs.Count)
CSV-WWIDs ohne Template-Treffer: $($csvOnly.Count)
Template-WWIDs ohne CSV-Treffer: $($templateOnly.Count)
Erhaltene Formelzellen AJ:AS: $($ajResult.PreservedFormulaCells)
Erhaltene Formelzellen BI:BN: $($biResult.PreservedFormulaCells)
Erhaltene Formelzellen CL:CU: $($clResult.PreservedFormulaCells)

CSV-WWIDs ohne Template-Treffer:
$($csvOnly -join [Environment]::NewLine)

Template-WWIDs ohne CSV-Treffer:
$($templateOnly -join [Environment]::NewLine)
"@
    [IO.File]::WriteAllText($importProtocolPath, $importProtocol, $Utf8Bom)

    $summaryPath = Join-Path $runDir 'ZUSAMMENFASSUNG.txt'
    $summary = @"
DC LNW GESAMTPROZESS
====================

Template:
$templatePath

DU-Datei:
$duPath

Ergebnislogik:
- AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Templates, exakt 1:1.
- BI:BN = Fondsportfolioanpassung aus der DU-Datei.
- CL:CU = AJ:AS plus die bereits vorzeichenbehafteten DU-Summen.
- 03_final_import.csv wurde WWID-basiert in eine Kopie des Templates integriert.
- Das Input-Template wurde nicht verändert.

Verarbeitete Template-Zeilen mit WWID: $rowsWithWWID
Davon mit DU-Daten: $rowsWithDU
Davon ohne DU-Daten: $($rowsWithWWID - $rowsWithDU)
Zeilen mit nichtnumerischen Startwerten: $nonNumericRows

Output-XLSM:
$outputPath

Dateien:
01_template_startbestand.csv
02_du_aggregation.csv
03_final_import.csv
04_kontrolle.csv
05_importprotokoll.txt
$([IO.Path]::GetFileName($outputPath))
"@
    [IO.File]::WriteAllText($summaryPath, $summary, $Utf8Bom)

    $outputBook.Close($true); $outputBook = $null
    $outputSheet = $null
    $excel.Quit(); $excel = $null

    Write-Log ("FERTIG. Ergebnisordner: $runDir")
    Start-Process explorer.exe -ArgumentList "`"$runDir`""
    [System.Windows.Forms.MessageBox]::Show(
        "Datenaufbereitung erfolgreich abgeschlossen.`n`nErgebnisordner:`n$runDir",
        'DC LNW Gesamtprozess', 'OK', 'Information'
    ) | Out-Null
    exit 0
}
catch {
    $message = $_.Exception.Message
    Write-Log ('FEHLER: ' + $message)
    [System.Windows.Forms.MessageBox]::Show(
        "$message`n`nDetails stehen in:`n$LogPath",
        'DC LNW Gesamtprozess – Fehler', 'OK', 'Error'
    ) | Out-Null
    exit 1
}
finally {
    foreach ($writer in $writers) { try { $writer.Close() } catch {} }
    if ($null -ne $duBook) { try { $duBook.Close($false) } catch {} }
    if ($null -ne $templateBook) { try { $templateBook.Close($false) } catch {} }
    if ($null -ne $outputBook) { try { $outputBook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }
    foreach ($obj in @($outputSheet, $outputBook, $templateSheet, $duBook, $templateBook, $excel)) {
        if ($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($obj) } catch {}
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
