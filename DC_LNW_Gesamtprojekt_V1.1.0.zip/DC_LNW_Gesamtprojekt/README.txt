DC LNW GESAMTPROZESS – VERSION 1.1.0
====================================

START
-----
1. ZIP vollständig entpacken.
2. Alle geöffneten Excel-Dateien schließen.
3. start.bat doppelklicken.
4. Zuerst das Template, danach die DU-Datei auswählen.

ERGEBNIS
--------
Das Tool erzeugt im Ordner output einen neuen Zeitstempel-Ordner mit:

- 01_template_startbestand.csv
- 02_du_aggregation.csv
- 03_final_import.csv
- 04_kontrolle.csv
- 05_importprotokoll.txt
- ZUSAMMENFASSUNG.txt
- einer neuen *_DC_LNW_Output.xlsm

FESTE FACHLOGIK
---------------
AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Templates, exakt 1:1.
BI:BN = Fondsportfolioanpassungen aus der DU-Datei.
CL:CU = Startwerte plus bereits vorzeichenbehaftete relevante DU-Bewegungen.

EXCEL-INTEGRATION
-----------------
- Das ausgewählte Template wird kopiert. Das Original wird nicht verändert.
- Bearbeitet wird ausschließlich das Sheet "Import DC LNW".
- Im Datenbereich ab AJ werden nur konstante Zellinhalte gelöscht.
- Header und Formeln bleiben erhalten.
- Danach werden AJ:AS, BI:BN und CL:CU aus der erzeugten 03_final_import.csv eingefügt.
- Die Zuordnung erfolgt über WWID, nicht über die Reihenfolge der Zeilen.
- Andere Sheets, Formatierungen und Makros bleiben erhalten.

VORAUSSETZUNGEN
---------------
- Windows
- Windows PowerShell
- Microsoft Excel Desktop

Es wird weder Go noch Python benötigt. Es gibt keine Installation und keine install.bat.

FEHLERPROTOKOLL
---------------
processing.log liegt direkt neben start.bat.
