@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW Gesamtprozess

where powershell.exe >nul 2>&1
if errorlevel 1 (
  echo FEHLER: Windows PowerShell wurde nicht gefunden.
  pause
  exit /b 1
)

powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0DC_LNW_Datenaufbereitung.ps1"
set "RC=%ERRORLEVEL%"

if not "%RC%"=="0" (
  echo.
  echo Verarbeitung mit Fehler beendet. Siehe processing.log.
  pause
)
exit /b %RC%
