# Changelog

## 1.0.13 – 19.08.2026

- Lange Gesellschaftsnamen in den Erlaeuterungszeilen werden nicht mehr abgeschnitten: A6:F7 mit 9 pt, Textumbruch und 28 pt Zeilenhoehe.
- Sichtbare ARE-Schriftfarbe auf Marsh RGB(0,15,71) vereinheitlicht.
- Spalte D `Pensionen (alt)` auf 17,5 verbreitert.
- Standard-Logohoehe auf 34 pt reduziert; alter Standardwert 42 wird automatisch migriert.
- Finale Dateien in `01_ARE_PDF` enthalten nun zuerst die ARE-Uebersicht und anschliessend das jeweilige Anschreiben.
- Bei mehreren Anschreiben fuer dieselbe LTRG werden alle Anschreiben hinter dieselbe ARE-Uebersicht gesetzt.
- Bestehende Einzel- und Gesamt-Serienbriefausgaben bleiben erhalten.

## 1.0.12 – 30.07.2026

- Serienbriefdaten werden dynamisch über eine LTRG-Spalte erkannt und auf die tatsächlich betroffenen Gesellschaften gefiltert.
- Nicht betroffene Gesellschaften erhalten kein Anschreiben.
- LTRG-/ARE-Spalten der Serienbriefdatei dürfen umsortiert sein; Überschriftenvarianten werden erkannt, A/B bleiben als Fallback erhalten.
- Jede betroffene Gesellschaft erhält neben der Einzel-PDF nun auch eine Einzel-DOCX.
- An jedes Einzelanschreiben wird nach einem Seitenumbruch die passende ARE-Übersicht angehängt.
- Die ARE-Übersicht wird als skalierte Vektorgrafik eingebettet und erscheint dadurch identisch in DOCX und PDF.
- Gesamt-DOCX und Gesamt-PDF werden aus den vollständigen Gesellschaftspaketen Anschreiben + Übersicht aufgebaut.
- Vollständigkeitsprüfung berücksichtigt nun Einzel-DOCX und Einzel-PDF.
- Anpassbare Excel-Vorlage `templates/ARE_Uebersicht_Template.xlsx` eingeführt.
- Fehlende Übersichtsvorlage wird beim ersten Lauf automatisch mit dem bisherigen Standardlayout erstellt.
- Statischer Berichtskopf, Musterzeilen, Spaltenbreiten, Zeilenhöhen, Seitenränder und Formatierungen werden aus der Vorlage übernommen.
- Platzhalter für Zeitraum, ARE, LTRG, Gesellschaft und Gegenpartei eingeführt.
- Logo-Anker, Höhe und Versatz können im Blatt `CONFIG` der Übersichtsvorlage angepasst werden.

## 1.0.11 – 30.07.2026

- Feste Spaltenpositionen in `Übersicht` vollständig entfernt.
- Kopfzeile wird in den ersten 30 Zeilen und bis zu 100 Spalten automatisch erkannt.
- Spalten dürfen beliebig angeordnet sein; zusätzliche Felder wie `ARE neu` und `ARE alt` sind erlaubt.
- Unterstützt die Schreibweisen `LTRG`, `LTGR`, `LGTR` und `LTRGR`.
- Daten werden in eine kanonische interne Struktur überführt, sodass die bestehende ARE-/PDF-Logik unverändert korrekt arbeitet.
- `Summe` ist optional und wird bei Bedarf aus BSAV plus Pensionen (alt) gebildet.
- Auch `Gesellschaften` wird dynamisch über die Überschriften LTRG, ARE und Name gelesen.
- ARE-Werte werden zentral über LTRG aus `Gesellschaften` bezogen; `ARE neu`/`ARE alt` in `Übersicht` sind nicht erforderlich.
- CHECK-Formeln verwenden die tatsächlich erkannten Quellspalten statt fester Buchstaben B, D und J.
- Blattnamenerkennung für Übersicht/Gesellschaften toleranter gestaltet.
- VBS-Starter, VBA-Modul und Dokumentation synchron aktualisiert.


## 1.0.10 – 29.07.2026

- Feste Logoquelle auf den Unterordner `docs` umgestellt; bevorzugter Pfad ist `docs/Bild 1.png`.
- Projektstamm bleibt nur als Abwärtskompatibilität eine zweite Suchposition.
- Word-Dokumente werden nach dem Export fehlertolerant geschlossen.
- Fehler `-2147417848` nach dem letzten Personendatensatz wird als Bereinigungswarnung behandelt, wenn Gesamt-DOCX, Gesamt-PDF und alle Einzel-PDFs vorhanden sind.
- Unvollständige native Serienbriefausgaben wechseln weiterhin automatisch in den kompatiblen Fallback.
- Dokumentation und Diagnosehinweise aktualisiert.

## 1.0.9 – 29.07.2026

- Falsche Unterschrift in den ARE-/LTRG-PDFs behoben.
- Bilder werden nicht mehr automatisch aus der DOCX-Serienbriefvorlage kopiert.
- Das Tool verwendet bevorzugt `Bild 1.png`, `Bild 1.jpg` oder `Bild 1.jpeg` direkt neben der VBS-Datei.
- Alternativ werden `Mercer Logo.*` und `Mercer_Logo.*` erkannt.
- Fehlt eine lokale Logodatei, erscheint weiterhin ein manueller Bildauswahldialog.
- Vor dem Einfügen werden alte Bilder im reservierten Logo-Bereich oben links entfernt.
- Serienbrief- und ARE-Datenlogik bleiben unverändert.

## 1.0.8 – 29.07.2026

- Zentralen Projektordner `Output` eingeführt.
- Jeder Lauf erhält einen eigenen Zeitstempelordner und die Unterordner `00_Excel`, `01_ARE_PDF`, `02_Serienbrief_Gesamt` und `03_Serienbrief_Einzel`.
- ARE-PDF-Layout an die gelieferte Idealansicht angepasst: Portraitformat, Mercer-Logo links, Berichtszeitraum und ARE-/LTRG-Kennung rechts, zentrierter Titel und größere Abstände.
- Tabellenbreiten und Zeilenhöhen so angepasst, dass `Pensionen (alt)`, `BSAV` und `Summe` sauber zweizeilig erscheinen.
- Mercer-Logo wird automatisch aus der ausgewählten DOCX-Vorlage übernommen.
- Falls die automatische Logoübernahme scheitert, wird optional eine PNG-/JPG-Datei abgefragt.
- Berichtszeitraum wird aus dem Quelldateinamen abgeleitet, beispielsweise `2025` → `2024/25`.
- Serienbrief verwendet bevorzugt den nativen Microsoft-Word-Seriendruck statt einer manuellen Dokumentverkettung.
- Leere Seriendruckzeilen werden unterdrückt, damit Name und Anschrift dem Vorlagenlayout entsprechen.
- Die Schlusszeile `Anlage` wird ohne zusätzlichen Absatzabstand formatiert, um ein unnötiges Ausweichen auf Seite 2 zu vermeiden.
- Kompatibler bisheriger Feldmodus bleibt als automatischer Fallback erhalten.


## 1.0.7 – 29.07.2026

- Tabellenköpfe, Abschnittsüberschriften, Zwischensummen und Kontrollsummen werden immer fett formatiert.
- Detailzeilen werden normal statt fett dargestellt.
- Jedes erzeugte ARE-/LTRG-Blatt wird als separate PDF exportiert.
- ARE-PDF-Dateinamen folgen `ERG_VWÜ_{sheet_name}.pdf`.
- VBS fragt zusätzlich nach einer DOCX-Serienbriefvorlage.
- VBS fragt zusätzlich nach einer Excel-Datei mit Personendaten.
- Serienbrief wird als Gesamt-DOCX und Gesamt-PDF gespeichert.
- Je Person wird eine eigene PDF erzeugt.
- Einzeldateinamen folgen `Anschrieben_ARE_{Spalte B}_LTRG_{Spalte A}.pdf`.
- Erstes Arbeitsblatt und Zeile 1 werden als Datenquelle und Feldnamenzeile verwendet.
- Word-Felder in Haupttext, Kopf-/Fußzeilen und Textfeldern werden verarbeitet.
- Ungültige Dateinamenszeichen werden abgesichert.
- Bestehende Ausgaben werden nicht überschrieben.
- VBA-Modul um separaten ARE-PDF-Export ergänzt.

## 1.0.6 – 29.07.2026

- Formatierung der erzeugten ARE-Blätter an das gelieferte Zielbild angepasst.
- Farbige Titel-, Abschnitts-, Kopf- und Kontrollbereiche entfernt.
- Kompaktes weißes Berichtslayout mit schwarzer Schrift eingeführt.
- Abschnittsüberschriften werden kräftig eingerahmt; Tabellenköpfe bleiben farbfrei.
- Detailzeilen besitzen kein durchgehendes Tabellenraster mehr.
- Zwischensummen erhalten nur noch eine obere Trennlinie in den Betragsspalten.
- Spaltenbreiten, Schriftgrößen und Zeilenhöhen wurden auf die kompakte Zielansicht reduziert.
- Negative Werte werden schwarz statt rot dargestellt.
- Druckbereich auf A:F begrenzt; der technische Kontrollbereich H:J liegt außerhalb des Druckbereichs.
- Erzeugte ARE-Blätter werden in der Seitenumbruchvorschau bei 58 % gespeichert.
- VBS-Starter und direkt importierbares VBA-Modul wurden synchron aktualisiert.

## 1.0.5 – 29.07.2026

- Excel-COM-Fehler 1004 beim Erstellen des ersten ARE-Blatts behoben.
- Problematischen Aufruf `Worksheets.Add(Empty, ...)` entfernt.
- Neue Blätter werden nun mit der stabilen parameterlosen COM-Variante `Worksheets.Add` erstellt.
- Das anschließende Verschieben ans Ende der Arbeitsmappe ist nur noch ein nicht-kritischer Schritt.
- Vor der Blatt-Erstellung wird geprüft, ob die Arbeitsmappenstruktur geschützt ist; in diesem Fall erscheint eine klare Handlungsanweisung.
- Diagnoseprotokoll um Warnungen beim optionalen Verschieben von Blättern erweitert.

## 1.0.4 – 2026-07-29

- Den weiterhin auftretenden Fehler 13 `Type mismatch` in der bisherigen Sammelphase `Quellblätter prüfen` umfassend behoben.
- Die Ermittlung der letzten Datenzeile verwendet nicht mehr die fehleranfällige Kombination aus Excel-`End(xlUp)` und verschachtelten Typkonvertierungen.
- `Übersicht!A2:D2` wird ausschließlich über sichere Einzelzell-Leser validiert.
- Die Übertrittsdaten werden nicht mehr als kompletter COM-SAFEARRAY-Block übernommen, sondern Zelle für Zelle in ein kontrolliertes VBScript-Array eingelesen.
- Excel-Fehlerwerte werden beim Einlesen als leer behandelt; Zahlen, Texte und Datumsserien bleiben erhalten.
- Auch das Blatt `Gesellschaften` wird über die sichere Leseroutine verarbeitet.
- Der Starter erstellt `ARE_Generator_Diagnose.log` im Projektordner.
- Fehlermeldungen zeigen jetzt die Tool-Version und eine deutlich genauere Unterphase.
- XLSX- und XLSM-Verarbeitung sowie die unveränderte Quelldatei bleiben erhalten.

## 1.0.3 – 2026-07-29

- Fehler 13 `Type mismatch` in der Phase `Quellblätter prüfen` behoben.
- Excel-Fehlerwerte, leere Zellen und `Null` werden im VBS jetzt anhand ihres Variant-Typs geprüft, bevor eine Text- oder Zahlenkonvertierung erfolgt.
- Die vier erwarteten Überschriften in `Übersicht!A2:D2` werden einzeln und ohne nicht-kurzschließende `Or`-Kette validiert.
- Bei tatsächlich abweichenden Überschriften zeigt die Meldung nun die gefundenen Werte aus A2 bis D2 an.
- XLSX- und XLSM-Verarbeitung sowie die sichere Ausgabekopie bleiben unverändert.

## 1.0.2 – 2026-07-29

- Fehler 500 `Variable is undefined` in der VBS-Ausführung behoben.
- Die VBA-spezifische Funktion `IsError(...)` wurde durch die VBScript-kompatible Prüfung `VarType(...)=10` ersetzt.
- Fehlermeldungen nennen jetzt zusätzlich die Verarbeitungsphase und die Fehlerquelle.
- Der Starter wurde statisch auf nicht deklarierte Variablen und verbleibende `IsError`-Aufrufe geprüft.

## 1.0.1 – 2026-07-29

- Dateiauswahl unterstützt jetzt `.xlsm` und `.xlsx`.
- Die Ausgabedatei behält automatisch das Format der Quelldatei bei.
- Fehlermeldungen und Dokumentation wurden entsprechend angepasst.

## 1.0.0

- Erste Projektversion mit VBS-Ausführung, VBA-Modul und Dokumentation.
