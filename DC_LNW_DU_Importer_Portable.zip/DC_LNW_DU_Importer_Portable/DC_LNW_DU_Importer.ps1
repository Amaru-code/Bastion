Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$TargetSheet = 'Import DC LNW'
$MovementTypes = @(
    'wiederanlage ertragsaussc',
    'fondsportfolioanpassung',
    'verkauf wegen vorabpausch'
)
$ReallocationType = 'fondsportfolioanpassung'

$Funds = @(
    [pscustomobject]@{ DUName='DWSI-EUR.EQ.HI.CO.FC'; StartUnits='AJ'; StartValue='AK'; EndUnits='CL'; EndValue='CM'; ReallocUnits='BI'; ReallocValue='BJ' },
    [pscustomobject]@{ DUName='DWS EURORENTA'; StartUnits='AL'; StartValue='AM'; EndUnits='CN'; EndValue='CO'; ReallocUnits='BK'; ReallocValue='BL' },
    [pscustomobject]@{ DUName='DWS INS.-ESG EO MO.M.IC'; StartUnits='AN'; StartValue='AO'; EndUnits='CP'; EndValue='CQ'; ReallocUnits='BM'; ReallocValue='BN' },
    [pscustomobject]@{ DUName='SIEMENS EUROINVEST AKTIEN'; StartUnits='AP'; StartValue='AQ'; EndUnits='CR'; EndValue='CS'; ReallocUnits=''; ReallocValue='' },
    [pscustomobject]@{ DUName='SIEMENS EUROINVEST RENTEN'; StartUnits='AR'; StartValue='AS'; EndUnits='CT'; EndValue='CU'; ReallocUnits=''; ReallocValue='' }
)

function Normalize-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = [string]$Value
    $s = $s.Trim().ToLowerInvariant()
    $s = $s -replace '[\s\-_]+', ' '
    return $s.Trim()
}

function Normalize-WWID([object]$Value) {
    if ($null -eq $Value) { return '' }
    $s = ([string]$Value).Trim()
    if ($s -match '^\d+([\.,]0+)?$') {
        return ($s -replace '[\.,]0+$','').TrimStart('0')
    }
    return $s.ToUpperInvariant()
}

function Select-ExcelFile([string]$Title) {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = $Title
    $dialog.Filter = 'Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'
    $dialog.Multiselect = $false
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        throw 'Dateiauswahl wurde abgebrochen.'
    }
    return $dialog.FileName
}

function Column-ToNumber([string]$Column) {
    $n = 0
    foreach ($c in $Column.ToUpperInvariant().ToCharArray()) {
        $n = $n * 26 + ([int][char]$c - [int][char]'A' + 1)
    }
    return $n
}

function Get-CellText($Sheet, [int]$Row, [int]$Col) {
    $v = $Sheet.Cells.Item($Row, $Col).Value2
    if ($null -eq $v) { return '' }
    return ([string]$v).Trim()
}

function Find-Header($Sheet, [string[]]$Aliases, [int]$MaxRows = 100) {
    $used = $Sheet.UsedRange
    $maxRow = [Math]::Min([int]$used.Rows.Count + [int]$used.Row - 1, $MaxRows)
    $maxCol = [int]$used.Columns.Count + [int]$used.Column - 1
    $normAliases = @($Aliases | ForEach-Object { Normalize-Text $_ })
    for ($r = 1; $r -le $maxRow; $r++) {
        for ($c = 1; $c -le $maxCol; $c++) {
            $x = Normalize-Text (Get-CellText $Sheet $r $c)
            if ($normAliases -contains $x) {
                return [pscustomobject]@{ Row=$r; Col=$c }
            }
        }
    }
    return $null
}

function Find-DUColumns($Workbook) {
    $aliases = @{
        WWID  = @('WWID')
        Fund  = @('Fondsname','Fonds Name','Fonds')
        Type  = @('Umsatzart','Umsatz Art')
        Units = @('UmsatzStuecke','Umsatzstücke','Umsatz Stuecke','Umsatz Stücke')
        Value = @('ZahlBetrag','Zahl Betrag')
    }
    foreach ($sheet in @($Workbook.Worksheets)) {
        for ($r = 1; $r -le [Math]::Min(100, [int]$sheet.UsedRange.Rows.Count + [int]$sheet.UsedRange.Row - 1); $r++) {
            $found = @{}
            $maxCol = [int]$sheet.UsedRange.Columns.Count + [int]$sheet.UsedRange.Column - 1
            for ($c = 1; $c -le $maxCol; $c++) {
                $text = Normalize-Text (Get-CellText $sheet $r $c)
                foreach ($key in $aliases.Keys) {
                    if (@($aliases[$key] | ForEach-Object { Normalize-Text $_ }) -contains $text) {
                        $found[$key] = $c
                    }
                }
            }
            if ($found.Count -eq 5) {
                return [pscustomobject]@{ Sheet=$sheet; HeaderRow=$r; WWID=$found.WWID; Fund=$found.Fund; Type=$found.Type; Units=$found.Units; Value=$found.Value }
            }
        }
    }
    throw 'Die DU-Spalten WWID, Fondsname, Umsatzart, UmsatzStuecke und ZahlBetrag wurden nicht gemeinsam gefunden.'
}

function To-Double([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return 0.0 }
    if ($Value -is [double] -or $Value -is [decimal] -or $Value -is [int] -or $Value -is [long]) { return [double]$Value }
    $s = ([string]$Value).Trim().Replace([char]0xA0, '')
    $cultures = @([Globalization.CultureInfo]::GetCultureInfo('de-DE'), [Globalization.CultureInfo]::InvariantCulture)
    foreach ($culture in $cultures) {
        $result = 0.0
        if ([double]::TryParse($s, [Globalization.NumberStyles]::Any, $culture, [ref]$result)) { return $result }
    }
    return 0.0
}

function Get-Aggregates($DUColumns) {
    $agg = @{}
    $sheet = $DUColumns.Sheet
    $lastRow = [int]$sheet.UsedRange.Rows.Count + [int]$sheet.UsedRange.Row - 1
    for ($r = $DUColumns.HeaderRow + 1; $r -le $lastRow; $r++) {
        $wwid = Normalize-WWID $sheet.Cells.Item($r, $DUColumns.WWID).Value2
        $fund = Normalize-Text $sheet.Cells.Item($r, $DUColumns.Fund).Value2
        $type = Normalize-Text $sheet.Cells.Item($r, $DUColumns.Type).Value2
        if ([string]::IsNullOrWhiteSpace($wwid) -or [string]::IsNullOrWhiteSpace($fund)) { continue }
        if (-not $agg.ContainsKey($wwid)) { $agg[$wwid] = @{} }
        if (-not $agg[$wwid].ContainsKey($fund)) {
            $agg[$wwid][$fund] = [pscustomobject]@{ MovementUnits=0.0; MovementValue=0.0; ReallocUnits=0.0; ReallocValue=0.0 }
        }
        $units = To-Double $sheet.Cells.Item($r, $DUColumns.Units).Value2
        $value = To-Double $sheet.Cells.Item($r, $DUColumns.Value).Value2
        $item = $agg[$wwid][$fund]
        if ($MovementTypes -contains $type) {
            $item.MovementUnits += $units
            $item.MovementValue += $value
        }
        if ($type -eq $ReallocationType) {
            $item.ReallocUnits += $units
            $item.ReallocValue += $value
        }
    }
    return $agg
}

$excel = $null
$templateBook = $null
$duBook = $null
try {
    Write-Host '============================================================'
    Write-Host ' DC LNW - DU Importer (portable, ohne Go)'
    Write-Host '============================================================'

    $template = Select-ExcelFile 'Template-Datei auswählen'
    $du = Select-ExcelFile 'DU-Datei auswählen'

    $baseDir = Split-Path -Parent $MyInvocation.MyCommand.Path
    $outputDir = Join-Path $baseDir 'output'
    New-Item -ItemType Directory -Path $outputDir -Force | Out-Null
    $baseName = [IO.Path]::GetFileNameWithoutExtension($template)
    $safeName = $baseName -replace '[<>:"/\\|?*]', '_'
    $output = Join-Path $outputDir ("{0}_DU_Import_{1}.xlsm" -f $safeName, (Get-Date -Format 'yyyyMMdd_HHmmss'))
    Copy-Item -LiteralPath $template -Destination $output -Force

    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    $excel.EnableEvents = $false

    $templateBook = $excel.Workbooks.Open($output, 0, $false)
    $duBook = $excel.Workbooks.Open($du, 0, $true)

    try { $target = $templateBook.Worksheets.Item($TargetSheet) } catch { throw "Sheet '$TargetSheet' wurde im Template nicht gefunden." }
    $wwidHeader = Find-Header $target @('WWID') 200
    if ($null -eq $wwidHeader) { throw "WWID-Header wurde im Sheet '$TargetSheet' nicht gefunden." }
    $lastRow = $target.Cells.Item($target.Rows.Count, $wwidHeader.Col).End(-4162).Row
    if ($lastRow -le $wwidHeader.Row) { throw 'Keine Ziel-Datenzeilen gefunden.' }

    $duColumns = Find-DUColumns $duBook
    $aggregates = Get-Aggregates $duColumns

    $firstDataRow = $wwidHeader.Row + 1
    $lastUsedCol = [int]$target.UsedRange.Columns.Count + [int]$target.UsedRange.Column - 1
    $aj = Column-ToNumber 'AJ'; $cl = Column-ToNumber 'CL'; $cu = Column-ToNumber 'CU'

    # CL:CU sichern.
    $snapshot = $target.Range($target.Cells.Item($firstDataRow, $cl), $target.Cells.Item($lastRow, $cu)).Value2

    # Nur Nicht-Formelwerte ab AJ löschen; Header bleiben bestehen.
    for ($r = $firstDataRow; $r -le $lastRow; $r++) {
        for ($c = $aj; $c -le $lastUsedCol; $c++) {
            $cell = $target.Cells.Item($r, $c)
            if (-not $cell.HasFormula) { $cell.ClearContents() }
        }
    }

    # CL:CU nach AJ:AS übernehmen.
    $target.Range($target.Cells.Item($firstDataRow, $aj), $target.Cells.Item($lastRow, $aj + 9)).Value2 = $snapshot

    for ($r = $firstDataRow; $r -le $lastRow; $r++) {
        $wwid = Normalize-WWID $target.Cells.Item($r, $wwidHeader.Col).Value2
        if ([string]::IsNullOrWhiteSpace($wwid)) { continue }
        $fundMap = if ($aggregates.ContainsKey($wwid)) { $aggregates[$wwid] } else { @{} }

        foreach ($f in $Funds) {
            $key = Normalize-Text $f.DUName
            $t = if ($fundMap.ContainsKey($key)) { $fundMap[$key] } else { [pscustomobject]@{ MovementUnits=0.0; MovementValue=0.0; ReallocUnits=0.0; ReallocValue=0.0 } }
            if ($f.ReallocUnits) {
                $target.Range("$($f.ReallocUnits)$r").Value2 = $t.ReallocUnits
                $target.Range("$($f.ReallocValue)$r").Value2 = $t.ReallocValue
            }
            $startUnits = To-Double $target.Range("$($f.StartUnits)$r").Value2
            $startValue = To-Double $target.Range("$($f.StartValue)$r").Value2
            $target.Range("$($f.EndUnits)$r").Value2 = $startUnits + $t.MovementUnits
            $target.Range("$($f.EndValue)$r").Value2 = $startValue + $t.MovementValue
        }
    }

    # 52 = xlOpenXMLWorkbookMacroEnabled (.xlsm)
    $templateBook.SaveAs($output, 52)
    $templateBook.Close($true)
    $templateBook = $null
    $duBook.Close($false)
    $duBook = $null
    $excel.Quit()
    $excel = $null

    Write-Host ''
    Write-Host 'Ergebnis erstellt:'
    Write-Host $output
    Start-Process explorer.exe -ArgumentList "/select,`"$output`""
    [System.Windows.Forms.MessageBox]::Show("Die Datei wurde erfolgreich erstellt:`n`n$output", 'DC LNW DU Importer', 'OK', 'Information') | Out-Null
    exit 0
}
catch {
    $message = $_.Exception.Message
    Write-Host ''
    Write-Host "FEHLER: $message" -ForegroundColor Red
    [System.Windows.Forms.MessageBox]::Show($message, 'DC LNW DU Importer - Fehler', 'OK', 'Error') | Out-Null
    exit 1
}
finally {
    if ($null -ne $duBook) { try { $duBook.Close($false) } catch {} }
    if ($null -ne $templateBook) { try { $templateBook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }
    foreach ($obj in @($duBook, $templateBook, $excel)) {
        if ($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)) {
            [void][Runtime.InteropServices.Marshal]::ReleaseComObject($obj)
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
