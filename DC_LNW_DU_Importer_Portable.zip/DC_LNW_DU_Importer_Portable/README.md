# DC LNW DU Importer – portable Version

Diese Version benötigt **keine Go-Installation**, keine Python-Installation und keinen Build.

## Voraussetzung

- Windows 10 oder Windows 11
- Microsoft Excel Desktop
- Windows PowerShell 5.1, standardmäßig in Windows enthalten

## Start

1. ZIP vollständig entpacken.
2. `start.bat` doppelklicken.
3. Template-Datei auswählen.
4. DU-Datei auswählen.
5. Die erzeugte XLSM-Datei liegt im Ordner `output`.

`install.bat` legt nur den Output-Ordner an und prüft keine Go-Installation mehr.

## Technische Umsetzung

Die portable Ausführung erfolgt über `DC_LNW_DU_Importer.ps1` und Microsoft Excel COM. Dadurch wird das Template direkt durch Excel geöffnet und wieder als XLSM gespeichert. Makros, Formatierungen, Formeln und sonstige Arbeitsmappenbestandteile bleiben dadurch besser erhalten als bei einer Neugenerierung der Datei.

## Fachliche Logik

- Ziel-Sheet: `Import DC LNW`
- Header werden beibehalten.
- Ab Spalte `AJ` werden nur konstante Zellinhalte gelöscht; Formeln bleiben bestehen.
- Vor dem Löschen wird `CL:CU` gesichert und anschließend nach `AJ:AS` übernommen.
- `BI:BN` wird über `Fondsportfolioanpassung` aggregiert.
- `CL:CU` wird aus Startbestand plus den signierten DU-Bewegungen berechnet.
