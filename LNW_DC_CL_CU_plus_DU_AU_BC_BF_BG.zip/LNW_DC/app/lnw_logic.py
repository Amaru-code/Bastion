from __future__ import annotations

import csv
import json
import logging
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pythoncom
import win32com.client


XL_CELL_TYPE_CONSTANTS = 2
XL_BY_ROWS = 1
XL_BY_COLUMNS = 2
XL_PREVIOUS = 2
XL_LOOK_IN_FORMULAS = -4123
XL_OPEN_XML_WORKBOOK_MACRO_ENABLED = 52


@dataclass(frozen=True)
class FundMapping:
    source_fund: str
    start_shares_col: str
    start_value_col: str
    end_shares_col: str
    end_value_col: str
    realloc_shares_col: str | None = None
    realloc_value_col: str | None = None


FUND_MAPPINGS: tuple[FundMapping, ...] = (
    FundMapping(
        "DWSI-EUR.EQ.HI.CO.FC", "AJ", "AK", "CL", "CM", "BI", "BJ"
    ),
    FundMapping("DWS EURORENTA", "AL", "AM", "CN", "CO", "BK", "BL"),
    FundMapping(
        "DWS INS.-ESG EO MO.M.IC", "AN", "AO", "CP", "CQ", "BM", "BN"
    ),
    FundMapping("SIEMENS EUROINVEST AKTIEN", "AP", "AQ", "CR", "CS"),
    FundMapping("SIEMENS EUROINVEST RENTEN", "AR", "AS", "CT", "CU"),
)

PREVIOUS_TO_CURRENT: tuple[tuple[str, str], ...] = (
    ("CL", "AJ"), ("CM", "AK"), ("CN", "AL"), ("CO", "AM"),
    ("CP", "AN"), ("CQ", "AO"), ("CR", "AP"), ("CS", "AQ"),
    ("CT", "AR"), ("CU", "AS"),
)


def normalize(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).replace("\xa0", " ").strip().casefold()
    return re.sub(r"\s+", " ", text)


def normalize_wwid(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = str(value).strip()
    if text.endswith(".0") and text[:-2].isdigit():
        return text[:-2]
    return text


def as_number(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(" ", "")
    if not text:
        return 0.0
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        text = text.replace(".", "").replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return 0.0


def col_to_num(col: str) -> int:
    result = 0
    for char in col.upper():
        result = result * 26 + (ord(char) - 64)
    return result


def load_settings(project_root: Path) -> dict[str, Any]:
    path = project_root / "config" / "settings.json"
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


class LNWProcessor:
    def __init__(self, project_root: Path, progress_callback=None):
        self.project_root = project_root
        self.settings = load_settings(project_root)
        self.progress_callback = progress_callback or (lambda _message: None)
        self.logger = logging.getLogger("LNW_DC")

    def progress(self, message: str) -> None:
        self.logger.info(message)
        self.progress_callback(message)

    def run(
        self,
        template_path: Path,
        du_path: Path,
        output_dir: Path,
        previous_template_path: Path | None = None,
    ) -> tuple[Path, Path]:
        template_path = template_path.resolve()
        du_path = du_path.resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_excel = output_dir / f"{template_path.stem}_LNW_DC_Output_{timestamp}{template_path.suffix}"
        output_csv = output_dir / f"{template_path.stem}_LNW_DC_Output_{timestamp}.csv"

        self.progress("Template wird als neue Output-Datei kopiert …")
        shutil.copy2(template_path, output_excel)

        pythoncom.CoInitialize()
        excel = None
        out_wb = None
        du_wb = None
        prev_wb = None
        try:
            excel = win32com.client.DispatchEx("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            excel.EnableEvents = False
            excel.ScreenUpdating = False
            excel.AskToUpdateLinks = False

            self.progress("Output-Template wird in Microsoft Excel geöffnet …")
            out_wb = excel.Workbooks.Open(str(output_excel), UpdateLinks=0, ReadOnly=False)
            sheet = self._get_sheet(out_wb, self.settings["target_sheet"])

            header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
            last_row = self._last_used_row(sheet)
            if last_row <= header_row:
                raise RuntimeError("Im Zielblatt wurden keine Datenzeilen unterhalb des Headers gefunden.")

            self.progress("Input-Endbestände CL:CU werden vor dem Bereinigen als neue Startbestände gesichert …")
            start_balances = self._capture_previous_end_balances(
                sheet, header_row + 1, last_row, wwid_col
            )

            self.progress("Konstante Zellwerte ab AJ bis CU werden gelöscht; Formeln bleiben erhalten …")
            self._clear_constants(sheet, header_row + 1, last_row, "AJ", "CU")

            self.progress("AJ:AS wird WWID-genau aus CL:CU derselben Input-Vorlage übernommen …")
            self._write_start_balances(sheet, header_row + 1, last_row, wwid_col, start_balances)

            self.progress("DU-Datei wird gelesen und nach WWID, Fonds und Umsatzart aggregiert …")
            du_wb = excel.Workbooks.Open(str(du_path), UpdateLinks=0, ReadOnly=True)
            du_sheet = du_wb.Worksheets(1)
            aggregations = self._aggregate_du(du_sheet)
            purchase_aggregations = self._aggregate_du_purchases(du_sheet)

            self.progress("Käufe aus Umwandlungen AV:BC werden geschrieben …")
            self._write_purchase_conversions(
                sheet, header_row + 1, last_row, wwid_col, purchase_aggregations
            )

            self.progress("Ertragsausschüttung BF:BG wird geschrieben …")
            self._write_distribution_block(
                sheet, header_row + 1, last_row, wwid_col, aggregations
            )

            self.progress("Umschichtungsblock BI:BN wird geschrieben …")
            self._write_reallocation(sheet, header_row + 1, last_row, wwid_col, aggregations)

            self.progress("Stichtagsblock CL:CU wird aus AJ:AS plus DU-Bewegungen berechnet …")
            self._write_end_balances(sheet, header_row + 1, last_row, wwid_col, aggregations)

            self.progress("Excel berechnet alle erhaltenen Formeln neu …")
            excel.CalculateFullRebuild()
            out_wb.Save()

            self.progress("CSV mit allen Output-Werten des Blatts wird erzeugt …")
            self._export_sheet_csv(sheet, output_csv)

            self.progress("Verarbeitung erfolgreich abgeschlossen.")
            return output_excel, output_csv
        except Exception:
            if output_excel.exists():
                try:
                    output_excel.unlink()
                except OSError:
                    pass
            raise
        finally:
            for wb in (prev_wb, du_wb, out_wb):
                if wb is not None:
                    try:
                        wb.Close(SaveChanges=False)
                    except Exception:
                        pass
            if excel is not None:
                try:
                    excel.Quit()
                except Exception:
                    pass
            pythoncom.CoUninitialize()

    @staticmethod
    def _get_sheet(workbook, name: str):
        try:
            return workbook.Worksheets(name)
        except Exception as exc:
            available = [workbook.Worksheets(i).Name for i in range(1, workbook.Worksheets.Count + 1)]
            raise RuntimeError(
                f"Blatt '{name}' wurde nicht gefunden. Vorhanden: {', '.join(available)}"
            ) from exc

    def _find_header_and_column(self, sheet, aliases: Iterable[str]) -> tuple[int, int]:
        aliases_norm = {normalize(a) for a in aliases}
        max_rows = int(self.settings.get("header_search_rows", 30))
        used_cols = max(sheet.UsedRange.Columns.Count, col_to_num("CU"))
        for row in range(1, max_rows + 1):
            values = sheet.Range(sheet.Cells(row, 1), sheet.Cells(row, used_cols)).Value2
            if values is None:
                continue
            row_values = values[0] if isinstance(values, tuple) and values and isinstance(values[0], tuple) else values
            for idx, value in enumerate(row_values, start=1):
                if normalize(value) in aliases_norm:
                    return row, idx
        raise RuntimeError(f"Kein Header für {', '.join(aliases)} in den ersten {max_rows} Zeilen gefunden.")

    @staticmethod
    def _last_used_row(sheet) -> int:
        found = sheet.Cells.Find(
            What="*", After=sheet.Cells(1, 1), LookIn=XL_LOOK_IN_FORMULAS,
            SearchOrder=XL_BY_ROWS, SearchDirection=XL_PREVIOUS
        )
        return int(found.Row) if found is not None else 1

    @staticmethod
    def _clear_constants(sheet, first_row: int, last_row: int, first_col: str, last_col: str) -> None:
        target = sheet.Range(f"{first_col}{first_row}:{last_col}{last_row}")
        try:
            constants = target.SpecialCells(XL_CELL_TYPE_CONSTANTS)
            constants.ClearContents()
        except Exception:
            # Excel wirft einen COM-Fehler, wenn keine konstanten Zellen existieren.
            pass

    @staticmethod
    def _capture_start_balances(sheet, first_row: int, last_row: int, wwid_col: int) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {}
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            result[wwid] = {
                col: as_number(sheet.Range(f"{col}{row}").Value2)
                for col in ("AJ", "AK", "AL", "AM", "AN", "AO", "AP", "AQ", "AR", "AS")
            }
        return result

    @staticmethod
    def _capture_previous_end_balances(sheet, first_row: int, last_row: int, wwid_col: int) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {}
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            converted: dict[str, float] = {}
            for previous_col, current_col in PREVIOUS_TO_CURRENT:
                converted[current_col] = as_number(sheet.Range(f"{previous_col}{row}").Value2)
            result[wwid] = converted
        return result

    @staticmethod
    def _write_start_balances(sheet, first_row: int, last_row: int, wwid_col: int, balances: dict[str, dict[str, float]]) -> None:
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid or wwid not in balances:
                continue
            for col, value in balances[wwid].items():
                cell = sheet.Range(f"{col}{row}")
                if not cell.HasFormula:
                    cell.Value2 = value

    def _aggregate_du(self, sheet) -> dict[tuple[str, str, str], tuple[float, float]]:
        header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
        _, fund_col = self._find_header_and_column(sheet, ["Fondsname", "Fonds Name"])
        _, movement_col = self._find_header_and_column(sheet, ["Umsatzart", "Umsatz Art"])
        _, shares_col = self._find_header_and_column(sheet, ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"])
        _, value_col = self._find_header_and_column(sheet, ["ZahlBetrag", "Zahlbetrag", "Zahl Betrag"])
        last_row = self._last_used_row(sheet)

        result: dict[tuple[str, str, str], list[float]] = defaultdict(lambda: [0.0, 0.0])
        for row in range(header_row + 1, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            fund = normalize(sheet.Cells(row, fund_col).Value2)
            movement = normalize(sheet.Cells(row, movement_col).Value2)
            if not wwid or not fund or not movement:
                continue
            key = (wwid, fund, movement)
            result[key][0] += as_number(sheet.Cells(row, shares_col).Value2)
            result[key][1] += as_number(sheet.Cells(row, value_col).Value2)
        return {key: (values[0], values[1]) for key, values in result.items()}

    def _aggregate_du_purchases(self, sheet) -> dict[tuple[str, str, str], tuple[float, float]]:
        """Aggregiert ausschließlich die für AU:BC benötigten DU-Felder.

        Diese separate Aggregation ist absichtlich unabhängig von der bestehenden
        DU-Aggregation, damit die bisherige BI:BN- und CL:CU-Logik unverändert bleibt.
        """
        header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
        _, fund_col = self._find_header_and_column(sheet, ["Fondsname", "Fonds Name"])
        _, movement_col = self._find_header_and_column(sheet, ["Umsatzart", "Umsatz Art"])
        _, shares_col = self._find_header_and_column(
            sheet, ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"]
        )
        _, investment_col = self._find_header_and_column(
            sheet, ["Anlbetrag", "AnlBetrag", "Anl Betrag"]
        )
        last_row = self._last_used_row(sheet)

        result: dict[tuple[str, str, str], list[float]] = defaultdict(lambda: [0.0, 0.0])
        for row in range(header_row + 1, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            fund = normalize(sheet.Cells(row, fund_col).Value2)
            movement = normalize(sheet.Cells(row, movement_col).Value2)
            if not wwid or not fund or not movement:
                continue
            key = (wwid, fund, movement)
            result[key][0] += as_number(sheet.Cells(row, shares_col).Value2)
            result[key][1] += as_number(sheet.Cells(row, investment_col).Value2)
        return {key: (values[0], values[1]) for key, values in result.items()}

    def _write_purchase_conversions(
        self, sheet, first_row: int, last_row: int, wwid_col: int, aggs
    ) -> None:
        movement = normalize("Kauf")
        mappings = (
            ("DWS EURORENTA", "AV", "AW"),
            ("DWS INS.-ESG EO MO.M.IC", "AX", "AY"),
            ("DWSI-EUR.EQ.HI.CO.FC", "BB", "BC"),
        )
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            for fund, shares_col, value_col in mappings:
                shares, value = aggs.get((wwid, normalize(fund), movement), (0.0, 0.0))
                self._set_if_not_formula(sheet.Range(f"{shares_col}{row}"), shares)
                self._set_if_not_formula(sheet.Range(f"{value_col}{row}"), value)

    def _write_distribution_block(
        self, sheet, first_row: int, last_row: int, wwid_col: int, aggs
    ) -> None:
        # Fachliche Vorgabe: BF/BG verwenden Fondsportfolioanpassung für DWS EURORENTA.
        movement = normalize(self.settings["movement_type_reallocation"])
        fund = normalize("DWS EURORENTA")
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            shares, value = aggs.get((wwid, fund, movement), (0.0, 0.0))
            self._set_if_not_formula(sheet.Range(f"BF{row}"), shares)
            self._set_if_not_formula(sheet.Range(f"BG{row}"), value)

    def _write_reallocation(self, sheet, first_row: int, last_row: int, wwid_col: int, aggs) -> None:
        movement = normalize(self.settings["movement_type_reallocation"])
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            for mapping in FUND_MAPPINGS:
                if not mapping.realloc_shares_col:
                    continue
                shares, value = aggs.get((wwid, normalize(mapping.source_fund), movement), (0.0, 0.0))
                self._set_if_not_formula(sheet.Range(f"{mapping.realloc_shares_col}{row}"), shares)
                self._set_if_not_formula(sheet.Range(f"{mapping.realloc_value_col}{row}"), value)

    def _write_end_balances(self, sheet, first_row: int, last_row: int, wwid_col: int, aggs) -> None:
        movement_types = [normalize(x) for x in self.settings["movement_types_end_balance"]]
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue
            for mapping in FUND_MAPPINGS:
                delta_shares = 0.0
                delta_value = 0.0
                for movement in movement_types:
                    shares, value = aggs.get((wwid, normalize(mapping.source_fund), movement), (0.0, 0.0))
                    delta_shares += shares
                    delta_value += value
                start_shares = as_number(sheet.Range(f"{mapping.start_shares_col}{row}").Value2)
                start_value = as_number(sheet.Range(f"{mapping.start_value_col}{row}").Value2)
                self._set_if_not_formula(sheet.Range(f"{mapping.end_shares_col}{row}"), start_shares + delta_shares)
                self._set_if_not_formula(sheet.Range(f"{mapping.end_value_col}{row}"), start_value + delta_value)

    @staticmethod
    def _set_if_not_formula(cell, value: float) -> None:
        if not cell.HasFormula:
            cell.Value2 = value

    def _export_sheet_csv(self, sheet, output_path: Path) -> None:
        last_row = self._last_used_row(sheet)
        found_col = sheet.Cells.Find(
            What="*", After=sheet.Cells(1, 1), LookIn=XL_LOOK_IN_FORMULAS,
            SearchOrder=XL_BY_COLUMNS, SearchDirection=XL_PREVIOUS
        )
        last_col = int(found_col.Column) if found_col is not None else 1
        values = sheet.Range(sheet.Cells(1, 1), sheet.Cells(last_row, last_col)).Value2
        rows = values if isinstance(values, tuple) else ((values,),)
        delimiter = self.settings.get("csv_delimiter", ";")
        encoding = self.settings.get("csv_encoding", "utf-8-sig")
        with output_path.open("w", newline="", encoding=encoding) as handle:
            writer = csv.writer(handle, delimiter=delimiter, quoting=csv.QUOTE_MINIMAL)
            for row in rows:
                writer.writerow(["" if value is None else value for value in row])
