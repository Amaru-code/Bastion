# LNW DC

## Voraussetzungen

- Windows 10/11
- Microsoft Excel Desktop
- Python 3.11 oder neuer

## Start

1. `install.bat` einmalig ausführen.
2. Danach `start.bat` öffnen.
3. LNW-Template und DU-Datei auswählen.
4. Optional ein Vorjahrestemplate auswählen.
5. Verarbeitung starten.

## Verarbeitungslogik

- Das Input-Template wird niemals direkt geändert.
- Zuerst wird eine neue Kopie im Output-Ordner erzeugt.
- Im Blatt `Import DC LNW` werden ab Spalte AJ bis CU ausschließlich konstante Zellinhalte der Datenzeilen gelöscht.
- Header und Formeln bleiben unangetastet.
- Ohne Vorjahrestemplate werden die ursprünglichen AJ:AS-Werte des aktuellen Templates als Startbestand wieder eingesetzt.
- Mit Vorjahrestemplate erfolgt die WWID-genaue Übergabe `CL:CU -> AJ:AS`.
- `BI:BN` aggregiert `UmsatzStuecke` und `ZahlBetrag` für `Umsatzart = Fondsportfolioanpassung`.
- `CL:CU` berechnet Startbestand plus die signierten DU-Summen für:
  - Wiederanlage Ertragsaussc
  - Fondsportfolioanpassung
  - Verkauf wegen Vorabpausch
- Die DU-Werte werden so addiert, wie sie in der Quelldatei vorliegen. Negative Verkäufe reduzieren den Bestand automatisch.
- Zusätzlich wird eine semikolongetrennte UTF-8-CSV mit allen berechneten Werten des Zielblatts erzeugt.

## Fonds-Mapping

- DWSI-EUR.EQ.HI.CO.FC
- DWS EURORENTA
- DWS INS.-ESG EO MO.M.IC
- SIEMENS EUROINVEST AKTIEN
- SIEMENS EUROINVEST RENTEN

## Konfiguration

In `config/settings.json` können Blattname, CSV-Trennzeichen und relevante Umsatzarten angepasst werden.

## Protokoll

Fehler und Verarbeitungsschritte werden in `logs/lnw_dc.log` gespeichert.
