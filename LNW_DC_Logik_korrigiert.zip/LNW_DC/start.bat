@echo off
setlocal
cd /d "%~dp0"

set "VENV_PYTHON=%~dp0.venv\Scripts\python.exe"

if not exist "%VENV_PYTHON%" (
    echo [INFO] Das Projekt ist noch nicht installiert.
    call "%~dp0install.bat"
    if errorlevel 1 exit /b 1
)

"%VENV_PYTHON%" -c "import pythoncom, win32com.client" >nul 2>nul
if errorlevel 1 (
    echo [INFO] Python-Abhaengigkeiten fehlen oder sind unvollstaendig.
    call "%~dp0install.bat"
    if errorlevel 1 exit /b 1
)

"%VENV_PYTHON%" "%~dp0app\main.py"
if errorlevel 1 (
    echo.
    echo [FEHLER] Das Programm wurde mit einem Fehler beendet.
    pause
    exit /b 1
)

exit /b 0
