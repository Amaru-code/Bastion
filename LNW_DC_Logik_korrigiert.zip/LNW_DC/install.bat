@echo off
setlocal
cd /d "%~dp0"

set "VENV_PYTHON=%~dp0.venv\Scripts\python.exe"
set "REQUIREMENTS=%~dp0app\requirements.txt"

echo ============================================================
echo  LNW DC - Installation
echo ============================================================
echo.

where py >nul 2>nul
if errorlevel 1 (
    echo [FEHLER] Python wurde nicht gefunden.
    echo Bitte Python 3.11 oder neuer installieren und danach erneut starten.
    pause
    exit /b 1
)

if not exist "%VENV_PYTHON%" (
    echo [1/3] Virtuelle Python-Umgebung wird erstellt...
    py -3 -m venv "%~dp0.venv"
    if errorlevel 1 goto :error
) else (
    echo [1/3] Virtuelle Python-Umgebung ist bereits vorhanden.
)

echo.
echo [2/3] Installierte pip-Version wird verwendet...
"%VENV_PYTHON%" -m pip --version
if errorlevel 1 goto :error

if not exist "%REQUIREMENTS%" (
    echo.
    echo [FEHLER] requirements.txt wurde nicht gefunden:
    echo %REQUIREMENTS%
    pause
    exit /b 1
)

echo.
echo [3/3] Projekt-Abhaengigkeiten werden installiert...
"%VENV_PYTHON%" -m pip install --no-cache-dir -r "%REQUIREMENTS%"
if errorlevel 1 goto :error

"%VENV_PYTHON%" -c "import pythoncom, win32com.client; print('[OK] pywin32/pythoncom wurde erfolgreich geprueft.')"
if errorlevel 1 goto :error

echo.
echo ============================================================
echo  LNW DC wurde erfolgreich installiert.
echo ============================================================
echo Starte das Programm kuenftig mit start.bat.
pause
exit /b 0

:error
echo.
echo [FEHLER] Die Installation ist fehlgeschlagen.
echo Bitte Artifactory-Zugriff und app\requirements.txt pruefen.
pause
exit /b 1
