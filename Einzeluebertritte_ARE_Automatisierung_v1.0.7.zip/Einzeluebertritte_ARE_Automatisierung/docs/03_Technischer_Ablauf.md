# Technischer Ablauf

## Gesamtprozess

1. Excel per COM starten.
2. ARE-Quelldatei auswählen.
3. DOCX-Serienbriefvorlage auswählen.
4. Excel-Personendatei auswählen.
5. ARE-Quelle schreibgeschützt öffnen.
6. Sichere Kopie mit `_ARE_Auswertung` erstellen.
7. ARE-Blätter neu aufbauen.
8. Arbeitsmappe berechnen und speichern.
9. Jedes ARE-Blatt über `ExportAsFixedFormat` als PDF exportieren.
10. Personendaten aus dem ersten Arbeitsblatt einlesen.
11. Für jede Datenzeile alle passenden `MERGEFIELD`-Felder ersetzen.
12. Je Person eine PDF exportieren.
13. Alle ausgefüllten Vorlagen mit Seitenumbrüchen zu einem DOCX zusammenführen.
14. Gesamt-DOCX als Gesamt-PDF exportieren.
15. Word schließen und ARE-Ausgabedatei in Excel geöffnet lassen.

## Feldzuordnung

Zuerst wird exakt verglichen. Danach folgt ein normalisierter Vergleich ohne Leerzeichen, Unterstriche, Bindestriche, Punkte und Doppelpunkte.

Beispiel:

```text
Word-Feld: Personal_Nummer
Excel-Kopf: Personal Nummer
```

## Fehlerbehandlung

Der Fehlerdialog enthält:

- Version
- genaue Phase
- Fehlernummer
- Beschreibung
- Fehlerquelle
- Pfad zum Diagnoseprotokoll

Das Protokoll dokumentiert zusätzlich alle erzeugten PDFs und Serienbriefdateien.
