# PDF- und Serienbriefausgabe

## ARE-PDFs

Alle Blätter mit dem Muster `ARE ... (LTRG ...)` werden einzeln exportiert:

```text
ERG_VWÜ_{sheet_name}.pdf
```

Beispiel:

```text
ERG_VWÜ_ARE 7020 (LTRG 0100).pdf
```

## Gesamtserienbrief

```text
Anschreiben_ARE_Gesamt.docx
Anschreiben_ARE_Gesamt.pdf
```

Alle Personen stehen hintereinander. Zwischen Personen wird ein Seitenumbruch eingefügt.

## Einzelserienbriefe

```text
Anschrieben_ARE_{Spalte B}_LTRG_{Spalte A}.pdf
```

Beispiele:

```text
Anschrieben_ARE_7020_LTRG_0100.pdf
Anschrieben_ARE_439q_LTRG_3080.pdf
```

## Word-Felder

In Word werden Felder über `Sendungen > Seriendruckfeld einfügen` angelegt. Der Feldname sollte der Kopfzeile der Personendatei entsprechen.

## Ordnerstruktur

```text
<Name der Quelle>_ARE_Export/
├── 01_ARE_PDF/
├── 02_Serienbrief_Gesamt/
└── 03_Serienbrief_Einzel/
```

Vorhandene Dateien werden nicht überschrieben.
