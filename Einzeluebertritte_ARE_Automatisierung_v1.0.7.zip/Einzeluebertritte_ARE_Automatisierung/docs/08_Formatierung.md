# Formatierung der ARE-Blätter

## Bereich A:F

- Arial, 10 pt
- Titel A1:F1: fett, 12 pt
- Erläuterungen A3:F4: normal
- Abschnittsüberschriften: fett, zentriert, kräftig eingerahmt
- Tabellenköpfe: immer fett
- Detailzeilen: normale Schrift
- Beträge D:F: rechtsbündig
- Zwischensummen: immer fett mit oberer Trennlinie
- negative Beträge: schwarz

## Bereich H:J

- Kontrollüberschriften: fett
- Kontrollsummen H4:I4: fett
- keine Farbfüllung und keine Rahmen
- außerhalb des Druckbereichs

## Druck und PDF

- Druckbereich A:F
- Querformat
- eine Seite breit
- beliebig viele Seiten hoch
- jede ARE-Tabelle separat als PDF
- Dateiname `ERG_VWÜ_{sheet_name}.pdf`
- Seitenumbruchvorschau bei 58 %
