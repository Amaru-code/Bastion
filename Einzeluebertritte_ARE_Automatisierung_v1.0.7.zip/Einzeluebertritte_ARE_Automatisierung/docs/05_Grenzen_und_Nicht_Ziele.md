# Grenzen und Nicht-Ziele

## Serienbrief

Die Vorlage muss direkte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten.

Nicht vorgesehen sind aktuell:

- komplexe Word-Regeln wie `NEXT`, `NEXTIF`, `SKIPIF`
- datenquellenabhängige Word-Filter
- mehrere Vorlagen in einem Lauf
- Auswahl eines anderen Personendatenblatts als des ersten Blatts
- automatische fachliche Interpretation beliebiger Spalten
- E-Mail-Versand

## PDF-Ausgabe

ARE-PDFs verwenden den bestehenden Druckbereich A:F und die definierte Seiteneinrichtung. Mehrseitige Berichte bleiben mehrseitig.

## Quelldateien

ARE-Quelle, Personendatei und DOCX-Vorlage werden nicht verändert.

## Spalte A/B

Die Einzeldateinamen verwenden fest Spalte B für ARE und Spalte A für LTRG.
