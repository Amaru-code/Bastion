# Bedienung

## VBS-Workflow

1. ZIP vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. ARE-Quelldatei mit `Übersicht` und `Gesellschaften` auswählen.
4. DOCX-Serienbriefvorlage auswählen.
5. Excel-Datei mit Personendaten auswählen.
6. Erfolgsmeldung abwarten.
7. ARE-Ausgabedatei und Exportordner prüfen.

Wird ein Auswahldialog abgebrochen, beendet sich das Tool ohne Verarbeitung.

## ARE-Ausgabedatei

```text
<Name der Quelle>_ARE_Auswertung.xlsm
oder
<Name der Quelle>_ARE_Auswertung.xlsx
```

## Exportordner

```text
<Name der Quelle>_ARE_Export/
├── 01_ARE_PDF/
├── 02_Serienbrief_Gesamt/
└── 03_Serienbrief_Einzel/
```

### ARE-PDFs

```text
ERG_VWÜ_<Name des ARE-Blatts>.pdf
```

### Gesamtserienbrief

```text
Anschreiben_ARE_Gesamt.docx
Anschreiben_ARE_Gesamt.pdf
```

### Einzelanschreiben

```text
Anschrieben_ARE_<Wert aus Spalte B>_LTRG_<Wert aus Spalte A>.pdf
```

Die Schreibweise `Anschrieben` wird entsprechend der vorgegebenen Dateinamenskonvention verwendet.

## Sicherheitsverhalten

- ARE-Quelle wird schreibgeschützt geöffnet und kopiert.
- Personendatei wird schreibgeschützt geöffnet.
- DOCX-Vorlage wird schreibgeschützt geöffnet.
- Vorhandene Ausgaben werden nicht überschrieben.
- Ungültige Windows-Dateinamenszeichen werden ersetzt.

## Direkte VBA-Nutzung

Das Modul bietet:

- `Erstelle_ARE_Blaetter`
- `Loesche_ARE_Blaetter`
- `Exportiere_ARE_Blaetter_Als_PDF`

Der Serienbriefteil ist im VBS-Starter enthalten, weil Excel und Word gemeinsam automatisiert werden.
