# Einzelübertritte ARE Automatisierung

**Version 1.0.7**

Dieses Projekt erzeugt aus einer bestehenden XLSM- oder XLSX-Datei automatisch die gesellschaftsbezogenen **ARE-Blätter**, exportiert jedes erzeugte Blatt als eigene PDF und erstellt zusätzlich einen Word-Serienbrief.

## Schnellstart

1. Projektordner vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. ARE-Quelldatei (`.xlsm` oder `.xlsx`) auswählen.
4. Word-Serienbriefvorlage (`.docx`) auswählen.
5. Excel-Datei mit Personendaten (`.xlsx`, `.xlsm` oder `.xls`) auswählen.
6. Erfolgsmeldung abwarten.

Die ARE-Quelldatei, die Personendatei und die DOCX-Vorlage werden **nicht verändert**.

## Ausgaben

```text
<Name der Quelle>_ARE_Auswertung.xlsx bzw. .xlsm
<Name der Quelle>_ARE_Export/
├── 01_ARE_PDF/
│   └── ERG_VWÜ_<Name des ARE-Blatts>.pdf
├── 02_Serienbrief_Gesamt/
│   ├── Anschreiben_ARE_Gesamt.docx
│   └── Anschreiben_ARE_Gesamt.pdf
└── 03_Serienbrief_Einzel/
    └── Anschrieben_ARE_<Spalte B>_LTRG_<Spalte A>.pdf
```

Vorhandene Dateien werden nicht überschrieben. Bei Namenskonflikten ergänzt das Tool einen Zeitstempel oder eine laufende Nummer.

## Serienbrief-Grundprinzip

- Erstes Arbeitsblatt der Personendatei wird verwendet.
- Zeile 1 enthält Feldnamen.
- Daten beginnen in Zeile 2.
- Leere Datenzeilen werden übersprungen.
- Word-Vorlage muss echte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten.
- Feldnamen werden Excel-Spaltenüberschriften zugeordnet.
- Einzel-PDF-Dateinamen verwenden Spalte B als ARE und Spalte A als LTRG.

## Formatierung

- Titel, Abschnittsüberschriften und Tabellenköpfe sind fett.
- Zwischensummen und Kontrollsummen sind fett.
- Detailzeilen sind normal formatiert.
- Das kompakte weiße Drucklayout aus Version 1.0.6 bleibt erhalten.

## VBA-Modul

Im Ordner `macro` liegt `modAREGenerator.bas`. Nach dem Import stehen bereit:

- `Erstelle_ARE_Blaetter`
- `Loesche_ARE_Blaetter`
- `Exportiere_ARE_Blaetter_Als_PDF`

Der vollständige Serienbriefablauf wird vom VBS-Starter ausgeführt.

## Voraussetzungen

- Windows
- Microsoft Excel Desktop
- Microsoft Word Desktop
- Schreibrecht im Ordner der ARE-Quelldatei
- ARE-Quelldatei mit `Übersicht` und `Gesellschaften`
- DOCX-Vorlage mit Word-Seriendruckfeldern
- Personendatei mit Kopfzeile in Zeile 1
