# Intel LNW DC Tool – Go Standalone v2

Keine Installation, kein Python, kein pip und keine externen Libraries erforderlich.

## Start

`start.bat` doppelklicken und die drei Eingabedateien auswählen bzw. eintragen.
Als letzte Eingabe wird nur noch der Ausgabeordner abgefragt. Standard ist `Output` im Tool-Ordner.

## Outputs

Alle Ergebnisse liegen direkt im gewählten Ordner `Output`:

- `generated_2025_LNW_DC_Template.xlsm`
- `audit_trail.csv`
- `comparison_differences.csv` (nur wenn eine Vergleichsdatei angegeben wurde)

Es wird kein zusätzlicher Report-Unterordner und keine JSON-Datei mehr erzeugt.

## Fachliche Kernlogik

- Vorjahresendwerte `CL:CU` werden als neue Startwerte nach `AJ:AS` übertragen.
- Der Umschichtungsblock `BI:BN` wird je WWID, Fonds und `Umsatzart = Fondsportfolioanpassung` aus der DU-Datei aggregiert.
- Der neue Endbestand `CL:CU` wird als `Startbestand AJ:AS minus DU-Bewegung` berechnet.
- Vorhandene Formeln in Zielzellen werden geschützt und nicht überschrieben.
- Makrobestandteile der `.xlsm`-Datei bleiben Bestandteil des ZIP-Containers.
