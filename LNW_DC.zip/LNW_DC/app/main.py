from __future__ import annotations

import logging
import queue
import sys
import threading
import traceback
from pathlib import Path
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from lnw_logic import LNWProcessor


PROJECT_ROOT = Path(__file__).resolve().parent.parent
LOG_DIR = PROJECT_ROOT / "logs"
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "lnw_dc.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("LNW DC")
        self.geometry("830x530")
        self.minsize(760, 500)
        self.template_var = tk.StringVar()
        self.du_var = tk.StringVar()
        self.previous_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(PROJECT_ROOT / "output"))
        self.status_queue: queue.Queue[tuple[str, str]] = queue.Queue()
        self._build_ui()
        self.after(100, self._drain_queue)

    def _build_ui(self):
        main = ttk.Frame(self, padding=18)
        main.pack(fill="both", expand=True)

        ttk.Label(main, text="Intel LNW DC", font=("Segoe UI", 20, "bold")).pack(anchor="w")
        ttk.Label(
            main,
            text="Template sicher kopieren, konstante Werte ab AJ bereinigen, DU-Bewegungen aggregieren und Excel + CSV erzeugen.",
            wraplength=760,
        ).pack(anchor="w", pady=(4, 18))

        form = ttk.Frame(main)
        form.pack(fill="x")
        self._file_row(form, 0, "LNW-Template (.xlsm/.xlsx)", self.template_var, self._choose_template)
        self._file_row(form, 1, "DU-Datei (.xlsx/.xlsm)", self.du_var, self._choose_du)
        self._file_row(form, 2, "Vorjahrestemplate (optional)", self.previous_var, self._choose_previous)
        self._file_row(form, 3, "Output-Ordner", self.output_var, self._choose_output)

        note = (
            "Ohne Vorjahrestemplate nutzt das Tool die ursprünglichen AJ:AS-Werte des gewählten Templates. "
            "Mit Vorjahrestemplate werden dessen CL:CU-Werte WWID-genau nach AJ:AS übernommen."
        )
        ttk.Label(main, text=note, wraplength=760, foreground="#444444").pack(anchor="w", pady=(16, 10))

        self.run_button = ttk.Button(main, text="Verarbeitung starten", command=self._start)
        self.run_button.pack(anchor="w", pady=(2, 14))

        ttk.Label(main, text="Protokoll").pack(anchor="w")
        self.log_text = tk.Text(main, height=12, wrap="word", state="disabled", font=("Consolas", 9))
        self.log_text.pack(fill="both", expand=True, pady=(4, 0))

    def _file_row(self, parent, row, label, variable, command):
        ttk.Label(parent, text=label).grid(row=row, column=0, sticky="w", pady=6)
        ttk.Entry(parent, textvariable=variable).grid(row=row, column=1, sticky="ew", padx=10, pady=6)
        ttk.Button(parent, text="Auswählen …", command=command).grid(row=row, column=2, pady=6)
        parent.columnconfigure(1, weight=1)

    def _choose_template(self):
        path = filedialog.askopenfilename(filetypes=[("Excel-Dateien", "*.xlsm *.xlsx"), ("Alle Dateien", "*.*")])
        if path:
            self.template_var.set(path)

    def _choose_du(self):
        path = filedialog.askopenfilename(filetypes=[("Excel-Dateien", "*.xlsx *.xlsm *.xls"), ("Alle Dateien", "*.*")])
        if path:
            self.du_var.set(path)

    def _choose_previous(self):
        path = filedialog.askopenfilename(filetypes=[("Excel-Dateien", "*.xlsm *.xlsx"), ("Alle Dateien", "*.*")])
        if path:
            self.previous_var.set(path)

    def _choose_output(self):
        path = filedialog.askdirectory(initialdir=self.output_var.get() or str(PROJECT_ROOT))
        if path:
            self.output_var.set(path)

    def _append_log(self, message: str):
        self.log_text.configure(state="normal")
        self.log_text.insert("end", message + "\n")
        self.log_text.see("end")
        self.log_text.configure(state="disabled")

    def _start(self):
        template = Path(self.template_var.get().strip())
        du = Path(self.du_var.get().strip())
        output = Path(self.output_var.get().strip())
        previous_text = self.previous_var.get().strip()
        previous = Path(previous_text) if previous_text else None

        if not template.is_file():
            messagebox.showerror("Fehlende Datei", "Bitte ein gültiges LNW-Template auswählen.")
            return
        if not du.is_file():
            messagebox.showerror("Fehlende Datei", "Bitte eine gültige DU-Datei auswählen.")
            return
        if previous and not previous.is_file():
            messagebox.showerror("Fehlende Datei", "Das gewählte Vorjahrestemplate wurde nicht gefunden.")
            return

        self.run_button.configure(state="disabled")
        self._append_log("--- Neue Verarbeitung ---")
        threading.Thread(
            target=self._worker,
            args=(template, du, output, previous),
            daemon=True,
        ).start()

    def _worker(self, template, du, output, previous):
        try:
            processor = LNWProcessor(PROJECT_ROOT, progress_callback=lambda msg: self.status_queue.put(("log", msg)))
            excel_path, csv_path = processor.run(template, du, output, previous)
            self.status_queue.put(("done", f"Excel: {excel_path}\nCSV: {csv_path}"))
        except Exception as exc:
            logging.exception("Verarbeitung fehlgeschlagen")
            self.status_queue.put(("error", f"{exc}\n\nDetails stehen in logs\\lnw_dc.log"))

    def _drain_queue(self):
        try:
            while True:
                kind, message = self.status_queue.get_nowait()
                if kind == "log":
                    self._append_log(message)
                elif kind == "done":
                    self.run_button.configure(state="normal")
                    self._append_log("FERTIG\n" + message)
                    messagebox.showinfo("LNW DC abgeschlossen", message)
                elif kind == "error":
                    self.run_button.configure(state="normal")
                    self._append_log("FEHLER: " + message)
                    messagebox.showerror("LNW DC Fehler", message)
        except queue.Empty:
            pass
        self.after(100, self._drain_queue)


if __name__ == "__main__":
    App().mainloop()
