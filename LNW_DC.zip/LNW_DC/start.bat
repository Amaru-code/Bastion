@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [INFO] Das Projekt ist noch nicht installiert.
    call install.bat
    if errorlevel 1 exit /b 1
)

".venv\Scripts\python.exe" app\main.py
if errorlevel 1 (
    echo.
    echo [FEHLER] Das Programm wurde mit einem Fehler beendet.
    pause
)
