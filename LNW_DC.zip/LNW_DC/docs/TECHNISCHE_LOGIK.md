# Technische Logik

## Bereinigung

Bereich: `AJ:<letzte Datenzeile>:CU<letzte Datenzeile>`

Gelöscht werden nur Excel-Zellen des Typs **Konstante**. Zellen mit Formeln werden nicht überschrieben. Die Headerzeile wird dynamisch über den Header `WWID` erkannt und von der Bereinigung ausgeschlossen.

## Jahresfortschreibung

| Vorjahresende | Neuer Startbestand |
|---|---|
| CL | AJ |
| CM | AK |
| CN | AL |
| CO | AM |
| CP | AN |
| CQ | AO |
| CR | AP |
| CS | AQ |
| CT | AR |
| CU | AS |

Das Mapping erfolgt WWID-genau, nicht zeilenpositionsbezogen.

## Aggregationsschlüssel

`(WWID, Fondsname, Umsatzart)`

Je Schlüssel werden summiert:

- Anteile: `UmsatzStuecke`
- Wert: `ZahlBetrag`

## Schutzmechanismen

- Input-Datei bleibt unverändert.
- Verarbeitung erfolgt nur in einer Kopie.
- Excel-Makros werden durch Nutzung der nativen Excel-Anwendung erhalten.
- Formeln werden weder gelöscht noch mit berechneten Konstanten überschrieben.
- Bei einem Fehler wird die unvollständige Output-Kopie entfernt.
