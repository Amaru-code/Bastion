@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo  LNW DC - Installation
echo ============================================================

where py >nul 2>nul
if errorlevel 1 (
    echo [FEHLER] Python wurde nicht gefunden.
    echo Bitte Python 3.11 oder neuer installieren und danach erneut starten.
    pause
    exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Virtuelle Python-Umgebung wird erstellt...
    py -3 -m venv .venv
    if errorlevel 1 goto :error
) else (
    echo [1/3] Virtuelle Python-Umgebung ist bereits vorhanden.
)

echo [2/3] pip wird aktualisiert...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :error

echo [3/3] Abhaengigkeiten werden installiert...
".venv\Scripts\python.exe" -m pip install -r app\requirements.txt
if errorlevel 1 goto :error

echo.
echo [OK] Installation abgeschlossen.
echo Starte das Programm kuenftig mit start.bat.
pause
exit /b 0

:error
echo.
echo [FEHLER] Die Installation ist fehlgeschlagen.
pause
exit /b 1
