Dieser Ordner wird vom ARE Generator verwendet.

Jeder Lauf legt hier einen eigenen zeitgestempelten Unterordner an:

<Quelle>_ARE_Export_<YYYYMMDD_HHMMSS>/
  00_Excel/
  01_ARE_PDF/
  02_Serienbrief_Gesamt/
  03_Serienbrief_Einzel/
