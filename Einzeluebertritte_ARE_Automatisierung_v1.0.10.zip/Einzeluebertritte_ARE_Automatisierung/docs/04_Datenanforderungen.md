# Datenanforderungen

## ARE-Quelldatei

Unterstützt:

- `.xlsx`
- `.xlsm`

Erforderliche Blätter:

- `Übersicht`
- `Gesellschaften`

## Word-Serienbriefvorlage

Unterstützt:

- `.docx`

Die Vorlage muss echte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten. Feldnamen müssen zu den Excel-Spaltenüberschriften passen.

Felder in Haupttext, Kopf-/Fußzeilen und Textfeldern werden berücksichtigt.

## Personendatei

Unterstützt:

- `.xlsx`
- `.xlsm`
- `.xls`

Aufbau:

- erstes Arbeitsblatt ist Datenquelle
- Zeile 1 enthält Spaltenüberschriften
- Daten beginnen in Zeile 2
- vollständig leere Zeilen werden übersprungen
- mindestens Spalte A und B müssen vorhanden sein

## Spalte A und B

```text
Anschrieben_ARE_{Spalte B}_LTRG_{Spalte A}.pdf
```

Damit gilt für die Dateinamen:

- Spalte A: LTRG
- Spalte B: ARE

## Dateinamen

Diese Zeichen werden durch `-` ersetzt:

```text
\ / : * ? " < > |
```

Bei gleichen Namen werden `_2`, `_3` usw. ergänzt.
