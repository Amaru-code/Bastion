# PDF- und Serienbriefausgabe

## Ordnerstruktur

```text
Output/<Quelle>_ARE_Export_<Zeitstempel>/
├── 00_Excel/
├── 01_ARE_PDF/
├── 02_Serienbrief_Gesamt/
└── 03_Serienbrief_Einzel/
```

## ARE-PDFs

```text
ERG_VWÜ_{sheet_name}.pdf
```

Die PDF übernimmt Mercer-Logo, Berichtskopf und das Portrait-Drucklayout aus dem erzeugten Excel-Blatt.

## Gesamtserienbrief

```text
Anschreiben_ARE_Gesamt.docx
Anschreiben_ARE_Gesamt.pdf
```

Der native Word-Seriendruck erzeugt alle Personen in einem zusammenhängenden Dokument und bewahrt dabei Kopfzeilen, Fußzeilen, Bilder, Abschnittseinstellungen und Seriendruckregeln der Vorlage.

## Einzelserienbriefe

```text
Anschrieben_ARE_{Spalte B}_LTRG_{Spalte A}.pdf
```

## Word-Felder

In Word werden Felder über `Sendungen > Seriendruckfeld einfügen` angelegt. Der Feldname muss zu einer Kopfzeile der Personendatei passen.

## Leere Adresszeilen und Anlage

Der native Seriendruck unterdrückt leere Seriendruckzeilen. Absätze, die mit `Anlage` beginnen, erhalten keinen zusätzlichen Absatzabstand, damit die Schlusszeile möglichst auf derselben Seite bleibt.
