# Grenzen und Nicht-Ziele

## Serienbrief

Die Vorlage muss direkte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten.

Der native Word-Seriendruck unterstützt das Vorlagenlayout wesentlich vollständiger als die frühere manuelle Verkettung. Dennoch gilt:

- Das erste Arbeitsblatt der Personendatei wird verwendet.
- Spalte A und B bestimmen weiterhin die Einzeldateinamen.
- Mehrere Vorlagen in einem Lauf sind nicht vorgesehen.
- E-Mail-Versand ist nicht enthalten.
- Fachlich falsche oder widersprüchliche Adressdaten werden nicht automatisch korrigiert.

## Logo

Das Logo wird nicht aus Word extrahiert. Es muss als eindeutige PNG-/JPG-Datei im Unterordner `docs` liegen oder im Dateidialog ausgewählt werden. Dadurch werden Unterschriften und andere Bilder aus der DOCX nicht übernommen.

## PDF-Ausgabe

ARE-PDFs verwenden Portraitformat und den Druckbereich A:F. Berichte, die trotz Skalierung nicht auf eine Seite passen, bleiben mehrseitig.

## Quelldateien

ARE-Quelle, Personendatei und DOCX-Vorlage werden nicht verändert.
