# Technische Logik

## 1. Template-Kopie und Bereinigung

Das ausgewählte LNW-Template wird zuerst kopiert. Nur die Kopie wird verarbeitet.

Im Blatt `Import DC LNW` werden ab der ersten Datenzeile im Bereich `AJ:CU` ausschließlich konstante Zellinhalte gelöscht. Formeln und Header bleiben erhalten.

Vor dem Löschen werden `CL:CU` WWID-genau gesichert.

## 2. VJ-/Startbestände AJ:AS

Die gesicherten Endbestände der Input-Vorlage werden auf die Startbestände übertragen:

| Input | Output |
|---|---|
| CL | AJ |
| CM | AK |
| CN | AL |
| CO | AM |
| CP | AN |
| CQ | AO |
| CR | AP |
| CS | AQ |
| CT | AR |
| CU | AS |

## 3. DU-Datei

Die DU-Aggregation verwendet `(WWID, Fondsname, Umsatzart)`.

### Kauf

- Anteile: `UmsatzStuecke`
- Wert: `Anlbetrag`
- Umsatzart: `Kauf`

### Ertragsausschüttung BF:BG

- Fonds: `DWS EURORENTA`
- Anteile: `UmsatzStuecke`
- Wert: `ZahlBetrag`
- Umsatzart: beginnt mit `Ertragsaussch` und endet mit `ttung`

### Umschichtung BI:BN

- Anteile: `UmsatzStuecke`
- Wert: `ZahlBetrag`
- Umsatzart: `Fondsportfolioanpassung`

## 4. DP-Datei und Stichtagsblock CL:CU

`CL:CU` wird nicht mehr aus Startbestand plus DU-Bewegungen berechnet.

Die Werte stammen ausschließlich aus der DP-Datei. Aggregationsschlüssel ist `(WWID, Fondsname)`:

- Anteile = Summe `Bestand_Stuecke`
- Wert = Summe `Bestand_Betrag`

Zuordnung:

| Fonds in DP | Anteile | Wert |
|---|---|---|
| DWSI-EUR.EQ.HI.CO.FC | CL | CM |
| DWS EURORENTA | CN | CO |
| DWS INS.-ESG EO MO.M.IC | CP | CQ |
| SIEMENS EUROINVEST AKTIEN | CR | CS |
| SIEMENS EUROINVEST RENTEN | CT | CU |

## 5. Header-Erkennung

DU und DP werden in den ersten 30 Zeilen nach den benötigten Headern durchsucht. Header werden robust normalisiert; Unterstriche, Leerzeichen, Umlaute und Groß-/Kleinschreibung sind dadurch weniger störanfällig.

Für DP werden insbesondere Varianten von `Bestand_Stuecke` und `Bestand_Betrag` unterstützt.

## 6. Schutzmechanismen

- Input-Template bleibt unverändert.
- Verarbeitung erfolgt nur in der Kopie.
- Formeln werden nicht gelöscht oder überschrieben.
- Excel-Makros und Formatierungen bleiben durch native Excel-Automation erhalten.
- Bei einem Fehler wird eine unvollständige Output-Kopie entfernt.


## DP-Datei – technische Verarbeitung
Die DP-Datei wird im Read-Only-Modus direkt mit Python/openpyxl gelesen und nicht über Excel-COM geöffnet. Damit werden Excel-Automationsfehler beim Öffnen bestimmter DP-Dateien vermieden.

## Fonds-Synonyme
Für den Fonds `DWSI-EUR.EQ.HI.CO.FC` wird zusätzlich der Quellname `DWS INV.FOC.EUROPE FC` als Synonym akzeptiert.
Die zentrale Alias-Tabelle befindet sich in `app/lnw_logic.py` unter `FUND_ALIASES`.
