# LNW DC

## Voraussetzungen

- Windows 10/11
- Microsoft Excel Desktop
- Python 3.11 oder neuer

## Start

1. `install.bat` einmalig ausführen.
2. Danach `start.bat` öffnen.
3. LNW-Template auswählen.
4. DU-Datei auswählen.
5. DP-Datei auswählen.
6. Output-Ordner auswählen.
7. Verarbeitung starten.

## Verarbeitungslogik

- Das Input-Template wird niemals direkt geändert.
- Zuerst wird eine neue Kopie im Output-Ordner erzeugt.
- Im Blatt `Import DC LNW` werden ab Spalte `AJ` bis `CU` ausschließlich konstante Zellinhalte der Datenzeilen gelöscht.
- Header, Formeln und Formatierungen bleiben unangetastet.
- `AJ:AS` erhält die zuvor gesicherten Werte aus `CL:CU` derselben Input-Vorlage (`CL:CU -> AJ:AS`).
- Die DU-Datei liefert Bewegungskennzahlen für Kauf, Ertragsausschüttung und Umschichtung.
- Die DP-Datei ist die alleinige Quelle für die neuen Stichtagsbestände `CL:CU`.
- Zusätzlich wird eine semikolongetrennte UTF-8-CSV des gesamten Zielblatts erzeugt.

## DU-Logik

### Käufe

- `AV/AW`: DWS EURORENTA, Umsatzart `Kauf`, Quellen `UmsatzStuecke` / `Anlbetrag`
- `AY/AZ`: DWS INS.-ESG EO MO.M.IC, Umsatzart `Kauf`, Quellen `UmsatzStuecke` / `Anlbetrag`
- `BB/BC`: DWSI-EUR.EQ.HI.CO.FC, Umsatzart `Kauf`, Quellen `UmsatzStuecke` / `Anlbetrag`

### Ertragsausschüttung BF:BG

Für DWS EURORENTA werden DU-Umsatzarten berücksichtigt, deren Text mit `Ertragsaussch` beginnt und mit `ttung` endet. Dadurch werden auch fehlerhafte Quellwerte wie `Ertragsaussch3ttung` oder `Ertragsaussch³ttung` erkannt.

### Umschichtung BI:BN

`BI:BN` aggregiert `UmsatzStuecke` und `ZahlBetrag` für `Umsatzart = Fondsportfolioanpassung`.

## DP-Logik für CL:CU

Aggregationsschlüssel: `(WWID, Fondsname)`.

- Anteile: Summe aus `Bestand_Stuecke`
- Wert: Summe aus `Bestand_Betrag`

Fondszuordnung:

- `CL/CM`: DWSI-EUR.EQ.HI.CO.FC
- `CN/CO`: DWS EURORENTA
- `CP/CQ`: DWS INS.-ESG EO MO.M.IC
- `CR/CS`: SIEMENS EUROINVEST AKTIEN
- `CT/CU`: SIEMENS EUROINVEST RENTEN

Die Fondsnamen werden ohne Beachtung der Groß-/Kleinschreibung verglichen. Dadurch werden z. B. `DWS Eurorenta` und `DWS EURORENTA` gleich behandelt.

## Protokoll

Fehler und Verarbeitungsschritte werden in `logs/lnw_dc.log` gespeichert.


## DP-Datei – technische Verarbeitung
Die DP-Datei wird im Read-Only-Modus direkt mit Python/openpyxl gelesen und nicht über Excel-COM geöffnet. Damit werden Excel-Automationsfehler beim Öffnen bestimmter DP-Dateien vermieden.
