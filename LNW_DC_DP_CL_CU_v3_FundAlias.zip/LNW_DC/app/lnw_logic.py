from __future__ import annotations

import csv
import json
import logging
import re
import shutil
from collections import defaultdict
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable

import pythoncom
import win32com.client
from openpyxl import load_workbook


XL_CELL_TYPE_CONSTANTS = 2
XL_BY_ROWS = 1
XL_BY_COLUMNS = 2
XL_PREVIOUS = 2
XL_LOOK_IN_FORMULAS = -4123


@dataclass(frozen=True)
class FundMapping:
    source_fund: str
    start_shares_col: str
    start_value_col: str
    end_shares_col: str
    end_value_col: str
    realloc_shares_col: str | None = None
    realloc_value_col: str | None = None


FUND_MAPPINGS: tuple[FundMapping, ...] = (
    FundMapping("DWSI-EUR.EQ.HI.CO.FC", "AJ", "AK", "CL", "CM", "BI", "BJ"),
    FundMapping("DWS EURORENTA", "AL", "AM", "CN", "CO", "BK", "BL"),
    FundMapping("DWS INS.-ESG EO MO.M.IC", "AN", "AO", "CP", "CQ", "BM", "BN"),
    FundMapping("SIEMENS EUROINVEST AKTIEN", "AP", "AQ", "CR", "CS"),
    FundMapping("SIEMENS EUROINVEST RENTEN", "AR", "AS", "CT", "CU"),
)


PREVIOUS_TO_CURRENT: tuple[tuple[str, str], ...] = (
    ("CL", "AJ"),
    ("CM", "AK"),
    ("CN", "AL"),
    ("CO", "AM"),
    ("CP", "AN"),
    ("CQ", "AO"),
    ("CR", "AP"),
    ("CS", "AQ"),
    ("CT", "AR"),
    ("CU", "AS"),
)


def normalize(value: Any) -> str:
    if value is None:
        return ""
    text = str(value).replace("\xa0", " ").strip().casefold()
    return re.sub(r"\s+", " ", text)


# Zentrale Fonds-Synonyme. Neue Bezeichnungen können hier ergänzt werden,
# ohne die eigentliche Aggregationslogik zu verändern.
FUND_ALIASES = {
    normalize("DWS INV.FOC.EUROPE FC"): normalize("DWSI-EUR.EQ.HI.CO.FC"),
    normalize("DWSI-EUR.EQ.HI.CO.FC Anteile"): normalize("DWSI-EUR.EQ.HI.CO.FC"),
}


def normalize_fund(value: Any) -> str:
    fund = normalize(value)
    return FUND_ALIASES.get(fund, fund)


def normalize_header(value: Any) -> str:
    """Robuste Header-Normalisierung für unterschiedliche Jahresdateien."""
    text = normalize(value)
    text = (
        text.replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("ß", "ss")
    )
    return re.sub(r"[^a-z0-9]+", "", text)


def normalize_wwid(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    text = str(value).strip()
    if text.endswith(".0") and text[:-2].isdigit():
        return text[:-2]
    return text


def as_number(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip().replace(" ", "")
    if not text:
        return 0.0

    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        text = text.replace(".", "").replace(",", ".")

    try:
        return float(text)
    except ValueError:
        return 0.0


def col_to_num(col: str) -> int:
    result = 0
    for char in col.upper():
        result = result * 26 + (ord(char) - 64)
    return result


def is_ertragsausschuettung(value: Any) -> bool:
    """Erkennt auch fehlerhafte Werte wie Ertragsaussch3ttung/Ertragsaussch³ttung."""
    text = normalize(value)
    return text.startswith("ertragsaussch") and text.endswith("ttung")


def load_settings(project_root: Path) -> dict[str, Any]:
    path = project_root / "config" / "settings.json"
    with path.open("r", encoding="utf-8") as handle:
        return json.load(handle)


class LNWProcessor:
    def __init__(self, project_root: Path, progress_callback=None):
        self.project_root = project_root
        self.settings = load_settings(project_root)
        self.progress_callback = progress_callback or (lambda _message: None)
        self.logger = logging.getLogger("LNW_DC")

    def progress(self, message: str) -> None:
        self.logger.info(message)
        self.progress_callback(message)

    def run(
        self,
        template_path: Path,
        du_path: Path,
        dp_path: Path,
        output_dir: Path,
    ) -> tuple[Path, Path]:
        template_path = template_path.resolve()
        du_path = du_path.resolve()
        dp_path = dp_path.resolve()
        output_dir.mkdir(parents=True, exist_ok=True)

        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        output_excel = (
            output_dir
            / f"{template_path.stem}_LNW_DC_Output_{timestamp}{template_path.suffix}"
        )
        output_csv = output_dir / f"{template_path.stem}_LNW_DC_Output_{timestamp}.csv"

        self.progress("Template wird als neue Output-Datei kopiert …")
        shutil.copy2(template_path, output_excel)

        pythoncom.CoInitialize()
        excel = None
        out_wb = None
        du_wb = None

        try:
            excel = win32com.client.DispatchEx("Excel.Application")
            excel.Visible = False
            excel.DisplayAlerts = False
            excel.EnableEvents = False
            excel.ScreenUpdating = False
            excel.AskToUpdateLinks = False

            self.progress("Output-Template wird in Microsoft Excel geöffnet …")
            out_wb = excel.Workbooks.Open(str(output_excel), UpdateLinks=0, ReadOnly=False)
            sheet = self._get_sheet(out_wb, self.settings["target_sheet"])

            header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
            last_row = self._last_used_row(sheet)
            if last_row <= header_row:
                raise RuntimeError(
                    "Im Zielblatt wurden keine Datenzeilen unterhalb des Headers gefunden."
                )

            # AJ:AS bleiben die Vorjahres-/Startbestände. Vor dem Bereinigen werden
            # CL:CU aus der Input-Vorlage gesichert und anschließend nach AJ:AS übertragen.
            self.progress(
                "Input-Endbestände CL:CU werden vor dem Bereinigen als neue Startbestände gesichert …"
            )
            start_balances = self._capture_previous_end_balances(
                sheet, header_row + 1, last_row, wwid_col
            )

            self.progress(
                "Konstante Zellwerte ab AJ bis CU werden gelöscht; Formeln bleiben erhalten …"
            )
            self._clear_constants(sheet, header_row + 1, last_row, "AJ", "CU")

            self.progress(
                "AJ:AS wird WWID-genau aus CL:CU derselben Input-Vorlage übernommen …"
            )
            self._write_start_balances(
                sheet, header_row + 1, last_row, wwid_col, start_balances
            )

            # DU: Kauf, Ertragsausschüttung und Umschichtung.
            self.progress(
                "DU-Datei wird gelesen und nach WWID, Fonds und Umsatzart aggregiert …"
            )
            du_wb = excel.Workbooks.Open(str(du_path), UpdateLinks=0, ReadOnly=True)
            du_sheet = self._find_sheet_with_headers(
                du_wb,
                [
                    ["WWID"],
                    ["Fondsname", "Fonds Name"],
                    ["Umsatzart", "Umsatz Art"],
                    ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"],
                ],
                "DU",
            )
            aggregations = self._aggregate_du(du_sheet)
            purchase_aggregations = self._aggregate_du_purchases(du_sheet)

            self.progress("Käufe aus Umwandlungen AV:BC werden geschrieben …")
            self._write_purchase_conversions(
                sheet, header_row + 1, last_row, wwid_col, purchase_aggregations
            )

            self.progress("Ertragsausschüttung BF:BG wird geschrieben …")
            self._write_distribution_block(
                sheet, header_row + 1, last_row, wwid_col, aggregations
            )

            self.progress("Umschichtungsblock BI:BN wird geschrieben …")
            self._write_reallocation(
                sheet, header_row + 1, last_row, wwid_col, aggregations
            )

            # DP: neue, eindeutig nachgewiesene Quelle für CL:CU.
            # Die DP-Datei wird bewusst NICHT über Excel-COM geöffnet.
            # Einige DP-Dateien lassen sich zwar interaktiv in Excel öffnen,
            # werden aber von Workbooks.Open in einer Automation-Instanz abgelehnt
            # (COM-Fehler 0x800A03EC). Da wir die DP-Datei nur lesen, verwenden
            # wir hier openpyxl im Read-Only-Modus.
            self.progress(
                "DP-Datei wird direkt mit Python gelesen: Bestand_Stuecke und Bestand_Betrag "
                "werden nach WWID und Fonds aggregiert …"
            )
            dp_aggregations = self._aggregate_dp_file(dp_path)

            self.progress(
                "Stichtagsblock CL:CU wird direkt aus den aggregierten DP-Beständen geschrieben …"
            )
            self._write_end_balances_from_dp(
                sheet, header_row + 1, last_row, wwid_col, dp_aggregations
            )

            self.progress("Excel berechnet alle erhaltenen Formeln neu …")
            excel.CalculateFullRebuild()
            out_wb.Save()

            self.progress("CSV mit allen Output-Werten des Blatts wird erzeugt …")
            self._export_sheet_csv(sheet, output_csv)

            self.progress("Verarbeitung erfolgreich abgeschlossen.")
            return output_excel, output_csv

        except Exception:
            if output_excel.exists():
                try:
                    output_excel.unlink()
                except OSError:
                    pass
            raise

        finally:
            for wb in (du_wb, out_wb):
                if wb is not None:
                    try:
                        wb.Close(SaveChanges=False)
                    except Exception:
                        pass

            if excel is not None:
                try:
                    excel.Quit()
                except Exception:
                    pass

            pythoncom.CoUninitialize()

    @staticmethod
    def _get_sheet(workbook, name: str):
        try:
            return workbook.Worksheets(name)
        except Exception as exc:
            available = [
                workbook.Worksheets(i).Name
                for i in range(1, workbook.Worksheets.Count + 1)
            ]
            raise RuntimeError(
                f"Blatt '{name}' wurde nicht gefunden. Vorhanden: {', '.join(available)}"
            ) from exc

    def _find_header_and_column(
        self,
        sheet,
        aliases: Iterable[str],
    ) -> tuple[int, int]:
        aliases_norm = {normalize_header(alias) for alias in aliases}
        max_rows = int(self.settings.get("header_search_rows", 30))
        used_cols = max(int(sheet.UsedRange.Columns.Count), col_to_num("CU"))

        for row in range(1, max_rows + 1):
            values = sheet.Range(
                sheet.Cells(row, 1),
                sheet.Cells(row, used_cols),
            ).Value2

            if values is None:
                continue

            row_values = (
                values[0]
                if isinstance(values, tuple)
                and values
                and isinstance(values[0], tuple)
                else values
            )

            for idx, value in enumerate(row_values, start=1):
                if normalize_header(value) in aliases_norm:
                    return row, idx

        raise RuntimeError(
            f"Kein Header für {', '.join(aliases)} in den ersten {max_rows} Zeilen gefunden."
        )

    def _find_sheet_with_headers(
        self,
        workbook,
        required_alias_groups: Iterable[Iterable[str]],
        source_name: str,
    ):
        """Findet robust das Blatt, das alle benötigten Header enthält."""
        checked: list[str] = []

        for index in range(1, workbook.Worksheets.Count + 1):
            sheet = workbook.Worksheets(index)
            checked.append(sheet.Name)
            try:
                for aliases in required_alias_groups:
                    self._find_header_and_column(sheet, aliases)
                return sheet
            except RuntimeError:
                continue

        raise RuntimeError(
            f"In der {source_name}-Datei wurde kein Blatt mit allen benötigten Headern gefunden. "
            f"Geprüfte Blätter: {', '.join(checked)}"
        )

    @staticmethod
    def _last_used_row(sheet) -> int:
        found = sheet.Cells.Find(
            What="*",
            After=sheet.Cells(1, 1),
            LookIn=XL_LOOK_IN_FORMULAS,
            SearchOrder=XL_BY_ROWS,
            SearchDirection=XL_PREVIOUS,
        )
        return int(found.Row) if found is not None else 1

    @staticmethod
    def _clear_constants(
        sheet,
        first_row: int,
        last_row: int,
        first_col: str,
        last_col: str,
    ) -> None:
        target = sheet.Range(f"{first_col}{first_row}:{last_col}{last_row}")
        try:
            constants = target.SpecialCells(XL_CELL_TYPE_CONSTANTS)
            constants.ClearContents()
        except Exception:
            # Excel wirft einen COM-Fehler, wenn keine konstanten Zellen existieren.
            pass

    @staticmethod
    def _capture_previous_end_balances(
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
    ) -> dict[str, dict[str, float]]:
        result: dict[str, dict[str, float]] = {}

        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue

            converted: dict[str, float] = {}
            for previous_col, current_col in PREVIOUS_TO_CURRENT:
                converted[current_col] = as_number(
                    sheet.Range(f"{previous_col}{row}").Value2
                )
            result[wwid] = converted

        return result

    @staticmethod
    def _write_start_balances(
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
        balances: dict[str, dict[str, float]],
    ) -> None:
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid or wwid not in balances:
                continue

            for col, value in balances[wwid].items():
                cell = sheet.Range(f"{col}{row}")
                if not cell.HasFormula:
                    cell.Value2 = value

    def _aggregate_du(
        self,
        sheet,
    ) -> dict[tuple[str, str, str], tuple[float, float]]:
        header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
        _, fund_col = self._find_header_and_column(sheet, ["Fondsname", "Fonds Name"])
        _, movement_col = self._find_header_and_column(
            sheet, ["Umsatzart", "Umsatz Art"]
        )
        _, shares_col = self._find_header_and_column(
            sheet,
            ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"],
        )
        _, value_col = self._find_header_and_column(
            sheet,
            ["ZahlBetrag", "Zahlbetrag", "Zahl Betrag"],
        )
        last_row = self._last_used_row(sheet)

        result: dict[tuple[str, str, str], list[float]] = defaultdict(
            lambda: [0.0, 0.0]
        )

        for row in range(header_row + 1, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            fund = normalize_fund(sheet.Cells(row, fund_col).Value2)
            movement = normalize(sheet.Cells(row, movement_col).Value2)

            if not wwid or not fund or not movement:
                continue

            key = (wwid, fund, movement)
            result[key][0] += as_number(sheet.Cells(row, shares_col).Value2)
            result[key][1] += as_number(sheet.Cells(row, value_col).Value2)

        return {key: (values[0], values[1]) for key, values in result.items()}

    def _aggregate_du_purchases(
        self,
        sheet,
    ) -> dict[tuple[str, str, str], tuple[float, float]]:
        """Kauf-Aggregation mit Anlbetrag als Wertquelle."""
        header_row, wwid_col = self._find_header_and_column(sheet, ["WWID"])
        _, fund_col = self._find_header_and_column(sheet, ["Fondsname", "Fonds Name"])
        _, movement_col = self._find_header_and_column(
            sheet, ["Umsatzart", "Umsatz Art"]
        )
        _, shares_col = self._find_header_and_column(
            sheet,
            ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"],
        )
        _, investment_col = self._find_header_and_column(
            sheet,
            ["Anlbetrag", "AnlBetrag", "Anl Betrag", "Anlagebetrag"],
        )
        last_row = self._last_used_row(sheet)

        result: dict[tuple[str, str, str], list[float]] = defaultdict(
            lambda: [0.0, 0.0]
        )

        for row in range(header_row + 1, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            fund = normalize_fund(sheet.Cells(row, fund_col).Value2)
            movement = normalize(sheet.Cells(row, movement_col).Value2)

            if not wwid or not fund or not movement:
                continue

            key = (wwid, fund, movement)
            result[key][0] += as_number(sheet.Cells(row, shares_col).Value2)
            result[key][1] += as_number(sheet.Cells(row, investment_col).Value2)

        return {key: (values[0], values[1]) for key, values in result.items()}

    def _aggregate_dp_file(
        self,
        dp_path: Path,
    ) -> dict[tuple[str, str], tuple[float, float]]:
        """
        Liest die DP-Datei ohne Excel-COM und aggregiert CL:CU-Quellwerte
        nach WWID + Fondsname.

        Erwartete fachliche Felder:
        - WWID
        - Fondsname
        - Bestand_Stuecke
        - Bestand_Betrag
        """
        if not dp_path.is_file():
            raise RuntimeError(f"Die DP-Datei wurde nicht gefunden: {dp_path}")

        if dp_path.suffix.lower() not in {".xlsx", ".xlsm"}:
            raise RuntimeError(
                "Die DP-Datei muss für die direkte Python-Verarbeitung im Format "
                f".xlsx oder .xlsm vorliegen. Ausgewählt: {dp_path.name}"
            )

        try:
            workbook = load_workbook(
                filename=dp_path,
                read_only=True,
                data_only=True,
                keep_links=False,
            )
        except Exception as exc:
            raise RuntimeError(
                "Die DP-Datei konnte auch direkt mit Python nicht gelesen werden. "
                f"Datei: {dp_path}\nUrsache: {exc}"
            ) from exc

        alias_groups = {
            "wwid": ["WWID"],
            "fund": ["Fondsname", "Fonds Name"],
            "shares": [
                "Bestand_Stuecke",
                "BestandStuecke",
                "Bestand Stücke",
                "Bestand_Stücke",
                "Bestandstücke",
            ],
            "value": ["Bestand_Betrag", "BestandBetrag", "Bestand Betrag"],
        }
        normalized_aliases = {
            key: {normalize_header(alias) for alias in aliases}
            for key, aliases in alias_groups.items()
        }
        max_rows = int(self.settings.get("header_search_rows", 30))

        selected_sheet = None
        header_row = None
        columns: dict[str, int] = {}
        checked_sheets: list[str] = []

        try:
            for ws in workbook.worksheets:
                checked_sheets.append(ws.title)
                for row_idx, row in enumerate(
                    ws.iter_rows(min_row=1, max_row=max_rows, values_only=True),
                    start=1,
                ):
                    found: dict[str, int] = {}
                    for col_idx, value in enumerate(row, start=1):
                        normalized = normalize_header(value)
                        if not normalized:
                            continue
                        for key, aliases in normalized_aliases.items():
                            if key not in found and normalized in aliases:
                                found[key] = col_idx

                    if all(key in found for key in ("wwid", "fund", "shares", "value")):
                        selected_sheet = ws
                        header_row = row_idx
                        columns = found
                        break

                if selected_sheet is not None:
                    break

            if selected_sheet is None or header_row is None:
                raise RuntimeError(
                    "In der DP-Datei wurden die benötigten Header WWID, Fondsname, "
                    "Bestand_Stuecke und Bestand_Betrag nicht gemeinsam gefunden. "
                    f"Geprüfte Blätter: {', '.join(checked_sheets)}"
                )

            self.progress(
                f"DP-Blatt erkannt: {selected_sheet.title}; Headerzeile: {header_row}"
            )

            result: dict[tuple[str, str], list[float]] = defaultdict(
                lambda: [0.0, 0.0]
            )

            max_needed_col = max(columns.values())
            for row in selected_sheet.iter_rows(
                min_row=header_row + 1,
                max_col=max_needed_col,
                values_only=True,
            ):
                def get_value(col_index: int):
                    return row[col_index - 1] if col_index - 1 < len(row) else None

                wwid = normalize_wwid(get_value(columns["wwid"]))
                fund = normalize_fund(get_value(columns["fund"]))

                if not wwid or not fund:
                    continue

                key = (wwid, fund)
                result[key][0] += as_number(get_value(columns["shares"]))
                result[key][1] += as_number(get_value(columns["value"]))

            return {
                key: (values[0], values[1])
                for key, values in result.items()
            }
        finally:
            workbook.close()

    def _write_purchase_conversions(
        self,
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
        aggs,
    ) -> None:
        movement = normalize("Kauf")

        # Letzte bestätigte Korrektur: DWS INS.-ESG EO MO.M.IC liegt in AY/AZ.
        mappings = (
            ("DWS EURORENTA", "AV", "AW"),
            ("DWS INS.-ESG EO MO.M.IC", "AY", "AZ"),
            ("DWSI-EUR.EQ.HI.CO.FC", "BB", "BC"),
        )

        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue

            for fund, shares_col, value_col in mappings:
                shares, value = aggs.get(
                    (wwid, normalize_fund(fund), movement),
                    (0.0, 0.0),
                )
                self._set_if_not_formula(sheet.Range(f"{shares_col}{row}"), shares)
                self._set_if_not_formula(sheet.Range(f"{value_col}{row}"), value)

    def _write_distribution_block(
        self,
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
        aggs,
    ) -> None:
        """BF/BG: DWS EURORENTA + fehlerhaft geschriebene Ertragsausschüttung."""
        target_fund = normalize_fund("DWS EURORENTA")

        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue

            total_shares = 0.0
            total_value = 0.0

            for (agg_wwid, agg_fund, agg_movement), values in aggs.items():
                if agg_wwid != wwid or agg_fund != target_fund:
                    continue
                if not is_ertragsausschuettung(agg_movement):
                    continue

                shares, value = values
                total_shares += shares
                total_value += value

            self._set_if_not_formula(sheet.Range(f"BF{row}"), total_shares)
            self._set_if_not_formula(sheet.Range(f"BG{row}"), total_value)

    def _write_reallocation(
        self,
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
        aggs,
    ) -> None:
        movement = normalize(self.settings["movement_type_reallocation"])

        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue

            for mapping in FUND_MAPPINGS:
                if not mapping.realloc_shares_col:
                    continue

                shares, value = aggs.get(
                    (wwid, normalize_fund(mapping.source_fund), movement),
                    (0.0, 0.0),
                )
                self._set_if_not_formula(
                    sheet.Range(f"{mapping.realloc_shares_col}{row}"),
                    shares,
                )
                self._set_if_not_formula(
                    sheet.Range(f"{mapping.realloc_value_col}{row}"),
                    value,
                )

    def _write_end_balances_from_dp(
        self,
        sheet,
        first_row: int,
        last_row: int,
        wwid_col: int,
        aggs: dict[tuple[str, str], tuple[float, float]],
    ) -> None:
        """Schreibt CL:CU ausschließlich aus DP: Bestand_Stuecke / Bestand_Betrag."""
        for row in range(first_row, last_row + 1):
            wwid = normalize_wwid(sheet.Cells(row, wwid_col).Value2)
            if not wwid:
                continue

            for mapping in FUND_MAPPINGS:
                shares, value = aggs.get(
                    (wwid, normalize_fund(mapping.source_fund)),
                    (0.0, 0.0),
                )
                self._set_if_not_formula(
                    sheet.Range(f"{mapping.end_shares_col}{row}"),
                    shares,
                )
                self._set_if_not_formula(
                    sheet.Range(f"{mapping.end_value_col}{row}"),
                    value,
                )

    @staticmethod
    def _set_if_not_formula(cell, value: float) -> None:
        if not cell.HasFormula:
            cell.Value2 = value

    def _export_sheet_csv(self, sheet, output_path: Path) -> None:
        last_row = self._last_used_row(sheet)
        found_col = sheet.Cells.Find(
            What="*",
            After=sheet.Cells(1, 1),
            LookIn=XL_LOOK_IN_FORMULAS,
            SearchOrder=XL_BY_COLUMNS,
            SearchDirection=XL_PREVIOUS,
        )
        last_col = int(found_col.Column) if found_col is not None else 1

        values = sheet.Range(
            sheet.Cells(1, 1),
            sheet.Cells(last_row, last_col),
        ).Value2
        rows = values if isinstance(values, tuple) else ((values,),)

        delimiter = self.settings.get("csv_delimiter", ";")
        encoding = self.settings.get("csv_encoding", "utf-8-sig")

        with output_path.open("w", newline="", encoding=encoding) as handle:
            writer = csv.writer(
                handle,
                delimiter=delimiter,
                quoting=csv.QUOTE_MINIMAL,
            )
            for row in rows:
                writer.writerow(["" if value is None else value for value in row])
