# Changelog

## 1.0.1 – 2026-07-29

- Dateiauswahl unterstützt jetzt `.xlsm` und `.xlsx`.
- Die Ausgabedatei behält automatisch das Format der Quelldatei bei.
- Fehlermeldungen und Dokumentation wurden entsprechend angepasst.

## 1.0.0

- Erste Projektversion mit VBS-Ausführung, VBA-Modul und Dokumentation.
