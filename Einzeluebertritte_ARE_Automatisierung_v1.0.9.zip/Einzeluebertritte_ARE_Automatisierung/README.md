# Einzelübertritte ARE Automatisierung

**Version 1.0.9**

Dieses Projekt erzeugt aus einer XLSM- oder XLSX-Datei automatisch die gesellschaftsbezogenen **ARE-Blätter**, exportiert jedes erzeugte Blatt als eigene PDF und erstellt zusätzlich einen Word-Serienbrief.

## Schnellstart

1. Projektordner vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. ARE-Quelldatei (`.xlsm` oder `.xlsx`) auswählen.
4. Word-Serienbriefvorlage (`.docx`) auswählen.
5. Excel-Datei mit Personendaten (`.xlsx`, `.xlsm` oder `.xls`) auswählen.
6. Erfolgsmeldung abwarten und den Ordner `Output` öffnen.

Die ARE-Quelldatei, die Personendatei und die DOCX-Vorlage werden **nicht verändert**.

## Ausgaben

```text
Output/
└── <Name der Quelle>_ARE_Export_<YYYYMMDD_HHMMSS>/
    ├── 00_Excel/
    │   └── <Name der Quelle>_ARE_Auswertung.xlsx bzw. .xlsm
    ├── 01_ARE_PDF/
    │   └── ERG_VWÜ_<Name des ARE-Blatts>.pdf
    ├── 02_Serienbrief_Gesamt/
    │   ├── Anschreiben_ARE_Gesamt.docx
    │   └── Anschreiben_ARE_Gesamt.pdf
    └── 03_Serienbrief_Einzel/
        └── Anschrieben_ARE_<Spalte B>_LTRG_<Spalte A>.pdf
```

Jeder Lauf erhält einen eigenen Zeitstempelordner. Vorhandene Ergebnisse werden dadurch nicht vermischt oder überschrieben.

## Mercer-Logo

Das Logo wird **nicht mehr aus der DOCX-Vorlage kopiert**, weil dort neben dem Mercer-Logo auch andere Bilder wie Unterschriften vorkommen können.

Legen Sie die korrekte Logodatei direkt neben `ARE_Generator_starten.vbs` ab. Automatisch erkannt werden, in dieser Reihenfolge:

- `Bild 1.png`
- `Bild 1.jpg`
- `Bild 1.jpeg`
- alternativ `Mercer Logo.*` oder `Mercer_Logo.*`

Fehlt diese Datei, öffnet das Tool einen Dateidialog zur manuellen Logoauswahl. Vor dem Einfügen werden vorhandene Bilder im reservierten Logo-Bereich oben links entfernt.

## ARE-PDF-Layout

- Mercer-Logo oben links
- Berichtszeitraum und ARE-/LTRG-Bezeichnung oben rechts
- zentrierter Haupttitel
- saubere zweizeilige Tabellenköpfe
- fett formatierte Header und Summenzeilen
- Portraitformat, eine Seite breit
- technische CHECK-Spalten H:J bleiben außerhalb des Druckbereichs

Der Berichtszeitraum wird aus einer vierstelligen Jahreszahl im Quelldateinamen abgeleitet. Bei `..._2025.xlsx` wird beispielsweise `2024/25` ausgegeben.

## Serienbrief-Grundprinzip

- Erstes Arbeitsblatt der Personendatei wird verwendet.
- Zeile 1 enthält Feldnamen.
- Daten beginnen in Zeile 2.
- Leere Datenzeilen werden übersprungen.
- Word-Vorlage muss echte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten.
- Einzel-PDF-Dateinamen verwenden Spalte B als ARE und Spalte A als LTRG.
- Version 1.0.9 verwendet bevorzugt den nativen Word-Seriendruck mit unterdrückten Leerzeilen, damit Namen, Anschrift, Abstände, Kopf-/Fußzeilen und die Schlusszeile `Anlage` dem Vorlagenlayout entsprechen.
- Falls der native Seriendruck auf einem System nicht verfügbar ist, wird automatisch auf den bisherigen kompatiblen Feldmodus zurückgefallen.

## VBA-Modul

Im Ordner `macro` liegt `modAREGenerator.bas`. Nach dem Import stehen bereit:

- `Erstelle_ARE_Blaetter`
- `Loesche_ARE_Blaetter`
- `Exportiere_ARE_Blaetter_Als_PDF`

Der vollständige Logo- und Serienbriefablauf wird vom VBS-Starter ausgeführt.

## Voraussetzungen

- Windows
- Microsoft Excel Desktop
- Microsoft Word Desktop
- Schreibrecht im entpackten Projektordner
- ARE-Quelldatei mit `Übersicht` und `Gesellschaften`
- DOCX-Vorlage mit Word-Seriendruckfeldern
- Personendatei mit Kopfzeile in Zeile 1
