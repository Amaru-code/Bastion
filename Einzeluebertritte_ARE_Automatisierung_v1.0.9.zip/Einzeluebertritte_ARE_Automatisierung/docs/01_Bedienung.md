# Bedienung

## VBS-Workflow

1. ZIP vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. ARE-Quelldatei mit `Übersicht` und `Gesellschaften` auswählen.
4. DOCX-Serienbriefvorlage auswählen.
5. Excel-Datei mit Personendaten auswählen.
6. Erfolgsmeldung abwarten.
7. Den automatisch angelegten Ordner `Output` prüfen.

Wird ein Auswahldialog abgebrochen, beendet sich das Tool ohne Verarbeitung.

## Output-Ordner

```text
Output/
└── <Name der Quelle>_ARE_Export_<Zeitstempel>/
    ├── 00_Excel/
    ├── 01_ARE_PDF/
    ├── 02_Serienbrief_Gesamt/
    └── 03_Serienbrief_Einzel/
```

### ARE-Ausgabedatei

```text
00_Excel/<Name der Quelle>_ARE_Auswertung.xlsm
oder
00_Excel/<Name der Quelle>_ARE_Auswertung.xlsx
```

### ARE-PDFs

```text
01_ARE_PDF/ERG_VWÜ_<Name des ARE-Blatts>.pdf
```

### Gesamtserienbrief

```text
02_Serienbrief_Gesamt/Anschreiben_ARE_Gesamt.docx
02_Serienbrief_Gesamt/Anschreiben_ARE_Gesamt.pdf
```

### Einzelanschreiben

```text
03_Serienbrief_Einzel/Anschrieben_ARE_<Wert aus Spalte B>_LTRG_<Wert aus Spalte A>.pdf
```

Die Schreibweise `Anschrieben` wird entsprechend der vorgegebenen Dateinamenskonvention verwendet.

## Logoauswahl

Speichern Sie das korrekte Logo als `Bild 1.png`, `Bild 1.jpg` oder `Bild 1.jpeg` direkt neben `ARE_Generator_starten.vbs`. Das Tool verwendet diese Datei automatisch. Die DOCX-Vorlage wird bewusst nicht mehr als Logoquelle verwendet, damit eine enthaltene Unterschrift nicht als Logo übernommen wird. Fehlt die lokale Datei, erscheint eine manuelle Auswahl für PNG/JPG.

## Sicherheitsverhalten

- ARE-Quelle wird schreibgeschützt geöffnet und kopiert.
- Personendatei wird schreibgeschützt geöffnet.
- DOCX-Vorlage wird schreibgeschützt geöffnet.
- Ergebnisse liegen ausschließlich im Projektordner `Output`.
- Ungültige Windows-Dateinamenszeichen werden ersetzt.

## Direkte VBA-Nutzung

Das Modul bietet:

- `Erstelle_ARE_Blaetter`
- `Loesche_ARE_Blaetter`
- `Exportiere_ARE_Blaetter_Als_PDF`

Logoübernahme und Serienbrief werden ausschließlich vom VBS-Starter ausgeführt, weil Excel und Word gemeinsam automatisiert werden.
