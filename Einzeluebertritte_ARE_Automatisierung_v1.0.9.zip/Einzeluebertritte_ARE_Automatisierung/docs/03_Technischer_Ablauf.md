# Technischer Ablauf

## Gesamtprozess

1. Excel per COM starten.
2. ARE-Quelldatei auswählen.
3. DOCX-Serienbriefvorlage auswählen.
4. Excel-Personendatei auswählen.
5. Zeitgestempelten Laufordner unter `Output` erstellen.
6. ARE-Quelle schreibgeschützt öffnen und nach `00_Excel` kopieren.
7. ARE-Blätter neu aufbauen.
8. Berichtskopf, Portrait-Seiteneinrichtung und Drucklayout setzen.
9. Lokale Logo-Datei `Bild 1.png/.jpg/.jpeg` neben dem VBS-Starter suchen und in die ARE-Blätter einfügen.
10. Falls kein Bild erkannt wird, PNG/JPG als Fallback auswählen lassen.
11. Arbeitsmappe berechnen und speichern.
12. Jedes ARE-Blatt über `ExportAsFixedFormat` als PDF exportieren.
13. Personendaten aus dem ersten Arbeitsblatt einlesen und leere Zeilen entfernen.
14. Eine temporäre, zusammenhängende Excel-Datenquelle für Word erzeugen.
15. Bevorzugt den nativen Word-Seriendruck mit `SuppressBlankLines = True` ausführen.
16. Gesamt-DOCX, Gesamt-PDF und Einzel-PDFs erzeugen.
17. Temporäre Datenquelle löschen und Word schließen.
18. ARE-Ausgabedatei in Excel geöffnet lassen.

## Serienbrief-Fallback

Falls der native Word-Seriendruck wegen einer lokalen Office-/Treiberkonfiguration nicht geöffnet werden kann, verwendet das Tool automatisch den bisherigen Feldmodus. Der Wechsel wird im Diagnoseprotokoll dokumentiert.

## Feldzuordnung im Fallback

Zuerst wird exakt verglichen. Danach folgt ein normalisierter Vergleich ohne Leerzeichen, Unterstriche, Bindestriche, Punkte und Doppelpunkte.

## Fehlerbehandlung

Der Fehlerdialog enthält Version, genaue Phase, Fehlernummer, Beschreibung, Fehlerquelle und den Pfad zum Diagnoseprotokoll.
