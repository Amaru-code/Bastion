# Logo und Vorlagenlayout

## Eindeutige lokale Logoquelle

Ab Version 1.0.9 wird das Logo nicht mehr aus der DOCX-Vorlage extrahiert. Der Grund: Eine Word-Vorlage kann mehrere Bilder enthalten, beispielsweise Logo und Unterschrift. Eine automatische Auswahl des ersten Bildes ist daher nicht eindeutig.

Das Tool sucht direkt neben `ARE_Generator_starten.vbs` in dieser Reihenfolge:

1. `Bild 1.png`
2. `Bild 1.jpg`
3. `Bild 1.jpeg`
4. `Mercer Logo.png/.jpg/.jpeg`
5. `Mercer_Logo.png/.jpg/.jpeg`

Die gefundene Datei wird auf jedes ARE-Blatt eingefügt. Vorher werden Bilder im reservierten Bereich oben links entfernt, sodass eine aus älteren Ausgaben stammende Unterschrift nicht bestehen bleibt.

## Manueller Fallback

Wird neben der VBS-Datei keine passende Bilddatei gefunden, öffnet sich ein Dateidialog. Dort kann die korrekte PNG-/JPG-Datei gewählt werden. Die DOCX-Datei wird auch im Fallback nicht nach Bildern durchsucht.

## Warum der native Word-Seriendruck verwendet wird

Die frühere Lösung öffnete die Vorlage je Person, ersetzte Felder und verkettete die Dokumentinhalte. Das war robust, konnte aber bei komplexen Vorlagen Abstände, Leerzeilen oder Abschnittslogik geringfügig verändern.

Version 1.0.9 verwendet bevorzugt Words eigene Seriendruckfunktion. Dadurch bleiben insbesondere diese Elemente näher an der Vorlage:

- Name und Anschrift
- leere Adresszeilen
- Kopf- und Fußzeilen
- Bilder und Logos
- Seiten- und Abschnittseinstellungen
- Position der Schlusszeile `Anlage`
