# Einzelübertritte ARE Automatisierung

**Version 1.0.12**

Dieses Projekt erzeugt aus einer XLSM- oder XLSX-Datei automatisch die gesellschaftsbezogenen **ARE-Blätter**, exportiert jedes Blatt als eigene PDF und erstellt nur für die **tatsächlich betroffenen Gesellschaften** Anschreiben. An jedes Anschreiben wird die zugehörige ARE-Übersicht angehängt – sowohl in der Einzel-DOCX als auch in der Einzel-PDF.

## Schnellstart

1. Projektordner vollständig entpacken.
2. Mercer-Logo als `docs/Bild 1.png` ablegen.
3. `ARE_Generator_starten.vbs` doppelklicken.
4. ARE-Quelldatei (`.xlsm` oder `.xlsx`) auswählen.
5. Word-Serienbriefvorlage (`.docx`) auswählen.
6. Excel-Datei mit Gesellschafts-/Empfängerdaten auswählen.
7. Erfolgsmeldung abwarten und den Ordner `Output` öffnen.

Die ARE-Quelldatei, die Serienbriefdaten und die DOCX-Vorlage werden **nicht verändert**.

## Ausgaben

```text
Output/
└── <Name der Quelle>_ARE_Export_<YYYYMMDD_HHMMSS>/
    ├── 00_Excel/
    │   └── <Name der Quelle>_ARE_Auswertung.xlsx bzw. .xlsm
    ├── 01_ARE_PDF/
    │   └── ERG_VWÜ_<Name des ARE-Blatts>.pdf
    ├── 02_Serienbrief_Gesamt/
    │   ├── Anschreiben_ARE_Gesamt.docx
    │   └── Anschreiben_ARE_Gesamt.pdf
    └── 03_Serienbrief_Einzel/
        ├── Anschrieben_ARE_<ARE>_LTRG_<LTRG>.docx
        └── Anschrieben_ARE_<ARE>_LTRG_<LTRG>.pdf
```

Jeder Lauf erhält einen eigenen Zeitstempelordner. Vorhandene Ergebnisse werden nicht vermischt oder überschrieben.

## Anschreiben nur für betroffene Gesellschaften

Aus `Übersicht` wird zuerst die Menge aller tatsächlich beteiligten `LTRG neu` und `LTRG alt` gebildet. Die Serienbriefdatei wird anschließend über ihre LTRG-Spalte gefiltert. Zeilen für nicht betroffene Gesellschaften werden übersprungen.

Die Spalten der Serienbriefdatei werden über die Überschriften erkannt:

- `LTRG`, `LTGR`, `LGTR`, `LTRGR` oder ähnliche Schreibweisen
- `ARE`, `ARE Nummer`, `ARE Code` oder ähnliche Schreibweisen

Werden diese Überschriften nicht gefunden, bleibt als Rückfalloption Spalte A = LTRG und Spalte B = ARE bestehen.

## Übersicht als Anlage im DOCX und PDF

Für jede betroffene Gesellschaft entsteht ein vollständiges Paket:

1. ausgefülltes Anschreiben,
2. Seitenumbruch,
3. zugehörige ARE-Übersicht.

Die Übersicht wird als hochauflösende Vektorgrafik aus dem erzeugten Excel-Blatt in Word eingefügt. Dadurch bleibt die Darstellung in DOCX und PDF identisch mit der ARE-PDF. Die Übersicht ist innerhalb des Word-Dokuments ein Bild; fachliche oder gestalterische Änderungen erfolgen deshalb in der Excel-Übersichtsvorlage und anschließend durch einen neuen Toollauf.

Auch `Anschreiben_ARE_Gesamt.docx` und `.pdf` enthalten ausschließlich betroffene Gesellschaften, jeweils mit direkt nachfolgender Übersicht.

## Anpassbare Übersichtsvorlage

Beim ersten Start erzeugt das Tool automatisch:

```text
templates/ARE_Uebersicht_Template.xlsx
```

Danach kann die Datei in Excel angepasst werden. Verwendet werden:

- Blatt `ARE_TEMPLATE`: sichtbares Layout und Musterzeilen
- Blatt `CONFIG`: Logo-Position und Logo-Größe

### Aufbau von `ARE_TEMPLATE`

| Bereich | Bedeutung |
|---|---|
| Zeilen 1–7 | Berichtskopf, Titel und Erläuterung |
| Zeile 10 | Muster für eine Gesellschaftsüberschrift |
| Zeile 11 | Muster für die Tabellenköpfe |
| Zeile 12 | Muster für Detailzeilen |
| Zeile 13 | Muster für Summenzeilen |
| Zeile 14 | Muster für den Abstand zwischen Blöcken |

Anpassbar sind unter anderem Schrift, Schriftgröße, Fettung, Farben, Rahmen, Zeilenhöhen, Spaltenbreiten, Ausrichtung und Seitenränder.

Folgende Platzhalter dürfen in den Textzellen verwendet werden:

```text
{{ZEITRAUM}}
{{ARE}}
{{LTRG}}
{{GESELLSCHAFT_KURZ}}
{{GEGENPARTEI_KURZ}}
{{GEGENPARTEI_ARE}}
{{GEGENPARTEI_LTRG}}
```

Nicht umbenennen oder löschen:

- Blatt `ARE_TEMPLATE`
- Blatt `CONFIG`
- die Musterzeilen 10–14

Das Mercer-Logo bleibt eine separate Datei unter `docs/Bild 1.png`. Position und Größe lassen sich im Blatt `CONFIG` anpassen.

## Dynamische Spaltenerkennung der ARE-Quelle

Die Daten werden nicht über feste Spaltenbuchstaben gelesen. Das Tool sucht die benötigten Überschriften in den ersten 30 Zeilen und 100 Spalten. Erlaubt sind:

- andere Spaltenreihenfolgen
- zusätzliche Spalten, etwa `ARE neu` und `ARE alt`
- verschobene Kopfzeilen
- Schreibweisen `LTRG`, `LTGR`, `LGTR` und `LTRGR`
- umsortierte Spalten im Blatt `Gesellschaften`

ARE und Gesellschaftsname werden zentral anhand der jeweiligen LTRG aus `Gesellschaften` ermittelt.

## Mercer-Logo

Das Logo wird ausschließlich aus einer lokalen Bilddatei geladen, bevorzugt:

```text
docs/Bild 1.png
```

Alternativ werden `Bild 1.jpg`, `Bild 1.jpeg`, `Mercer Logo.*` und `Mercer_Logo.*` erkannt. Die DOCX-Vorlage wird nicht als Logoquelle verwendet, sodass Unterschriften nicht versehentlich in ARE-Ausgaben gelangen.

## VBA-Modul

Im Ordner `macro` liegt `modAREGenerator.bas` für die direkte ARE-Erzeugung in Excel. Der vollständige Ablauf mit anpassbarer Übersichtsvorlage, Logo, Filterung, Einzel-DOCX und angehängter Übersicht wird vom VBS-Starter ausgeführt.

## Voraussetzungen

- Windows
- Microsoft Excel Desktop
- Microsoft Word Desktop
- Schreibrecht im entpackten Projektordner
- ARE-Quelldatei mit `Übersicht` und `Gesellschaften`
- DOCX-Vorlage mit Word-Seriendruckfeldern
- Serienbriefdatei mit einer erkennbaren LTRG-Spalte
