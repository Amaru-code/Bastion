Hier erzeugt das Tool für jeden Lauf einen eigenen Zeitstempelordner.

Ab Version 1.0.12 enthält 03_Serienbrief_Einzel pro betroffener Gesellschaft eine DOCX und PDF. In beiden ist die passende ARE-Übersicht angehängt.
