# ============================================================================
# Presence Toolbox v0.1
# ============================================================================
# Prototype with two local modes:
#   Normal    - no simulated activity; Teams controls presence normally
#   Available - taps Scroll Lock every 60 seconds without changing its state
#
# The selected mode can run indefinitely or for a chosen duration. When a
# duration expires, the application automatically returns to Normal mode.
# Closing this terminal window terminates the complete tray application.
# ============================================================================

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

try { $Host.UI.RawUI.WindowTitle = "Presence Toolbox - Runtime Log" } catch {}
try { [Console]::OutputEncoding = [System.Text.Encoding]::UTF8 } catch {}

Clear-Host
Write-Host ""
Write-Host "============================================================"
Write-Host " Presence Toolbox v0.1"
Write-Host "============================================================"
Write-Host ""
Write-Host "Das Programm läuft, solange dieses Terminal geöffnet ist."
Write-Host "Schließe dieses Fenster, um das Programm zu beenden."
Write-Host ""

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
[System.Windows.Forms.Application]::SetCompatibleTextRenderingDefault($false)

Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;

public static class PresenceKeyboard
{
    [DllImport("user32.dll")]
    public static extern void keybd_event(byte bVk, byte bScan, uint dwFlags, UIntPtr dwExtraInfo);
}

public static class PresenceNativeIcon
{
    [DllImport("user32.dll", SetLastError = true)]
    public static extern bool DestroyIcon(IntPtr hIcon);
}
"@

# ----------------------------------------------------------------------------
# State and paths
# ----------------------------------------------------------------------------

$script:AppName = "Presence Toolbox"
$script:IntervalSeconds = 60
$script:CurrentMode = "Normal"
$script:ModeExpiresAt = $null
$script:ToggleCount = 0
$script:LastRunAt = $null
$script:NextRunAt = $null
$script:IsShuttingDown = $false

$script:ProjectRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
$script:LogDirectory = Join-Path $script:ProjectRoot "Logs"
$script:ConfigDirectory = Join-Path $script:ProjectRoot "app\config"
$script:SettingsPath = Join-Path $script:ConfigDirectory "settings.json"
$script:LogRetentionDays = 5

$script:Mutex = $null
$script:NotifyIcon = $null
$script:Timer = $null
$script:BaseIcon = $null
$script:NormalIcon = $null
$script:AvailableIcon = $null

# ----------------------------------------------------------------------------
# Logging and settings
# ----------------------------------------------------------------------------

function Initialize-AppDirectory {
    param([Parameter(Mandatory = $true)][string]$Path)
    if (-not (Test-Path -LiteralPath $Path -PathType Container)) {
        New-Item -ItemType Directory -Path $Path -Force | Out-Null
    }
}

function Remove-OldLogFiles {
    try {
        if (-not (Test-Path -LiteralPath $script:LogDirectory -PathType Container)) { return }
        $cutoff = (Get-Date).AddDays(-[double]$script:LogRetentionDays)
        Get-ChildItem -LiteralPath $script:LogDirectory -Filter "*.log" -File -ErrorAction Stop |
            Where-Object { $_.LastWriteTime -lt $cutoff } |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch {}
}

function Write-AppLog {
    param(
        [Parameter(Mandatory = $true)][AllowEmptyString()][string]$Message,
        [ValidateSet("INFO", "SUCCESS", "WARNING", "ERROR")][string]$Level = "INFO"
    )

    $now = Get-Date
    $line = "[{0}] [{1}] {2}" -f $now.ToString("yyyy-MM-dd HH:mm:ss"), $Level, $Message

    switch ($Level) {
        "SUCCESS" { Write-Host $line -ForegroundColor DarkGreen }
        "WARNING" { Write-Host $line -ForegroundColor DarkYellow }
        "ERROR"   { Write-Host $line -ForegroundColor Red }
        default   { Write-Host $line -ForegroundColor Gray }
    }

    try {
        Initialize-AppDirectory -Path $script:LogDirectory
        Remove-OldLogFiles
        $logName = "Presence-Toolbox-{0}.log" -f $now.ToString("yyyy-MM-dd")
        Add-Content -LiteralPath (Join-Path $script:LogDirectory $logName) -Value $line -Encoding UTF8
    } catch {
        Write-Host ("Logdatei konnte nicht geschrieben werden: {0}" -f $_.Exception.Message) -ForegroundColor DarkYellow
    }
}

function Save-AppSettings {
    try {
        Initialize-AppDirectory -Path $script:ConfigDirectory
        $settings = [ordered]@{
            version = 1
            intervalSeconds = $script:IntervalSeconds
            lastSelectedMode = $script:CurrentMode
        }
        $settings | ConvertTo-Json | Set-Content -LiteralPath $script:SettingsPath -Encoding UTF8
    } catch {
        Write-AppLog -Message ("Einstellungen konnten nicht gespeichert werden: {0}" -f $_.Exception.Message) -Level "WARNING"
    }
}

function Import-AppSettings {
    if (-not (Test-Path -LiteralPath $script:SettingsPath -PathType Leaf)) { return }
    try {
        $settings = Get-Content -LiteralPath $script:SettingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
        if ($settings.intervalSeconds -and [int]$settings.intervalSeconds -ge 10) {
            $script:IntervalSeconds = [int]$settings.intervalSeconds
        }
    } catch {
        Write-AppLog -Message ("Einstellungen konnten nicht gelesen werden; Standardwerte werden verwendet: {0}" -f $_.Exception.Message) -Level "WARNING"
    }
}

# ----------------------------------------------------------------------------
# Single instance
# ----------------------------------------------------------------------------

$createdNew = $false
$script:Mutex = New-Object System.Threading.Mutex($true, "Local\PresenceToolbox-v01", [ref]$createdNew)
if (-not $createdNew) {
    Write-AppLog -Message "Eine andere Presence-Toolbox-Instanz läuft bereits." -Level "WARNING"
    Start-Sleep -Seconds 2
    return
}

Import-AppSettings

# ----------------------------------------------------------------------------
# Icons
# ----------------------------------------------------------------------------

function Get-BaseIcon {
    $candidates = @(
        (Join-Path $script:ProjectRoot "assets\icons\Tray_Icon.ico"),
        (Join-Path $script:ProjectRoot "assets\icons\Presence_Toolbox.ico")
    )

    foreach ($iconPath in $candidates) {
        if (Test-Path -LiteralPath $iconPath -PathType Leaf) {
            try { return New-Object System.Drawing.Icon($iconPath) } catch {}
        }
    }

    return [System.Drawing.SystemIcons]::Application
}

function New-StatusIcon {
    param(
        [Parameter(Mandatory = $true)][System.Drawing.Icon]$BaseIcon,
        [Parameter(Mandatory = $true)][System.Drawing.Color]$StatusColor
    )

    $bitmap = New-Object System.Drawing.Bitmap 32, 32
    $graphics = [System.Drawing.Graphics]::FromImage($bitmap)
    try {
        $graphics.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
        $graphics.Clear([System.Drawing.Color]::Transparent)
        $graphics.DrawIcon($BaseIcon, (New-Object System.Drawing.Rectangle 0, 0, 32, 32))

        $outlineBrush = New-Object System.Drawing.SolidBrush([System.Drawing.Color]::White)
        $statusBrush = New-Object System.Drawing.SolidBrush($StatusColor)
        try {
            $graphics.FillEllipse($outlineBrush, 18, 18, 13, 13)
            $graphics.FillEllipse($statusBrush, 20, 20, 9, 9)
        } finally {
            $outlineBrush.Dispose()
            $statusBrush.Dispose()
        }

        $handle = [IntPtr]::Zero
        try {
            $handle = $bitmap.GetHicon()
            $tempIcon = [System.Drawing.Icon]::FromHandle($handle)
            return $tempIcon.Clone()
        } finally {
            if ($handle -ne [IntPtr]::Zero) { [PresenceNativeIcon]::DestroyIcon($handle) | Out-Null }
        }
    } finally {
        $graphics.Dispose()
        $bitmap.Dispose()
    }
}

# ----------------------------------------------------------------------------
# Mode logic
# ----------------------------------------------------------------------------

function Format-TimeSpanShort {
    param([Parameter(Mandatory = $true)][TimeSpan]$TimeSpan)
    if ($TimeSpan.TotalSeconds -le 0) { return "now" }
    if ($TimeSpan.TotalHours -ge 1) { return "{0}h {1}m" -f [int]$TimeSpan.TotalHours, $TimeSpan.Minutes }
    if ($TimeSpan.TotalMinutes -ge 1) { return "{0}m {1}s" -f [int]$TimeSpan.TotalMinutes, $TimeSpan.Seconds }
    return "{0}s" -f [Math]::Max(0, [int][Math]::Ceiling($TimeSpan.TotalSeconds))
}

function Get-ModeExpiryText {
    if (-not $script:ModeExpiresAt) { return "Duration: unlimited" }
    return "Duration remaining: {0}" -f (Format-TimeSpanShort ($script:ModeExpiresAt - (Get-Date)))
}

function Invoke-PresenceTap {
    param([string]$Reason = "timer")
    try {
        $scrollLock = [byte]0x91
        $keyUp = [uint32]0x0002
        [PresenceKeyboard]::keybd_event($scrollLock, 0, 0, [UIntPtr]::Zero)
        [PresenceKeyboard]::keybd_event($scrollLock, 0, $keyUp, [UIntPtr]::Zero)
        Start-Sleep -Milliseconds 60
        [PresenceKeyboard]::keybd_event($scrollLock, 0, 0, [UIntPtr]::Zero)
        [PresenceKeyboard]::keybd_event($scrollLock, 0, $keyUp, [UIntPtr]::Zero)

        $script:ToggleCount++
        $script:LastRunAt = Get-Date
        $script:NextRunAt = $script:LastRunAt.AddSeconds($script:IntervalSeconds)
        Write-AppLog -Message ("Available tap abgeschlossen. Grund={0}; Anzahl={1}; Nächster Lauf={2}" -f $Reason, $script:ToggleCount, $script:NextRunAt.ToString("HH:mm:ss")) -Level "SUCCESS"
    } catch {
        Write-AppLog -Message ("Available tap fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

function Set-PresenceMode {
    param(
        [Parameter(Mandatory = $true)][ValidateSet("Normal", "Available")][string]$Mode,
        [Nullable[DateTime]]$ExpiresAt = $null,
        [string]$Reason = "manual"
    )

    $previousMode = $script:CurrentMode
    $script:CurrentMode = $Mode
    $script:ModeExpiresAt = $ExpiresAt

    if ($Mode -eq "Available") {
        $script:NextRunAt = (Get-Date).AddSeconds($script:IntervalSeconds)
    } else {
        $script:NextRunAt = $null
    }

    $durationText = if ($ExpiresAt) { "bis {0}" -f $ExpiresAt.Value.ToString("HH:mm:ss") } else { "unbegrenzt" }
    Write-AppLog -Message ("Moduswechsel: {0} -> {1}; Dauer={2}; Grund={3}" -f $previousMode, $Mode, $durationText, $Reason) -Level "INFO"
    Save-AppSettings
    Update-Tray
}

function Set-SelectedDuration {
    param([ValidateSet("Unlimited", "30m", "1h", "2h", "EndOfDay")][string]$Duration)

    $script:SelectedDuration = $Duration
    foreach ($entry in $script:DurationItems.GetEnumerator()) { $entry.Value.Checked = ($entry.Key -eq $Duration) }
    Write-AppLog -Message ("Voreingestellte Dauer geändert: {0}" -f $Duration)
    Update-Tray
}

function Get-SelectedExpiry {
    switch ($script:SelectedDuration) {
        "30m"      { return (Get-Date).AddMinutes(30) }
        "1h"       { return (Get-Date).AddHours(1) }
        "2h"       { return (Get-Date).AddHours(2) }
        "EndOfDay" { return (Get-Date).Date.AddDays(1).AddSeconds(-1) }
        default     { return $null }
    }
}

# ----------------------------------------------------------------------------
# Tray UI
# ----------------------------------------------------------------------------

function Update-Tray {
    if (-not $script:NotifyIcon) { return }

    $isAvailable = ($script:CurrentMode -eq "Available")
    $script:NotifyIcon.Icon = if ($isAvailable) { $script:AvailableIcon } else { $script:NormalIcon }
    $script:NotifyIcon.Text = "{0} - {1}" -f $script:AppName, $script:CurrentMode

    $script:StatusItem.Text = "Mode: {0}" -f $script:CurrentMode
    $script:DurationStatusItem.Text = Get-ModeExpiryText
    $script:NormalItem.Checked = (-not $isAvailable)
    $script:AvailableItem.Checked = $isAvailable

    if ($isAvailable) {
        $script:NextRunItem.Text = if ($script:NextRunAt) { "Next tap: {0}" -f (Format-TimeSpanShort ($script:NextRunAt - (Get-Date))) } else { "Next tap: pending" }
    } else {
        $script:NextRunItem.Text = "Next tap: inactive"
    }

    $script:LastRunItem.Text = if ($script:LastRunAt) { "Last tap: {0}" -f $script:LastRunAt.ToString("HH:mm:ss") } else { "Last tap: never" }
    $script:RunOnceItem.Enabled = $isAvailable
}

function Exit-App {
    if ($script:IsShuttingDown) { return }
    $script:IsShuttingDown = $true
    Write-AppLog -Message "Presence Toolbox wird beendet."
    [System.Windows.Forms.Application]::Exit()
}

function Restart-App {
    try {
        $launcherPath = Join-Path $script:ProjectRoot "Presence Toolbox.VBS"
        if (-not (Test-Path -LiteralPath $launcherPath -PathType Leaf)) {
            Write-AppLog -Message ("Neustart nicht möglich; Launcher fehlt: {0}" -f $launcherPath) -Level "ERROR"
            return
        }
        Start-Process -FilePath "wscript.exe" -ArgumentList ('"{0}"' -f $launcherPath) -WorkingDirectory $script:ProjectRoot | Out-Null
        Write-AppLog -Message "Neustart angefordert."
        Exit-App
    } catch {
        Write-AppLog -Message ("Neustart fehlgeschlagen: {0}" -f $_.Exception.Message) -Level "ERROR"
    }
}

$script:SelectedDuration = "Unlimited"
$script:DurationItems = @{}

$script:BaseIcon = Get-BaseIcon
$script:NormalIcon = New-StatusIcon $script:BaseIcon ([System.Drawing.Color]::FromArgb(148, 163, 184))
$script:AvailableIcon = New-StatusIcon $script:BaseIcon ([System.Drawing.Color]::FromArgb(34, 197, 94))

$script:NotifyIcon = New-Object System.Windows.Forms.NotifyIcon
$script:NotifyIcon.Text = $script:AppName
$script:NotifyIcon.Icon = $script:NormalIcon
$script:NotifyIcon.Visible = $true

$script:Menu = New-Object System.Windows.Forms.ContextMenuStrip
$script:Menu.ShowImageMargin = $false

$script:StatusItem = New-Object System.Windows.Forms.ToolStripMenuItem("Mode: Normal")
$script:StatusItem.Enabled = $false
$script:DurationStatusItem = New-Object System.Windows.Forms.ToolStripMenuItem("Duration: unlimited")
$script:DurationStatusItem.Enabled = $false
$script:NextRunItem = New-Object System.Windows.Forms.ToolStripMenuItem("Next tap: inactive")
$script:NextRunItem.Enabled = $false
$script:LastRunItem = New-Object System.Windows.Forms.ToolStripMenuItem("Last tap: never")
$script:LastRunItem.Enabled = $false

$script:ModeMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Mode")
$script:NormalItem = New-Object System.Windows.Forms.ToolStripMenuItem("Normal")
$script:AvailableItem = New-Object System.Windows.Forms.ToolStripMenuItem("Available")
$script:NormalItem.CheckOnClick = $false
$script:AvailableItem.CheckOnClick = $false
[void]$script:ModeMenu.DropDownItems.Add($script:NormalItem)
[void]$script:ModeMenu.DropDownItems.Add($script:AvailableItem)

$script:DurationMenu = New-Object System.Windows.Forms.ToolStripMenuItem("Duration for next mode")
$durationDefinitions = [ordered]@{
    "Unlimited" = "Unlimited"
    "30m" = "30 minutes"
    "1h" = "1 hour"
    "2h" = "2 hours"
    "EndOfDay" = "Until end of day"
}
foreach ($key in $durationDefinitions.Keys) {
    $item = New-Object System.Windows.Forms.ToolStripMenuItem($durationDefinitions[$key])
    $capturedKey = $key
    $item.Add_Click({ Set-SelectedDuration -Duration $capturedKey }.GetNewClosure())
    $script:DurationItems[$key] = $item
    [void]$script:DurationMenu.DropDownItems.Add($item)
}
$script:DurationItems["Unlimited"].Checked = $true

$script:RunOnceItem = New-Object System.Windows.Forms.ToolStripMenuItem("Run Available Tap Now")
$script:RestartItem = New-Object System.Windows.Forms.ToolStripMenuItem("Restart")
$script:ExitItem = New-Object System.Windows.Forms.ToolStripMenuItem("Exit")

$script:NormalItem.Add_Click({ Set-PresenceMode -Mode "Normal" -Reason "tray" })
$script:AvailableItem.Add_Click({ Set-PresenceMode -Mode "Available" -ExpiresAt (Get-SelectedExpiry) -Reason "tray" })
$script:RunOnceItem.Add_Click({ Invoke-PresenceTap -Reason "manual"; Update-Tray })
$script:RestartItem.Add_Click({ Restart-App })
$script:ExitItem.Add_Click({ Exit-App })

[void]$script:Menu.Items.Add($script:StatusItem)
[void]$script:Menu.Items.Add($script:DurationStatusItem)
[void]$script:Menu.Items.Add($script:NextRunItem)
[void]$script:Menu.Items.Add($script:LastRunItem)
[void]$script:Menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
[void]$script:Menu.Items.Add($script:ModeMenu)
[void]$script:Menu.Items.Add($script:DurationMenu)
[void]$script:Menu.Items.Add($script:RunOnceItem)
[void]$script:Menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
[void]$script:Menu.Items.Add($script:RestartItem)
[void]$script:Menu.Items.Add($script:ExitItem)
$script:NotifyIcon.ContextMenuStrip = $script:Menu

# ----------------------------------------------------------------------------
# Timer and cleanup
# ----------------------------------------------------------------------------

$script:Timer = New-Object System.Windows.Forms.Timer
$script:Timer.Interval = 1000
$script:Timer.Add_Tick({
    if ($script:IsShuttingDown) { return }

    $now = Get-Date
    if ($script:ModeExpiresAt -and $now -ge $script:ModeExpiresAt) {
        Set-PresenceMode -Mode "Normal" -Reason "duration-expired"
        Write-AppLog -Message "Die gewählte Dauer ist abgelaufen; Rückkehr zu Normal." -Level "WARNING"
        return
    }

    if ($script:CurrentMode -eq "Available" -and $script:NextRunAt -and $now -ge $script:NextRunAt) {
        Invoke-PresenceTap -Reason "timer"
    }

    Update-Tray
})
$script:Timer.Start()

[System.Windows.Forms.Application]::Add_ApplicationExit({
    try {
        if ($script:Timer) { $script:Timer.Stop(); $script:Timer.Dispose() }
        if ($script:NotifyIcon) { $script:NotifyIcon.Visible = $false; $script:NotifyIcon.Dispose() }
        if ($script:NormalIcon) { $script:NormalIcon.Dispose() }
        if ($script:AvailableIcon) { $script:AvailableIcon.Dispose() }
        if ($script:BaseIcon) { $script:BaseIcon.Dispose() }
        if ($script:Mutex) {
            try { $script:Mutex.ReleaseMutex() } catch {}
            $script:Mutex.Dispose()
        }
    } catch {}
})

# ----------------------------------------------------------------------------
# Start
# ----------------------------------------------------------------------------

try {
    Write-AppLog -Message ("Presence Toolbox v0.1 gestartet. Intervall={0}s; Startmodus=Normal" -f $script:IntervalSeconds) -Level "SUCCESS"
    Write-AppLog -Message "Prototyp enthält Normal, Available und zeitgesteuerte Rückkehr zu Normal."
    Set-PresenceMode -Mode "Normal" -Reason "startup"
    [System.Windows.Forms.Application]::Run()
} catch {
    Write-AppLog -Message ("Unerwarteter Programmfehler: {0}" -f $_.Exception.Message) -Level "ERROR"
    Write-Host ""
    Read-Host "Drücke Enter zum Schließen"
} finally {
    try { if ($script:NotifyIcon) { $script:NotifyIcon.Visible = $false } } catch {}
}
