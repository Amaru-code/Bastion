Presence Toolbox v0.1
=====================

Start:
  Doppelklick auf "Presence Toolbox.VBS"

Enthaltene Modi:
  Normal    - keine Aktivitätssimulation
  Available - Scroll-Lock-Tap alle 60 Sekunden

Dauer:
  Unlimited
  30 minutes
  1 hour
  2 hours
  Until end of day

Nach Ablauf einer Dauer wechselt die Toolbox automatisch zurück zu Normal.
Das Schließen des Terminalfensters beendet auch die Tray-Anwendung.

Optional:
  Kopiere den bestehenden Ordner "assets" aus Teams-Always-Green in diesen
  Projektordner. Dann wird das vorhandene Tray_Icon.ico weiterverwendet.
