using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;

namespace ARE.Automatisierung.Services.Excel;

public sealed class ExcelComOutputWriter(AppLogger logger)
{
    private const int XlTypePdf = 0;
    private const int XlQualityStandard = 0;
    private const int XlPortrait = 1;
    private const int XlCenter = -4108;
    private const int XlLeft = -4131;
    private const int XlRight = -4152;
    private const int XlContinuous = 1;
    private const int XlThin = 2;
    private const int XlMedium = -4138;
    private const int XlManual = -4135;
    private const int XlAutomatic = -4105;
    private const int MsoFalse = 0;
    private const int MsoTrue = -1;
    private static readonly int MarshNavy = Rgb(0, 15, 71);

    public Task<IReadOnlyDictionary<long, string>> WriteAsync(
        string workbookPath,
        IReadOnlyList<AreReport> reports,
        string pdfFolder,
        string? logoPath,
        bool createPdfs,
        IProgress<RunProgress>? progress = null,
        CancellationToken token = default) =>
        StaThreadRunner.RunAsync<IReadOnlyDictionary<long, string>>(() => Write(workbookPath, reports, pdfFolder, logoPath, createPdfs, progress), token);

    private IReadOnlyDictionary<long, string> Write(
        string workbookPath,
        IReadOnlyList<AreReport> reports,
        string pdfFolder,
        string? logoPath,
        bool createPdfs,
        IProgress<RunProgress>? progress)
    {
        var excelType = Type.GetTypeFromProgID("Excel.Application") ??
            throw new InvalidOperationException("Microsoft Excel Desktop wurde nicht gefunden. Für die finale XLSX/XLSM-Ausgabe und den druckgetreuen PDF-Export wird Excel als unsichtbare Rendering-Schicht benötigt.");

        dynamic? excel = null;
        dynamic? wb = null;
        var pdfs = new Dictionary<long, string>();
        try
        {
            Directory.CreateDirectory(pdfFolder);
            excel = Activator.CreateInstance(excelType)!;
            excel.Visible = false;
            excel.DisplayAlerts = false;
            excel.ScreenUpdating = false;
            excel.EnableEvents = false;
            excel.Calculation = XlManual;
            wb = excel.Workbooks.Open(workbookPath, 0, false);

            DeleteOldAreSheets(wb);

            for (var i = 0; i < reports.Count; i++)
            {
                var report = reports[i];
                progress?.Report(new RunProgress(45 + 20d * (i + 1) / Math.Max(1, reports.Count), "ARE-Blätter erzeugen", $"LTRG {report.Target.LtrgText}"));
                dynamic? ws = null;
                try
                {
                    ws = AddWorksheetAtEnd(wb);
                    ws.Name = UniqueSheetName(wb, report.SheetName);
                    BuildSheet(excel, ws, report, logoPath);

                    if (createPdfs)
                    {
                        var sheetName = Convert.ToString(ws.Name) ?? report.SheetName;
                        var pdfPath = Path.Combine(pdfFolder, $"ERG_VWÜ_{SanitizeFileName(sheetName)}.pdf");
                        ws.ExportAsFixedFormat(XlTypePdf, pdfPath, XlQualityStandard, true, false);
                        pdfs[report.Target.Ltrg] = pdfPath;
                        logger.Info($"ARE-PDF | {pdfPath}");
                    }
                }
                finally
                {
                    ComHelpers.FinalRelease(ws);
                }
            }

            excel.Calculation = XlAutomatic;
            wb.Save();
            logger.Info($"EXCEL | Ausgabekopie gespeichert: {workbookPath}");
            return pdfs;
        }
        finally
        {
            try { if (wb is not null) wb.Close(true); } catch { }
            try
            {
                if (excel is not null)
                {
                    excel.ScreenUpdating = true;
                    excel.EnableEvents = true;
                    excel.DisplayAlerts = true;
                    excel.Quit();
                }
            }
            catch { }
            ComHelpers.FinalRelease(wb);
            ComHelpers.FinalRelease(excel);
        }
    }

    private static dynamic AddWorksheetAtEnd(dynamic wb)
    {
        if ((bool)wb.ProtectStructure)
            throw new InvalidOperationException("Die Struktur der Arbeitsmappe ist geschützt. Bitte den Arbeitsmappenschutz in Excel aufheben und erneut starten.");

        wb.Activate();
        wb.Worksheets[1].Activate();
        dynamic ws = wb.Worksheets.Add();

        if ((int)wb.Worksheets.Count > 1)
        {
            dynamic? last = null;
            try
            {
                last = wb.Worksheets[wb.Worksheets.Count];
                var isAlreadyLast = string.Equals(Convert.ToString(ws.Name), Convert.ToString(last.Name), StringComparison.OrdinalIgnoreCase);
                if (!isAlreadyLast)
                {
                    try { ws.Move(Type.Missing, last); }
                    catch { /* Reihenfolge ist nicht fachkritisch. */ }
                }
            }
            finally { ComHelpers.FinalRelease(last); }
        }
        return ws;
    }

    private static void DeleteOldAreSheets(dynamic wb)
    {
        for (var i = (int)wb.Worksheets.Count; i >= 1; i--)
        {
            dynamic? ws = null;
            try
            {
                ws = wb.Worksheets[i];
                var name = Convert.ToString(ws.Name) ?? "";
                if (name.StartsWith("ARE ", StringComparison.OrdinalIgnoreCase)) ws.Delete();
            }
            finally { ComHelpers.FinalRelease(ws); }
        }
    }

    private static void BuildSheet(dynamic excel, dynamic ws, AreReport report, string? logoPath)
    {
        ws.Cells.Clear();
        ws.Range("E1:F1").Merge();
        ws.Range("E2:F2").Merge();
        ws.Range("A4:F4").Merge();
        ws.Range("A6:F6").Merge();
        ws.Range("A7:F7").Merge();

        ws.Range("E1").Value2 = $"Einzelübertritte {report.ReportPeriod}";
        ws.Range("E2").Value2 = $"ARE {(string.IsNullOrWhiteSpace(report.Target.Are) ? "n.v." : report.Target.Are)} (LTRG {report.Target.LtrgText})";
        ws.Range("A4").Value2 = "Übertragene Rückstellungen bei Einzelübertritten";
        ws.Range("A6").Value2 = $"Positive Beträge erhält die {report.Target.ShortName} von der genannten Gesellschaft,";
        ws.Range("A7").Value2 = $"negative Beträge gibt die {report.Target.ShortName} an die genannte Gesellschaft ab.";

        ws.Range("H1").Value2 = "CHECK";
        ws.Range("I1").Value2 = "ORZ, OK";
        ws.Range("H2").Value2 = report.Target.Ltrg;
        ws.Range("I2").Value2 = report.Target.Are;
        ws.Range("J2").Value2 = report.Target.Name;
        ws.Range("H3").Value2 = "CHECK";
        ws.Range("H4").Value2 = report.NetBalance;
        ws.Range("I4").Value2 = report.ControlDelta;

        dynamic all = ws.Cells;
        all.Font.Name = "Arial";
        all.Font.Size = 10;
        all.VerticalAlignment = XlCenter;
        ComHelpers.FinalRelease(all);

        ws.Range("A1:F5000").Font.Color = MarshNavy;
        ws.Range("E1:F2").HorizontalAlignment = XlCenter;
        ws.Range("A4:F4").Font.Bold = true;
        ws.Range("A4:F4").Font.Size = 15;
        ws.Range("A4:F4").HorizontalAlignment = XlCenter;
        ws.Range("A6:F7").Font.Size = 9;
        ws.Range("A6:F7").WrapText = true;
        ws.Range("A6:F7").HorizontalAlignment = XlLeft;
        ws.Rows[6].RowHeight = 28;
        ws.Rows[7].RowHeight = 28;

        ws.Columns["A"].ColumnWidth = 12;
        ws.Columns["B"].ColumnWidth = 12;
        ws.Columns["C"].ColumnWidth = 12;
        ws.Columns["D"].ColumnWidth = 17.5;
        ws.Columns["E"].ColumnWidth = 12.5;
        ws.Columns["F"].ColumnWidth = 12.5;
        ws.Columns["G"].ColumnWidth = 3;
        ws.Columns["H"].ColumnWidth = 9;
        ws.Columns["I"].ColumnWidth = 9;
        ws.Columns["J"].ColumnWidth = 40;
        ws.Columns["A:B"].NumberFormat = "0";
        ws.Columns["C"].NumberFormat = "dd.mm.yyyy";
        ws.Columns["D:F"].NumberFormat = "#,##0;-#,##0";
        ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0";

        var currentRow = 10;
        foreach (var group in report.Groups)
        {
            var sectionRow = currentRow;
            var headerRow = sectionRow + 1;
            var dataStart = headerRow + 1;
            var dataEnd = dataStart + group.Rows.Count - 1;
            var subtotalRow = dataEnd + 1;

            ws.Range(ws.Cells[sectionRow, 1], ws.Cells[sectionRow, 6]).Merge();
            ws.Cells[sectionRow, 1].Value2 = $"{group.Counterparty.ShortName} (ARE {(string.IsNullOrWhiteSpace(group.Counterparty.Are) ? "n.v." : group.Counterparty.Are)}, LTRG {group.Counterparty.LtrgText})";
            ws.Cells[sectionRow, 8].Value2 = group.Counterparty.Ltrg;
            ws.Cells[sectionRow, 9].Value2 = group.Counterparty.Are;
            ws.Cells[sectionRow, 10].Value2 = group.Counterparty.Name;

            var headings = new object[1, 6] { { "PNR", "alte PNR", "Übertritt", "Pensionen (alt)\n(Euro)", "BSAV\n(Euro)", "Summe\n(Euro)" } };
            ws.Range(ws.Cells[headerRow, 1], ws.Cells[headerRow, 6]).Value2 = headings;

            if (group.Rows.Count > 0)
            {
                var matrix = new object[group.Rows.Count, 6];
                for (var r = 0; r < group.Rows.Count; r++)
                {
                    var row = group.Rows[r];
                    matrix[r, 0] = row.Pnr;
                    matrix[r, 1] = row.OldPnr;
                    matrix[r, 2] = row.TransferDate.HasValue
                        ? row.TransferDate.Value.ToOADate()
                        : string.Empty;
                    matrix[r, 3] = row.Pension;
                    matrix[r, 4] = row.Bsav;
                    matrix[r, 5] = row.Total;
                }
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 6]).Value2 = matrix;
            }

            ws.Cells[subtotalRow, 4].Value2 = group.PensionSubtotal;
            ws.Cells[subtotalRow, 5].Value2 = group.BsavSubtotal;
            ws.Cells[subtotalRow, 6].Value2 = group.TotalSubtotal;

            dynamic section = ws.Range(ws.Cells[sectionRow, 1], ws.Cells[sectionRow, 6]);
            section.Font.Bold = true;
            section.HorizontalAlignment = XlCenter;
            section.Borders.LineStyle = XlContinuous;
            section.Borders.Weight = XlMedium;
            ws.Rows[sectionRow].RowHeight = 19;
            ComHelpers.FinalRelease(section);

            dynamic header = ws.Range(ws.Cells[headerRow, 1], ws.Cells[headerRow, 6]);
            header.Font.Bold = true;
            header.HorizontalAlignment = XlCenter;
            header.WrapText = true;
            ws.Rows[headerRow].RowHeight = 31;
            ComHelpers.FinalRelease(header);

            if (group.Rows.Count > 0)
            {
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 3]).HorizontalAlignment = XlCenter;
                ws.Range(ws.Cells[dataStart, 4], ws.Cells[dataEnd, 6]).HorizontalAlignment = XlRight;
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 6]).RowHeight = 15;
            }
            dynamic subtotal = ws.Range(ws.Cells[subtotalRow, 4], ws.Cells[subtotalRow, 6]);
            subtotal.Font.Bold = true;
            subtotal.Borders.LineStyle = 0;
            subtotal.Borders[8].LineStyle = XlContinuous;
            subtotal.Borders[8].Weight = XlThin;
            ComHelpers.FinalRelease(subtotal);
            ws.Rows[subtotalRow].RowHeight = 15;
            ws.Rows[subtotalRow + 1].RowHeight = 8;

            currentRow = subtotalRow + 2;
        }

        var lastContentRow = Math.Max(7, currentRow - 1);
        ws.Range($"A1:F{lastContentRow}").Font.Color = MarshNavy;
        ws.PageSetup.PrintArea = $"$A$1:$F${lastContentRow}";
        ws.PageSetup.PrintGridlines = false;
        ws.PageSetup.Orientation = XlPortrait;
        ws.PageSetup.Zoom = false;
        ws.PageSetup.FitToPagesWide = 1;
        ws.PageSetup.FitToPagesTall = false;
        ws.PageSetup.CenterHorizontally = true;
        ws.PageSetup.LeftMargin = excel.CentimetersToPoints(1.2);
        ws.PageSetup.RightMargin = excel.CentimetersToPoints(1.2);
        ws.PageSetup.TopMargin = excel.CentimetersToPoints(1.0);
        ws.PageSetup.BottomMargin = excel.CentimetersToPoints(1.0);
        ws.PageSetup.HeaderMargin = excel.CentimetersToPoints(0.4);
        ws.PageSetup.FooterMargin = excel.CentimetersToPoints(0.4);

        if (!string.IsNullOrWhiteSpace(logoPath) && File.Exists(logoPath))
        {
            try
            {
                dynamic anchor = ws.Range("A1");
                dynamic picture = ws.Shapes.AddPicture(logoPath, MsoFalse, MsoTrue, anchor.Left, anchor.Top + 2, -1, -1);
                picture.Name = "ARE_Mercer_Logo";
                picture.LockAspectRatio = MsoTrue;
                picture.Height = 34;
                ComHelpers.FinalRelease(picture);
                ComHelpers.FinalRelease(anchor);
            }
            catch { /* logo is optional in v2 */ }
        }
    }

    private static string UniqueSheetName(dynamic wb, string requested)
    {
        var baseName = requested.Length <= 31 ? requested : requested[..31];
        var candidate = baseName;
        var counter = 2;
        while (SheetExists(wb, candidate))
        {
            var suffix = $"_{counter++}";
            candidate = baseName[..Math.Min(baseName.Length, 31 - suffix.Length)] + suffix;
        }
        return candidate;
    }

    private static bool SheetExists(dynamic wb, string name)
    {
        for (var i = 1; i <= (int)wb.Worksheets.Count; i++)
        {
            dynamic? ws = null;
            try
            {
                ws = wb.Worksheets[i];
                if (string.Equals(Convert.ToString(ws.Name), name, StringComparison.OrdinalIgnoreCase)) return true;
            }
            finally { ComHelpers.FinalRelease(ws); }
        }
        return false;
    }

    private static string SanitizeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '-');
        return value;
    }

    private static int Rgb(int r, int g, int b) => r + g * 256 + b * 65536;
}
