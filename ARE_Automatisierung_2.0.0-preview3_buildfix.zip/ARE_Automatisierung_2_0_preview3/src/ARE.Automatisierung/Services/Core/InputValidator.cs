using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Excel;

namespace ARE.Automatisierung.Services.Core;

public sealed class InputValidator(
    SourceWorkbookReader sourceReader,
    SerialDataReader serialReader,
    AreEngine engine,
    OfficePreflightService officePreflight,
    DocxTemplateInspector templateInspector,
    AppLogger logger)
{
    public async Task<ValidationSnapshot> ValidateAsync(InputSelection input, IProgress<RunProgress>? progress = null, CancellationToken cancellationToken = default)
    {
        ValidatePaths(input);
        if (!input.CreateExcelOutput && !input.CreateArePdfs && !input.CreateLetters)
            throw new InvalidOperationException("Bitte mindestens eine Ausgabeoption aktivieren: Excel-Ausgabekopie, ARE-PDFs oder Anschreiben.");

        officePreflight.Validate(
            needsExcel: input.CreateExcelOutput || input.CreateArePdfs || input.CreateLetters,
            needsWord: input.CreateLetters);

        var mergeFieldCount = templateInspector.CountMergeFields(input.WordTemplatePath);
        progress?.Report(new RunProgress(8, "ARE-Quelldatei einlesen"));
        var source = await sourceReader.ReadAsync(input.AreSourcePath, cancellationToken);

        progress?.Report(new RunProgress(35, "ARE-Fachlogik aufbauen"));
        var reports = engine.BuildReports(source);

        progress?.Report(new RunProgress(50, "Serienbriefdaten einlesen"));
        var serial = await serialReader.ReadAsync(input.SerialDataPath, cancellationToken);
        var affected = reports.Select(r => r.Target.Ltrg).ToHashSet();
        var filtered = serial.Where(r => r.Ltrg.HasValue && affected.Contains(r.Ltrg.Value)).ToArray();

        var preview = reports.Select(r => new PreviewItem
        {
            Ltrg = r.Target.Ltrg,
            Are = r.Target.Are,
            Company = r.Target.Name,
            GroupCount = r.Groups.Count,
            PositionCount = r.PositionCount,
            NetBalance = r.NetBalance,
            LetterCount = filtered.Count(x => x.Ltrg == r.Target.Ltrg)
        }).ToArray();

        var snapshot = new ValidationSnapshot
        {
            Input = input,
            Source = source,
            Reports = reports,
            SerialRecords = serial,
            AffectedSerialRecords = filtered,
            Preview = preview
        };

        foreach (var report in reports.Where(x => Math.Abs(x.ControlDelta) > 0.01))
            snapshot.Warnings.Add($"LTRG {AreEngine.FormatLtrg(report.Target.Ltrg)}: Kontrollsaldo weicht um {report.ControlDelta:N2} EUR ab.");
        foreach (var report in reports.Where(x => !filtered.Any(s => s.Ltrg == x.Target.Ltrg)))
            snapshot.Warnings.Add($"LTRG {AreEngine.FormatLtrg(report.Target.Ltrg)}: keine passende Zeile in den Serienbriefdaten gefunden.");
        if (input.CreateLetters && mergeFieldCount == 0)
            snapshot.Warnings.Add("Die Word-Vorlage enthält keine erkennbaren MERGEFIELD-Felder. Anschreiben würden dadurch keine personenbezogenen Werte übernehmen.");
        if (input.CreateAggregate && !input.CreateLetters)
            snapshot.Warnings.Add("'Gesamtdokumente' ist aktiviert, 'Anschreiben' jedoch nicht. Es kann daher kein Gesamtdokument erzeugt werden.");

        progress?.Report(new RunProgress(100, $"Prüfung erfolgreich: {reports.Count} Gesellschaften, {filtered.Length} Anschreiben"));
        logger.Info($"VALIDIERUNG | erfolgreich | Berichte={reports.Count} | betroffene Serienbriefzeilen={filtered.Length}");
        return snapshot;
    }

    private static void ValidatePaths(InputSelection input)
    {
        if (!File.Exists(input.AreSourcePath)) throw new FileNotFoundException("ARE-Quelldatei wurde nicht gefunden.", input.AreSourcePath);
        if (!File.Exists(input.WordTemplatePath)) throw new FileNotFoundException("Word-Vorlage wurde nicht gefunden.", input.WordTemplatePath);
        if (!File.Exists(input.SerialDataPath)) throw new FileNotFoundException("Serienbriefdatei wurde nicht gefunden.", input.SerialDataPath);
        var sourceExt = Path.GetExtension(input.AreSourcePath).ToLowerInvariant();
        if (sourceExt != ".xlsx" && sourceExt != ".xlsm")
            throw new InvalidOperationException("ARE-Quelle muss XLSX oder XLSM sein.");
        if (!Path.GetExtension(input.WordTemplatePath).Equals(".docx", StringComparison.OrdinalIgnoreCase)) throw new InvalidOperationException("Word-Vorlage muss DOCX sein.");
        var serialExt = Path.GetExtension(input.SerialDataPath).ToLowerInvariant();
        if (serialExt != ".xlsx" && serialExt != ".xlsm" && serialExt != ".xls")
            throw new InvalidOperationException("Serienbriefdaten müssen XLSX, XLSM oder XLS sein.");
        if (string.IsNullOrWhiteSpace(input.OutputFolder)) throw new InvalidOperationException("Bitte einen Ausgabeordner auswählen.");
        Directory.CreateDirectory(input.OutputFolder);
        if (!string.IsNullOrWhiteSpace(input.LogoPath) && !File.Exists(input.LogoPath)) throw new FileNotFoundException("Die ausgewählte Logo-Datei wurde nicht gefunden.", input.LogoPath);
    }
}
