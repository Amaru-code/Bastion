@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0 - Build Test

set "DOTNET_CMD="
if exist "%~dp0tools\dotnet\dotnet.exe" set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
if not defined DOTNET_CMD (
  where dotnet.exe >nul 2>&1
  if not errorlevel 1 set "DOTNET_CMD=dotnet"
)
if not defined DOTNET_CMD (
  echo FEHLER: Kein dotnet gefunden.
  echo Bitte zuerst START.bat ausfuehren, damit das portable SDK eingerichtet wird.
  pause
  exit /b 1
)

echo ============================================================
echo  ARE Automatisierung 2.0 - Build Test
echo ============================================================
echo.
echo DOTNET: %DOTNET_CMD%
echo.

"%DOTNET_CMD%" --version
"%DOTNET_CMD%" build "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" -c Release --nologo > "%~dp0BUILD_TEST.log" 2>&1
set "RC=%ERRORLEVEL%"
type "%~dp0BUILD_TEST.log"
echo.
if not "%RC%"=="0" (
  echo FEHLER: Build fehlgeschlagen. Log: %~dp0BUILD_TEST.log
  pause
  exit /b %RC%
)
echo Build erfolgreich.
echo Log: %~dp0BUILD_TEST.log
if exist "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe" (
  echo EXE: %~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe
)
pause
exit /b 0
