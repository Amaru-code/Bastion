@echo off
cd /d "%~dp0"
title Intel LNW DC Tool - Go Standalone
LNW_DC_Tool.exe
