# Intel LNW DC Tool – Go Standalone

## Start

Es ist keine Installation erforderlich.

1. ZIP vollständig entpacken.
2. `start.bat` doppelklicken.
3. Die vier Pfade bestätigen oder einfügen.
4. Nach Abschluss die erzeugte `.xlsm` und den `_report`-Ordner prüfen.

Alternativ kann eine Konfiguration übergeben werden:

```bat
LNW_DC_Tool.exe config.example.json
```

## Enthaltene Logik

- Öffnet `.xlsx` und `.xlsm` direkt als Office-Open-XML-Container.
- Behält nicht bearbeitete Bestandteile einschließlich `vbaProject.bin`, Verknüpfungen und Makroobjekten bei.
- Erkennt `Import DC LNW` und die WWID-Kopfzeile.
- Überträgt `CL:CU` positionsgleich nach `AJ:AS`.
- Aggregiert `BI:BN` nach WWID, Fondsname und `Umsatzart = Fondsportfolioanpassung`.
- Berechnet Kandidaten für `CL:CU` als Startbestand plus DU-Bewegung, sofern keine Formel vorhanden ist.
- Erzeugt `audit_trail.csv`, `comparison_differences.csv` und `run_summary.json`.
- Setzt Excel auf vollständige Neuberechnung beim nächsten Öffnen.

## Wichtiger Prüfhinweis

Da die echten Arbeitsmappen beim Build nicht vorlagen, muss der erste Lauf über den Vergleichsbericht fachlich geprüft werden. Die gesicherte Logik für `AJ:AS` und `BI:BN` ist fest implementiert. Die Kandidatenlogik für `CL:CU` bleibt als Hypothese erkennbar im Audit-Trail.
