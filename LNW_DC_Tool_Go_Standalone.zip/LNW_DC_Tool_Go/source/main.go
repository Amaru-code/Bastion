package main

import (
	"archive/zip"
	"bufio"
	"encoding/csv"
	"encoding/json"
	"encoding/xml"
	"errors"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"regexp"
	"sort"
	"strconv"
	"strings"
	"time"
)

type Config struct {
	OldTemplate      string `json:"old_template"`
	DUFile           string `json:"du_file"`
	ComparisonTarget string `json:"comparison_target"`
	Output           string `json:"output"`
	Sheet            string `json:"sheet"`
}

type Cell struct {
	Ref     string
	Type    string
	Style   string
	Formula string
	Value   string
	Inline  string
}

type Row struct {
	Num   int
	Cells map[string]*Cell
}

type Sheet struct {
	Rows map[int]*Row
}

type Audit struct {
	WWID, Cell, Rule, Value, Source string
}

type DURecord struct {
	WWID, Fund, TxType string
	Units, Amount      float64
}

type Agg struct{ Units, Amount float64 }

var reNonSpace = regexp.MustCompile(`\s+`)
var reFundWords = regexp.MustCompile(`(?i)\b(anfang|start|ende|endbestand|bestand|stichtag|anteile|stücke|stuecke|wert|betrag|eur)\b`)

func norm(v string) string {
	v = strings.ReplaceAll(v, "\u00a0", " ")
	v = strings.TrimSpace(v)
	v = reNonSpace.ReplaceAllString(v, " ")
	return strings.ToLower(v)
}

func parseNumber(s string) float64 {
	s = strings.TrimSpace(strings.ReplaceAll(strings.ReplaceAll(s, "\u00a0", ""), " ", ""))
	if s == "" {
		return 0
	}
	if strings.Contains(s, ",") && strings.Contains(s, ".") {
		if strings.LastIndex(s, ",") > strings.LastIndex(s, ".") {
			s = strings.ReplaceAll(s, ".", "")
			s = strings.ReplaceAll(s, ",", ".")
		} else {
			s = strings.ReplaceAll(s, ",", "")
		}
	} else if strings.Contains(s, ",") {
		s = strings.ReplaceAll(s, ".", "")
		s = strings.ReplaceAll(s, ",", ".")
	}
	clean := regexp.MustCompile(`[^0-9+\-.]`).ReplaceAllString(s, "")
	f, _ := strconv.ParseFloat(clean, 64)
	return f
}

func colNum(col string) int {
	n := 0
	for _, r := range strings.ToUpper(col) {
		n = n*26 + int(r-'A'+1)
	}
	return n
}
func colName(n int) string {
	s := ""
	for n > 0 {
		n--
		s = string(rune('A'+n%26)) + s
		n /= 26
	}
	return s
}
func splitRef(ref string) (string, int) {
	i := 0
	for i < len(ref) && ((ref[i] >= 'A' && ref[i] <= 'Z') || (ref[i] >= 'a' && ref[i] <= 'z')) {
		i++
	}
	r, _ := strconv.Atoi(ref[i:])
	return strings.ToUpper(ref[:i]), r
}

func unzipMap(path string) (map[string][]byte, map[string]uint16, error) {
	zr, err := zip.OpenReader(path)
	if err != nil {
		return nil, nil, err
	}
	defer zr.Close()
	out := map[string][]byte{}
	methods := map[string]uint16{}
	for _, f := range zr.File {
		rc, e := f.Open()
		if e != nil {
			return nil, nil, e
		}
		b, e := io.ReadAll(rc)
		rc.Close()
		if e != nil {
			return nil, nil, e
		}
		out[f.Name] = b
		methods[f.Name] = f.Method
	}
	return out, methods, nil
}
func zipMap(path string, files map[string][]byte, methods map[string]uint16) error {
	tmp := path + ".tmp"
	os.Remove(tmp)
	fh, err := os.Create(tmp)
	if err != nil {
		return err
	}
	zw := zip.NewWriter(fh)
	names := make([]string, 0, len(files))
	for n := range files {
		names = append(names, n)
	}
	sort.Strings(names)
	for _, n := range names {
		h := &zip.FileHeader{Name: n, Method: methods[n]}
		if h.Method == 0 {
			h.Method = zip.Deflate
		}
		h.SetModTime(time.Now())
		w, e := zw.CreateHeader(h)
		if e != nil {
			return e
		}
		if _, e = w.Write(files[n]); e != nil {
			return e
		}
	}
	if err = zw.Close(); err != nil {
		return err
	}
	if err = fh.Close(); err != nil {
		return err
	}
	os.Remove(path)
	return os.Rename(tmp, path)
}

func sharedStrings(files map[string][]byte) []string {
	b, ok := files["xl/sharedStrings.xml"]
	if !ok {
		return nil
	}
	dec := xml.NewDecoder(strings.NewReader(string(b)))
	var out []string
	inSI := false
	cur := ""
	for {
		t, e := dec.Token()
		if e == io.EOF {
			break
		}
		if e != nil {
			break
		}
		switch x := t.(type) {
		case xml.StartElement:
			if x.Name.Local == "si" {
				inSI = true
				cur = ""
			}
			if inSI && x.Name.Local == "t" {
				var s string
				dec.DecodeElement(&s, &x)
				cur += s
			}
		case xml.EndElement:
			if x.Name.Local == "si" {
				out = append(out, cur)
				inSI = false
			}
		}
	}
	return out
}

type workbookXML struct {
	Sheets []struct {
		Name string `xml:"name,attr"`
		RID  string `xml:"id,attr"`
	} `xml:"sheets>sheet"`
}
type relsXML struct {
	Rels []struct {
		ID     string `xml:"Id,attr"`
		Target string `xml:"Target,attr"`
	} `xml:"Relationship"`
}

func sheetPath(files map[string][]byte, sheetName string) (string, error) {
	var wb workbookXML
	if err := xml.Unmarshal(files["xl/workbook.xml"], &wb); err != nil {
		return "", err
	}
	rid := ""
	for _, s := range wb.Sheets {
		if s.Name == sheetName {
			rid = s.RID
			break
		}
	}
	if rid == "" {
		return "", fmt.Errorf("Blatt %q nicht gefunden", sheetName)
	}
	var rs relsXML
	if err := xml.Unmarshal(files["xl/_rels/workbook.xml.rels"], &rs); err != nil {
		return "", err
	}
	for _, r := range rs.Rels {
		if r.ID == rid {
			t := strings.ReplaceAll(r.Target, "\\", "/")
			if strings.HasPrefix(t, "/") {
				t = strings.TrimPrefix(t, "/")
			} else if !strings.HasPrefix(t, "xl/") {
				t = "xl/" + t
			}
			return filepath.ToSlash(filepath.Clean(t)), nil
		}
	}
	return "", errors.New("Worksheet-Relation nicht gefunden")
}

func parseSheet(b []byte, ss []string) (*Sheet, error) {
	sh := &Sheet{Rows: map[int]*Row{}}
	dec := xml.NewDecoder(strings.NewReader(string(b)))
	var rowNum int
	var cur *Cell
	for {
		t, e := dec.Token()
		if e == io.EOF {
			break
		}
		if e != nil {
			return nil, e
		}
		switch x := t.(type) {
		case xml.StartElement:
			if x.Name.Local == "row" {
				rowNum = 0
				for _, a := range x.Attr {
					if a.Name.Local == "r" {
						rowNum, _ = strconv.Atoi(a.Value)
					}
				}
				if rowNum == 0 {
					rowNum = len(sh.Rows) + 1
				}
				sh.Rows[rowNum] = &Row{Num: rowNum, Cells: map[string]*Cell{}}
			}
			if x.Name.Local == "c" {
				cur = &Cell{}
				for _, a := range x.Attr {
					switch a.Name.Local {
					case "r":
						cur.Ref = a.Value
					case "t":
						cur.Type = a.Value
					case "s":
						cur.Style = a.Value
					}
				}
			}
			if cur != nil && x.Name.Local == "f" {
				var s string
				dec.DecodeElement(&s, &x)
				cur.Formula = s
			}
			if cur != nil && x.Name.Local == "v" {
				var s string
				dec.DecodeElement(&s, &x)
				cur.Value = s
			}
			if cur != nil && x.Name.Local == "t" && cur.Type == "inlineStr" {
				var s string
				dec.DecodeElement(&s, &x)
				cur.Inline = s
			}
		case xml.EndElement:
			if x.Name.Local == "c" && cur != nil {
				_, r := splitRef(cur.Ref)
				if rr := sh.Rows[r]; rr != nil {
					rr.Cells[strings.ToUpper(cur.Ref)] = cur
				}
				cur = nil
			}
		}
	}
	return sh, nil
}
func cellText(c *Cell, ss []string) string {
	if c == nil {
		return ""
	}
	if c.Type == "s" {
		i, _ := strconv.Atoi(c.Value)
		if i >= 0 && i < len(ss) {
			return ss[i]
		}
	}
	if c.Type == "inlineStr" {
		return c.Inline
	}
	return c.Value
}
func setNumber(sh *Sheet, row int, col string, v float64, preserveFormula bool) bool {
	ref := strings.ToUpper(col) + strconv.Itoa(row)
	rr := sh.Rows[row]
	if rr == nil {
		rr = &Row{Num: row, Cells: map[string]*Cell{}}
		sh.Rows[row] = rr
	}
	c := rr.Cells[ref]
	if c == nil {
		c = &Cell{Ref: ref}
		rr.Cells[ref] = c
	}
	if preserveFormula && c.Formula != "" {
		return false
	}
	c.Type = "n"
	c.Formula = ""
	c.Inline = ""
	c.Value = strconv.FormatFloat(v, 'f', -1, 64)
	return true
}
func setText(sh *Sheet, row int, col, val string, preserveFormula bool) bool {
	ref := strings.ToUpper(col) + strconv.Itoa(row)
	rr := sh.Rows[row]
	if rr == nil {
		rr = &Row{Num: row, Cells: map[string]*Cell{}}
		sh.Rows[row] = rr
	}
	c := rr.Cells[ref]
	if c == nil {
		c = &Cell{Ref: ref}
		rr.Cells[ref] = c
	}
	if preserveFormula && c.Formula != "" {
		return false
	}
	c.Type = "inlineStr"
	c.Formula = ""
	c.Value = ""
	c.Inline = val
	return true
}
func copyCell(sh *Sheet, srcRow int, srcCol string, dstRow int, dstCol string) bool {
	src := sh.Rows[srcRow]
	if src == nil {
		return setNumber(sh, dstRow, dstCol, 0, false)
	}
	c := src.Cells[strings.ToUpper(srcCol)+strconv.Itoa(srcRow)]
	if c == nil {
		return setNumber(sh, dstRow, dstCol, 0, false)
	}
	if c.Type == "s" || c.Type == "inlineStr" {
		return setText(sh, dstRow, dstCol, cellText(c, nil), false)
	}
	v := parseNumber(c.Value)
	return setNumber(sh, dstRow, dstCol, v, false)
}
func escape(s string) string { var b strings.Builder; xml.EscapeText(&b, []byte(s)); return b.String() }
func renderSheetData(sh *Sheet) string {
	rows := make([]int, 0, len(sh.Rows))
	for r := range sh.Rows {
		rows = append(rows, r)
	}
	sort.Ints(rows)
	var b strings.Builder
	b.WriteString(`<sheetData>`)
	for _, r := range rows {
		rr := sh.Rows[r]
		refs := make([]string, 0, len(rr.Cells))
		for ref := range rr.Cells {
			refs = append(refs, ref)
		}
		sort.Slice(refs, func(i, j int) bool {
			ci, _ := splitRef(refs[i])
			cj, _ := splitRef(refs[j])
			return colNum(ci) < colNum(cj)
		})
		b.WriteString(fmt.Sprintf(`<row r="%d">`, r))
		for _, ref := range refs {
			c := rr.Cells[ref]
			b.WriteString(`<c r="` + ref + `"`)
			if c.Style != "" {
				b.WriteString(` s="` + c.Style + `"`)
			}
			if c.Type != "" && c.Type != "n" {
				b.WriteString(` t="` + c.Type + `"`)
			}
			b.WriteString(`>`)
			if c.Formula != "" {
				b.WriteString(`<f>` + escape(c.Formula) + `</f>`)
			}
			if c.Type == "inlineStr" {
				b.WriteString(`<is><t>` + escape(c.Inline) + `</t></is>`)
			} else {
				b.WriteString(`<v>` + escape(c.Value) + `</v>`)
			}
			b.WriteString(`</c>`)
		}
		b.WriteString(`</row>`)
	}
	b.WriteString(`</sheetData>`)
	return b.String()
}
func replaceSheetData(original []byte, sh *Sheet) []byte {
	re := regexp.MustCompile(`(?s)<sheetData[^>]*>.*?</sheetData>`)
	return re.ReplaceAll(original, []byte(renderSheetData(sh)))
}

func findHeader(sh *Sheet, ss []string, aliases []string, maxRows int) (int, int, map[int]string, error) {
	aset := map[string]bool{}
	for _, a := range aliases {
		aset[norm(a)] = true
	}
	for r := 1; r <= maxRows; r++ {
		rr := sh.Rows[r]
		if rr == nil {
			continue
		}
		headers := map[int]string{}
		wcol := 0
		for _, c := range rr.Cells {
			col, _ := splitRef(c.Ref)
			txt := cellText(c, ss)
			if strings.TrimSpace(txt) != "" {
				headers[colNum(col)] = txt
				if aset[norm(txt)] {
					wcol = colNum(col)
				}
			}
		}
		if wcol > 0 {
			return r, wcol, headers, nil
		}
	}
	return 0, 0, nil, errors.New("WWID-Kopfzeile nicht gefunden")
}

func readDU(path string) ([]DURecord, error) {
	files, _, err := unzipMap(path)
	if err != nil {
		return nil, err
	}
	ss := sharedStrings(files)
	var wb workbookXML
	if err = xml.Unmarshal(files["xl/workbook.xml"], &wb); err != nil {
		return nil, err
	}
	aliases := map[string][]string{"wwid": {"wwid"}, "fund": {"fondsname", "fonds name", "fonds"}, "tx": {"umsatzart", "umsatz art"}, "units": {"umsatzstuecke", "umsatzstücke", "umsatz stuecke"}, "amount": {"zahlbetrag", "zahl betrag", "betrag"}}
	for _, ws := range wb.Sheets {
		p, e := sheetPath(files, ws.Name)
		if e != nil {
			continue
		}
		sh, e := parseSheet(files[p], ss)
		if e != nil {
			continue
		}
		for hr := 1; hr <= 20; hr++ {
			rr := sh.Rows[hr]
			if rr == nil {
				continue
			}
			idx := map[string]int{}
			for _, c := range rr.Cells {
				col, _ := splitRef(c.Ref)
				t := norm(cellText(c, ss))
				for k, als := range aliases {
					for _, a := range als {
						if t == norm(a) {
							idx[k] = colNum(col)
						}
					}
				}
			}
			if len(idx) == 5 {
				var out []DURecord
				maxr := 0
				for r := range sh.Rows {
					if r > maxr {
						maxr = r
					}
				}
				for r := hr + 1; r <= maxr; r++ {
					row := sh.Rows[r]
					if row == nil {
						continue
					}
					get := func(n int) string { return cellText(row.Cells[colName(n)+strconv.Itoa(r)], ss) }
					w := strings.TrimSuffix(strings.TrimSpace(get(idx["wwid"])), ".0")
					if w == "" {
						continue
					}
					out = append(out, DURecord{WWID: w, Fund: get(idx["fund"]), TxType: get(idx["tx"]), Units: parseNumber(get(idx["units"])), Amount: parseNumber(get(idx["amount"]))})
				}
				return out, nil
			}
		}
	}
	return nil, errors.New("Kein DU-Blatt mit WWID/Fondsname/Umsatzart/UmsatzStuecke/ZahlBetrag gefunden")
}

func inferFund(header string) string {
	h := reFundWords.ReplaceAllString(header, " ")
	h = reNonSpace.ReplaceAllString(h, " ")
	return norm(strings.Trim(h, " -_/:"))
}

func compareSheet(genPath, targetPath, sheetName string) ([][]string, error) {
	gf, _, e := unzipMap(genPath)
	if e != nil {
		return nil, e
	}
	tf, _, e := unzipMap(targetPath)
	if e != nil {
		return nil, e
	}
	gp, e := sheetPath(gf, sheetName)
	if e != nil {
		return nil, e
	}
	tp, e := sheetPath(tf, sheetName)
	if e != nil {
		return nil, e
	}
	gs, _ := parseSheet(gf[gp], sharedStrings(gf))
	ts, _ := parseSheet(tf[tp], sharedStrings(tf))
	gss := sharedStrings(gf)
	tss := sharedStrings(tf)
	refs := map[string]bool{}
	for _, r := range gs.Rows {
		for k := range r.Cells {
			refs[k] = true
		}
	}
	for _, r := range ts.Rows {
		for k := range r.Cells {
			refs[k] = true
		}
	}
	keys := make([]string, 0, len(refs))
	for k := range refs {
		keys = append(keys, k)
	}
	sort.Slice(keys, func(i, j int) bool {
		ci, ri := splitRef(keys[i])
		cj, rj := splitRef(keys[j])
		if ri != rj {
			return ri < rj
		}
		return colNum(ci) < colNum(cj)
	})
	out := [][]string{{"Zelle", "Erzeugt", "Ziel"}}
	for _, ref := range keys {
		_, r := splitRef(ref)
		gv := ""
		tv := ""
		if gs.Rows[r] != nil {
			gv = cellText(gs.Rows[r].Cells[ref], gss)
		}
		if ts.Rows[r] != nil {
			tv = cellText(ts.Rows[r].Cells[ref], tss)
		}
		if strings.TrimSpace(gv) != strings.TrimSpace(tv) {
			out = append(out, []string{ref, gv, tv})
		}
	}
	return out, nil
}

func writeCSV(path string, rows [][]string) error {
	f, e := os.Create(path)
	if e != nil {
		return e
	}
	defer f.Close()
	w := csv.NewWriter(f)
	w.Comma = ';'
	defer w.Flush()
	for _, r := range rows {
		if e = w.Write(r); e != nil {
			return e
		}
	}
	return nil
}

func run(cfg Config) error {
	if cfg.Sheet == "" {
		cfg.Sheet = "Import DC LNW"
	}
	if _, e := os.Stat(cfg.OldTemplate); e != nil {
		return fmt.Errorf("Altes Template fehlt: %w", e)
	}
	if _, e := os.Stat(cfg.DUFile); e != nil {
		return fmt.Errorf("DU-Datei fehlt: %w", e)
	}
	if cfg.Output == "" {
		cfg.Output = filepath.Join(filepath.Dir(cfg.OldTemplate), "generated_2025_LNW_DC_Template.xlsm")
	}
	files, methods, e := unzipMap(cfg.OldTemplate)
	if e != nil {
		return e
	}
	sp, e := sheetPath(files, cfg.Sheet)
	if e != nil {
		return e
	}
	ss := sharedStrings(files)
	sh, e := parseSheet(files[sp], ss)
	if e != nil {
		return e
	}
	hr, wcol, headers, e := findHeader(sh, ss, []string{"WWID", "Wwid", "wwid"}, 40)
	if e != nil {
		return e
	}
	fmt.Printf("Kopfzeile %d, WWID-Spalte %s erkannt.\n", hr, colName(wcol))
	du, e := readDU(cfg.DUFile)
	if e != nil {
		return e
	}
	fmt.Printf("%d DU-Zeilen gelesen.\n", len(du))
	all := map[string]Agg{}
	realloc := map[string]Agg{}
	for _, d := range du {
		k := d.WWID + "|" + norm(d.Fund)
		a := all[k]
		a.Units += d.Units
		a.Amount += d.Amount
		all[k] = a
		if norm(d.TxType) == norm("Fondsportfolioanpassung") {
			a = realloc[k]
			a.Units += d.Units
			a.Amount += d.Amount
			realloc[k] = a
		}
	}
	maxr := 0
	for r := range sh.Rows {
		if r > maxr {
			maxr = r
		}
	}
	var audit []Audit
	for r := hr + 1; r <= maxr; r++ {
		row := sh.Rows[r]
		if row == nil {
			continue
		}
		wc := row.Cells[colName(wcol)+strconv.Itoa(r)]
		wwid := strings.TrimSuffix(strings.TrimSpace(cellText(wc, ss)), ".0")
		if wwid == "" {
			continue
		}
		for off := 0; off < 10; off++ {
			src := colName(colNum("CL") + off)
			dst := colName(colNum("AJ") + off)
			c := row.Cells[src+strconv.Itoa(r)]
			val := cellText(c, ss)
			if c != nil && (c.Type == "s" || c.Type == "inlineStr") {
				setText(sh, r, dst, val, false)
			} else {
				setNumber(sh, r, dst, parseNumber(val), false)
			}
			audit = append(audit, Audit{wwid, dst + strconv.Itoa(r), "Vorjahresübertrag", val, src + strconv.Itoa(r)})
		}
		rules := []struct{ fund, u, v string }{{"DWSI-EUR.EQ.HI.CO.FC", "BI", "BJ"}, {"DWS EURORENTA", "BK", "BL"}, {"DWS INS.-ESG EO MO.M.IC", "BM", "BN"}}
		for _, ru := range rules {
			a := realloc[wwid+"|"+norm(ru.fund)]
			if setNumber(sh, r, ru.u, a.Units, true) {
				audit = append(audit, Audit{wwid, ru.u + strconv.Itoa(r), "Umschichtung Anteile", strconv.FormatFloat(a.Units, 'f', -1, 64), ru.fund})
			}
			if setNumber(sh, r, ru.v, a.Amount, true) {
				audit = append(audit, Audit{wwid, ru.v + strconv.Itoa(r), "Umschichtung Wert", strconv.FormatFloat(a.Amount, 'f', -1, 64), ru.fund})
			}
		}
		for off := 0; off < 10; off++ {
			sc := colNum("AJ") + off
			ec := colNum("CL") + off
			h := headers[ec]
			if h == "" {
				h = headers[sc]
			}
			fk := inferFund(h)
			metricAmount := strings.Contains(norm(h), "wert") || strings.Contains(norm(h), "betrag") || strings.Contains(norm(h), "eur")
			a := all[wwid+"|"+fk]
			mov := a.Units
			if metricAmount {
				mov = a.Amount
			}
			start := parseNumber(cellText(sh.Rows[r].Cells[colName(sc)+strconv.Itoa(r)], ss))
			candidate := start + mov
			if setNumber(sh, r, colName(ec), candidate, true) {
				audit = append(audit, Audit{wwid, colName(ec) + strconv.Itoa(r), "Kandidat Endbestand", strconv.FormatFloat(candidate, 'f', -1, 64), fmt.Sprintf("Start %s + DU %s", colName(sc), h)})
			}
		}
	}
	files[sp] = replaceSheetData(files[sp], sh) // force Excel recalculation when opened
	if wb := string(files["xl/workbook.xml"]); strings.Contains(wb, "<calcPr") {
		wb = regexp.MustCompile(`<calcPr[^>]*/>`).ReplaceAllString(wb, `<calcPr calcMode="auto" fullCalcOnLoad="1" forceFullCalc="1"/>`)
		files["xl/workbook.xml"] = []byte(wb)
	}
	if e = os.MkdirAll(filepath.Dir(cfg.Output), 0755); e != nil {
		return e
	}
	if e = zipMap(cfg.Output, files, methods); e != nil {
		return e
	}
	reportDir := strings.TrimSuffix(cfg.Output, filepath.Ext(cfg.Output)) + "_report"
	os.MkdirAll(reportDir, 0755)
	rows := [][]string{{"WWID", "Zelle", "Regel", "Wert", "Herleitung"}}
	for _, a := range audit {
		rows = append(rows, []string{a.WWID, a.Cell, a.Rule, a.Value, a.Source})
	}
	writeCSV(filepath.Join(reportDir, "audit_trail.csv"), rows)
	summary := map[string]any{"status": "completed", "output": cfg.Output, "report_dir": reportDir, "du_rows": len(du), "audit_rows": len(audit)}
	if cfg.ComparisonTarget != "" {
		if _, e := os.Stat(cfg.ComparisonTarget); e == nil {
			diff, e := compareSheet(cfg.Output, cfg.ComparisonTarget, cfg.Sheet)
			if e == nil {
				writeCSV(filepath.Join(reportDir, "comparison_differences.csv"), diff)
				summary["different_cells"] = len(diff) - 1
			}
		}
	}
	jb, _ := json.MarshalIndent(summary, "", "  ")
	os.WriteFile(filepath.Join(reportDir, "run_summary.json"), jb, 0644)
	fmt.Println("Fertig:", cfg.Output)
	fmt.Println("Berichte:", reportDir)
	return nil
}

func prompt(reader *bufio.Reader, label, def string) string {
	fmt.Printf("%s\n[%s]\n> ", label, def)
	s, _ := reader.ReadString('\n')
	s = strings.Trim(strings.TrimSpace(s), "\"")
	if s == "" {
		return def
	}
	return s
}
func main() {
	fmt.Println("============================================================")
	fmt.Println(" Intel LNW DC Tool - Go Standalone")
	fmt.Println(" Keine Installation und keine externen Libraries erforderlich")
	fmt.Println("============================================================")
	cwd, _ := os.Getwd()
	cfg := Config{OldTemplate: filepath.Join(cwd, "_2024_LNW DC Template_v3.xlsm"), DUFile: filepath.Join(cwd, "DU_20240301-20250228 KA 2024-2025 DC Intel - Umsaetze Meldung FNZ.xlsx"), ComparisonTarget: filepath.Join(cwd, "_2025_LNW DC Template.xlsm"), Output: filepath.Join(cwd, "generated_2025_LNW_DC_Template.xlsm"), Sheet: "Import DC LNW"}
	if len(os.Args) > 1 {
		b, e := os.ReadFile(os.Args[1])
		if e == nil {
			json.Unmarshal(b, &cfg)
		}
	} else {
		r := bufio.NewReader(os.Stdin)
		cfg.OldTemplate = prompt(r, "Pfad zum alten Template:", cfg.OldTemplate)
		cfg.DUFile = prompt(r, "Pfad zur DU-Datei:", cfg.DUFile)
		cfg.ComparisonTarget = prompt(r, "Pfad zur Vergleichszieldatei (optional):", cfg.ComparisonTarget)
		cfg.Output = prompt(r, "Pfad der erzeugten Datei:", cfg.Output)
	}
	if e := run(cfg); e != nil {
		fmt.Println("\nFEHLER:", e)
		fmt.Println("\nEnter drücken zum Beenden ...")
		bufio.NewReader(os.Stdin).ReadString('\n')
		os.Exit(1)
	}
	fmt.Println("\nEnter drücken zum Beenden ...")
	bufio.NewReader(os.Stdin).ReadString('\n')
}
