﻿$ErrorActionPreference = "Stop"

$Url = "https://julialang-s3.julialang.org/bin/winnt/x64/1.12/julia-1.12.7-win64.zip"
$Out = Join-Path $PSScriptRoot "julia-1.12.7-win64.zip"

Write-Host "Lade Julia 1.12.7 Windows x64 herunter ..."
Write-Host $Url
Write-Host ""

Invoke-WebRequest -Uri $Url -OutFile $Out -UseBasicParsing

Write-Host ""
Write-Host "Download abgeschlossen:"
Write-Host $Out
Write-Host ""
Write-Host "Dateigroesse:"
(Get-Item $Out).Length
