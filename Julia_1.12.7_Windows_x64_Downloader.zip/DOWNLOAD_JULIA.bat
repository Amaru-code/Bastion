@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0DOWNLOAD_JULIA.ps1"
echo.
pause
