# Changelog

## 1.0.3 – 2026-07-29

- Fehler 13 `Type mismatch` in der Phase `Quellblätter prüfen` behoben.
- Excel-Fehlerwerte, leere Zellen und `Null` werden im VBS jetzt anhand ihres Variant-Typs geprüft, bevor eine Text- oder Zahlenkonvertierung erfolgt.
- Die vier erwarteten Überschriften in `Übersicht!A2:D2` werden einzeln und ohne nicht-kurzschließende `Or`-Kette validiert.
- Bei tatsächlich abweichenden Überschriften zeigt die Meldung nun die gefundenen Werte aus A2 bis D2 an.
- XLSX- und XLSM-Verarbeitung sowie die sichere Ausgabekopie bleiben unverändert.

## 1.0.2 – 2026-07-29

- Fehler 500 `Variable is undefined` in der VBS-Ausführung behoben.
- Die VBA-spezifische Funktion `IsError(...)` wurde durch die VBScript-kompatible Prüfung `VarType(...)=10` ersetzt.
- Fehlermeldungen nennen jetzt zusätzlich die Verarbeitungsphase und die Fehlerquelle.
- Der Starter wurde statisch auf nicht deklarierte Variablen und verbleibende `IsError`-Aufrufe geprüft.

## 1.0.1 – 2026-07-29

- Dateiauswahl unterstützt jetzt `.xlsm` und `.xlsx`.
- Die Ausgabedatei behält automatisch das Format der Quelldatei bei.
- Fehlermeldungen und Dokumentation wurden entsprechend angepasst.

## 1.0.0

- Erste Projektversion mit VBS-Ausführung, VBA-Modul und Dokumentation.
