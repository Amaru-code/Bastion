# Intel LNW DC Tool – Python Source

Diese Version benötigt **keine externen Python-Libraries**. Sie nutzt ausschließlich die Python-Standardbibliothek und bearbeitet `.xlsx/.xlsm` direkt als Office-Open-XML-Archive.

## Start

1. ZIP entpacken.
2. `run.bat` starten.
3. Dateipfade bestätigen oder eingeben.

## Output

Alle Ergebnisse landen direkt in `Output`:

- `generated_2025_LNW_DC_Template.xlsm`
- `audit_trail.csv`
- `comparison_differences.csv` (nur bei vorhandener Vergleichsdatei)

Es wird **kein JSON** erzeugt.

## Umgesetzte Logik

### WWID

Die Spalte `WWID` wird im Kopfbereich automatisch gesucht. Sie ist nicht fest auf Spalte D begrenzt.

### Umschichtung BI:BN

Je WWID und Fondsname, gefiltert auf `Umsatzart = Fondsportfolioanpassung`:

- BI: DWSI-EUR.EQ.HI.CO.FC / UmsatzStuecke
- BJ: DWSI-EUR.EQ.HI.CO.FC / ZahlBetrag
- BK: DWS EURORENTA / UmsatzStuecke
- BL: DWS EURORENTA / ZahlBetrag
- BM: DWS INS.-ESG EO MO.M.IC / UmsatzStuecke
- BN: DWS INS.-ESG EO MO.M.IC / ZahlBetrag

### Stichtag CL:CU

`Endbestand = Startbestand + signierte DU-Summe`

Berücksichtigte Umsatzarten:

- Wiederanlage Ertragsaussc
- Fondsportfolioanpassung
- Verkauf wegen Vorabpausch

Mapping:

- CL = AJ + DWSI-EUR.EQ.HI.CO.FC / UmsatzStuecke
- CM = AK + DWSI-EUR.EQ.HI.CO.FC / ZahlBetrag
- CN = AL + DWS EURORENTA / UmsatzStuecke
- CO = AM + DWS EURORENTA / ZahlBetrag
- CP = AN + DWS INS.-ESG EO MO.M.IC / UmsatzStuecke
- CQ = AO + DWS INS.-ESG EO MO.M.IC / ZahlBetrag
- CR = AP + SIEMENS EUROINVEST AKTIEN / UmsatzStuecke
- CS = AQ + SIEMENS EUROINVEST AKTIEN / ZahlBetrag
- CT = AR + SIEMENS EUROINVEST RENTEN / UmsatzStuecke
- CU = AS + SIEMENS EUROINVEST RENTEN / ZahlBetrag

Das Vorzeichen aus der DU-Datei bleibt unverändert. Beispiel: `AJ + (-0,070455)` reduziert CL entsprechend.

## Makros

Das Tool kopiert das komplette XLSM-Paket und ersetzt ausschließlich Zellwerte im Blatt `Import DC LNW`. `vbaProject.bin`, externe Links und übrige Paketbestandteile bleiben erhalten.
