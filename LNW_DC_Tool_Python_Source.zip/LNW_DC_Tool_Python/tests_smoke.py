import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent / "src"))
from ooxml import normalize_wwid, parse_number, normalize_key

assert normalize_wwid(11368899.0) == "11368899"
assert parse_number("-0,070455") == -0.070455
assert normalize_key("Verkauf wegen\nVorabpausch") == normalize_key("Verkauf wegen Vorabpausch")
print("Smoke tests erfolgreich")
