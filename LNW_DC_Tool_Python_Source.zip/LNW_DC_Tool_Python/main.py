from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from engine import LNWEngine  # noqa: E402


def clean_path(value: str) -> str:
    return value.strip().strip('"').strip("'")


def ask(label: str, default: str = "", optional: bool = False) -> str:
    suffix = f"\n[{default}]" if default else ""
    print(f"{label}:{suffix}")
    entered = clean_path(input("> "))
    if entered:
        return entered
    if default:
        return default
    if optional:
        return ""
    raise ValueError(f"Pfad fehlt: {label}")


def main() -> int:
    parser = argparse.ArgumentParser(description="Intel LNW DC Tool")
    parser.add_argument("--template")
    parser.add_argument("--du")
    parser.add_argument("--comparison")
    parser.add_argument("--output-dir")
    args = parser.parse_args()

    base = ROOT.parent if ROOT.name.lower().startswith("lnw_dc_tool") else ROOT
    print("=" * 64)
    print(" Intel LNW DC Tool - Python / ohne externe Libraries")
    print("=" * 64)

    try:
        template = clean_path(args.template) if args.template else ask(
            "Pfad zum alten Template",
            str(base / "_2024_LNW DC Template_v3.xlsm"),
        )
        du = clean_path(args.du) if args.du else ask(
            "Pfad zur DU-Datei",
            str(base / "DU_20240301-20250228 KA 2024-2025 DC Intel - Umsaetze Meldung FNZ.xlsx"),
        )
        comparison = clean_path(args.comparison) if args.comparison else ask(
            "Pfad zur Vergleichszieldatei (optional)",
            str(base / "_2025_LNW DC Template.xlsm"),
            optional=True,
        )
        output_dir = clean_path(args.output_dir) if args.output_dir else ask(
            "Ausgabeordner",
            str(ROOT / "Output"),
        )

        for path, label in [(template, "Template"), (du, "DU-Datei")]:
            if not Path(path).is_file():
                raise FileNotFoundError(f"{label} nicht gefunden: {path}")
        if comparison and not Path(comparison).is_file():
            print(f"Hinweis: Vergleichsdatei nicht gefunden, Vergleich wird übersprungen: {comparison}")
            comparison = ""

        output = LNWEngine(template, du, comparison or None, output_dir).run()
        print("\nERFOLG")
        print(f"Erzeugte Datei: {output}")
        print(f"Audit: {Path(output_dir) / 'audit_trail.csv'}")
        if comparison:
            print(f"Vergleich: {Path(output_dir) / 'comparison_differences.csv'}")
        return 0
    except Exception as exc:
        print(f"\nFEHLER: {exc}")
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
