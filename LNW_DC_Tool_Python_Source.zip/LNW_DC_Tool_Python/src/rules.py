from __future__ import annotations

from dataclasses import dataclass


RELEVANT_END_MOVEMENTS = {
    "wiederanlage ertragsaussc",
    "fondsportfolioanpassung",
    "verkauf wegen vorabpausch",
}

PORTFOLIO_ADJUSTMENT = {"fondsportfolioanpassung"}


@dataclass(frozen=True)
class EndBalanceRule:
    target_col: str
    start_col: str
    fund_name: str
    value_field: str


@dataclass(frozen=True)
class ReallocationRule:
    target_col: str
    fund_name: str
    value_field: str


END_BALANCE_RULES = [
    EndBalanceRule("CL", "AJ", "DWSI-EUR.EQ.HI.CO.FC", "UmsatzStuecke"),
    EndBalanceRule("CM", "AK", "DWSI-EUR.EQ.HI.CO.FC", "ZahlBetrag"),
    EndBalanceRule("CN", "AL", "DWS EURORENTA", "UmsatzStuecke"),
    EndBalanceRule("CO", "AM", "DWS EURORENTA", "ZahlBetrag"),
    EndBalanceRule("CP", "AN", "DWS INS.-ESG EO MO.M.IC", "UmsatzStuecke"),
    EndBalanceRule("CQ", "AO", "DWS INS.-ESG EO MO.M.IC", "ZahlBetrag"),
    EndBalanceRule("CR", "AP", "SIEMENS EUROINVEST AKTIEN", "UmsatzStuecke"),
    EndBalanceRule("CS", "AQ", "SIEMENS EUROINVEST AKTIEN", "ZahlBetrag"),
    EndBalanceRule("CT", "AR", "SIEMENS EUROINVEST RENTEN", "UmsatzStuecke"),
    EndBalanceRule("CU", "AS", "SIEMENS EUROINVEST RENTEN", "ZahlBetrag"),
]

REALLOCATION_RULES = [
    ReallocationRule("BI", "DWSI-EUR.EQ.HI.CO.FC", "UmsatzStuecke"),
    ReallocationRule("BJ", "DWSI-EUR.EQ.HI.CO.FC", "ZahlBetrag"),
    ReallocationRule("BK", "DWS EURORENTA", "UmsatzStuecke"),
    ReallocationRule("BL", "DWS EURORENTA", "ZahlBetrag"),
    ReallocationRule("BM", "DWS INS.-ESG EO MO.M.IC", "UmsatzStuecke"),
    ReallocationRule("BN", "DWS INS.-ESG EO MO.M.IC", "ZahlBetrag"),
]
