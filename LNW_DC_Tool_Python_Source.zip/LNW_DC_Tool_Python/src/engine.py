from __future__ import annotations

import csv
from collections import defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from ooxml import (
    WorkbookPackage,
    col_to_num,
    normalize_key,
    normalize_text,
    normalize_wwid,
    parse_number,
)
from rules import END_BALANCE_RULES, PORTFOLIO_ADJUSTMENT, REALLOCATION_RULES, RELEVANT_END_MOVEMENTS


HEADER_ALIASES = {
    "wwid": ["WWID"],
    "fund": ["Fondsname", "Fonds Name"],
    "movement": ["Umsatzart", "Umsatz Art"],
    "units": ["UmsatzStuecke", "Umsatzstücke", "Umsatz Stücke"],
    "amount": ["ZahlBetrag", "Zahlbetrag", "Zahl Betrag"],
}


@dataclass
class DUEntry:
    row: int
    wwid: str
    fund: str
    movement: str
    units: float
    amount: float


class LNWEngine:
    def __init__(self, template_path: str, du_path: str, comparison_path: str | None, output_dir: str):
        self.template_path = Path(template_path)
        self.du_path = Path(du_path)
        self.comparison_path = Path(comparison_path) if comparison_path else None
        self.output_dir = Path(output_dir)
        self.audit_rows: list[dict[str, object]] = []

    def run(self) -> Path:
        self.output_dir.mkdir(parents=True, exist_ok=True)
        output_path = self.output_dir / "generated_2025_LNW_DC_Template.xlsm"
        template = WorkbookPackage.load(self.template_path)
        du = WorkbookPackage.load(self.du_path)

        template_sheet_name = self._choose_sheet(template, "Import DC LNW")
        du_sheet_name = self._choose_du_sheet(du)
        template_root = template.get_sheet_tree(template_sheet_name)
        du_root = du.get_sheet_tree(du_sheet_name)

        template_header_row, template_wwid_col = template.find_header(template_root, ["WWID"])
        du_entries = self._read_du_entries(du, du_root)
        index = self._build_index(du_entries)

        self._apply_rules(template, template_root, template_header_row, template_wwid_col, index)
        template.set_sheet_tree(template_sheet_name, template_root)
        template.save(output_path)

        self._write_audit(self.output_dir / "audit_trail.csv")
        if self.comparison_path and self.comparison_path.exists():
            self._write_comparison(output_path, self.comparison_path, self.output_dir / "comparison_differences.csv")
        return output_path

    @staticmethod
    def _choose_sheet(book: WorkbookPackage, preferred: str) -> str:
        for name in book.sheet_names():
            if normalize_text(name) == normalize_text(preferred):
                return name
        raise ValueError(f"Blatt '{preferred}' nicht gefunden. Vorhanden: {', '.join(book.sheet_names())}")

    def _choose_du_sheet(self, book: WorkbookPackage) -> str:
        for name in book.sheet_names():
            root = book.get_sheet_tree(name)
            try:
                book.find_header(root, HEADER_ALIASES["wwid"], max_rows=100)
                book.find_header(root, HEADER_ALIASES["fund"], max_rows=100)
                book.find_header(root, HEADER_ALIASES["movement"], max_rows=100)
                return name
            except ValueError:
                continue
        raise ValueError("Kein DU-Blatt mit WWID, Fondsname und Umsatzart gefunden.")

    def _read_du_entries(self, book: WorkbookPackage, root) -> list[DUEntry]:
        found = {key: book.find_header(root, aliases, max_rows=100) for key, aliases in HEADER_ALIASES.items()}
        header_rows = {row for row, _ in found.values()}
        header_row = max(header_rows)
        cols = {key: col for key, (_, col) in found.items()}
        entries: list[DUEntry] = []
        for row_num, cells in book.rows_as_cells(root):
            if row_num <= header_row:
                continue
            wwid = normalize_wwid(book.cell_value(cells.get(cols["wwid"])))
            if not wwid:
                continue
            fund = normalize_text(book.cell_value(cells.get(cols["fund"])))
            movement = normalize_text(book.cell_value(cells.get(cols["movement"])))
            units = parse_number(book.cell_value(cells.get(cols["units"])))
            amount = parse_number(book.cell_value(cells.get(cols["amount"])))
            entries.append(DUEntry(row_num, wwid, fund, movement, units, amount))
        print(f"{len(entries)} DU-Zeilen gelesen.")
        return entries

    @staticmethod
    def _build_index(entries: Iterable[DUEntry]):
        index: dict[tuple[str, str, str], list[DUEntry]] = defaultdict(list)
        for entry in entries:
            index[(entry.wwid, normalize_key(entry.fund), normalize_key(entry.movement))].append(entry)
        return index

    @staticmethod
    def _sum(index, wwid: str, fund: str, movements: set[str], field: str) -> tuple[float, list[int]]:
        total = 0.0
        rows: list[int] = []
        fund_key = normalize_key(fund)
        for movement in movements:
            for entry in index.get((wwid, fund_key, normalize_key(movement)), []):
                total += entry.units if field == "UmsatzStuecke" else entry.amount
                rows.append(entry.row)
        return total, rows

    def _apply_rules(self, book: WorkbookPackage, root, header_row: int, wwid_col: int, index) -> None:
        start_cols = {rule.start_col: col_to_num(rule.start_col) for rule in END_BALANCE_RULES}
        data_rows = 0
        for row_num, cells in book.rows_as_cells(root):
            if row_num <= header_row:
                continue
            wwid = normalize_wwid(book.cell_value(cells.get(wwid_col)))
            if not wwid:
                continue
            data_rows += 1

            for rule in REALLOCATION_RULES:
                movement, du_rows = self._sum(index, wwid, rule.fund_name, PORTFOLIO_ADJUSTMENT, rule.value_field)
                target_col = col_to_num(rule.target_col)
                book.set_numeric_cell(root, row_num, target_col, movement)
                self.audit_rows.append({
                    "WWID": wwid, "TemplateRow": row_num, "TargetCell": f"{rule.target_col}{row_num}",
                    "Rule": "Umschichtung", "Fund": rule.fund_name, "DUField": rule.value_field,
                    "StartValue": "", "MovementSum": movement, "EndValue": movement,
                    "DUHits": len(du_rows), "DURows": ";".join(map(str, du_rows)),
                    "Movements": "Fondsportfolioanpassung",
                })

            for rule in END_BALANCE_RULES:
                start_cell = cells.get(start_cols[rule.start_col])
                start_value = parse_number(book.cell_value(start_cell))
                movement, du_rows = self._sum(index, wwid, rule.fund_name, RELEVANT_END_MOVEMENTS, rule.value_field)
                end_value = start_value + movement
                target_col = col_to_num(rule.target_col)
                book.set_numeric_cell(root, row_num, target_col, end_value)
                self.audit_rows.append({
                    "WWID": wwid, "TemplateRow": row_num, "TargetCell": f"{rule.target_col}{row_num}",
                    "Rule": "Endbestand = Startbestand + signierte DU-Summe", "Fund": rule.fund_name,
                    "DUField": rule.value_field, "StartValue": start_value, "MovementSum": movement,
                    "EndValue": end_value, "DUHits": len(du_rows), "DURows": ";".join(map(str, du_rows)),
                    "Movements": "Wiederanlage Ertragsaussc; Fondsportfolioanpassung; Verkauf wegen Vorabpausch",
                })
        print(f"{data_rows} Template-Zeilen verarbeitet.")

    def _write_audit(self, path: Path) -> None:
        fields = ["WWID", "TemplateRow", "TargetCell", "Rule", "Fund", "DUField", "StartValue", "MovementSum", "EndValue", "DUHits", "DURows", "Movements"]
        with path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields, delimiter=";")
            writer.writeheader()
            writer.writerows(self.audit_rows)

    def _write_comparison(self, generated_path: Path, expected_path: Path, report_path: Path) -> None:
        generated = WorkbookPackage.load(generated_path)
        expected = WorkbookPackage.load(expected_path)
        sheet_g = self._choose_sheet(generated, "Import DC LNW")
        sheet_e = self._choose_sheet(expected, "Import DC LNW")
        root_g = generated.get_sheet_tree(sheet_g)
        root_e = expected.get_sheet_tree(sheet_e)
        values_g = self._cell_map(generated, root_g)
        values_e = self._cell_map(expected, root_e)
        columns = {col_to_num(rule.target_col) for rule in END_BALANCE_RULES + REALLOCATION_RULES}
        with report_path.open("w", newline="", encoding="utf-8-sig") as handle:
            writer = csv.writer(handle, delimiter=";")
            writer.writerow(["Cell", "Generated", "Expected", "Difference"])
            for ref in sorted(set(values_g) | set(values_e), key=self._ref_sort):
                col_letters = ''.join(filter(str.isalpha, ref))
                if col_to_num(col_letters) not in columns:
                    continue
                g = parse_number(values_g.get(ref))
                e = parse_number(values_e.get(ref))
                if abs(g - e) > 1e-9:
                    writer.writerow([ref, g, e, g - e])

    @staticmethod
    def _cell_map(book: WorkbookPackage, root) -> dict[str, object]:
        result = {}
        for _, cells in book.rows_as_cells(root):
            for cell in cells.values():
                result[cell.attrib["r"]] = book.cell_value(cell)
        return result

    @staticmethod
    def _ref_sort(ref: str):
        letters = ''.join(filter(str.isalpha, ref))
        digits = ''.join(filter(str.isdigit, ref))
        return int(digits or 0), col_to_num(letters)
