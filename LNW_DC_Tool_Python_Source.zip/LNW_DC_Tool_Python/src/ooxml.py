from __future__ import annotations

import copy
import re
import shutil
import tempfile
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable
from xml.etree import ElementTree as ET

NS_MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
NS_REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
NS_PKG_REL = "http://schemas.openxmlformats.org/package/2006/relationships"
ET.register_namespace("", NS_MAIN)
ET.register_namespace("r", NS_REL)


def qn(tag: str) -> str:
    return f"{{{NS_MAIN}}}{tag}"


def col_to_num(col: str) -> int:
    result = 0
    for ch in col.upper():
        result = result * 26 + ord(ch) - 64
    return result


def num_to_col(num: int) -> str:
    out = []
    while num:
        num, rem = divmod(num - 1, 26)
        out.append(chr(65 + rem))
    return "".join(reversed(out))


def split_ref(ref: str) -> tuple[str, int]:
    match = re.fullmatch(r"([A-Z]+)(\d+)", ref.upper())
    if not match:
        raise ValueError(f"Ungültige Zellreferenz: {ref}")
    return match.group(1), int(match.group(2))


def normalize_text(value: object) -> str:
    if value is None:
        return ""
    text = str(value).replace("\u00a0", " ").replace("\r", " ").replace("\n", " ")
    text = re.sub(r"\s+", " ", text).strip().casefold()
    return text


def normalize_key(value: object) -> str:
    text = normalize_text(value)
    text = re.sub(r"[^a-z0-9äöüß]+", "", text)
    return text


def normalize_wwid(value: object) -> str:
    if value is None:
        return ""
    text = str(value).strip().replace(" ", "")
    text = text.replace(",", ".")
    try:
        number = float(text)
        if number.is_integer():
            return str(int(number))
    except ValueError:
        pass
    return re.sub(r"\D", "", text)


def parse_number(value: object) -> float:
    if value is None or value == "":
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace("\u00a0", "").replace(" ", "")
    if not text:
        return 0.0
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        text = text.replace(".", "").replace(",", ".")
    try:
        return float(text)
    except ValueError:
        return 0.0


@dataclass
class WorkbookPackage:
    path: Path
    files: dict[str, bytes]
    shared_strings: list[str]
    sheet_paths: dict[str, str]

    @classmethod
    def load(cls, path: str | Path) -> "WorkbookPackage":
        path = Path(path)
        with zipfile.ZipFile(path, "r") as archive:
            files = {name: archive.read(name) for name in archive.namelist()}
        shared = cls._load_shared_strings(files)
        sheets = cls._load_sheet_paths(files)
        return cls(path=path, files=files, shared_strings=shared, sheet_paths=sheets)

    @staticmethod
    def _load_shared_strings(files: dict[str, bytes]) -> list[str]:
        raw = files.get("xl/sharedStrings.xml")
        if not raw:
            return []
        root = ET.fromstring(raw)
        values: list[str] = []
        for si in root.findall(qn("si")):
            values.append("".join(node.text or "" for node in si.iter(qn("t"))))
        return values

    @staticmethod
    def _load_sheet_paths(files: dict[str, bytes]) -> dict[str, str]:
        workbook = ET.fromstring(files["xl/workbook.xml"])
        rels = ET.fromstring(files["xl/_rels/workbook.xml.rels"])
        targets = {
            rel.attrib["Id"]: rel.attrib["Target"]
            for rel in rels.findall(f"{{{NS_PKG_REL}}}Relationship")
        }
        result: dict[str, str] = {}
        for sheet in workbook.find(qn("sheets")) or []:
            name = sheet.attrib["name"]
            rel_id = sheet.attrib[f"{{{NS_REL}}}id"]
            target = targets[rel_id].replace("\\", "/")
            if target.startswith("/"):
                target = target.lstrip("/")
            elif not target.startswith("xl/"):
                target = "xl/" + target.lstrip("./")
            result[name] = target
        return result

    def sheet_names(self) -> list[str]:
        return list(self.sheet_paths)

    def get_sheet_tree(self, sheet_name: str) -> ET.Element:
        path = self.sheet_paths[sheet_name]
        return ET.fromstring(self.files[path])

    def set_sheet_tree(self, sheet_name: str, root: ET.Element) -> None:
        path = self.sheet_paths[sheet_name]
        self.files[path] = ET.tostring(root, encoding="utf-8", xml_declaration=True)

    def cell_value(self, cell: ET.Element | None) -> object:
        if cell is None:
            return None
        cell_type = cell.attrib.get("t")
        if cell_type == "inlineStr":
            inline = cell.find(qn("is"))
            if inline is None:
                return ""
            return "".join(node.text or "" for node in inline.iter(qn("t")))
        value_node = cell.find(qn("v"))
        if value_node is None:
            formula = cell.find(qn("f"))
            return formula.text if formula is not None else None
        raw = value_node.text or ""
        if cell_type == "s":
            try:
                return self.shared_strings[int(raw)]
            except (ValueError, IndexError):
                return raw
        if cell_type in {"str", "e"}:
            return raw
        return parse_number(raw)

    def rows_as_cells(self, root: ET.Element) -> Iterable[tuple[int, dict[int, ET.Element]]]:
        sheet_data = root.find(qn("sheetData"))
        if sheet_data is None:
            return
        for row in sheet_data.findall(qn("row")):
            row_num = int(row.attrib.get("r", "0"))
            cells: dict[int, ET.Element] = {}
            for cell in row.findall(qn("c")):
                ref = cell.attrib.get("r")
                if not ref:
                    continue
                col, _ = split_ref(ref)
                cells[col_to_num(col)] = cell
            yield row_num, cells

    def find_header(self, root: ET.Element, aliases: Iterable[str], max_rows: int = 200) -> tuple[int, int]:
        alias_keys = {normalize_key(alias) for alias in aliases}
        for row_num, cells in self.rows_as_cells(root):
            if row_num > max_rows:
                break
            for col_num, cell in cells.items():
                if normalize_key(self.cell_value(cell)) in alias_keys:
                    return row_num, col_num
        raise ValueError(f"Kopfzeile nicht gefunden: {', '.join(aliases)}")

    def set_numeric_cell(self, root: ET.Element, row_num: int, col_num: int, value: float) -> None:
        sheet_data = root.find(qn("sheetData"))
        if sheet_data is None:
            sheet_data = ET.SubElement(root, qn("sheetData"))
        row = next((r for r in sheet_data.findall(qn("row")) if int(r.attrib.get("r", "0")) == row_num), None)
        if row is None:
            row = ET.Element(qn("row"), {"r": str(row_num)})
            inserted = False
            for idx, existing in enumerate(sheet_data.findall(qn("row"))):
                if int(existing.attrib.get("r", "0")) > row_num:
                    sheet_data.insert(idx, row)
                    inserted = True
                    break
            if not inserted:
                sheet_data.append(row)
        ref = f"{num_to_col(col_num)}{row_num}"
        cell = next((c for c in row.findall(qn("c")) if c.attrib.get("r") == ref), None)
        if cell is None:
            cell = ET.Element(qn("c"), {"r": ref})
            target_col = col_num
            inserted = False
            for idx, existing in enumerate(row.findall(qn("c"))):
                existing_col, _ = split_ref(existing.attrib["r"])
                if col_to_num(existing_col) > target_col:
                    row.insert(idx, cell)
                    inserted = True
                    break
            if not inserted:
                row.append(cell)
        for child in list(cell):
            if child.tag in {qn("f"), qn("v"), qn("is")}:
                cell.remove(child)
        cell.attrib.pop("t", None)
        value_node = ET.SubElement(cell, qn("v"))
        value_node.text = format(value, ".15g")

    def save(self, output_path: str | Path) -> None:
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        temp_path = output_path.with_suffix(output_path.suffix + ".tmp")
        with zipfile.ZipFile(temp_path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            for name, data in self.files.items():
                archive.writestr(name, data)
        temp_path.replace(output_path)
