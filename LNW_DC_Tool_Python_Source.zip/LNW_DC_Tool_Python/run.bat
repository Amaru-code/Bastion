@echo off
setlocal
cd /d "%~dp0"
cls
where py >nul 2>nul
if %errorlevel%==0 (
    py -3.12 main.py
    if not %errorlevel%==0 py -3 main.py
) else (
    python main.py
)
echo.
pause
