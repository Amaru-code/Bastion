@echo off
setlocal
cd /d "%~dp0"
py -3.12 main.py ^
  --template "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Intel_LNW_DC\_2024_LNW DC Template_v3.xlsm" ^
  --du "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Intel_LNW_DC\DU_20240301-20250228 KA 2024-2025 DC Intel - Umsaetze Meldung FNZ.xlsx" ^
  --comparison "C:\Users\Amaru-Zegarra\projects\Aktive_Projekte\Intel_LNW_DC\_2025_LNW DC Template.xlsm" ^
  --output-dir "%~dp0Output"
pause
