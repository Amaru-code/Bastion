Option Explicit

' ============================================================================
' Einzeluebertritte ARE Generator - externe Ausfuehrung
' Version 1.0.8
'
' Ablauf:
'   1. Excel-Quelldatei fuer die ARE-Auswertung auswaehlen.
'   2. Word-DOCX als Serienbriefvorlage auswaehlen.
'   3. Excel-Datei mit den Personendaten auswaehlen.
'   4. Sichere Ausgabekopie der ARE-Quelldatei anlegen.
'   5. ARE-Blaetter erzeugen und jedes Blatt als einzelne PDF exportieren.
'   6. Serienbrief als Gesamt-DOCX/Gesamt-PDF und je Person als PDF erzeugen.
'
' Die Quelldateien und die Serienbriefvorlage werden nicht veraendert.
' ============================================================================

Const xlCalculationAutomatic = -4105
Const xlCalculationManual = -4135
Const xlCenter = -4108
Const xlLeft = -4131
Const xlRight = -4152
Const xlContinuous = 1
Const xlThin = 2
Const xlMedium = -4138
Const xlDouble = -4119
Const xlNone = -4142
Const xlEdgeLeft = 7
Const xlEdgeTop = 8
Const xlEdgeBottom = 9
Const xlEdgeRight = 10
Const xlCellValue = 1
Const xlEqual = 3
Const xlNotEqual = 4
Const xlPortrait = 1
Const xlLandscape = 2
Const xlOpenXMLWorkbook = 51
Const xlPageBreakPreview = 2
Const xlUp = -4162
Const xlTypePDF = 0
Const xlQualityStandard = 0

Const wdDoNotSaveChanges = 0
Const wdFormatXMLDocument = 12
Const wdExportFormatPDF = 17
Const wdPageBreak = 7
Const wdCollapseEnd = 0
Const wdFieldMergeField = 59
Const wdSendToNewDocument = 0
Const wdOpenFormatAuto = 0
Const wdMergeSubTypeOther = 0

Const msoFalse = 0
Const msoTrue = -1
Const msoLinkedPicture = 11
Const msoPicture = 13

Const SHEET_OVERVIEW = "�bersicht"
Const SHEET_COMPANIES = "Gesellschaften"
Const GENERATED_PREFIX = "ARE "
Const FIRST_DATA_ROW = 3
Const CENTRAL_LTRG = 100
Const INCLUDE_ZERO_ON_RECEIVER_SIDE = False
Const VB_ERROR_TYPE = 10
Const TOOL_VERSION = "1.0.8"

Dim gExcel
Dim gWorkbook
Dim gWord
Dim gOutputPath
Dim gExportFolder
Dim gSerialTemplatePath
Dim gSerialDataPath
Dim gSuccess
Dim gStage
Dim gLogPath
Dim gProjectFolder
Dim gReportPeriod
Dim gLogoSourceDescription
Dim errNumber
Dim errDescription
Dim errSource

gStage = "Initialisierung"

On Error Resume Next
RunGenerator
errNumber = Err.Number
errDescription = Err.Description
errSource = Err.Source
On Error GoTo 0

If errNumber <> 0 Then
    On Error Resume Next
    CloseWordSafely
    If IsObject(gWorkbook) Then
        If Not gWorkbook Is Nothing Then gWorkbook.Close False
    End If
    If IsObject(gExcel) Then
        If Not gExcel Is Nothing Then
            gExcel.ScreenUpdating = True
            gExcel.EnableEvents = True
            gExcel.DisplayAlerts = True
            gExcel.StatusBar = False
            gExcel.Quit
        End If
    End If
    On Error GoTo 0

    WriteLog "FEHLER | Phase=" & gStage & " | Nummer=" & CStr(errNumber) & _
             " | Quelle=" & errSource & " | Beschreibung=" & errDescription

    MsgBox "Die ARE-Auswertung konnte nicht erstellt werden." & vbCrLf & vbCrLf & _
           "Version: " & TOOL_VERSION & vbCrLf & _
           "Phase: " & gStage & vbCrLf & _
           "Fehler " & CStr(errNumber) & ": " & errDescription & vbCrLf & _
           "Quelle: " & errSource & vbCrLf & vbCrLf & _
           "Diagnoseprotokoll:" & vbCrLf & SafeDisplayPath(gLogPath) & vbCrLf & vbCrLf & _
           "Hinweise stehen im Ordner docs, insbesondere in 06_Fehlersuche.md.", _
           vbCritical, "ARE Generator " & TOOL_VERSION
    WScript.Quit 1
End If

Sub RunGenerator()
    Dim fso
    Dim sourcePath
    Dim sourceWorkbook
    Dim oldCalculation
    Dim sourceExtension
    Dim templateExtension
    Dim serialDataExtension
    Dim excelFolder
    Dim pdfFolder
    Dim serialFolder
    Dim individualFolder
    Dim logoCount
    Dim mergeCount
    Dim aggregateDocxPath
    Dim aggregatePdfPath

    gStage = "Excel starten"
    Set fso = CreateObject("Scripting.FileSystemObject")
    gProjectFolder = fso.GetParentFolderName(WScript.ScriptFullName)
    gLogPath = fso.BuildPath(gProjectFolder, "ARE_Generator_Diagnose.log")
    ResetLog
    WriteLog "START | Version " & TOOL_VERSION

    Set gExcel = CreateObject("Excel.Application")

    gExcel.Visible = True
    gExcel.DisplayAlerts = False

    gStage = "ARE-Quelldatei ausw�hlen"
    sourcePath = gExcel.GetOpenFilename( _
        "Excel-Dateien (*.xlsm;*.xlsx),*.xlsm;*.xlsx", _
        1, _
        "ARE-Quelldatei mit �bersicht und Gesellschaften ausw�hlen" _
    )

    If VarType(sourcePath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    WriteLog "ARE-QUELLE | " & CStr(sourcePath)
    sourceExtension = LCase(fso.GetExtensionName(CStr(sourcePath)))

    If sourceExtension <> "xlsm" And sourceExtension <> "xlsx" Then
        Err.Raise -2147221504 + 2000, "ARE Generator", _
                  "Bitte eine XLSM- oder XLSX-Datei als ARE-Quelle ausw�hlen."
    End If

    gReportPeriod = BuildReportPeriod(fso.GetBaseName(CStr(sourcePath)))
    WriteLog "BERICHTSZEITRAUM | " & gReportPeriod

    gStage = "Serienbriefvorlage ausw�hlen"
    gSerialTemplatePath = gExcel.GetOpenFilename( _
        "Word-Dokumente (*.docx),*.docx", _
        1, _
        "DOCX-Serienbriefvorlage ausw�hlen" _
    )

    If VarType(gSerialTemplatePath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    templateExtension = LCase(fso.GetExtensionName(CStr(gSerialTemplatePath)))
    If templateExtension <> "docx" Then
        Err.Raise -2147221504 + 2001, "ARE Generator", _
                  "Bitte eine DOCX-Datei als Serienbriefvorlage ausw�hlen."
    End If
    WriteLog "SERIENBRIEF-VORLAGE | " & CStr(gSerialTemplatePath)

    gStage = "Personendaten ausw�hlen"
    gSerialDataPath = gExcel.GetOpenFilename( _
        "Excel-Dateien (*.xlsx;*.xlsm;*.xls),*.xlsx;*.xlsm;*.xls", _
        1, _
        "Excel-Datei mit den Personendaten ausw�hlen" _
    )

    If VarType(gSerialDataPath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    serialDataExtension = LCase(fso.GetExtensionName(CStr(gSerialDataPath)))
    If serialDataExtension <> "xlsx" And serialDataExtension <> "xlsm" And _
       serialDataExtension <> "xls" Then
        Err.Raise -2147221504 + 2002, "ARE Generator", _
                  "Bitte eine XLSX-, XLSM- oder XLS-Datei mit Personendaten ausw�hlen."
    End If
    WriteLog "PERSONENDATEN | " & CStr(gSerialDataPath)

    gStage = "Output-Ordner anlegen"
    BuildExportFolders fso, CStr(sourcePath), excelFolder, pdfFolder, _
                       serialFolder, individualFolder
    WriteLog "AUSGABE-ORDNER | " & gExportFolder

    gStage = "Ausgabepfad vorbereiten"
    gOutputPath = BuildOutputPath(fso, CStr(sourcePath), excelFolder)
    WriteLog "AUSGABE-EXCEL | " & gOutputPath

    gStage = "Ausgabekopie erstellen"
    gExcel.StatusBar = "Sichere Ausgabekopie wird erstellt ..."
    Set sourceWorkbook = gExcel.Workbooks.Open(CStr(sourcePath), 0, True)
    sourceWorkbook.SaveCopyAs gOutputPath
    sourceWorkbook.Close False
    Set sourceWorkbook = Nothing

    gStage = "Ausgabedatei �ffnen"
    Set gWorkbook = gExcel.Workbooks.Open(gOutputPath, 0, False)

    oldCalculation = gExcel.Calculation
    gExcel.ScreenUpdating = False
    gExcel.EnableEvents = False
    gExcel.DisplayAlerts = False

    ' Vor dem Auslesen vorhandene Formeln aktualisieren.
    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gExcel.Calculation = xlCalculationManual

    gStage = "ARE-Bl�tter erzeugen"
    WriteLog "PHASE | " & gStage
    GenerateARESheets gExcel, gWorkbook

    gStage = "Mercer-Logo aus Serienbriefvorlage �bernehmen"
    logoCount = PrepareARELogos(gExcel, gWorkbook, fso, CStr(gSerialTemplatePath))
    WriteLog "INFO | Mercer-Logo auf " & CStr(logoCount) & " ARE-Bl�tter �bertragen"

    gStage = "Ergebnis berechnen und speichern"
    WriteLog "PHASE | " & gStage

    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gWorkbook.Save

    gStage = "ARE-Bl�tter als PDF exportieren"
    ExportGeneratedSheetsAsPdf gWorkbook, fso, pdfFolder

    ' Excel wieder in einen normalen Benutzerzustand versetzen, bevor Word startet.
    gExcel.StatusBar = False
    gExcel.ScreenUpdating = True
    gExcel.EnableEvents = True
    gExcel.DisplayAlerts = True
    gExcel.Calculation = oldCalculation
    gExcel.Visible = True

    gStage = "Serienbrief erzeugen"
    GenerateSerialLetters gExcel, fso, CStr(gSerialTemplatePath), _
                          CStr(gSerialDataPath), serialFolder, individualFolder, _
                          mergeCount, aggregateDocxPath, aggregatePdfPath

    gWorkbook.Activate
    gStage = "Abgeschlossen"
    gSuccess = True

    WriteLog "ERFOLG | Ausgabedatei=" & gOutputPath
    WriteLog "ERFOLG | Exportordner=" & gExportFolder
    WriteLog "ERFOLG | Serienbrief-Datens�tze=" & CStr(mergeCount)

    MsgBox "Die ARE-Auswertung und der Serienbrief wurden erfolgreich erstellt." & vbCrLf & vbCrLf & _
           "Version: " & TOOL_VERSION & vbCrLf & _
           "ARE-Ausgabedatei:" & vbCrLf & gOutputPath & vbCrLf & vbCrLf & _
           "Alle Ausgaben im Output-Ordner:" & vbCrLf & gExportFolder & vbCrLf & vbCrLf & _
           "Logoquelle: " & gLogoSourceDescription & vbCrLf & _
           "Personen im Serienbrief: " & CStr(mergeCount) & vbCrLf & _
           "Gesamt-DOCX: " & fso.GetFileName(aggregateDocxPath) & vbCrLf & _
           "Gesamt-PDF: " & fso.GetFileName(aggregatePdfPath) & vbCrLf & vbCrLf & _
           "Die Quelldateien und die DOCX-Vorlage wurden nicht ver�ndert.", _
           vbInformation, "ARE Generator " & TOOL_VERSION
End Sub

Sub GenerateARESheets(ByVal xlApp, ByVal wb)
    Dim wsOverview
    Dim wsCompanies
    Dim companies
    Dim targets
    Dim transferData()
    Dim targetKeys
    Dim lastTransferRow
    Dim i

    Set wsOverview = GetWorksheetOrNothing(wb, SHEET_OVERVIEW)
    Set wsCompanies = GetWorksheetOrNothing(wb, SHEET_COMPANIES)

    If wsOverview Is Nothing Then
        Err.Raise -2147221504 + 2010, "ARE Generator", _
                  "Das Blatt '" & SHEET_OVERVIEW & "' wurde nicht gefunden."
    End If

    If wsCompanies Is Nothing Then
        Err.Raise -2147221504 + 2011, "ARE Generator", _
                  "Das Blatt '" & SHEET_COMPANIES & "' wurde nicht gefunden."
    End If

    gStage = "Quellbl�tter pr�fen - Kopfzeilen"
    WriteLog "PHASE | " & gStage
    ValidateOverviewLayout wsOverview

    gStage = "Quellbl�tter pr�fen - letzte Datenzeile"
    WriteLog "PHASE | " & gStage
    lastTransferRow = FindLastTransferRow(wsOverview)
    If lastTransferRow < FIRST_DATA_ROW Then
        Err.Raise -2147221504 + 2012, "ARE Generator", _
                  "Im Blatt '" & SHEET_OVERVIEW & "' wurden keine �bertritte gefunden."
    End If
    WriteLog "INFO | Letzte �bertrittszeile=" & CStr(lastTransferRow)

    gStage = "Quellbl�tter pr�fen - Daten sicher einlesen"
    WriteLog "PHASE | " & gStage
    LoadTransferData wsOverview, lastTransferRow, transferData

    gStage = "Gesellschaften und LTRG einlesen"
    WriteLog "PHASE | " & gStage
    Set companies = LoadCompanies(wsCompanies)
    Set targets = BuildTargetLtrgs(transferData)

    gStage = "LTRG-Zuordnungen pr�fen"
    ValidateCompanyAssignments targets, companies
    gStage = "Alte ARE-Bl�tter entfernen"
    DeleteGeneratedSheets wb

    targetKeys = targets.Keys
    SortNumericKeys targetKeys

    For i = 0 To UBound(targetKeys)
        gStage = "ARE-Blatt f�r LTRG " & FormatLtrg(CLng(targetKeys(i))) & " erstellen"
        WriteLog "PHASE | " & gStage
        xlApp.StatusBar = "ARE-Blatt f�r LTRG " & _
                          FormatLtrg(CLng(targetKeys(i))) & " wird erstellt ..."
        CreateARESheet xlApp, wb, wsOverview, companies, transferData, CLng(targetKeys(i))
    Next
End Sub

Function AddWorksheetAtEnd(ByVal wb)
    Dim ws
    Dim lastSheet
    Dim addErrorNumber
    Dim addErrorDescription
    Dim moveErrorNumber
    Dim moveErrorDescription

    ' Das Hinzufuegen oder Loeschen von Blaettern ist bei geschuetzter
    ' Arbeitsmappenstruktur nicht erlaubt. Eine klare Meldung ist hilfreicher
    ' als der unspezifische Excel-Fehler 1004.
    If CBool(wb.ProtectStructure) Then
        Err.Raise -2147221504 + 2030, "ARE Generator", _
                  "Die Struktur der Arbeitsmappe ist geschuetzt. " & _
                  "Bitte in Excel unter 'Ueberpruefen > Arbeitsmappe schuetzen' " & _
                  "den Strukturschutz aufheben und das Tool erneut starten."
    End If

    ' Wichtig fuer VBScript/Excel-COM:
    ' Keine Platzhalter wie Empty an Worksheets.Add uebergeben. Excel kann
    ' Empty als zuzuweisenden Parameter interpretieren und meldet dann Fehler 1004.
    wb.Activate
    wb.Worksheets(1).Activate

    Set ws = Nothing
    On Error Resume Next
    Err.Clear
    Set ws = wb.Worksheets.Add
    addErrorNumber = Err.Number
    addErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If ws Is Nothing Then
        If addErrorNumber = 0 Then addErrorNumber = -2147221504 + 2031
        Err.Raise addErrorNumber, "Microsoft Excel", _
                  "Ein neues Arbeitsblatt konnte nicht erstellt werden. " & _
                  addErrorDescription
    End If

    ' Worksheets.Add ohne Parameter ist die stabilste COM-Variante. Das neue
    ' Blatt wird zunaechst vor dem aktiven Blatt eingefuegt. Anschliessend wird
    ' lediglich versucht, es ans Ende zu verschieben. Ein Fehlschlag beim
    ' Verschieben ist nicht fachkritisch und darf die Auswertung nicht stoppen.
    If wb.Worksheets.Count > 1 Then
        Set lastSheet = wb.Worksheets(wb.Worksheets.Count)
        If Not (ws Is lastSheet) Then
            On Error Resume Next
            Err.Clear
            Call ws.Move(, lastSheet)
            moveErrorNumber = Err.Number
            moveErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0

            If moveErrorNumber <> 0 Then
                WriteLog "WARNUNG | Neues Blatt wurde erstellt, konnte aber nicht " & _
                         "ans Ende verschoben werden. Nummer=" & _
                         CStr(moveErrorNumber) & " | Beschreibung=" & _
                         moveErrorDescription
            End If
        End If
    End If

    Set AddWorksheetAtEnd = ws
End Function

Sub CreateARESheet(ByVal xlApp, ByVal wb, ByVal wsOverview, ByVal companies, _
                   ByRef transferData, ByVal targetLtrg)
    Dim ws
    Dim groups
    Dim targetInfo
    Dim counterpartyInfo
    Dim groupKeys
    Dim rowsInGroup
    Dim descriptor
    Dim targetName
    Dim targetShortName
    Dim sheetName
    Dim newLtrg
    Dim oldLtrg
    Dim validNew
    Dim validOld
    Dim sourceIndex
    Dim direction
    Dim signedPension
    Dim signedBsav
    Dim signedTotal
    Dim currentRow
    Dim sectionRow
    Dim headerRow
    Dim dataStartRow
    Dim dataEndRow
    Dim subtotalRow
    Dim subtotalRefs
    Dim pass
    Dim i
    Dim j
    Dim amount
    Dim shouldWrite
    Dim counterpartyKey
    Dim overviewNameEscaped

    targetInfo = companies.Item(CStr(targetLtrg))
    targetName = CStr(targetInfo(1))
    targetShortName = ShortCompanyName(targetName)

    sheetName = UniqueSheetName(wb, BuildSheetName(targetLtrg, targetInfo(0)))
    Set ws = AddWorksheetAtEnd(wb)
    ws.Name = sheetName

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = 1

    For i = 1 To UBound(transferData, 1)
        validNew = TryGetLong(transferData(i, 2), newLtrg)
        validOld = TryGetLong(transferData(i, 4), oldLtrg)

        If validNew And validOld Then
            If newLtrg <> oldLtrg Then
                amount = NzNumber(transferData(i, 10))

                If newLtrg = targetLtrg Then
                    If amount <> 0 Or INCLUDE_ZERO_ON_RECEIVER_SIDE Then
                        AddGroupRecord groups, CStr(oldLtrg), i, 1
                    End If
                End If

                If oldLtrg = targetLtrg Then
                    AddGroupRecord groups, CStr(newLtrg), i, -1
                End If
            End If
        End If
    Next

    ' Zeilen 1 bis 2 bilden den Berichtskopf: Logo links und Metadaten rechts.
    ws.Range("E1:F1").Merge
    ws.Range("E2:F2").Merge
    ws.Range("A4:F4").Merge
    ws.Range("A6:F6").Merge
    ws.Range("A7:F7").Merge

    ws.Range("E1").Value = "Einzel�bertritte " & gReportPeriod
    ws.Range("E2").Value = "ARE " & DisplayValue(targetInfo(0)) & _
                           " (LTRG " & FormatLtrg(targetLtrg) & ")"
    ws.Range("A4").Value = "�bertragene R�ckstellungen bei Einzel�bertritten"
    ws.Range("A6").Value = "Positive Betr�ge erh�lt die " & targetShortName & _
                           " von der genannten Gesellschaft,"
    ws.Range("A7").Value = "negative Betr�ge gibt die " & targetShortName & _
                           " an die genannte Gesellschaft ab."

    ws.Range("H1").Value = "CHECK"
    ws.Range("I1").Value = "ORZ, OK"
    ws.Range("H2").Value = targetLtrg
    ws.Range("I2").Value = targetInfo(0)
    ws.Range("J2").Value = targetName
    ws.Range("H3").Value = "CHECK"

    overviewNameEscaped = Replace(wsOverview.Name, "'", "''")
    ws.Range("H4").Formula = _
        "=SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$B:$B,$H$2)-" & _
        "SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$D:$D,$H$2)"

    currentRow = 10
    subtotalRefs = ""

    If groups.Count > 0 Then
        groupKeys = groups.Keys
        SortGroupKeys groupKeys, groups, transferData, targetLtrg

        For i = 0 To UBound(groupKeys)
            counterpartyKey = CStr(groupKeys(i))
            counterpartyInfo = companies.Item(counterpartyKey)
            Set rowsInGroup = groups.Item(counterpartyKey)

            sectionRow = currentRow
            headerRow = sectionRow + 1
            dataStartRow = headerRow + 1

            ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
            ws.Cells(sectionRow, 1).Value = _
                ShortCompanyName(CStr(counterpartyInfo(1))) & _
                " (ARE " & DisplayValue(counterpartyInfo(0)) & _
                ", LTRG " & FormatLtrg(CLng(counterpartyKey)) & ")"

            ws.Cells(sectionRow, 8).Value = CLng(counterpartyKey)
            ws.Cells(sectionRow, 9).Value = counterpartyInfo(0)
            ws.Cells(sectionRow, 10).Value = CStr(counterpartyInfo(1))

            ws.Cells(headerRow, 1).Value = "PNR" & vbLf
            ws.Cells(headerRow, 2).Value = "alte PNR" & vbLf
            ws.Cells(headerRow, 3).Value = "�bertritt" & vbLf
            ws.Cells(headerRow, 4).Value = "Pensionen (alt)" & vbLf & "(Euro)"
            ws.Cells(headerRow, 5).Value = "BSAV" & vbLf & "(Euro)"
            ws.Cells(headerRow, 6).Value = "Summe" & vbLf & "(Euro)"

            currentRow = dataStartRow

            For pass = 1 To 2
                For j = 0 To rowsInGroup.Count - 1
                    descriptor = rowsInGroup.Item(CStr(j))
                    sourceIndex = CLng(descriptor(0))
                    direction = CLng(descriptor(1))
                    signedTotal = direction * NzNumber(transferData(sourceIndex, 10))

                    shouldWrite = _
                        (pass = 1 And signedTotal > 0) Or _
                        (pass = 2 And signedTotal <= 0)

                    If shouldWrite Then
                        signedPension = direction * NzNumber(transferData(sourceIndex, 9))
                        signedBsav = direction * NzNumber(transferData(sourceIndex, 8))

                        ws.Cells(currentRow, 1).Value = transferData(sourceIndex, 1)
                        ws.Cells(currentRow, 2).Value = transferData(sourceIndex, 3)
                        ws.Cells(currentRow, 3).Value = transferData(sourceIndex, 5)
                        ws.Cells(currentRow, 4).Value = signedPension
                        ws.Cells(currentRow, 5).Value = signedBsav
                        ws.Cells(currentRow, 6).Value = signedTotal

                        currentRow = currentRow + 1
                    End If
                Next
            Next

            dataEndRow = currentRow - 1
            subtotalRow = currentRow

            ws.Cells(subtotalRow, 4).Formula = _
                "=SUM(D" & CStr(dataStartRow) & ":D" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 5).Formula = _
                "=SUM(E" & CStr(dataStartRow) & ":E" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 6).Formula = _
                "=SUM(F" & CStr(dataStartRow) & ":F" & CStr(dataEndRow) & ")"

            subtotalRefs = subtotalRefs & "," & _
                           ws.Cells(subtotalRow, 6).Address(False, False)

            FormatSection ws, sectionRow, headerRow, dataStartRow, dataEndRow, subtotalRow
            currentRow = subtotalRow + 2
        Next
    End If

    If Len(subtotalRefs) > 0 Then
        ws.Range("I4").Formula = "=H4-SUM(" & Mid(subtotalRefs, 2) & ")"
    Else
        ws.Range("I4").Formula = "=H4"
    End If

    FormatARESheet xlApp, ws, currentRow - 1
End Sub


Sub BuildExportFolders(ByVal fso, ByVal sourcePath, ByRef excelFolder, _
                       ByRef pdfFolder, ByRef serialFolder, _
                       ByRef individualFolder)
    Dim outputRoot
    Dim baseName
    Dim candidate
    Dim stamp
    Dim counter

    ' Alle Ergebnisse liegen gesammelt neben dem Starter im Ordner Output.
    outputRoot = fso.BuildPath(gProjectFolder, "Output")
    If Not fso.FolderExists(outputRoot) Then fso.CreateFolder outputRoot

    baseName = SanitizeFileName(fso.GetBaseName(sourcePath))
    stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
            "_" & TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & _
            TwoDigits(Second(Now))
    candidate = fso.BuildPath(outputRoot, baseName & "_ARE_Export_" & stamp)

    counter = 2
    Do While fso.FolderExists(candidate) Or fso.FileExists(candidate)
        candidate = fso.BuildPath(outputRoot, baseName & "_ARE_Export_" & _
                                  stamp & "_" & CStr(counter))
        counter = counter + 1
    Loop

    fso.CreateFolder candidate
    gExportFolder = candidate

    excelFolder = fso.BuildPath(candidate, "00_Excel")
    pdfFolder = fso.BuildPath(candidate, "01_ARE_PDF")
    serialFolder = fso.BuildPath(candidate, "02_Serienbrief_Gesamt")
    individualFolder = fso.BuildPath(candidate, "03_Serienbrief_Einzel")

    fso.CreateFolder excelFolder
    fso.CreateFolder pdfFolder
    fso.CreateFolder serialFolder
    fso.CreateFolder individualFolder
End Sub

Sub ExportGeneratedSheetsAsPdf(ByVal wb, ByVal fso, ByVal pdfFolder)
    Dim i
    Dim ws
    Dim pdfPath
    Dim exportCount
    Dim sheetName

    exportCount = 0

    For i = 1 To wb.Worksheets.Count
        Set ws = wb.Worksheets(i)
        sheetName = SafeString(ws.Name)

        If Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", 1) > 0 Then

            gStage = "ARE-PDF f�r Blatt " & sheetName & " exportieren"
            gExcel.StatusBar = gStage & " ..."
            pdfPath = UniqueFilePath( _
                fso, _
                pdfFolder, _
                "ERG_VW�_" & SanitizeFileName(sheetName), _
                "pdf" _
            )

            ws.ExportAsFixedFormat xlTypePDF, pdfPath, xlQualityStandard, True, False
            exportCount = exportCount + 1
            WriteLog "ARE-PDF | " & pdfPath
        End If
    Next

    If exportCount = 0 Then
        Err.Raise -2147221504 + 2040, "ARE Generator", _
                  "Es wurden keine erzeugten ARE-Bl�tter f�r den PDF-Export gefunden."
    End If

    WriteLog "INFO | " & CStr(exportCount) & " ARE-Bl�tter als PDF exportiert"
End Sub

Sub EnsureWordApplication()
    If IsObject(gWord) Then
        If Not gWord Is Nothing Then Exit Sub
    End If

    Set gWord = CreateObject("Word.Application")
    gWord.Visible = False
    gWord.DisplayAlerts = 0
End Sub

Function IsGeneratedARESheet(ByVal sheetName)
    sheetName = SafeString(sheetName)
    IsGeneratedARESheet = _
        (Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
         InStr(1, sheetName, "(LTRG ", 1) > 0)
End Function

Function PrepareARELogos(ByVal xlApp, ByVal wb, ByVal fso, ByVal templatePath)
    Dim copied
    Dim logoCount
    Dim logoPath

    EnsureWordApplication
    copied = CopyLogoFromWordTemplate(templatePath)

    If copied Then
        logoCount = PasteCopiedLogoIntoGeneratedSheets(xlApp, wb)
    End If

    If logoCount = 0 Then
        WriteLog "WARNUNG | Logo konnte nicht automatisch aus der DOCX-Vorlage �bernommen werden."
        logoPath = xlApp.GetOpenFilename( _
            "Logo-Bild (*.png;*.jpg;*.jpeg),*.png;*.jpg;*.jpeg", _
            1, _
            "Mercer-Logo als PNG oder JPG ausw�hlen" _
        )

        If VarType(logoPath) = vbBoolean Then
            Err.Raise -2147221504 + 2041, "ARE Generator", _
                      "Das Mercer-Logo wurde in der DOCX-Vorlage nicht erkannt. " & _
                      "Bitte beim erneuten Start ein PNG- oder JPG-Logo ausw�hlen."
        End If

        logoCount = InsertLogoFileIntoGeneratedSheets(wb, CStr(logoPath))
        gLogoSourceDescription = "Bilddatei " & fso.GetFileName(CStr(logoPath))
    Else
        gLogoSourceDescription = "DOCX-Serienbriefvorlage"
    End If

    If logoCount = 0 Then
        Err.Raise -2147221504 + 2042, "ARE Generator", _
                  "Das Mercer-Logo konnte auf keinem ARE-Blatt eingef�gt werden."
    End If

    PrepareARELogos = logoCount
End Function

Function CopyLogoFromWordTemplate(ByVal templatePath)
    Dim logoDoc
    Dim sectionItem
    Dim headerFooter
    Dim shapeItem
    Dim inlineItem
    Dim copied

    CopyLogoFromWordTemplate = False
    Set logoDoc = Nothing

    On Error Resume Next
    Set logoDoc = gWord.Documents.Open(CStr(templatePath), False, True)
    If Err.Number <> 0 Or logoDoc Is Nothing Then
        WriteLog "WARNUNG | DOCX f�r Logo konnte nicht ge�ffnet werden: " & Err.Description
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    copied = False

    ' Bevorzugt werden Bilder in Kopfzeilen. Dort liegt das Mercer-Logo
    ' in der gelieferten Serienbriefvorlage.
    For Each sectionItem In logoDoc.Sections
        For Each headerFooter In sectionItem.Headers
            If Not copied Then
                For Each inlineItem In headerFooter.Range.InlineShapes
                    On Error Resume Next
                    Err.Clear
                    inlineItem.Range.Copy
                    If Err.Number = 0 Then copied = True
                    Err.Clear
                    On Error GoTo 0
                    If copied Then Exit For
                Next
            End If

            If Not copied Then
                For Each shapeItem In headerFooter.Shapes
                    If CLng(shapeItem.Type) = msoPicture Or _
                       CLng(shapeItem.Type) = msoLinkedPicture Then
                        On Error Resume Next
                        Err.Clear
                        shapeItem.Copy
                        If Err.Number = 0 Then copied = True
                        Err.Clear
                        On Error GoTo 0
                        If copied Then Exit For
                    End If
                Next
            End If

            If copied Then Exit For
        Next
        If copied Then Exit For
    Next

    ' Fallback: erstes Bild im Hauptdokument.
    If Not copied Then
        For Each inlineItem In logoDoc.InlineShapes
            On Error Resume Next
            Err.Clear
            inlineItem.Range.Copy
            If Err.Number = 0 Then copied = True
            Err.Clear
            On Error GoTo 0
            If copied Then Exit For
        Next
    End If

    If Not copied Then
        For Each shapeItem In logoDoc.Shapes
            If CLng(shapeItem.Type) = msoPicture Or _
               CLng(shapeItem.Type) = msoLinkedPicture Then
                On Error Resume Next
                Err.Clear
                shapeItem.Copy
                If Err.Number = 0 Then copied = True
                Err.Clear
                On Error GoTo 0
                If copied Then Exit For
            End If
        Next
    End If

    logoDoc.Close wdDoNotSaveChanges
    Set logoDoc = Nothing
    WScript.Sleep 250

    CopyLogoFromWordTemplate = copied
End Function

Function PasteCopiedLogoIntoGeneratedSheets(ByVal xlApp, ByVal wb)
    Dim ws
    Dim beforeCount
    Dim pastedShape
    Dim pasteError
    Dim logoCount

    logoCount = 0

    For Each ws In wb.Worksheets
        If IsGeneratedARESheet(ws.Name) Then
            RemoveExistingARELogo ws
            beforeCount = ws.Shapes.Count

            On Error Resume Next
            Err.Clear
            wb.Activate
            ws.Activate
            ws.Range("A1").Select
            ws.Paste
            pasteError = Err.Number
            Err.Clear
            On Error GoTo 0

            If pasteError = 0 And ws.Shapes.Count > beforeCount Then
                Set pastedShape = ws.Shapes(ws.Shapes.Count)
                PositionARELogo ws, pastedShape
                logoCount = logoCount + 1
            End If
        End If
    Next

    PasteCopiedLogoIntoGeneratedSheets = logoCount
End Function

Function InsertLogoFileIntoGeneratedSheets(ByVal wb, ByVal logoPath)
    Dim ws
    Dim logoShape
    Dim logoCount

    logoCount = 0

    For Each ws In wb.Worksheets
        If IsGeneratedARESheet(ws.Name) Then
            RemoveExistingARELogo ws
            Set logoShape = Nothing

            On Error Resume Next
            Err.Clear
            Set logoShape = ws.Shapes.AddPicture( _
                CStr(logoPath), msoFalse, msoTrue, _
                ws.Range("A1").Left, ws.Range("A1").Top, -1, -1 _
            )
            Err.Clear
            On Error GoTo 0

            If Not logoShape Is Nothing Then
                PositionARELogo ws, logoShape
                logoCount = logoCount + 1
            End If
        End If
    Next

    InsertLogoFileIntoGeneratedSheets = logoCount
End Function

Sub PositionARELogo(ByVal ws, ByVal logoShape)
    On Error Resume Next
    logoShape.Name = "ARE_Mercer_Logo"
    logoShape.LockAspectRatio = msoTrue
    logoShape.Height = 42
    logoShape.Left = ws.Range("A1").Left
    logoShape.Top = ws.Range("A1").Top + 2
    logoShape.Placement = 1
    Err.Clear
    On Error GoTo 0
End Sub

Sub RemoveExistingARELogo(ByVal ws)
    Dim shapeIndex
    Dim shapeName

    For shapeIndex = ws.Shapes.Count To 1 Step -1
        shapeName = SafeString(ws.Shapes(shapeIndex).Name)
        If Left(shapeName, 16) = "ARE_Mercer_Logo" Then
            ws.Shapes(shapeIndex).Delete
        End If
    Next
End Sub

Sub GenerateSerialLetters(ByVal xlApp, ByVal fso, ByVal templatePath, _
                          ByVal dataPath, ByVal serialFolder, _
                          ByVal individualFolder, ByRef mergeCount, _
                          ByRef aggregateDocxPath, ByRef aggregatePdfPath)
    Dim nativeErrorNumber
    Dim nativeErrorDescription
    Dim nativeErrorSource

    On Error Resume Next
    Err.Clear
    GenerateSerialLettersNative xlApp, fso, templatePath, dataPath, _
                                serialFolder, individualFolder, mergeCount, _
                                aggregateDocxPath, aggregatePdfPath
    nativeErrorNumber = Err.Number
    nativeErrorDescription = Err.Description
    nativeErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0

    If nativeErrorNumber <> 0 Then
        WriteLog "WARNUNG | Nativer Word-Seriendruck fehlgeschlagen. " & _
                 "Nummer=" & CStr(nativeErrorNumber) & _
                 " | Quelle=" & nativeErrorSource & _
                 " | Beschreibung=" & nativeErrorDescription & _
                 " | Fallback auf kompatiblen Feldmodus."

        CloseWordSafely
        DeleteFileIfExists fso, aggregateDocxPath
        DeleteFileIfExists fso, aggregatePdfPath
        DeleteFilesInFolder fso, individualFolder
        GenerateSerialLettersLegacy xlApp, fso, templatePath, dataPath, _
                                    serialFolder, individualFolder, mergeCount, _
                                    aggregateDocxPath, aggregatePdfPath
    End If
End Sub

Sub GenerateSerialLettersNative(ByVal xlApp, ByVal fso, ByVal templatePath, _
                                ByVal dataPath, ByVal serialFolder, _
                                ByVal individualFolder, ByRef mergeCount, _
                                ByRef aggregateDocxPath, ByRef aggregatePdfPath)
    Dim headers
    Dim dataRows
    Dim rowCount
    Dim columnCount
    Dim dataSheetName
    Dim mergeDataPath
    Dim mainDoc
    Dim mergedDoc
    Dim mailMerge
    Dim sqlStatement
    Dim recordIndex
    Dim ltrgValue
    Dim areValue
    Dim individualPdfPath

    gStage = "Serienbriefdaten einlesen"
    LoadSerialData xlApp, dataPath, headers, dataRows, rowCount, _
                   columnCount, dataSheetName

    If columnCount < 2 Then
        Err.Raise -2147221504 + 2050, "ARE Generator", _
                  "Die Personendatei ben�tigt mindestens die Spalten A und B."
    End If
    If rowCount < 1 Then
        Err.Raise -2147221504 + 2051, "ARE Generator", _
                  "Die Personendatei enth�lt unterhalb der Kopfzeile keine Datens�tze."
    End If

    mergeCount = rowCount
    aggregateDocxPath = UniqueFilePath( _
        fso, serialFolder, "Anschreiben_ARE_Gesamt", "docx" _
    )
    aggregatePdfPath = UniqueFilePath( _
        fso, serialFolder, "Anschreiben_ARE_Gesamt", "pdf" _
    )

    gStage = "Tempor�re Serienbrief-Datenquelle erstellen"
    mergeDataPath = BuildNativeMergeDataSource( _
        xlApp, fso, headers, dataRows, rowCount, columnCount _
    )

    gStage = "Microsoft Word starten"
    EnsureWordApplication

    Set mainDoc = gWord.Documents.Open(CStr(templatePath), False, True)
    Set mailMerge = mainDoc.MailMerge

    If mailMerge.Fields.Count = 0 Then
        mainDoc.Close wdDoNotSaveChanges
        DeleteFileIfExists fso, mergeDataPath
        Err.Raise -2147221504 + 2052, "ARE Generator", _
                  "In der DOCX-Vorlage wurden keine Word-Seriendruckfelder " & _
                  "(MERGEFIELD) gefunden."
    End If

    sqlStatement = "SELECT * FROM [Daten$]"
    mailMerge.OpenDataSource CStr(mergeDataPath), wdOpenFormatAuto, _
                             False, True, True, False, "", "", False, _
                             "", "", "", sqlStatement, "", _
                             wdMergeSubTypeOther
    mailMerge.Destination = wdSendToNewDocument
    mailMerge.SuppressBlankLines = True

    gStage = "Gesamt-Serienbrief nativ zusammenf�hren"
    mainDoc.Activate
    mailMerge.DataSource.FirstRecord = 1
    mailMerge.DataSource.LastRecord = rowCount
    mailMerge.Execute False
    Set mergedDoc = gWord.ActiveDocument
    OptimizeMergedLetterLayout mergedDoc
    mergedDoc.SaveAs2 aggregateDocxPath, wdFormatXMLDocument
    mergedDoc.ExportAsFixedFormat aggregatePdfPath, wdExportFormatPDF
    mergedDoc.Close wdDoNotSaveChanges
    Set mergedDoc = Nothing

    For recordIndex = 1 To rowCount
        gStage = "Serienbrief Person " & CStr(recordIndex) & _
                 " von " & CStr(rowCount) & " nativ erstellen"
        xlApp.StatusBar = gStage & " ..."

        mainDoc.Activate
        mailMerge.DataSource.FirstRecord = recordIndex
        mailMerge.DataSource.LastRecord = recordIndex
        mailMerge.Execute False
        Set mergedDoc = gWord.ActiveDocument
        OptimizeMergedLetterLayout mergedDoc

        ltrgValue = SanitizeFileName(SafeString(dataRows(recordIndex, 1)))
        areValue = SanitizeFileName(SafeString(dataRows(recordIndex, 2)))
        If Len(ltrgValue) = 0 Then ltrgValue = "ohne_LTRG"
        If Len(areValue) = 0 Then areValue = "ohne_ARE"

        individualPdfPath = UniqueFilePath( _
            fso, individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, _
            "pdf" _
        )
        mergedDoc.ExportAsFixedFormat individualPdfPath, wdExportFormatPDF
        WriteLog "PERSONEN-PDF-NATIV | Datensatz=" & CStr(recordIndex) & _
                 " | Datei=" & individualPdfPath

        mergedDoc.Close wdDoNotSaveChanges
        Set mergedDoc = Nothing
    Next

    mainDoc.Close wdDoNotSaveChanges
    Set mainDoc = Nothing
    Set mailMerge = Nothing
    DeleteFileIfExists fso, mergeDataPath

    WriteLog "SERIENBRIEF-MODUS | Nativer Microsoft-Word-Seriendruck"
    WriteLog "SERIENBRIEF-GESAMT-DOCX | " & aggregateDocxPath
    WriteLog "SERIENBRIEF-GESAMT-PDF | " & aggregatePdfPath
    CloseWordSafely
    xlApp.StatusBar = False
End Sub

Function BuildNativeMergeDataSource(ByVal xlApp, ByVal fso, ByRef headers, _
                                    ByRef dataRows, ByVal rowCount, _
                                    ByVal columnCount)
    Dim tempFolder
    Dim tempPath
    Dim tempWorkbook
    Dim tempSheet
    Dim rowIndex
    Dim columnIndex
    Dim stamp

    tempFolder = fso.GetSpecialFolder(2)
    stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
            TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & _
            TwoDigits(Second(Now))
    tempPath = fso.BuildPath(tempFolder, _
        "ARE_Serienbrief_Daten_" & stamp & "_" & CStr(Int(Rnd * 100000)) & ".xlsx")

    Set tempWorkbook = xlApp.Workbooks.Add
    Set tempSheet = tempWorkbook.Worksheets(1)
    tempSheet.Name = "Daten"

    For columnIndex = 1 To columnCount
        tempSheet.Cells(1, columnIndex).Value = SafeString(headers(columnIndex))
    Next

    For rowIndex = 1 To rowCount
        For columnIndex = 1 To columnCount
            tempSheet.Cells(rowIndex + 1, columnIndex).NumberFormat = "@"
            tempSheet.Cells(rowIndex + 1, columnIndex).Value = _
                SafeString(dataRows(rowIndex, columnIndex))
        Next
    Next

    tempWorkbook.SaveAs tempPath, xlOpenXMLWorkbook
    tempWorkbook.Close False
    Set tempSheet = Nothing
    Set tempWorkbook = Nothing

    BuildNativeMergeDataSource = tempPath
End Function

Sub OptimizeMergedLetterLayout(ByVal doc)
    Dim paragraphItem
    Dim paragraphText

    ' Der native Seriendruck �bernimmt das Vorlagenlayout. Diese kleine
    ' Nachbearbeitung verhindert, dass die Schlusszeile "Anlage" wegen
    ' unn�tigem Absatzabstand allein auf eine zweite Seite rutscht.
    For Each paragraphItem In doc.Paragraphs
        paragraphText = Trim(Replace(Replace( _
            SafeString(paragraphItem.Range.Text), vbCr, ""), Chr(7), ""))
        If LCase(Left(paragraphText, 6)) = "anlage" Then
            paragraphItem.Format.SpaceBefore = 0
            paragraphItem.Format.SpaceAfter = 0
            paragraphItem.KeepTogether = True
        End If
    Next

    On Error Resume Next
    doc.Repaginate
    Err.Clear
    On Error GoTo 0
End Sub

Sub DeleteFilesInFolder(ByVal fso, ByVal folderPath)
    Dim folderItem
    Dim fileItem

    On Error Resume Next
    If fso.FolderExists(CStr(folderPath)) Then
        Set folderItem = fso.GetFolder(CStr(folderPath))
        For Each fileItem In folderItem.Files
            fileItem.Delete True
        Next
    End If
    Set fileItem = Nothing
    Set folderItem = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Sub DeleteFileIfExists(ByVal fso, ByVal filePath)
    On Error Resume Next
    If Len(SafeString(filePath)) > 0 Then
        If fso.FileExists(CStr(filePath)) Then fso.DeleteFile CStr(filePath), True
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Sub GenerateSerialLettersLegacy(ByVal xlApp, ByVal fso, ByVal templatePath, _
                          ByVal dataPath, ByVal serialFolder, _
                          ByVal individualFolder, ByRef mergeCount, _
                          ByRef aggregateDocxPath, ByRef aggregatePdfPath)
    Dim headers
    Dim dataRows
    Dim rowCount
    Dim columnCount
    Dim dataSheetName
    Dim recordIndex
    Dim personDoc
    Dim aggregateDoc
    Dim insertRange
    Dim individualPdfPath
    Dim areValue
    Dim ltrgValue
    Dim filledFieldCount

    gStage = "Serienbriefdaten einlesen"
    LoadSerialData xlApp, dataPath, headers, dataRows, rowCount, _
                   columnCount, dataSheetName

    If columnCount < 2 Then
        Err.Raise -2147221504 + 2050, "ARE Generator", _
                  "Die Personendatei ben�tigt mindestens die Spalten A und B."
    End If

    If rowCount < 1 Then
        Err.Raise -2147221504 + 2051, "ARE Generator", _
                  "Die Personendatei enth�lt unterhalb der Kopfzeile keine Datens�tze."
    End If

    mergeCount = rowCount
    aggregateDocxPath = UniqueFilePath( _
        fso, serialFolder, "Anschreiben_ARE_Gesamt", "docx" _
    )
    aggregatePdfPath = UniqueFilePath( _
        fso, serialFolder, "Anschreiben_ARE_Gesamt", "pdf" _
    )

    gStage = "Microsoft Word starten"
    EnsureWordApplication
    Set aggregateDoc = Nothing

    For recordIndex = 1 To rowCount
        gStage = "Serienbrief Person " & CStr(recordIndex) & _
                 " von " & CStr(rowCount) & " erstellen"
        xlApp.StatusBar = gStage & " ..."

        Set personDoc = gWord.Documents.Open(CStr(templatePath), False, True)
        filledFieldCount = 0
        FillMergeFieldsInDocument personDoc, headers, dataRows, _
                                  recordIndex, columnCount, filledFieldCount

        If recordIndex = 1 And filledFieldCount = 0 Then
            personDoc.Close wdDoNotSaveChanges
            Set personDoc = Nothing
            Err.Raise -2147221504 + 2052, "ARE Generator", _
                      "In der DOCX-Vorlage wurden keine Word-Seriendruckfelder " & _
                      "(MERGEFIELD) gefunden."
        End If

        ltrgValue = SanitizeFileName(SafeString(dataRows(recordIndex, 1)))
        areValue = SanitizeFileName(SafeString(dataRows(recordIndex, 2)))

        If Len(ltrgValue) = 0 Then ltrgValue = "ohne_LTRG"
        If Len(areValue) = 0 Then areValue = "ohne_ARE"

        individualPdfPath = UniqueFilePath( _
            fso, _
            individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, _
            "pdf" _
        )

        OptimizeMergedLetterLayout personDoc
        personDoc.ExportAsFixedFormat individualPdfPath, wdExportFormatPDF
        WriteLog "PERSONEN-PDF | Datensatz=" & CStr(recordIndex) & _
                 " | Datei=" & individualPdfPath

        If aggregateDoc Is Nothing Then
            personDoc.SaveAs2 aggregateDocxPath, wdFormatXMLDocument
            Set aggregateDoc = personDoc
            Set personDoc = Nothing
        Else
            Set insertRange = aggregateDoc.Range( _
                aggregateDoc.Content.End - 1, aggregateDoc.Content.End - 1 _
            )
            insertRange.InsertBreak wdPageBreak
            insertRange.Collapse wdCollapseEnd
            insertRange.FormattedText = personDoc.Content.FormattedText

            personDoc.Close wdDoNotSaveChanges
            Set personDoc = Nothing
            Set insertRange = Nothing
        End If
    Next

    gStage = "Gesamt-Serienbrief speichern"
    OptimizeMergedLetterLayout aggregateDoc
    aggregateDoc.Save
    aggregateDoc.ExportAsFixedFormat aggregatePdfPath, wdExportFormatPDF
    aggregateDoc.Close wdDoNotSaveChanges
    Set aggregateDoc = Nothing

    WriteLog "SERIENBRIEF-GESAMT-DOCX | " & aggregateDocxPath
    WriteLog "SERIENBRIEF-GESAMT-PDF | " & aggregatePdfPath
    WriteLog "INFO | Serienbriefdaten: Blatt='" & dataSheetName & _
             "', Datens�tze=" & CStr(rowCount) & _
             ", Spalten=" & CStr(columnCount)

    CloseWordSafely
    xlApp.StatusBar = False
End Sub

Sub LoadSerialData(ByVal xlApp, ByVal dataPath, ByRef headers, _
                   ByRef dataRows, ByRef rowCount, ByRef columnCount, _
                   ByRef dataSheetName)
    Dim dataWorkbook
    Dim ws
    Dim usedStartRow
    Dim usedRowCount
    Dim usedStartColumn
    Dim usedColumnCount
    Dim usedLastRow
    Dim usedLastColumn
    Dim lastRow
    Dim lastColumn
    Dim sourceRow
    Dim recordIndex
    Dim columnIndex
    Dim headerText

    Set dataWorkbook = xlApp.Workbooks.Open(CStr(dataPath), 0, True)
    Set ws = dataWorkbook.Worksheets(1)
    dataSheetName = SafeString(ws.Name)

    usedStartRow = CLng(ws.UsedRange.Row)
    usedRowCount = CLng(ws.UsedRange.Rows.Count)
    usedStartColumn = CLng(ws.UsedRange.Column)
    usedColumnCount = CLng(ws.UsedRange.Columns.Count)

    usedLastRow = usedStartRow + usedRowCount - 1
    usedLastColumn = usedStartColumn + usedColumnCount - 1

    lastColumn = FindLastSerialColumn(ws, usedLastColumn)
    lastRow = FindLastSerialRow(ws, usedLastRow, lastColumn)

    If lastColumn < 1 Then
        dataWorkbook.Close False
        Set dataWorkbook = Nothing
        Err.Raise -2147221504 + 2053, "ARE Generator", _
                  "In der ersten Zeile der Personendatei wurden keine Spalten�berschriften gefunden."
    End If

    columnCount = lastColumn
    ReDim headers(columnCount)

    For columnIndex = 1 To columnCount
        headerText = Trim(ReadCellTextSafe(ws.Cells(1, columnIndex)))
        If Len(headerText) = 0 Then
            headerText = "Spalte_" & CStr(columnIndex)
            WriteLog "WARNUNG | Leere Serienbrief-Kopfzelle in Spalte " & _
                     CStr(columnIndex) & " wird als '" & headerText & "' gef�hrt."
        End If
        headers(columnIndex) = headerText
    Next

    rowCount = 0
    For sourceRow = 2 To lastRow
        If SerialRowHasData(ws, sourceRow, columnCount) Then
            rowCount = rowCount + 1
        End If
    Next

    If rowCount > 0 Then
        ReDim dataRows(rowCount, columnCount)
        recordIndex = 0

        For sourceRow = 2 To lastRow
            If SerialRowHasData(ws, sourceRow, columnCount) Then
                recordIndex = recordIndex + 1
                For columnIndex = 1 To columnCount
                    dataRows(recordIndex, columnIndex) = _
                        ReadCellTextSafe(ws.Cells(sourceRow, columnIndex))
                Next
            End If
        Next
    End If

    dataWorkbook.Close False
    Set ws = Nothing
    Set dataWorkbook = Nothing
End Sub

Function FindLastSerialColumn(ByVal ws, ByVal usedLastColumn)
    Dim columnIndex

    FindLastSerialColumn = 0

    For columnIndex = usedLastColumn To 1 Step -1
        If CellHasContent(ws.Cells(1, columnIndex)) Then
            FindLastSerialColumn = columnIndex
            Exit Function
        End If
    Next
End Function

Function FindLastSerialRow(ByVal ws, ByVal usedLastRow, ByVal lastColumn)
    Dim rowIndex
    Dim columnIndex

    FindLastSerialRow = 1
    If lastColumn < 1 Then Exit Function

    For rowIndex = usedLastRow To 2 Step -1
        For columnIndex = 1 To lastColumn
            If CellHasContent(ws.Cells(rowIndex, columnIndex)) Then
                FindLastSerialRow = rowIndex
                Exit Function
            End If
        Next
    Next
End Function

Function SerialRowHasData(ByVal ws, ByVal rowIndex, ByVal columnCount)
    Dim columnIndex

    SerialRowHasData = False

    For columnIndex = 1 To columnCount
        If CellHasContent(ws.Cells(rowIndex, columnIndex)) Then
            SerialRowHasData = True
            Exit Function
        End If
    Next
End Function

Sub FillMergeFieldsInDocument(ByVal doc, ByRef headers, ByRef dataRows, _
                              ByVal recordIndex, ByVal columnCount, _
                              ByRef filledFieldCount)
    Dim storyRange
    Dim currentRange
    Dim nextRange

    filledFieldCount = 0

    For Each storyRange In doc.StoryRanges
        Set currentRange = storyRange

        Do While Not currentRange Is Nothing
            ProcessMergeFieldsInRange currentRange, headers, dataRows, _
                                      recordIndex, columnCount, filledFieldCount

            Set nextRange = Nothing
            On Error Resume Next
            Set nextRange = currentRange.NextStoryRange
            Err.Clear
            On Error GoTo 0

            Set currentRange = nextRange
        Loop
    Next

    ' Zus�tzliche Absicherung f�r Seriendruckfelder in Textfeldern,
    ' insbesondere in Kopf- und Fu�zeilen.
    ProcessDocumentShapeFields doc, headers, dataRows, recordIndex, _
                               columnCount, filledFieldCount
End Sub

Sub ProcessDocumentShapeFields(ByVal doc, ByRef headers, ByRef dataRows, _
                               ByVal recordIndex, ByVal columnCount, _
                               ByRef filledFieldCount)
    Dim shapeItem
    Dim sectionItem
    Dim headerFooter
    Dim textRange

    For Each shapeItem In doc.Shapes
        Set textRange = Nothing
        On Error Resume Next
        If shapeItem.TextFrame.HasText Then
            Set textRange = shapeItem.TextFrame.TextRange
        End If
        Err.Clear
        On Error GoTo 0

        If Not textRange Is Nothing Then
            ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                      recordIndex, columnCount, filledFieldCount
        End If
    Next

    For Each sectionItem In doc.Sections
        For Each headerFooter In sectionItem.Headers
            For Each shapeItem In headerFooter.Shapes
                Set textRange = Nothing
                On Error Resume Next
                If shapeItem.TextFrame.HasText Then
                    Set textRange = shapeItem.TextFrame.TextRange
                End If
                Err.Clear
                On Error GoTo 0

                If Not textRange Is Nothing Then
                    ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                              recordIndex, columnCount, _
                                              filledFieldCount
                End If
            Next
        Next

        For Each headerFooter In sectionItem.Footers
            For Each shapeItem In headerFooter.Shapes
                Set textRange = Nothing
                On Error Resume Next
                If shapeItem.TextFrame.HasText Then
                    Set textRange = shapeItem.TextFrame.TextRange
                End If
                Err.Clear
                On Error GoTo 0

                If Not textRange Is Nothing Then
                    ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                              recordIndex, columnCount, _
                                              filledFieldCount
                End If
            Next
        Next
    Next
End Sub

Sub ProcessMergeFieldsInRange(ByVal targetRange, ByRef headers, _
                              ByRef dataRows, ByVal recordIndex, _
                              ByVal columnCount, ByRef filledFieldCount)
    Dim fieldIndex
    Dim mergeField
    Dim fieldName
    Dim fieldValue
    Dim valueFound

    For fieldIndex = targetRange.Fields.Count To 1 Step -1
        Set mergeField = targetRange.Fields(fieldIndex)

        If CLng(mergeField.Type) = wdFieldMergeField Then
            fieldName = GetMergeFieldName(SafeString(mergeField.Code.Text))
            valueFound = False
            fieldValue = LookupMergeValue( _
                fieldName, headers, dataRows, recordIndex, columnCount, valueFound _
            )

            If Not valueFound And recordIndex = 1 Then
                WriteLog "WARNUNG | Serienbrieffeld ohne passende Excel-Spalte: " & _
                         fieldName
            End If

            mergeField.Result.Text = fieldValue
            mergeField.Unlink
            filledFieldCount = filledFieldCount + 1
        End If
    Next
End Sub

Function GetMergeFieldName(ByVal fieldCode)
    Dim textValue
    Dim rest
    Dim endPosition
    Dim spacePosition
    Dim slashPosition
    Dim cutPosition

    textValue = Trim(SafeString(fieldCode))
    GetMergeFieldName = ""

    If LCase(Left(textValue, 10)) <> "mergefield" Then Exit Function

    rest = Trim(Mid(textValue, 11))
    If Len(rest) = 0 Then Exit Function

    If Left(rest, 1) = Chr(34) Then
        endPosition = InStr(2, rest, Chr(34), 1)
        If endPosition > 1 Then
            GetMergeFieldName = Mid(rest, 2, endPosition - 2)
        End If
        Exit Function
    End If

    spacePosition = InStr(1, rest, " ", 1)
    slashPosition = InStr(1, rest, "\", 1)
    cutPosition = 0

    If spacePosition > 0 Then cutPosition = spacePosition
    If slashPosition > 0 Then
        If cutPosition = 0 Or slashPosition < cutPosition Then
            cutPosition = slashPosition
        End If
    End If

    If cutPosition > 0 Then
        GetMergeFieldName = Trim(Left(rest, cutPosition - 1))
    Else
        GetMergeFieldName = Trim(rest)
    End If
End Function

Function LookupMergeValue(ByVal fieldName, ByRef headers, ByRef dataRows, _
                          ByVal recordIndex, ByVal columnCount, ByRef valueFound)
    Dim columnIndex
    Dim normalizedField

    LookupMergeValue = ""
    valueFound = False

    For columnIndex = 1 To columnCount
        If StrComp(Trim(SafeString(headers(columnIndex))), _
                   Trim(SafeString(fieldName)), 1) = 0 Then
            LookupMergeValue = SafeString(dataRows(recordIndex, columnIndex))
            valueFound = True
            Exit Function
        End If
    Next

    normalizedField = NormalizeMergeKey(fieldName)

    For columnIndex = 1 To columnCount
        If NormalizeMergeKey(headers(columnIndex)) = normalizedField Then
            LookupMergeValue = SafeString(dataRows(recordIndex, columnIndex))
            valueFound = True
            Exit Function
        End If
    Next
End Function

Function NormalizeMergeKey(ByVal value)
    Dim textValue

    textValue = LCase(Trim(SafeString(value)))
    textValue = Replace(textValue, " ", "")
    textValue = Replace(textValue, "_", "")
    textValue = Replace(textValue, "-", "")
    textValue = Replace(textValue, ".", "")
    textValue = Replace(textValue, ":", "")
    textValue = Replace(textValue, vbTab, "")
    textValue = Replace(textValue, vbCr, "")
    textValue = Replace(textValue, vbLf, "")
    textValue = Replace(textValue, Chr(160), "")
    textValue = Replace(textValue, "�", "")
    textValue = Replace(textValue, "�", "")

    NormalizeMergeKey = textValue
End Function

Function SanitizeFileName(ByVal value)
    Dim textValue
    Dim forbidden
    Dim item

    textValue = Trim(SafeString(value))
    forbidden = Array("\", "/", ":", "*", "?", Chr(34), "<", ">", "|")

    For Each item In forbidden
        textValue = Replace(textValue, CStr(item), "-")
    Next

    Do While Len(textValue) > 0 And _
             (Right(textValue, 1) = "." Or Right(textValue, 1) = " ")
        textValue = Left(textValue, Len(textValue) - 1)
    Loop

    Do While InStr(1, textValue, "  ", 1) > 0
        textValue = Replace(textValue, "  ", " ")
    Loop

    If Len(textValue) > 120 Then textValue = Left(textValue, 120)
    SanitizeFileName = textValue
End Function

Function UniqueFilePath(ByVal fso, ByVal folderPath, ByVal baseName, _
                        ByVal extension)
    Dim safeBaseName
    Dim candidate
    Dim counter

    safeBaseName = SanitizeFileName(baseName)
    If Len(safeBaseName) = 0 Then safeBaseName = "Ausgabe"

    candidate = fso.BuildPath(folderPath, safeBaseName & "." & extension)
    counter = 2

    Do While fso.FileExists(candidate) Or fso.FolderExists(candidate)
        candidate = fso.BuildPath( _
            folderPath, safeBaseName & "_" & CStr(counter) & "." & extension _
        )
        counter = counter + 1
    Loop

    UniqueFilePath = candidate
End Function

Sub CloseWordSafely()
    On Error Resume Next

    If IsObject(gWord) Then
        If Not gWord Is Nothing Then
            Do While gWord.Documents.Count > 0
                gWord.Documents(1).Close wdDoNotSaveChanges
            Loop
            gWord.DisplayAlerts = 0
            gWord.Quit wdDoNotSaveChanges
        End If
    End If

    Set gWord = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Function LoadCompanies(ByVal ws)
    Dim dict
    Dim lastRow
    Dim r
    Dim ltrg
    Dim isValid
    Dim companyName
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    lastRow = FindLastCompanyRow(ws)

    For r = 2 To lastRow
        isValid = TryGetLong(ReadCellValueSafe(ws.Cells(r, 4)), ltrg)
        If isValid Then
            companyName = SafeString(ReadCellValueSafe(ws.Cells(r, 6)))
            If Len(Trim(companyName)) > 0 Then
                key = CStr(ltrg)
                If dict.Exists(key) Then
                    dict.Item(key) = Array(ReadCellValueSafe(ws.Cells(r, 5)), companyName)
                Else
                    dict.Add key, Array(ReadCellValueSafe(ws.Cells(r, 5)), companyName)
                End If
            End If
        End If
    Next

    If dict.Count = 0 Then
        Err.Raise -2147221504 + 2020, "ARE Generator", _
                  "Im Blatt '" & SHEET_COMPANIES & "' wurden keine Gesellschaften gefunden."
    End If

    Set LoadCompanies = dict
End Function

Function BuildTargetLtrgs(ByRef transferData)
    Dim dict
    Dim i
    Dim ltrg
    Dim isValid
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    For i = 1 To UBound(transferData, 1)
        isValid = TryGetLong(transferData(i, 2), ltrg)
        If isValid Then
            key = CStr(ltrg)
            If Not dict.Exists(key) Then dict.Add key, True
        End If

        isValid = TryGetLong(transferData(i, 4), ltrg)
        If isValid Then
            key = CStr(ltrg)
            If Not dict.Exists(key) Then dict.Add key, True
        End If
    Next

    Set BuildTargetLtrgs = dict
End Function

Sub ValidateCompanyAssignments(ByVal targets, ByVal companies)
    Dim key
    Dim missing

    missing = ""
    For Each key In targets.Keys
        If Not companies.Exists(CStr(key)) Then
            missing = missing & vbCrLf & "- LTRG " & FormatLtrg(CLng(key))
        End If
    Next

    If Len(missing) > 0 Then
        Err.Raise -2147221504 + 2021, "ARE Generator", _
                  "F�r folgende LTRG fehlt eine Zuordnung im Blatt '" & _
                  SHEET_COMPANIES & "':" & missing
    End If
End Sub

Sub AddGroupRecord(ByVal groups, ByVal counterpartyKey, ByVal sourceIndex, ByVal direction)
    Dim rowsInGroup

    If Not groups.Exists(counterpartyKey) Then
        Set rowsInGroup = CreateObject("Scripting.Dictionary")
        rowsInGroup.CompareMode = 1
        groups.Add counterpartyKey, rowsInGroup
    Else
        Set rowsInGroup = groups.Item(counterpartyKey)
    End If

    rowsInGroup.Add CStr(rowsInGroup.Count), Array(sourceIndex, direction)
End Sub

Sub SortNumericKeys(ByRef keys)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If CLng(keys(i)) > CLng(keys(j)) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Sub SortGroupKeys(ByRef keys, ByVal groups, ByRef transferData, ByVal targetLtrg)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If GroupKeyComesAfter(CStr(keys(i)), CStr(keys(j)), _
                                  groups, transferData, targetLtrg) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Function GroupKeyComesAfter(ByVal firstKey, ByVal secondKey, ByVal groups, _
                            ByRef transferData, ByVal targetLtrg)
    Dim firstRows
    Dim secondRows
    Dim firstHasPositive
    Dim secondHasPositive

    If targetLtrg = CENTRAL_LTRG Then
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
        Exit Function
    End If

    Set firstRows = groups.Item(firstKey)
    Set secondRows = groups.Item(secondKey)

    firstHasPositive = GroupHasPositive(firstRows, transferData)
    secondHasPositive = GroupHasPositive(secondRows, transferData)

    If firstHasPositive <> secondHasPositive Then
        GroupKeyComesAfter = (Not firstHasPositive And secondHasPositive)
    Else
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
    End If
End Function

Function GroupHasPositive(ByVal rowsInGroup, ByRef transferData)
    Dim i
    Dim descriptor
    Dim sourceIndex
    Dim direction

    GroupHasPositive = False

    For i = 0 To rowsInGroup.Count - 1
        descriptor = rowsInGroup.Item(CStr(i))
        sourceIndex = CLng(descriptor(0))
        direction = CLng(descriptor(1))

        If direction * NzNumber(transferData(sourceIndex, 10)) > 0 Then
            GroupHasPositive = True
            Exit Function
        End If
    Next
End Function

Sub FormatARESheet(ByVal xlApp, ByVal ws, ByVal lastContentRow)
    Dim maxRow

    maxRow = MaxLong(lastContentRow, 7)

    With ws.Cells
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlNone
    End With

    ' Berichtskopf wie im fachlichen Ziel-PDF.
    With ws.Range("E1:F2")
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Bold = False
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = False
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(1).RowHeight = 24
    ws.Rows(2).RowHeight = 20

    With ws.Range("A4:F4")
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(4).RowHeight = 24

    With ws.Range("A6:F7")
        .Font.Size = 10
        .Font.Bold = False
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .WrapText = False
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(6).RowHeight = 16
    ws.Rows(7).RowHeight = 16

    With ws.Range("H1:J" & CStr(maxRow))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .Borders.LineStyle = xlNone
    End With
    ws.Range("H1:J1").Font.Bold = True
    ws.Range("H3:I4").Font.Bold = True
    ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0"
    ws.Range("I4").FormatConditions.Delete

    ' Breiten f�r eine saubere zweizeilige Kopfzeile ohne abgeschnittene Texte.
    ws.Columns("A").ColumnWidth = 12
    ws.Columns("B").ColumnWidth = 12
    ws.Columns("C").ColumnWidth = 12
    ws.Columns("D").ColumnWidth = 15.5
    ws.Columns("E").ColumnWidth = 12.5
    ws.Columns("F").ColumnWidth = 12.5
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 9
    ws.Columns("I").ColumnWidth = 9
    ws.Columns("J").ColumnWidth = 40

    ws.Columns("A:B").NumberFormat = "0"
    ws.Columns("C").NumberFormat = "dd.mm.yyyy"
    ws.Columns("D:F").NumberFormat = "#,##0;-#,##0"
    ws.Columns("H").NumberFormat = "0"
    ws.Range("A1:J" & CStr(maxRow)).WrapText = False

    With ws.PageSetup
        .Orientation = xlPortrait
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .CenterHorizontally = True
        .LeftMargin = xlApp.CentimetersToPoints(1.2)
        .RightMargin = xlApp.CentimetersToPoints(1.2)
        .TopMargin = xlApp.CentimetersToPoints(1)
        .BottomMargin = xlApp.CentimetersToPoints(1)
        .HeaderMargin = xlApp.CentimetersToPoints(0.4)
        .FooterMargin = xlApp.CentimetersToPoints(0.4)
        .PrintArea = "$A$1:$F$" & CStr(maxRow)
        .PrintGridlines = False
    End With

    On Error Resume Next
    ws.Activate
    xlApp.ActiveWindow.View = xlPageBreakPreview
    xlApp.ActiveWindow.Zoom = 58
    xlApp.ActiveWindow.DisplayGridlines = False
    Err.Clear
    On Error GoTo 0
End Sub

Sub FormatSection(ByVal ws, ByVal sectionRow, ByVal headerRow, _
                  ByVal dataStartRow, ByVal dataEndRow, ByVal subtotalRow)

    ' Abschnitts�berschrift: wei�, fett, zentriert und kr�ftig eingerahmt.
    With ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    ws.Rows(sectionRow).RowHeight = 19

    ' Technische Gegenpartei-Informationen rechts bleiben unformatiert.
    With ws.Range(ws.Cells(sectionRow, 8), ws.Cells(sectionRow, 10))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With

    ' Spaltenkopf ohne Farbfl�che oder Tabellenraster.
    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(headerRow).RowHeight = 31

    If dataEndRow >= dataStartRow Then
        With ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGBColor(0, 0, 0)
            .Font.Bold = False
            .Borders.LineStyle = xlNone
        End With

        ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(dataStartRow, 4), ws.Cells(dataEndRow, 6)).HorizontalAlignment = xlRight
        ws.Rows(CStr(dataStartRow) & ":" & CStr(dataEndRow)).RowHeight = 15
    End If

    ' Nur die Betrags-Zwischensumme erh�lt eine einfache obere Linie.
    With ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = True
        .Borders.LineStyle = xlNone
        .Borders(xlEdgeTop).LineStyle = xlContinuous
        .Borders(xlEdgeTop).Weight = xlThin
    End With
    ws.Rows(subtotalRow).RowHeight = 15
End Sub

Sub ValidateOverviewLayout(ByVal ws)
    Dim headerA
    Dim headerB
    Dim headerC
    Dim headerD

    headerA = NormalizeHeaderCell(ReadCellTextSafe(ws.Cells(2, 1)))
    headerB = NormalizeHeaderCell(ReadCellTextSafe(ws.Cells(2, 2)))
    headerC = NormalizeHeaderCell(ReadCellTextSafe(ws.Cells(2, 3)))
    headerD = NormalizeHeaderCell(ReadCellTextSafe(ws.Cells(2, 4)))

    WriteLog "INFO | Kopfzeilen: A2='" & HeaderForMessage(headerA) & _
             "' | B2='" & HeaderForMessage(headerB) & _
             "' | C2='" & HeaderForMessage(headerC) & _
             "' | D2='" & HeaderForMessage(headerD) & "'"

    If headerA <> "pnr neu" Then
        RaiseOverviewHeaderError headerA, headerB, headerC, headerD
    End If
    If headerB <> "ltrg neu" Then
        RaiseOverviewHeaderError headerA, headerB, headerC, headerD
    End If
    If headerC <> "pnr alt" Then
        RaiseOverviewHeaderError headerA, headerB, headerC, headerD
    End If
    If headerD <> "ltrg alt" Then
        RaiseOverviewHeaderError headerA, headerB, headerC, headerD
    End If
End Sub

Sub RaiseOverviewHeaderError(ByVal headerA, ByVal headerB, ByVal headerC, ByVal headerD)
    Dim actualHeaders

    actualHeaders = "A2='" & HeaderForMessage(headerA) & "', " & _
                    "B2='" & HeaderForMessage(headerB) & "', " & _
                    "C2='" & HeaderForMessage(headerC) & "', " & _
                    "D2='" & HeaderForMessage(headerD) & "'"

    Err.Raise -2147221504 + 2030, "ARE Generator", _
              "Die Spalten A bis D im Blatt '" & SHEET_OVERVIEW & _
              "' entsprechen nicht dem erwarteten Aufbau." & vbCrLf & _
              "Erwartet: PNR neu | Ltrg neu | PNR alt | Ltrg alt" & vbCrLf & _
              "Gefunden: " & actualHeaders
End Sub

Function NormalizeHeaderCell(ByVal cellText)
    Dim textValue

    textValue = SafeString(cellText)
    textValue = Replace(textValue, vbCr, " ")
    textValue = Replace(textValue, vbLf, " ")
    textValue = Trim(textValue)

    Do While InStr(1, textValue, "  ", 1) > 0
        textValue = Replace(textValue, "  ", " ")
    Loop

    NormalizeHeaderCell = LCase(textValue)
End Function

Function HeaderForMessage(ByVal value)
    If Len(SafeString(value)) = 0 Then
        HeaderForMessage = "<leer/Fehlerwert>"
    Else
        HeaderForMessage = SafeString(value)
    End If
End Function

Function ReadCellTextSafe(ByVal cell)
    Dim value

    ReadCellTextSafe = ""

    On Error Resume Next
    Err.Clear
    value = cell.Text
    If Err.Number <> 0 Then
        Err.Clear
        value = cell.Value2
    End If
    On Error GoTo 0

    ReadCellTextSafe = SafeString(value)
End Function

Function ReadCellValueSafe(ByVal cell)
    Dim value
    Dim valueType

    ReadCellValueSafe = Empty

    On Error Resume Next
    Err.Clear
    value = cell.Value2
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = VB_ERROR_TYPE Then Exit Function
    ReadCellValueSafe = value
End Function

Function CellHasContent(ByVal cell)
    Dim value
    Dim valueType

    CellHasContent = False
    value = ReadCellValueSafe(cell)

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    If valueType = 8 Then
        CellHasContent = (Len(Trim(SafeString(value))) > 0)
    Else
        CellHasContent = True
    End If
End Function

Function FindLastTransferRow(ByVal ws)
    Dim usedStart
    Dim usedCount
    Dim usedLast
    Dim rowNumber
    Dim columnNumber

    FindLastTransferRow = FIRST_DATA_ROW - 1

    On Error Resume Next
    Err.Clear
    usedStart = CLng(ws.UsedRange.Row)
    usedCount = CLng(ws.UsedRange.Rows.Count)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    usedLast = usedStart + usedCount - 1
    If usedLast < FIRST_DATA_ROW Then Exit Function

    For rowNumber = usedLast To FIRST_DATA_ROW Step -1
        For columnNumber = 1 To 4
            If CellHasContent(ws.Cells(rowNumber, columnNumber)) Then
                FindLastTransferRow = rowNumber
                Exit Function
            End If
        Next
    Next
End Function

Sub LoadTransferData(ByVal ws, ByVal lastRow, ByRef data)
    Dim rowCount
    Dim sourceRow
    Dim targetRow
    Dim columnNumber

    rowCount = lastRow - FIRST_DATA_ROW + 1
    If rowCount <= 0 Then
        Err.Raise -2147221504 + 2031, "ARE Generator", _
                  "Es konnten keine Datenzeilen eingelesen werden."
    End If

    ' VBScript-Arrays sind nullbasiert. Index 0 bleibt bewusst unbenutzt,
    ' damit die bestehende 1-basierte Fachlogik unver�ndert funktioniert.
    ReDim data(rowCount, 10)

    targetRow = 1
    For sourceRow = FIRST_DATA_ROW To lastRow
        For columnNumber = 1 To 10
            data(targetRow, columnNumber) = ReadCellValueSafe(ws.Cells(sourceRow, columnNumber))
        Next
        targetRow = targetRow + 1
    Next

    WriteLog "INFO | " & CStr(rowCount) & " Datenzeilen sicher eingelesen"
End Sub

Function FindLastCompanyRow(ByVal ws)
    Dim usedStart
    Dim usedCount
    Dim usedLast
    Dim rowNumber

    FindLastCompanyRow = 1

    On Error Resume Next
    Err.Clear
    usedStart = CLng(ws.UsedRange.Row)
    usedCount = CLng(ws.UsedRange.Rows.Count)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    usedLast = usedStart + usedCount - 1

    For rowNumber = usedLast To 2 Step -1
        If CellHasContent(ws.Cells(rowNumber, 4)) Or _
           CellHasContent(ws.Cells(rowNumber, 6)) Then
            FindLastCompanyRow = rowNumber
            Exit Function
        End If
    Next
End Function

Function GetWorksheetOrNothing(ByVal wb, ByVal sheetName)
    Dim ws
    Set ws = Nothing

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    Set GetWorksheetOrNothing = ws
End Function

Sub DeleteGeneratedSheets(ByVal wb)
    Dim i
    Dim sheetName

    For i = wb.Worksheets.Count To 1 Step -1
        sheetName = wb.Worksheets(i).Name
        If Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", 1) > 0 Then
            wb.Worksheets(i).Delete
        End If
    Next
End Sub

Function BuildSheetName(ByVal ltrg, ByVal areValue)
    BuildSheetName = SafeSheetName( _
        "ARE " & DisplayValue(areValue) & _
        " (LTRG " & FormatLtrg(ltrg) & ")" _
    )
End Function

Function UniqueSheetName(ByVal wb, ByVal requestedName)
    Dim baseName
    Dim candidate
    Dim suffix
    Dim counter

    baseName = SafeSheetName(requestedName)
    candidate = baseName
    counter = 2

    Do While WorksheetExists(wb, candidate)
        suffix = "_" & CStr(counter)
        candidate = Left(baseName, 31 - Len(suffix)) & suffix
        counter = counter + 1
    Loop

    UniqueSheetName = candidate
End Function

Function WorksheetExists(ByVal wb, ByVal sheetName)
    Dim ws
    Set ws = Nothing

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    WorksheetExists = Not (ws Is Nothing)
End Function

Function SafeSheetName(ByVal value)
    Dim forbidden
    Dim item

    forbidden = Array("\", "/", ":", "*", "?", "[", "]")

    For Each item In forbidden
        value = Replace(value, CStr(item), "-")
    Next

    value = Trim(value)
    If Len(value) = 0 Then value = "ARE-Auswertung"
    If Len(value) > 31 Then value = Left(value, 31)

    SafeSheetName = value
End Function

Function FormatLtrg(ByVal ltrg)
    Dim value
    value = CStr(ltrg)
    If Len(value) < 4 Then value = Right("0000" & value, 4)
    FormatLtrg = value
End Function

Function ShortCompanyName(ByVal fullName)
    Dim commaPosition

    fullName = Trim(fullName)
    commaPosition = InStr(1, fullName, ",", 1)

    If commaPosition > 0 Then
        ShortCompanyName = Trim(Left(fullName, commaPosition - 1))
    Else
        ShortCompanyName = fullName
    End If
End Function

Function DisplayValue(ByVal value)
    Dim textValue

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then
        DisplayValue = "n.v."
    Else
        DisplayValue = textValue
    End If
End Function

Function SafeString(ByVal value)
    Dim valueType

    SafeString = ""

    ' Wichtig: VBScript wertet OR-Ausdr�cke vollst�ndig aus. Bei einem
    ' Excel-Fehlerwert kann bereits IsNull(value) einen Type mismatch ausl�sen.
    ' Deshalb wird zuerst ausschlie�lich der Variant-Typ gepr�ft.
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function   ' Empty
    If valueType = 1 Then Exit Function   ' Null
    If valueType = VB_ERROR_TYPE Then Exit Function

    On Error Resume Next
    SafeString = CStr(value)
    If Err.Number <> 0 Then
        Err.Clear
        SafeString = ""
    End If
    On Error GoTo 0
End Function

Function IsVariantError(ByVal value)
    Dim valueType

    IsVariantError = False
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number = 0 Then
        IsVariantError = (valueType = VB_ERROR_TYPE)
    Else
        Err.Clear
        IsVariantError = True
    End If
    On Error GoTo 0
End Function

Function NzNumber(ByVal value)
    Dim valueType
    Dim textValue
    Dim convertedValue

    NzNumber = 0

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then Exit Function
    If Not IsNumeric(textValue) Then Exit Function

    On Error Resume Next
    convertedValue = CDbl(textValue)
    If Err.Number = 0 Then
        NzNumber = convertedValue
    Else
        Err.Clear
        NzNumber = 0
    End If
    On Error GoTo 0
End Function

Function TryGetLong(ByVal value, ByRef result)
    Dim valueType
    Dim textValue
    Dim convertedValue

    TryGetLong = False

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then Exit Function
    If Not IsNumeric(textValue) Then Exit Function

    On Error Resume Next
    convertedValue = CLng(CDbl(textValue))
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    result = convertedValue
    TryGetLong = True
End Function

Function RGBColor(ByVal redValue, ByVal greenValue, ByVal blueValue)
    RGBColor = CLng(redValue) + CLng(greenValue) * 256 + CLng(blueValue) * 65536
End Function

Function MaxLong(ByVal firstValue, ByVal secondValue)
    If CLng(firstValue) >= CLng(secondValue) Then
        MaxLong = CLng(firstValue)
    Else
        MaxLong = CLng(secondValue)
    End If
End Function

Sub ResetLog()
    Dim fso
    Dim file

    On Error Resume Next
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set file = fso.CreateTextFile(gLogPath, True, True)
    If Err.Number = 0 Then
        file.WriteLine "ARE Generator Diagnose"
        file.WriteLine "Version: " & TOOL_VERSION
        file.WriteLine "Start: " & CStr(Now)
        file.WriteLine String(72, "-")
        file.Close
    Else
        Err.Clear
    End If
    Set file = Nothing
    Set fso = Nothing
    On Error GoTo 0
End Sub

Sub WriteLog(ByVal message)
    Dim fso
    Dim file

    If Len(SafeString(gLogPath)) = 0 Then Exit Sub

    On Error Resume Next
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set file = fso.OpenTextFile(gLogPath, 8, True, -1)
    If Err.Number = 0 Then
        file.WriteLine CStr(Now) & " | " & SafeString(message)
        file.Close
    Else
        Err.Clear
    End If
    Set file = Nothing
    Set fso = Nothing
    On Error GoTo 0
End Sub

Function SafeDisplayPath(ByVal value)
    Dim textValue

    textValue = SafeString(value)
    If Len(textValue) = 0 Then
        SafeDisplayPath = "<Protokoll konnte nicht angelegt werden>"
    Else
        SafeDisplayPath = textValue
    End If
End Function

Function BuildOutputPath(ByVal fso, ByVal sourcePath, ByVal outputFolder)
    Dim folder
    Dim baseName
    Dim extension
    Dim candidate
    Dim stamp

    folder = CStr(outputFolder)
    baseName = fso.GetBaseName(sourcePath)
    extension = LCase(fso.GetExtensionName(sourcePath))

    candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung." & extension)

    If fso.FileExists(candidate) Then
        stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
                "_" & TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & TwoDigits(Second(Now))
        candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung_" & stamp & "." & extension)
    End If

    BuildOutputPath = candidate
End Function

Function BuildReportPeriod(ByVal baseName)
    Dim regex
    Dim matches
    Dim yearValue
    Dim previousYear

    BuildReportPeriod = "2024/25"
    Set regex = CreateObject("VBScript.RegExp")
    regex.Pattern = "(19|20)[0-9]{2}"
    regex.Global = False
    regex.IgnoreCase = True

    If regex.Test(SafeString(baseName)) Then
        Set matches = regex.Execute(SafeString(baseName))
        yearValue = CLng(matches(0).Value)
        previousYear = yearValue - 1
        BuildReportPeriod = CStr(previousYear) & "/" & Right(CStr(yearValue), 2)
    End If
End Function

Function TwoDigits(ByVal value)
    TwoDigits = Right("0" & CStr(value), 2)
End Function
