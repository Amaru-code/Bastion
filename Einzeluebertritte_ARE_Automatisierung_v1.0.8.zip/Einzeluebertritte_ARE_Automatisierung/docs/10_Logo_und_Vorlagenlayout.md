# Logo und Vorlagenlayout

## Automatische Logoübernahme

Das Tool öffnet die ausgewählte DOCX schreibgeschützt und sucht in dieser Reihenfolge:

1. Inline-Bilder in Kopfzeilen
2. Bild-Shapes in Kopfzeilen
3. Inline-Bilder im Hauptdokument
4. Bild-Shapes im Hauptdokument

Das erste gefundene Bild wird über die Office-Zwischenablage auf alle ARE-Blätter übertragen.

## PNG-/JPG-Fallback

Scheitert die automatische Übernahme, erscheint ein Dateidialog. Die ausgewählte Bilddatei wird mit festem Seitenverhältnis und definierter Höhe oben links eingefügt.

## Warum der native Word-Seriendruck verwendet wird

Die frühere Lösung öffnete die Vorlage je Person, ersetzte Felder und verkettete die Dokumentinhalte. Das war robust, konnte aber bei komplexen Vorlagen Abstände, Leerzeilen oder Abschnittslogik geringfügig verändern.

Version 1.0.8 verwendet bevorzugt Words eigene Seriendruckfunktion. Dadurch bleiben insbesondere diese Elemente näher an der Vorlage:

- Name und Anschrift
- leere Adresszeilen
- Kopf- und Fußzeilen
- Bilder und Logos
- Seiten- und Abschnittseinstellungen
- Position der Schlusszeile `Anlage`
