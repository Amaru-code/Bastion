# Fehlersuche

## Fehler 500 „Variable is undefined“

Dieser Fehler konnte in Version 1.0.1 auftreten, weil die VBA-Funktion `IsError(...)` im externen VBScript nicht verfügbar ist.

**Lösung:** Version 1.0.5 oder neuer verwenden. Dort werden Excel-Fehlerwerte über `VarType(value) = 10` erkannt. Der Wert `10` entspricht dem Variant-Untertyp `vbError`.

Ab Version 1.0.5 nennt die Fehlermeldung zusätzlich die aktuelle `Phase`, damit die Fehlerstelle leichter eingegrenzt werden kann.

## „Das Blatt Übersicht wurde nicht gefunden“

Der Blattname muss exakt `Übersicht` lauten. Auch zusätzliche Leerzeichen im Namen führen zu einem Fehler.

## „Das Blatt Gesellschaften wurde nicht gefunden“

Der Stammdatenbereich muss in einem Blatt mit dem exakten Namen `Gesellschaften` liegen.

## „Die Spalten A bis D entsprechen nicht dem erwarteten Aufbau“

Prüfen Sie Zeile 2 im Blatt `Übersicht`:

```text
PNR neu | Ltrg neu | PNR alt | Ltrg alt
```

## „Für folgende LTRG fehlt eine Zuordnung“

Mindestens eine LTRG aus `Übersicht` ist im Blatt `Gesellschaften` nicht mit einem Namen in Spalte F hinterlegt. Die fehlenden LTRG werden in der Meldung genannt.

## Die VBS-Datei startet nicht

Mögliche Ursachen:

- Windows Script Host ist durch die Unternehmensrichtlinie deaktiviert.
- Excel Desktop ist nicht installiert.
- Die ZIP-Datei wurde nicht vollständig entpackt.
- Sicherheitssoftware blockiert `.vbs`-Dateien.

In diesem Fall kann alternativ das VBA-Modul aus dem Ordner `macro` direkt in Excel importiert werden.

## Die Ausgabedatei kann nicht gespeichert werden

Prüfen Sie:

- Schreibrechte im entpackten Projektordner beziehungsweise im Ordner `Output`
- ob die Datei bereits exklusiv geöffnet ist
- ob der Pfad zu lang ist
- ob OneDrive oder ein Netzlaufwerk gerade synchronisiert bzw. nicht erreichbar ist

## CHECK in I4 ist nicht 0

Dann stimmen die erzeugten Abschnittssummen nicht mit dem Nettosaldo aus `Übersicht` überein. Prüfen Sie insbesondere:

- nicht numerische LTRG
- fehlende oder ungewöhnliche Betragswerte
- nachträgliche Änderungen nach der Generierung
- manuell veränderte Detailzeilen oder Summenformeln

## Excel bleibt nach einem Fehler geöffnet

Das Skript versucht Excel bei einem Fehler zu schließen. Falls Excel oder ein Dialog nicht reagiert, schließen Sie die betroffene Excel-Instanz manuell und starten Sie das Skript erneut.

## Fehler 13 „Type mismatch“ bei „Quellblätter prüfen“

Version 1.0.5 ersetzt den gesamten bisher zusammengefassten Prüfschritt. Die Ursache konnte nicht nur in der Überschriftenprüfung liegen, sondern auch in der Excel-COM-Übergabe der letzten Zeile oder des kompletten Datenbereichs.

Die aktuelle Version:

- liest `Übersicht!A2:D2` einzeln und typgesichert,
- bestimmt die letzte Übertrittszeile ohne verschachtelte `CLng`-/`End(xlUp)`-Ausdrücke,
- übernimmt `Übersicht!A3:J...` Zelle für Zelle,
- behandelt Excel-Fehlerwerte kontrolliert als leer,
- schreibt die genaue Unterphase in `ARE_Generator_Diagnose.log`.

Das Protokoll liegt direkt neben `ARE_Generator_starten.vbs`. Bei einem neuen Fehler bitte die letzten Zeilen dieses Protokolls zusammen mit der Fehlermeldung bereitstellen.

Erwartete Überschriften:

```text
PNR neu | Ltrg neu | PNR alt | Ltrg alt
```

## Fehler 1004 beim Erstellen eines ARE-Blatts

**Meldung:** „Die Add-Eigenschaft des Sheets-Objektes kann nicht zugeordnet werden.“

Dieser Fehler wurde bis Version 1.0.4 durch den VBScript-/COM-Aufruf `Worksheets.Add(Empty, ...)` ausgelöst. Version 1.0.5 verwendet keine `Empty`-Platzhalter mehr, sondern erstellt das Blatt zunächst parameterlos.

Falls der Fehler in Version 1.0.5 weiterhin auftritt, prüfen Sie in Excel unter **Überprüfen → Arbeitsmappe schützen**, ob die **Struktur** der Arbeitsmappe geschützt ist. Das Erstellen und Löschen von Blättern ist bei aktivem Strukturschutz technisch nicht möglich.


## Microsoft Word konnte nicht gestartet werden

Microsoft Word Desktop muss installiert sein. Word Online oder ein Viewer reicht nicht.

## Keine MERGEFIELD-Felder gefunden

Sichtbare Platzhalter wie `{Vorname}` oder `<<Vorname>>` sind keine echten Word-Felder.

In Word:

1. `Sendungen` öffnen.
2. `Seriendruckfeld einfügen` wählen.
3. Felder mit Namen der Excel-Kopfzeilen einfügen.
4. Vorlage als `.docx` speichern.

## Serienbrieffeld bleibt leer

Prüfen:

- Feldname passt zur Excel-Kopfzeile
- Kopfzeile steht in Zeile 1
- Wert steht im ersten Arbeitsblatt
- Datenzeile ist nicht leer

Nicht zugeordnete Felder stehen als Warnung im Diagnoseprotokoll.

## PDF kann nicht gespeichert werden

Prüfen:

- Schreibrechte
- Datei nicht in einem anderen Programm gesperrt
- Pfadlänge
- freier Speicherplatz
- Excel oder Word nicht durch einen Dialog blockiert


## Mercer-Logo wird nicht aus der DOCX übernommen

Das Tool sucht zuerst in den Kopfzeilen der DOCX nach einem Bild und danach im Hauptdokument. Wird kein Bild erkannt oder kann die Zwischenablage nicht verwendet werden, öffnet sich automatisch ein Dialog für PNG/JPG.

Empfehlung für den Fallback:

- transparente PNG-Datei
- ausreichend hohe Auflösung
- nur das Mercer-Logo ohne großen weißen Rand

## Serienbrief weicht von der Vorlage ab

Version 1.0.8 verwendet zuerst den nativen Word-Seriendruck. Im Diagnoseprotokoll sollte stehen:

```text
SERIENBRIEF-MODUS | Nativer Microsoft-Word-Seriendruck
```

Steht dort stattdessen eine Warnung zum Fallback, konnte Word die temporäre Excel-Datenquelle nicht nativ verbinden. Die Ausgabe wird dann mit dem kompatiblen bisherigen Feldmodus erstellt.

## `Anlage` steht weiterhin auf Seite 2

Das Tool entfernt vor und nach Absätzen, die mit `Anlage` beginnen, zusätzlichen Absatzabstand. Passt der Brief dennoch nicht auf eine Seite, enthält die Vorlage oder ein eingesetzter Datenwert mehr Inhalt als die Idealversion. In diesem Fall sind insbesondere lange Namens-/Adressfelder und zusätzliche Leerzeilen in der DOCX zu prüfen.
