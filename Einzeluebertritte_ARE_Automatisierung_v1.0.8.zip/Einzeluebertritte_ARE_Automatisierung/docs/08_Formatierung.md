# Formatierung der ARE-Blätter

## Berichtskopf

- Portraitformat
- Mercer-Logo oben links
- rechts oben `Einzelübertritte <Zeitraum>`
- darunter `ARE <ARE> (LTRG <LTRG>)`
- Haupttitel zentriert und fett
- Beschreibungstext mit Abstand unter dem Haupttitel

## Tabellenbereich A:F

- Arial, 10 pt
- Abschnittsüberschriften fett, zentriert und kräftig eingerahmt
- Tabellenköpfe immer fett und zweizeilig
- Detailzeilen normal
- Beträge D:F rechtsbündig
- Zwischensummen immer fett mit oberer Trennlinie
- negative Beträge schwarz

## Kontrollbereich H:J

- Kontrollüberschriften und Kontrollsummen fett
- keine Farbfüllung und keine Rahmen
- außerhalb des Druckbereichs

## Druck und PDF

- Druckbereich A:F
- Portraitformat
- horizontal zentriert
- eine Seite breit
- beliebig viele Seiten hoch
- keine Gitternetzlinien im PDF
- Dateiname `ERG_VWÜ_{sheet_name}.pdf`
