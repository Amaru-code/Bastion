# Bedienung

## VBS-Workflow

1. ZIP vollständig entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. ARE-Quelldatei mit `Übersicht` und `Gesellschaften` auswählen.
4. DOCX-Serienbriefvorlage auswählen.
5. Excel-Datei mit Personendaten auswählen.
6. Erfolgsmeldung abwarten.
7. Den automatisch angelegten Ordner `Output` prüfen.

Wird ein Auswahldialog abgebrochen, beendet sich das Tool ohne Verarbeitung.

## Output-Ordner

```text
Output/
└── <Name der Quelle>_ARE_Export_<Zeitstempel>/
    ├── 00_Excel/
    ├── 01_ARE_PDF/
    ├── 02_Serienbrief_Gesamt/
    └── 03_Serienbrief_Einzel/
```

### ARE-Ausgabedatei

```text
00_Excel/<Name der Quelle>_ARE_Auswertung.xlsm
oder
00_Excel/<Name der Quelle>_ARE_Auswertung.xlsx
```

### ARE-PDFs

```text
01_ARE_PDF/ERG_VWÜ_<Name des ARE-Blatts>.pdf
```

### Gesamtserienbrief

```text
02_Serienbrief_Gesamt/Anschreiben_ARE_Gesamt.docx
02_Serienbrief_Gesamt/Anschreiben_ARE_Gesamt.pdf
```

### Einzelanschreiben

```text
03_Serienbrief_Einzel/Anschrieben_ARE_<Wert aus Spalte B>_LTRG_<Wert aus Spalte A>.pdf
```

Die Schreibweise `Anschrieben` wird entsprechend der vorgegebenen Dateinamenskonvention verwendet.

## Logoauswahl

Normalerweise ist keine zusätzliche Logo-Datei nötig. Das Tool kopiert das Mercer-Logo aus der DOCX-Vorlage. Nur wenn dort kein Bild erkannt wird, erscheint eine weitere Auswahl für PNG/JPG.

## Sicherheitsverhalten

- ARE-Quelle wird schreibgeschützt geöffnet und kopiert.
- Personendatei wird schreibgeschützt geöffnet.
- DOCX-Vorlage wird schreibgeschützt geöffnet.
- Ergebnisse liegen ausschließlich im Projektordner `Output`.
- Ungültige Windows-Dateinamenszeichen werden ersetzt.

## Direkte VBA-Nutzung

Das Modul bietet:

- `Erstelle_ARE_Blaetter`
- `Loesche_ARE_Blaetter`
- `Exportiere_ARE_Blaetter_Als_PDF`

Logoübernahme und Serienbrief werden ausschließlich vom VBS-Starter ausgeführt, weil Excel und Word gemeinsam automatisiert werden.
