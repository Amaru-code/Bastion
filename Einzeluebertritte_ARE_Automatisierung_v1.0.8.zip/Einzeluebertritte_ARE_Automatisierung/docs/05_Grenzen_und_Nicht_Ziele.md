# Grenzen und Nicht-Ziele

## Serienbrief

Die Vorlage muss direkte Word-Seriendruckfelder vom Typ `MERGEFIELD` enthalten.

Der native Word-Seriendruck unterstützt das Vorlagenlayout wesentlich vollständiger als die frühere manuelle Verkettung. Dennoch gilt:

- Das erste Arbeitsblatt der Personendatei wird verwendet.
- Spalte A und B bestimmen weiterhin die Einzeldateinamen.
- Mehrere Vorlagen in einem Lauf sind nicht vorgesehen.
- E-Mail-Versand ist nicht enthalten.
- Fachlich falsche oder widersprüchliche Adressdaten werden nicht automatisch korrigiert.

## Logo

Das erste geeignete Bild in der DOCX-Kopfzeile wird als Logo interpretiert. Enthält die Vorlage mehrere Bilder vor dem Mercer-Logo, sollte stattdessen beim Fallback-Dialog eine eindeutige PNG-/JPG-Datei gewählt werden.

## PDF-Ausgabe

ARE-PDFs verwenden Portraitformat und den Druckbereich A:F. Berichte, die trotz Skalierung nicht auf eine Seite passen, bleiben mehrseitig.

## Quelldateien

ARE-Quelle, Personendatei und DOCX-Vorlage werden nicht verändert.
