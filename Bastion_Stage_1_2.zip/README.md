# Bastion – Stage 1.2

Lokaler JavaScript-Prototyp eines schnellen Strategie- und Eroberungsspiels.

## Start

1. ZIP vollständig entpacken.
2. `Start_Game.bat` doppelklicken.
3. Alternativ `Start_Game.ps1` oder `index.html` öffnen.

Keine Installation, kein Node.js und kein lokaler Server erforderlich.

## Steuerung

- Eigenes Gebäude anklicken.
- 25 %, 50 % oder 75 % mobilisieren.
- Zielgebäude oder freien Boden anklicken.
- Ein eigenes Feldheer anklicken und mit „Ausgewähltes Heer bewegen“ erneut befehligen.
- Erneuter Klick, leere Karte, Rechtsklick, Escape oder „Abbrechen“ hebt die Auswahl auf.
- Eigene Gebäude können für 15 Gold verbessert werden.

## Stage 1.2

- freie Bewegung ohne vorgegebene Straßen
- automatische Umgehung von Gebäuden
- auswählbare Feldarmeen
- globale Versorgungsgrenze statt unendlicher Soldaten
- Farmen erhöhen das Armeelimit
- aktive KI mit Expansion, Angriffen, Upgrades und Forschung
- sichtbare Jahreszeitenboni und Produktionsraten
- zufällige Forschungsauswahl
- Speichern und Laden im Browser
