from __future__ import annotations

import json
import math
import os
import re
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

from collections import defaultdict

from openpyxl import Workbook, load_workbook
import pythoncom
import win32com.client as win32


def norm(value: Any) -> str:
    if value is None or (isinstance(value, float) and math.isnan(value)):
        return ""
    s = str(value).strip().replace("\u00a0", " ")
    s = re.sub(r"\s+", " ", s)
    return s.casefold()


def excel_col_to_num(col: str) -> int:
    n = 0
    for c in col.upper():
        n = n * 26 + ord(c) - 64
    return n


def num_to_excel_col(n: int) -> str:
    out = ""
    while n:
        n, r = divmod(n - 1, 26)
        out = chr(65 + r) + out
    return out


def parse_block(block: str) -> tuple[int, int]:
    a, b = block.split(":")
    return excel_col_to_num(a), excel_col_to_num(b)


def resolve_column(columns: Iterable[str], aliases: list[str]) -> str:
    lookup = {norm(c): c for c in columns}
    for alias in aliases:
        if norm(alias) in lookup:
            return lookup[norm(alias)]
    raise KeyError(f"Keine passende Spalte gefunden. Gesucht: {aliases}; vorhanden: {list(columns)}")


def parse_number(value: Any) -> float:
    if value in (None, ""):
        return 0.0
    if isinstance(value, (int, float)):
        return 0.0 if isinstance(value, float) and math.isnan(value) else float(value)
    text = str(value).strip().replace("\u00a0", "").replace(" ", "")
    if not text:
        return 0.0
    # Deutsche und internationale Zahlenformate robust behandeln.
    if "," in text and "." in text:
        if text.rfind(",") > text.rfind("."):
            text = text.replace(".", "").replace(",", ".")
        else:
            text = text.replace(",", "")
    elif "," in text:
        text = text.replace(".", "").replace(",", ".")
    text = re.sub(r"[^0-9+\-.]", "", text)
    try:
        return float(text)
    except (TypeError, ValueError):
        return 0.0


def write_xlsx(path: Path, headers: list[str], rows: list[list[Any]] | list[dict[str, Any]]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Report"
    ws.append(headers)
    for row in rows:
        if isinstance(row, dict):
            ws.append([row.get(h) for h in headers])
        else:
            ws.append(list(row))
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions
    for column_cells in ws.columns:
        max_len = min(max((len(str(c.value)) if c.value is not None else 0) for c in column_cells), 80)
        ws.column_dimensions[column_cells[0].column_letter].width = max(10, max_len + 2)
    wb.save(path)


@dataclass
class SheetLayout:
    header_row: int
    data_start_row: int
    last_row: int
    wwid_col: int
    headers: dict[int, str]


class ExcelSession:
    def __init__(self, visible: bool = False):
        pythoncom.CoInitialize()
        self.excel = win32.DispatchEx("Excel.Application")
        self.excel.Visible = visible
        self.excel.DisplayAlerts = False
        self.excel.AskToUpdateLinks = False
        self.excel.EnableEvents = False

    def close(self):
        try:
            self.excel.Quit()
        finally:
            pythoncom.CoUninitialize()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()


def find_layout(ws, aliases: list[str], scan_rows: int) -> SheetLayout:
    used = ws.UsedRange
    first_row = used.Row
    first_col = used.Column
    last_row = first_row + used.Rows.Count - 1
    last_col = first_col + used.Columns.Count - 1
    alias_set = {norm(x) for x in aliases}

    for r in range(first_row, min(last_row, scan_rows) + 1):
        headers: dict[int, str] = {}
        wwid_col = None
        for c in range(first_col, last_col + 1):
            val = ws.Cells(r, c).Value
            if val not in (None, ""):
                headers[c] = str(val).strip()
                if norm(val) in alias_set:
                    wwid_col = c
        if wwid_col:
            return SheetLayout(r, r + 1, last_row, wwid_col, headers)
    raise RuntimeError(f"WWID-Überschrift in den ersten {scan_rows} Zeilen nicht gefunden.")


def read_du(path: str, cfg: dict[str, Any]) -> tuple[list[dict[str, Any]], dict[str, str]]:
    wb = load_workbook(path, read_only=True, data_only=True)
    last_error: Exception | None = None
    try:
        for ws in wb.worksheets:
            try:
                rows = ws.iter_rows(values_only=True)
                header_values = next(rows, None)
                if not header_values:
                    continue
                headers = [str(v).strip() if v is not None else "" for v in header_values]
                cols = cfg["du_columns"]
                resolved = {key: resolve_column(headers, aliases) for key, aliases in cols.items()}
                index = {name: headers.index(name) for name in resolved.values()}
                records: list[dict[str, Any]] = []
                for values in rows:
                    if not values or all(v in (None, "") for v in values):
                        continue
                    record = {}
                    for key, name in resolved.items():
                        pos = index[name]
                        record[name] = values[pos] if pos < len(values) else None
                    wwid_name = resolved["wwid"]
                    raw_wwid = record.get(wwid_name)
                    if isinstance(raw_wwid, float) and raw_wwid.is_integer():
                        raw_wwid = int(raw_wwid)
                    record[wwid_name] = str(raw_wwid or "").strip().removesuffix(".0")
                    record[resolved["units"]] = parse_number(record.get(resolved["units"]))
                    record[resolved["value"]] = parse_number(record.get(resolved["value"]))
                    records.append(record)
                return records, resolved
            except Exception as exc:
                last_error = exc
    finally:
        wb.close()
    raise RuntimeError(f"Kein DU-Blatt mit allen benötigten Spalten gefunden: {last_error}")


def build_aggregates(records: list[dict[str, Any]], col: dict[str, str], cfg: dict[str, Any]):
    all_movements: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: {col["units"]: 0.0, col["value"]: 0.0})
    realloc: dict[tuple[str, str], dict[str, float]] = defaultdict(lambda: {col["units"]: 0.0, col["value"]: 0.0})
    expected_tx = norm(cfg["reallocation_transaction_type"])
    for row in records:
        key = (str(row.get(col["wwid"], "")).strip(), norm(row.get(col["fund"])))
        if not key[0] or not key[1]:
            continue
        all_movements[key][col["units"]] += parse_number(row.get(col["units"]))
        all_movements[key][col["value"]] += parse_number(row.get(col["value"]))
        if norm(row.get(col["transaction_type"])) == expected_tx:
            realloc[key][col["units"]] += parse_number(row.get(col["units"]))
            realloc[key][col["value"]] += parse_number(row.get(col["value"]))
    return all_movements, realloc


def cell_value(ws, row: int, col: int):
    return ws.Cells(row, col).Value


def write_cell(ws, row: int, col: int, value: Any, preserve_formula: bool):
    cell = ws.Cells(row, col)
    if preserve_formula and bool(cell.HasFormula):
        return False
    cell.Value = value
    return True


def infer_fund_from_header(header: str) -> str:
    h = str(header or "")
    # Entfernt typische Kennzahlwörter, damit der Fondsname übrig bleibt.
    h = re.sub(r"(?i)\b(anfang|start|ende|endbestand|bestand|stichtag|anteile|stücke|stuecke|wert|betrag|eur)\b", " ", h)
    h = re.sub(r"\s+", " ", h).strip(" -_/:")
    return norm(h)


def compare_workbooks(excel, generated: str, target: str, sheet_name: str, output_dir: Path) -> dict[str, Any]:
    wb_g = excel.Workbooks.Open(os.path.abspath(generated), UpdateLinks=0, ReadOnly=True)
    wb_t = excel.Workbooks.Open(os.path.abspath(target), UpdateLinks=0, ReadOnly=True)
    try:
        ws_g, ws_t = wb_g.Worksheets(sheet_name), wb_t.Worksheets(sheet_name)
        rows = max(ws_g.UsedRange.Rows.Count + ws_g.UsedRange.Row - 1, ws_t.UsedRange.Rows.Count + ws_t.UsedRange.Row - 1)
        cols = max(ws_g.UsedRange.Columns.Count + ws_g.UsedRange.Column - 1, ws_t.UsedRange.Columns.Count + ws_t.UsedRange.Column - 1)
        differences = []
        block_stats: dict[str, dict[str, int]] = {}
        for r in range(1, rows + 1):
            for c in range(1, cols + 1):
                a, b = ws_g.Cells(r, c).Value, ws_t.Cells(r, c).Value
                equal = False
                if a in (None, "") and b in (None, ""):
                    equal = True
                elif isinstance(a, (int, float)) and isinstance(b, (int, float)):
                    equal = abs(float(a) - float(b)) <= max(1e-8, abs(float(b)) * 1e-8)
                else:
                    equal = str(a).strip() == str(b).strip()
                if not equal:
                    col_letter = num_to_excel_col(c)
                    differences.append({"cell": f"{col_letter}{r}", "row": r, "column": col_letter, "generated": a, "target": b})
        write_xlsx(output_dir / "comparison_differences.xlsx", ["cell", "row", "column", "generated", "target"], differences)
        return {"different_cells": len(differences), "rows_checked": rows, "columns_checked": cols}
    finally:
        wb_g.Close(False)
        wb_t.Close(False)


def run(config_path: str, log=print) -> dict[str, Any]:
    cfg = json.loads(Path(config_path).read_text(encoding="utf-8"))
    paths = cfg["paths"]
    for key in ("old_template", "du_file"):
        if not Path(paths[key]).exists():
            raise FileNotFoundError(f"Datei fehlt: {paths[key]}")

    output = Path(paths["output"])
    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(paths["old_template"], output)
    report_dir = output.parent / f"{output.stem}_report"
    report_dir.mkdir(exist_ok=True)

    log("DU-Datei lesen und aggregieren …")
    du, du_cols = read_du(paths["du_file"], cfg)
    all_movements, realloc = build_aggregates(du, du_cols, cfg)

    audit_rows = []
    with ExcelSession(visible=False) as session:
        log("Template über Microsoft Excel öffnen …")
        wb = session.excel.Workbooks.Open(os.path.abspath(output), UpdateLinks=0, ReadOnly=False)
        try:
            ws = wb.Worksheets(cfg["sheet"])
            layout = find_layout(ws, cfg["wwid_aliases"], cfg["header_scan_rows"])
            log(f"Kopfzeile {layout.header_row}, WWID-Spalte {num_to_excel_col(layout.wwid_col)} erkannt.")
            opening_a, opening_b = parse_block(cfg["blocks"]["opening"])
            closing_a, closing_b = parse_block(cfg["blocks"]["closing"])
            preserve = cfg["behavior"]["preserve_existing_formulas"]

            # 1) Vorjahresendwerte -> neue Startwerte, positionsgleich innerhalb der 10-Spalten-Blöcke.
            if cfg["behavior"]["copy_prior_closing_to_opening"]:
                width = min(opening_b - opening_a, closing_b - closing_a) + 1
                for r in range(layout.data_start_row, layout.last_row + 1):
                    wwid = cell_value(ws, r, layout.wwid_col)
                    if wwid in (None, ""):
                        continue
                    for off in range(width):
                        value = cell_value(ws, r, closing_a + off)
                        wrote = write_cell(ws, r, opening_a + off, value, preserve_formula=False)
                        if wrote:
                            audit_rows.append([str(wwid), f"{num_to_excel_col(opening_a+off)}{r}", "Vorjahresübertrag", value, f"{num_to_excel_col(closing_a+off)}{r}"])

            # 2) BI:BN aus gesicherten DU-Regeln.
            if cfg["behavior"]["calculate_reallocation"]:
                for r in range(layout.data_start_row, layout.last_row + 1):
                    raw_wwid = cell_value(ws, r, layout.wwid_col)
                    if raw_wwid in (None, ""):
                        continue
                    wwid = str(raw_wwid).strip().replace(".0", "")
                    for rule in cfg["known_reallocation"]:
                        key = (wwid, norm(rule["fund"]))
                        units = float(realloc[key][du_cols["units"]]) if key in realloc else 0.0
                        value = float(realloc[key][du_cols["value"]]) if key in realloc else 0.0
                        for col_letter, val, metric in ((rule["units_column"], units, "Umschichtung Anteile"), (rule["value_column"], value, "Umschichtung Wert")):
                            c = excel_col_to_num(col_letter)
                            if write_cell(ws, r, c, val, preserve):
                                audit_rows.append([wwid, f"{col_letter}{r}", metric, val, f"DU | {rule['fund']} | {cfg['reallocation_transaction_type']}"])

            # 3) Kandidatenlogik CL:CU = AJ:AS + sämtliche signierten DU-Bewegungen je aus Header erkanntem Fonds.
            if cfg["behavior"]["calculate_candidate_closing"]:
                width = min(opening_b - opening_a, closing_b - closing_a) + 1
                for r in range(layout.data_start_row, layout.last_row + 1):
                    raw_wwid = cell_value(ws, r, layout.wwid_col)
                    if raw_wwid in (None, ""):
                        continue
                    wwid = str(raw_wwid).strip().replace(".0", "")
                    for off in range(width):
                        start_col, end_col = opening_a + off, closing_a + off
                        start = cell_value(ws, r, start_col)
                        start_num = float(start) if isinstance(start, (int, float)) else 0.0
                        header = layout.headers.get(end_col) or layout.headers.get(start_col) or ""
                        fund_key = infer_fund_from_header(header)
                        metric_is_value = bool(re.search(r"(?i)(wert|betrag|eur)", str(header)))
                        metric_col = du_cols["value"] if metric_is_value else du_cols["units"]
                        movement = 0.0
                        if fund_key and (wwid, fund_key) in all_movements:
                            movement = float(all_movements[(wwid, fund_key)][metric_col])
                        candidate = start_num + movement
                        if write_cell(ws, r, end_col, candidate, preserve):
                            audit_rows.append([wwid, f"{num_to_excel_col(end_col)}{r}", "Kandidat Endbestand", candidate, f"Start {num_to_excel_col(start_col)}{r} + DU {header}"])

            wb.Save()
        finally:
            wb.Close(SaveChanges=True)

        comparison = None
        target = paths.get("comparison_target")
        if target and Path(target).exists():
            log("Erzeugte Datei gegen Vergleichsziel prüfen …")
            comparison = compare_workbooks(session.excel, str(output), target, cfg["sheet"], report_dir)

    write_xlsx(report_dir / "audit_trail.xlsx", ["WWID", "Zelle", "Regel", "Wert", "Herleitung"], audit_rows)
    summary = {
        "output": str(output),
        "report_dir": str(report_dir),
        "du_rows": len(du),
        "comparison": comparison,
        "status": "completed"
    }
    (report_dir / "run_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary
