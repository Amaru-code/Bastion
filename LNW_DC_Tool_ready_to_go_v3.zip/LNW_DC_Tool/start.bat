@echo off
setlocal
cd /d "%~dp0"
if not exist runtime\Scripts\python.exe (echo Bitte zuerst install.bat ausfuehren. & pause & exit /b 1)
runtime\Scripts\python.exe app.py
if errorlevel 1 pause
