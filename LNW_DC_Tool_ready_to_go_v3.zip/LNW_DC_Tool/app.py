from __future__ import annotations

import json
import queue
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from lnw_engine import run

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Intel LNW DC Generator")
        self.geometry("920x650")
        self.minsize(820, 580)
        self.q: queue.Queue = queue.Queue()
        self.cfg = json.loads(CONFIG.read_text(encoding="utf-8"))
        self.vars = {k: tk.StringVar(value=v) for k, v in self.cfg["paths"].items()}
        self._build()
        self.after(150, self._poll)

    def _build(self):
        top = ttk.Frame(self, padding=18)
        top.pack(fill="both", expand=True)
        ttk.Label(top, text="Intel LNW DC Generator", font=("Segoe UI", 18, "bold")).pack(anchor="w")
        ttk.Label(top, text="Erzeugt eine neue makrofähige LNW-Datei und dokumentiert jede Befüllungsregel.").pack(anchor="w", pady=(2, 18))

        labels = {
            "old_template": "Altes LNW-Template (.xlsm)",
            "du_file": "DU-Bewegungsdatei (.xlsx)",
            "comparison_target": "Vergleichszieldatei (.xlsm, optional)",
            "output": "Neue Ausgabedatei (.xlsm)"
        }
        for key, label in labels.items():
            row = ttk.Frame(top)
            row.pack(fill="x", pady=6)
            ttk.Label(row, text=label, width=35).pack(side="left")
            ttk.Entry(row, textvariable=self.vars[key]).pack(side="left", fill="x", expand=True, padx=8)
            ttk.Button(row, text="Auswählen", command=lambda k=key: self._pick(k)).pack(side="right")

        options = ttk.LabelFrame(top, text="Ablauf", padding=10)
        options.pack(fill="x", pady=(16, 10))
        ttk.Label(options, text="1. Makro-Template kopieren  →  2. AJ:AS aus CL:CU übernehmen  →  3. BI:BN aus DU aggregieren  →  4. CL:CU-Kandidaten bilden  →  5. Soll-Ist-Bericht").pack(anchor="w")

        self.run_btn = ttk.Button(top, text="LNW-Datei erzeugen", command=self._start)
        self.run_btn.pack(anchor="w", pady=10)
        self.progress = ttk.Progressbar(top, mode="indeterminate")
        self.progress.pack(fill="x")
        self.log = tk.Text(top, height=18, wrap="word", font=("Consolas", 10))
        self.log.pack(fill="both", expand=True, pady=(10, 0))

    def _pick(self, key: str):
        if key == "output":
            p = filedialog.asksaveasfilename(defaultextension=".xlsm", filetypes=[("Excel Macro Workbook", "*.xlsm")])
        else:
            p = filedialog.askopenfilename(filetypes=[("Excel", "*.xlsm *.xlsx"), ("Alle Dateien", "*.*")])
        if p:
            self.vars[key].set(p)

    def _start(self):
        for k, var in self.vars.items():
            self.cfg["paths"][k] = var.get().strip()
        CONFIG.write_text(json.dumps(self.cfg, ensure_ascii=False, indent=2), encoding="utf-8")
        self.log.delete("1.0", "end")
        self.run_btn.configure(state="disabled")
        self.progress.start(12)
        threading.Thread(target=self._worker, daemon=True).start()

    def _worker(self):
        try:
            result = run(str(CONFIG), log=lambda m: self.q.put(("log", m)))
            self.q.put(("done", result))
        except Exception as exc:
            self.q.put(("error", str(exc)))

    def _poll(self):
        try:
            while True:
                typ, payload = self.q.get_nowait()
                if typ == "log":
                    self.log.insert("end", payload + "\n")
                    self.log.see("end")
                elif typ == "done":
                    self.progress.stop(); self.run_btn.configure(state="normal")
                    self.log.insert("end", f"\nFERTIG: {payload['output']}\nBerichte: {payload['report_dir']}\n")
                    messagebox.showinfo("Fertig", "LNW-Datei und Prüfberichte wurden erzeugt.")
                elif typ == "error":
                    self.progress.stop(); self.run_btn.configure(state="normal")
                    self.log.insert("end", "\nFEHLER: " + payload + "\n")
                    messagebox.showerror("Fehler", payload)
        except queue.Empty:
            pass
        self.after(150, self._poll)


if __name__ == "__main__":
    App().mainloop()
