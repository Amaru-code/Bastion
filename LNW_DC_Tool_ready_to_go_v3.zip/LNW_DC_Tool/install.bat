@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title Intel LNW DC Tool - Installation

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PIP_CONFIG_FILE=NUL"
set "PIP_REQUIRE_HASHES=0"
set "PIP_CONSTRAINT="
set "PIP_INDEX_URL="
set "PIP_EXTRA_INDEX_URL="
set "PYTHON_CMD="

for %%V in (3.13 3.12 3.11) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 set "PYTHON_CMD=python"
)

if not defined PYTHON_CMD (
    echo ============================================================
    echo FEHLER: Python 3.11, 3.12 oder 3.13 wurde nicht gefunden.
    echo ============================================================
    pause
    exit /b 1
)

echo ============================================================
echo  Intel LNW DC Tool - Installation v3
 echo ============================================================
echo Verwende: %PYTHON_CMD%
%PYTHON_CMD% -c "import sys,platform; print('Python:', sys.version); print('Architektur:', platform.architecture()[0])"
if errorlevel 1 goto :failed

if exist runtime rmdir /s /q runtime
%PYTHON_CMD% -m venv runtime
if errorlevel 1 goto :failed

set "VENV_PY=%CD%\runtime\Scripts\python.exe"

REM Kein pandas mehr: dadurch wird der auf diesem Rechner defekte pandas-CDN-Cache umgangen.
echo.
echo Installiere openpyxl und pywin32 ...
"%VENV_PY%" -m pip --isolated install --disable-pip-version-check --no-cache-dir --index-url https://pypi.org/simple openpyxl==3.1.5 pywin32==310
if errorlevel 1 goto :fallback

goto :verify

:fallback
echo.
echo Standardinstallation fehlgeschlagen. Versuche feste Alternativversionen ...
"%VENV_PY%" -m pip --isolated install --disable-pip-version-check --no-cache-dir --index-url https://pypi.org/simple openpyxl==3.1.4 pywin32==308
if errorlevel 1 goto :failed

:verify
echo.
echo Pruefe Installation ...
"%VENV_PY%" -c "import openpyxl, pythoncom, win32com.client; print('Pakete erfolgreich geladen.')"
if errorlevel 1 goto :failed

"%VENV_PY%" -m pywin32_postinstall -install >nul 2>&1

echo.
echo ============================================================
echo Installation erfolgreich.
echo Starte das Tool mit start.bat.
echo ============================================================
pause
exit /b 0

:failed
echo.
echo ============================================================
echo Installation fehlgeschlagen.
echo Bitte sende den vollstaendigen neuen Fehlertext.
echo ============================================================
pause
exit /b 1
