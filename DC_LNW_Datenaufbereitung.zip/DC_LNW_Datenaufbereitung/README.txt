DC LNW DATENAUFBEREITUNG
========================

START
-----
1. ZIP vollständig entpacken.
2. Alle Excel-Dateien schließen.
3. start.bat doppelklicken.
4. Zuerst das Template auswählen.
5. Danach die DU-Datei auswählen.

Es ist keine Go-Installation, keine Python-Installation und keine Installation über install.bat nötig.
Microsoft Excel Desktop muss auf dem Windows-Rechner installiert sein. Excel wird nur zum Lesen verwendet.

AUSGABE
-------
Für jeden Lauf entsteht unter output ein eigener Zeitstempel-Ordner mit:

01_template_startbestand.csv
- WWID und AJ:AS.
- AJ:AS sind exakt die ursprünglichen Werte aus CL:CU des ausgewählten Templates.
- Keine DU-Daten und keine Berechnung werden in AJ:AS eingebracht.

02_du_aggregation.csv
- BI:BN aus Umsatzart Fondsportfolioanpassung.
- Zusätzlich alle DU-Bewegungssummen zur Kontrolle.

03_final_import.csv
- WWID, AJ:AS, BI:BN und CL:CU in einer Datei.
- CL:CU = AJ:AS plus die signierten DU-Bewegungen.

04_kontrolle.csv
- Zeigt je WWID, ob DU-Daten gefunden wurden und ob Startwerte nichtnumerisch waren.

ZUSAMMENFASSUNG.txt
- Dokumentiert Inputdateien, genaue Logik und Zeilenzahlen.

WICHTIG
-------
Das Tool verändert weder das Template noch die DU-Datei und schreibt keine XLSM-Datei.
Die DU-Werte werden mit ihrem bereits in der DU-Datei vorhandenen Vorzeichen summiert.
Es wird kein Vorzeichen gedreht oder erfunden.
