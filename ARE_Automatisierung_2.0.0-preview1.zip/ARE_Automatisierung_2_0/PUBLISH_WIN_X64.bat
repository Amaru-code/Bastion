@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0 - Publish
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"

where dotnet.exe >nul 2>&1
if errorlevel 1 (
    echo FEHLER: .NET 10 SDK wurde nicht gefunden.
    pause
    exit /b 1
)

dotnet --list-sdks | findstr /R /B "10\." >nul 2>&1
if errorlevel 1 (
    echo FEHLER: Fuer den Publish wird das .NET 10 SDK benoetigt.
    pause
    exit /b 1
)

if exist "%~dp0publish" rmdir /s /q "%~dp0publish"
mkdir "%~dp0publish"

echo NuGet Restore ...
dotnet restore "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj"
if errorlevel 1 goto :ERROR

echo Self-Contained Windows x64 Publish ...
dotnet publish "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" ^
  -c Release ^
  -r win-x64 ^
  --self-contained true ^
  --no-restore ^
  -p:PublishSingleFile=false ^
  -p:DebugType=None ^
  -p:DebugSymbols=false ^
  -o "%~dp0publish"
if errorlevel 1 goto :ERROR

if not exist "%~dp0publish\Output" mkdir "%~dp0publish\Output"

echo.
echo ============================================================
echo  Fertig: publish\ARE.Automatisierung.exe
echo ============================================================
echo Dieser publish-Ordner kann zusammen mit START.bat verteilt werden.
echo Auf dem Zielrechner ist dann kein .NET SDK erforderlich.
echo Microsoft Excel und Word Desktop bleiben fuer Rendering/Kompatibilitaet erforderlich.
echo.
pause
exit /b 0

:ERROR
echo.
echo Publish fehlgeschlagen. Bei Restore-Problemen siehe:
echo docs\04_NuGet_und_Artifactory.md
echo.
pause
exit /b 1
