# 01 – Bedienung

## Start

`START.bat` ist der normale Einstiegspunkt.

- Existiert `publish/ARE.Automatisierung.exe`, wird diese Version gestartet.
- Existiert bereits ein lokaler Release-Build, wird dieser gestartet.
- Andernfalls versucht `START.bat` einmalig Restore + Release-Build mit dem .NET 10 SDK.

## Eingaben

Alle Eingaben werden vor dem Lauf ausgewählt:

1. ARE-Quelldatei (`xlsx`/`xlsm`)
2. Word-Anschreibenvorlage (`docx`)
3. Serienbrief-/Empfängerdaten (`xlsx`/`xlsm`/`xls`)
4. optionales Mercer-Logo (`png`/`jpg`/`jpeg`)
5. Ausgabeordner

`Eingaben prüfen` liest und analysiert die Daten, ohne einen Output-Lauf anzulegen. Die Vorschau zeigt je LTRG ARE, Gesellschaft, Gruppen, Positionen, Nettosaldo und Anzahl passender Anschreiben.

## Lauf

`Verarbeitung starten` validiert nochmals und erstellt einen neuen Zeitstempelordner. Originaldateien werden nicht geändert.
