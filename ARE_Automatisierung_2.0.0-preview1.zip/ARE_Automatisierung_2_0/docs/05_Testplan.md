# 05 – Testplan für den ersten Windows-Lauf

## A. Voraussetzungen

1. `PRUEFE_VORAUSSETZUNGEN.ps1` ausführen.
2. Excel COM muss verfügbar sein.
3. Word COM muss verfügbar sein.
4. Beim Build müssen ClosedXML und PDFsharp aus einem zulässigen NuGet-Feed wiederhergestellt werden können.

## B. Vergleich mit v1.0.22

Mit **denselben drei Inputdateien** beide Versionen ausführen und vergleichen:

1. Anzahl betroffener LTRG
2. ARE-Zuordnung je LTRG
3. Gegenparteien je ARE
4. Anzahl Detailzeilen je Gruppe
5. Vorzeichen je Detailzeile
6. Zwischensummen Pensionen / BSAV / Summe
7. Nettosaldo/Kontrollsaldo
8. Anzahl Einzelanschreiben
9. Reihenfolge Anschreiben -> ARE in Einzel-PDF
10. XLSM-Makros in der Ausgabekopie (falls Quelle XLSM)

## C. Edge Cases

- Kopfzeile nicht in Zeile 1
- zusätzliche `ARE neu`/`ARE alt`-Spalten
- LTRG-Schreibweise `LTGR`/`LGTR`
- Summe-Spalte fehlt
- Nullbetrag
- mehrere Serienbriefzeilen je LTRG
- führende Null `0100`
- fehlende Gesellschaftszuordnung
- fehlende Serienbriefzeile
- `.xls` als Serienbriefquelle
- Word COM trennt sich: Retry muss den Datensatz erneut starten

## D. Abnahme

`2.0.0-preview1` wird erst nach fachlichem Vergleich eines realen Laufs mit v1.0.22 als produktionsreif markiert.
