# 06 – Bekannte Unterschiede zu v1.0.22

## ARE_Uebersicht_Template.xlsx

Die frei editierbare Excel-Layoutvorlage aus v1.0.22 wird in `2.0.0-preview1` noch nicht eingelesen. Das Standardlayout ist im `ExcelComOutputWriter` fest definiert und entspricht den dokumentierten v1.0.22-Grundwerten (Arial, Marsh Navy, Spaltenbreiten, Zeilenhöhen, Portrait, FitToPagesWide=1).

Die Architektur trennt Renderer und Fachlogik, sodass ein `OverviewTemplateProvider` später ergänzt werden kann, ohne den ARE-Algorithmus anzufassen.

## DOCX-Anlage

Die finale Einzel-PDF verwendet die echte, von Excel exportierte ARE-PDF. Dadurch ist die PDF-Anlage druckgetreu.

Die DOCX-Datei enthält zusätzlich eine native Word-Tabellenfassung der ARE-Anlage. Sie ist editierbar, kann aber in Details anders umbrechen als die Excel-PDF.

## Office bleibt für Rendering erforderlich

v2 vermeidet Excel/Word für die Datenlogik, entfernt Office aber in `preview1` noch nicht vollständig. Das ist bewusst gewählt, um XLSM-, Word-Template- und PDF-Layout-Kompatibilität zu erhalten.

## Kontrollsaldo im Excel-Output

Die Kontrollwerte im Kopf des erzeugten ARE-Blatts werden in dieser Preview-Version als von C# berechnete Werte geschrieben. In v1 waren Teile davon Excel-Formeln. Die fachliche Berechnung ist identisch gekapselt; eine spätere Version kann die Formeldarstellung wieder exakt nachbauen, falls das für die Prüfung gewünscht ist.
