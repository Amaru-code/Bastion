# Changelog

## 2.0.0-preview1 - 2026-08-20

- vollständige neue C#/.NET/WPF-Projektarchitektur
- Dateiauswahl aller Inputs vor dem Prozess
- Validierungs-/Vorschauansicht
- dynamische Übersicht-/Gesellschaften-Spaltenerkennung portiert
- LTRG-/ARE-/Gesellschaftslogik aus v1.0.22 portiert
- Vorzeichen-, Gruppierungs-, Nullbetrag- und Kontrollsaldo-Logik portiert
- XLSX/XLSM direkt über ClosedXML lesbar
- XLS-Fallback über unsichtbares Excel COM
- Excel-Ausgabekopie über isolierten unsichtbaren COM-Renderer
- ARE-PDF-Export direkt aus Excel-Druckdarstellung
- Word MERGEFIELD-Ersetzung inkl. Header/Footer/Text-Shapes
- Word-Isolation pro Person und Retry
- native ARE-Anlage im DOCX
- finale Einzel-/Gesamt-PDFs via PDFsharp ohne Adobe/Word-PDF-Import
- START.bat und self-contained Publish-Skript
