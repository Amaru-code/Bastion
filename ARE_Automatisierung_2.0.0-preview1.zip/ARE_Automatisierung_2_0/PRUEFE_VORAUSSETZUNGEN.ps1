$ErrorActionPreference = 'SilentlyContinue'
Write-Host 'ARE Automatisierung 2.0 - Voraussetzungen' -ForegroundColor Cyan
Write-Host ('=' * 56)

$dotnet = Get-Command dotnet.exe
if ($dotnet) {
    Write-Host '[OK] dotnet gefunden:' $dotnet.Source
    dotnet --list-sdks | ForEach-Object { Write-Host '     SDK' $_ }
} else {
    Write-Host '[INFO] Kein dotnet SDK gefunden. Das ist bei einer self-contained publish-Version in Ordnung.'
}

$excel = [type]::GetTypeFromProgID('Excel.Application')
$word  = [type]::GetTypeFromProgID('Word.Application')
if ($excel) { Write-Host '[OK] Microsoft Excel COM verfügbar' } else { Write-Host '[FEHLT] Microsoft Excel Desktop/COM' -ForegroundColor Red }
if ($word)  { Write-Host '[OK] Microsoft Word COM verfügbar' }  else { Write-Host '[FEHLT] Microsoft Word Desktop/COM' -ForegroundColor Red }

Write-Host ''
Write-Host 'Hinweis: Die Quelldatenanalyse läuft ohne Excel. Excel/Word werden nur unsichtbar für die Office-kompatible Ausgabe verwendet.'
