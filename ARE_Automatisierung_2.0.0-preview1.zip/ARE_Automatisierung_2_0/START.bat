@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0

set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"

if exist "%~dp0publish\ARE.Automatisierung.exe" (
    start "" "%~dp0publish\ARE.Automatisierung.exe"
    exit /b 0
)

if exist "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe" (
    start "" "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe"
    exit /b 0
)

where dotnet.exe >nul 2>&1
if errorlevel 1 goto :NO_DOTNET

dotnet --list-sdks | findstr /R /B "10\." >nul 2>&1
if errorlevel 1 goto :NO_SDK

echo ============================================================
echo  ARE Automatisierung 2.0 - erster Build
echo ============================================================
echo.
echo Es wurde noch keine kompilierte Version gefunden.
echo Das Projekt wird einmalig in Release gebaut.
echo.

dotnet restore "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj"
if errorlevel 1 goto :RESTORE_ERROR

dotnet build "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" -c Release --no-restore
if errorlevel 1 goto :BUILD_ERROR

start "" "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe"
exit /b 0

:NO_DOTNET
echo FEHLER: .NET wurde nicht gefunden.
echo.
echo Fuer die Entwicklung/den ersten Build wird das .NET 10 SDK benoetigt.
echo Fuer Kollegen empfiehlt sich eine Self-Contained-Version aus PUBLISH_WIN_X64.bat.
echo Dann ist auf dem Zielrechner kein .NET SDK erforderlich.
echo.
pause
exit /b 1

:NO_SDK
echo FEHLER: .NET ist vorhanden, aber kein .NET 10 SDK.
echo.
echo Bitte .NET 10 SDK installieren oder auf einem Entwicklerrechner
echo PUBLISH_WIN_X64.bat ausfuehren und danach den publish-Ordner verteilen.
echo.
pause
exit /b 1

:RESTORE_ERROR
echo.
echo FEHLER: NuGet-Pakete konnten nicht wiederhergestellt werden.
echo In einer Unternehmensumgebung kann dafuer ein interner Artifactory-/NuGet-Feed erforderlich sein.
echo Siehe docs\04_NuGet_und_Artifactory.md
echo.
pause
exit /b 1

:BUILD_ERROR
echo.
echo FEHLER: Das Projekt konnte nicht kompiliert werden.
echo.
pause
exit /b 1
