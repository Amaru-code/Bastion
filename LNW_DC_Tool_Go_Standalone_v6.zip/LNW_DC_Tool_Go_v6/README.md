# Intel LNW DC Tool – Go Standalone v4

Keine Installation, kein Python und keine externen Libraries erforderlich.

## Korrigierte Endbestandslogik

Für jede Datenzeile im Blatt `Import DC LNW`:

1. WWID wird fest aus **Spalte D** des Templates gelesen.
2. Fondsname wird aus **Zeile 1** der jeweiligen Spalte `CL:CU` beziehungsweise der korrespondierenden Spalte `AJ:AS` gelesen.
3. In der DU-Datei wird exakt gefiltert nach:
   - gleicher WWID,
   - gleichem Fondsnamen,
   - `Umsatzart = Verkauf wegen Vorabpausch`.
4. Aggregiert wird `UmsatzStuecke`.
5. Berechnung:

   `Endbestand CL:CU = Startbestand AJ:AS + signierte Summe(UmsatzStuecke)`

Ein negativer UmsatzStuecke-Wert reduziert den Bestand automatisch. Ein positiver Wert erhöht ihn.

## Ausgabe

Alle Dateien werden direkt im gewählten Ordner `Output` abgelegt:

- `generated_2025_LNW_DC_Template.xlsm`
- `audit_trail.csv`
- optional `comparison_differences.csv`

## Start

`start.bat` doppelklicken und die vier Pfade bestätigen.

## Änderung v4

- Die WWID-Spalte ist nicht mehr fest auf Spalte D eingestellt.
- Das Tool durchsucht die ersten 200 Zeilen des gesamten Blatts `Import DC LNW` nach der Kopfzelle `WWID`.
- Die tatsächlich gefundene Spalte wird für alle Datenzeilen verwendet und beim Start protokolliert.
