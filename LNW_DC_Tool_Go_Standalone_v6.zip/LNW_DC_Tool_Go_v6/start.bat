@echo off
cd /d "%~dp0"
title Intel LNW DC Tool - Go Standalone v2
LNW_DC_Tool.exe
