DC LNW IMPORTER – FINALE PORTABLE VERSION
=========================================

START
-----
1. ZIP vollständig entpacken.
2. Microsoft Excel und die Input-Dateien schließen.
3. start.bat oder DC_LNW_Importer.exe doppelt anklicken.
4. Zuerst das Template, danach die DU-Datei auswählen.

VERARBEITUNG
------------
- Die ausgewählte Template-Datei wird nicht verändert.
- Im Ordner output wird ein neuer Laufordner angelegt.
- Im Sheet "Import DC LNW" werden in der Output-Kopie ab AJ nur feste
  Datenwerte entfernt. Header und Formeln bleiben bestehen.
- AJ:AS erhält exakt die ursprünglichen Werte aus CL:CU des Input-Templates.
- BI:BN erhält die DU-Umschichtungswerte.
- CL:CU erhält die geprüften Endbestände.
- Die Zuordnung erfolgt über WWID.

OUTPUT
------
- *_DC_LNW_Output.xlsm
- 03_final_import.csv
- 04_kontrolle.csv
- ZUSAMMENFASSUNG.txt
- processing.log

VORAUSSETZUNGEN
---------------
- Windows 10 oder Windows 11
- Keine Go-, Python- oder zusätzliche Installation erforderlich.
