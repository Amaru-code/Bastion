# Technische Logik

## Bereinigung

Im Blatt `Import DC LNW` werden ab der ersten Datenzeile im Bereich `AJ:CU` ausschließlich konstante Zellinhalte gelöscht. Header und Formeln bleiben unverändert.

Vor dem Löschen werden die Werte `CL:CU` der gewählten Input-Vorlage WWID-genau zwischengespeichert.

## Startbestände AJ:AS

Die neue Output-Datei erhält ihre Startbestände ausschließlich aus derselben Input-Vorlage:

| Input-Vorlage | Output |
|---|---|
| CL | AJ |
| CM | AK |
| CN | AL |
| CO | AM |
| CP | AN |
| CQ | AO |
| CR | AP |
| CS | AQ |
| CT | AR |
| CU | AS |

Das Mapping erfolgt WWID-genau, nicht nach der bloßen Zeilenposition.

## DU-Aggregation

Aggregationsschlüssel: `(WWID, Fondsname, Umsatzart)`.

Je Schlüssel werden summiert:

- Anteile: `UmsatzStuecke`
- Wert: `ZahlBetrag`

## Neue Endbestände CL:CU

Für jeden Fonds gilt paarweise:

- `CL = AJ + aggregierte DU-Anteile`
- `CM = AK + aggregierter DU-Wert`
- entsprechend weiter bis `CU = AS + aggregierter DU-Wert`

Berücksichtigt werden die in `config/settings.json` definierten Umsatzarten.

## Umschichtungsblock BE:BN

Die bestehende, bereits korrekte Logik für `BE:BN` bleibt unverändert. Tatsächlich beschriebene Umschichtungsspalten werden weiterhin aus der DU-Datei befüllt, ohne Formeln zu überschreiben.

## Schutzmechanismen

- Die Input-Datei bleibt unverändert.
- Die Verarbeitung erfolgt ausschließlich in einer Kopie.
- Makros bleiben durch die native Excel-Automation erhalten.
- Formeln werden weder gelöscht noch überschrieben.
- Bei einem Fehler wird eine unvollständige Output-Kopie entfernt.
