Optional: place a file named Tray_Icon.ico in this folder.
Without it, the Windows application icon is used automatically.
