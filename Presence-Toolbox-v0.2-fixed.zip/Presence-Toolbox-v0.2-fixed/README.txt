PRESENCE TOOLBOX v0.2 - FIXED PROTOTYPE
=======================================

START
-----
Double-click:

    Presence Toolbox.VBS

The visible terminal is part of the application. Closing the terminal ends the
whole program.

AVAILABLE MODES
---------------
Normal
    No activity simulation. Windows and Teams behave normally.

Available
    Sends a double Scroll Lock tap every 60 seconds. The original Scroll Lock
    state is preserved because the key is toggled twice.

DURATION
--------
The tray menu supports:

    Unlimited
    30 minutes
    1 hour
    2 hours
    Until end of day

When a timed Available mode expires, the application returns to Normal.
Changing the duration while Available is active recalculates the end time from
that moment.

TRAY MENU
---------
Right-click the Presence Toolbox icon in the Windows notification area.

The Busy, Do Not Disturb and In a Meeting entries are visible as planned modes,
but intentionally disabled in this prototype.

LOGS
----
Terminal output is also written to:

    Logs\Presence-Toolbox-YYYY-MM-DD.log

Old log files are deleted after five days.

IMPORTANT FIX IN v0.2
---------------------
Duration values are handled directly as DateTime calculations. The faulty
nullable .Value access from v0.1 is no longer present. Every click and timer
handler also catches errors so a menu action cannot trigger an unhandled .NET
Framework popup.
