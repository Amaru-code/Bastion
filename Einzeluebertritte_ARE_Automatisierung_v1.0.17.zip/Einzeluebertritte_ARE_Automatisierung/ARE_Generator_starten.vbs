Option Explicit

' ============================================================================
' Einzeluebertritte ARE Generator - externe Ausfuehrung
' Version 1.0.17
'
' Ablauf:
'   1. Excel-Quelldatei fuer die ARE-Auswertung auswaehlen.
'   2. Word-DOCX als Serienbriefvorlage auswaehlen.
'   3. Excel-Datei mit den Personendaten auswaehlen.
'   4. Sichere Ausgabekopie der ARE-Quelldatei anlegen.
'   5. ARE-Blaetter erzeugen und jedes Blatt als einzelne PDF exportieren.
'   6. Nur betroffene Gesellschaften verarbeiten und je Gesellschaft DOCX/PDF mit ARE-�bersicht erzeugen.
'
' Die Quelldateien und die Serienbriefvorlage werden nicht veraendert.
' ============================================================================

Const xlCalculationAutomatic = -4105
Const xlCalculationManual = -4135
Const xlCenter = -4108
Const xlLeft = -4131
Const xlRight = -4152
Const xlContinuous = 1
Const xlThin = 2
Const xlMedium = -4138
Const xlDouble = -4119
Const xlNone = -4142
Const xlEdgeLeft = 7
Const xlEdgeTop = 8
Const xlEdgeBottom = 9
Const xlEdgeRight = 10
Const xlCellValue = 1
Const xlEqual = 3
Const xlNotEqual = 4
Const xlPortrait = 1
Const xlLandscape = 2
Const xlOpenXMLWorkbook = 51
Const xlPageBreakPreview = 2
Const xlUp = -4162
Const xlTypePDF = 0
Const xlQualityStandard = 0
Const xlScreen = 1
Const xlPicture = -4147
Const xlPasteFormats = -4122

Const wdDoNotSaveChanges = 0
Const wdFormatXMLDocument = 12
Const wdExportFormatPDF = 17
Const wdPageBreak = 7
Const wdCollapseEnd = 0
Const wdFieldMergeField = 59
Const wdSendToNewDocument = 0
Const wdOpenFormatAuto = 0
Const wdMergeSubTypeOther = 0
Const wdSectionBreakNextPage = 2
Const wdPasteEnhancedMetafile = 9
Const wdInLine = 0
Const wdAlignParagraphCenter = 1

Const msoFalse = 0
Const msoTrue = -1
Const msoLinkedPicture = 11
Const msoPicture = 13

Const SHEET_OVERVIEW = "�bersicht"
Const SHEET_COMPANIES = "Gesellschaften"
Const GENERATED_PREFIX = "ARE "
Const FIRST_DATA_ROW = 3
Const HEADER_SCAN_MAX_ROWS = 30
Const HEADER_SCAN_MAX_COLUMNS = 100
Const CENTRAL_LTRG = 100
Const INCLUDE_ZERO_ON_RECEIVER_SIDE = False
Const VB_ERROR_TYPE = 10
Const TOOL_VERSION = "1.0.17"

Dim gExcel
Dim gWorkbook
Dim gWord
Dim gOutputPath
Dim gExportFolder
Dim gSerialTemplatePath
Dim gSerialDataPath
Dim gSuccess
Dim gStage
Dim gLogPath
Dim gProjectFolder
Dim gReportPeriod
Dim gLogoSourceDescription
Dim gAffectedLtrgs
Dim gAREPdfAttachmentsComplete
Dim gOverviewTemplateWorkbook
Dim gOverviewTemplateSheet
Dim gOverviewTemplatePath
Dim gTemplateConfig
Dim errNumber
Dim errDescription
Dim errSource

gStage = "Initialisierung"

On Error Resume Next
RunGenerator
errNumber = Err.Number
errDescription = Err.Description
errSource = Err.Source
On Error GoTo 0

If errNumber <> 0 Then
    On Error Resume Next
    CloseWordSafely
    CloseOverviewTemplateSafely
    If IsObject(gWorkbook) Then
        If Not gWorkbook Is Nothing Then gWorkbook.Close False
    End If
    If IsObject(gExcel) Then
        If Not gExcel Is Nothing Then
            gExcel.ScreenUpdating = True
            gExcel.EnableEvents = True
            gExcel.DisplayAlerts = True
            gExcel.StatusBar = False
            gExcel.Quit
        End If
    End If
    On Error GoTo 0

    WriteLog "FEHLER | Phase=" & gStage & " | Nummer=" & CStr(errNumber) & _
             " | Quelle=" & errSource & " | Beschreibung=" & errDescription

    MsgBox "Die ARE-Auswertung konnte nicht erstellt werden." & vbCrLf & vbCrLf & _
           "Version: " & TOOL_VERSION & vbCrLf & _
           "Phase: " & gStage & vbCrLf & _
           "Fehler " & CStr(errNumber) & ": " & errDescription & vbCrLf & _
           "Quelle: " & errSource & vbCrLf & vbCrLf & _
           "Diagnoseprotokoll:" & vbCrLf & SafeDisplayPath(gLogPath) & vbCrLf & vbCrLf & _
           "Hinweise stehen im Ordner docs, insbesondere in 06_Fehlersuche.md.", _
           vbCritical, "ARE Generator " & TOOL_VERSION
    WScript.Quit 1
End If

Sub RunGenerator()
    Dim fso
    Dim sourcePath
    Dim sourceWorkbook
    Dim oldCalculation
    Dim sourceExtension
    Dim templateExtension
    Dim serialDataExtension
    Dim excelFolder
    Dim pdfFolder
    Dim serialFolder
    Dim individualFolder
    Dim logoCount
    Dim mergeCount
    Dim aggregateDocxPath
    Dim aggregatePdfPath

    gStage = "Excel starten"
    Set fso = CreateObject("Scripting.FileSystemObject")
    gProjectFolder = fso.GetParentFolderName(WScript.ScriptFullName)
    gLogPath = fso.BuildPath(gProjectFolder, "ARE_Generator_Diagnose.log")
    ResetLog
    WriteLog "START | Version " & TOOL_VERSION

    Set gExcel = CreateObject("Excel.Application")

    gExcel.Visible = True
    gExcel.DisplayAlerts = False

    gStage = "ARE-Quelldatei ausw�hlen"
    sourcePath = gExcel.GetOpenFilename( _
        "Excel-Dateien (*.xlsm;*.xlsx),*.xlsm;*.xlsx", _
        1, _
        "ARE-Quelldatei mit �bersicht und Gesellschaften ausw�hlen" _
    )

    If VarType(sourcePath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    WriteLog "ARE-QUELLE | " & CStr(sourcePath)
    sourceExtension = LCase(fso.GetExtensionName(CStr(sourcePath)))

    If sourceExtension <> "xlsm" And sourceExtension <> "xlsx" Then
        Err.Raise -2147221504 + 2000, "ARE Generator", _
                  "Bitte eine XLSM- oder XLSX-Datei als ARE-Quelle ausw�hlen."
    End If

    gReportPeriod = BuildReportPeriod(fso.GetBaseName(CStr(sourcePath)))
    WriteLog "BERICHTSZEITRAUM | " & gReportPeriod

    gStage = "Serienbriefvorlage ausw�hlen"
    gSerialTemplatePath = gExcel.GetOpenFilename( _
        "Word-Dokumente (*.docx),*.docx", _
        1, _
        "DOCX-Serienbriefvorlage ausw�hlen" _
    )

    If VarType(gSerialTemplatePath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    templateExtension = LCase(fso.GetExtensionName(CStr(gSerialTemplatePath)))
    If templateExtension <> "docx" Then
        Err.Raise -2147221504 + 2001, "ARE Generator", _
                  "Bitte eine DOCX-Datei als Serienbriefvorlage ausw�hlen."
    End If
    WriteLog "SERIENBRIEF-VORLAGE | " & CStr(gSerialTemplatePath)

    gStage = "Personendaten ausw�hlen"
    gSerialDataPath = gExcel.GetOpenFilename( _
        "Excel-Dateien (*.xlsx;*.xlsm;*.xls),*.xlsx;*.xlsm;*.xls", _
        1, _
        "Excel-Datei mit den Personendaten ausw�hlen" _
    )

    If VarType(gSerialDataPath) = vbBoolean Then
        gExcel.Quit
        WScript.Quit 0
    End If

    serialDataExtension = LCase(fso.GetExtensionName(CStr(gSerialDataPath)))
    If serialDataExtension <> "xlsx" And serialDataExtension <> "xlsm" And _
       serialDataExtension <> "xls" Then
        Err.Raise -2147221504 + 2002, "ARE Generator", _
                  "Bitte eine XLSX-, XLSM- oder XLS-Datei mit Personendaten ausw�hlen."
    End If
    WriteLog "PERSONENDATEN | " & CStr(gSerialDataPath)

    gStage = "Output-Ordner anlegen"
    BuildExportFolders fso, CStr(sourcePath), excelFolder, pdfFolder, _
                       serialFolder, individualFolder
    WriteLog "AUSGABE-ORDNER | " & gExportFolder

    gStage = "Ausgabepfad vorbereiten"
    gOutputPath = BuildOutputPath(fso, CStr(sourcePath), excelFolder)
    WriteLog "AUSGABE-EXCEL | " & gOutputPath

    gStage = "Ausgabekopie erstellen"
    gExcel.StatusBar = "Sichere Ausgabekopie wird erstellt ..."
    Set sourceWorkbook = gExcel.Workbooks.Open(CStr(sourcePath), 0, True)
    sourceWorkbook.SaveCopyAs gOutputPath
    sourceWorkbook.Close False
    Set sourceWorkbook = Nothing

    gStage = "Ausgabedatei �ffnen"
    Set gWorkbook = gExcel.Workbooks.Open(gOutputPath, 0, False)

    gStage = "�bersichtsvorlage vorbereiten"
    PrepareOverviewTemplate gExcel, fso, gProjectFolder

    oldCalculation = gExcel.Calculation
    gExcel.ScreenUpdating = False
    gExcel.EnableEvents = False
    gExcel.DisplayAlerts = False

    ' Vor dem Auslesen vorhandene Formeln aktualisieren.
    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gExcel.Calculation = xlCalculationManual

    gStage = "ARE-Bl�tter erzeugen"
    WriteLog "PHASE | " & gStage
    GenerateARESheets gExcel, gWorkbook
    CloseOverviewTemplateSafely

    gStage = "Mercer-Logo aus lokaler Bilddatei einf�gen"
    logoCount = PrepareARELogos(gExcel, gWorkbook, fso, gProjectFolder)
    WriteLog "INFO | Mercer-Logo auf " & CStr(logoCount) & " ARE-Bl�tter �bertragen"

    gStage = "Ergebnis berechnen und speichern"
    WriteLog "PHASE | " & gStage

    gExcel.Calculation = xlCalculationAutomatic
    gExcel.CalculateFull
    gWorkbook.Save

    gStage = "ARE-Bl�tter als PDF exportieren"
    ExportGeneratedSheetsAsPdf gWorkbook, fso, pdfFolder

    ' Excel wieder in einen normalen Benutzerzustand versetzen, bevor Word startet.
    gExcel.StatusBar = False
    gExcel.ScreenUpdating = True
    gExcel.EnableEvents = True
    gExcel.DisplayAlerts = True
    gExcel.Calculation = oldCalculation
    gExcel.Visible = True

    gStage = "Serienbrief erzeugen"
    GenerateSerialLetters gExcel, fso, CStr(gSerialTemplatePath), _
                          CStr(gSerialDataPath), serialFolder, individualFolder, _
                          pdfFolder, mergeCount, aggregateDocxPath, aggregatePdfPath

    gWorkbook.Activate
    gStage = "Abgeschlossen"
    gSuccess = True

    WriteLog "ERFOLG | Ausgabedatei=" & gOutputPath
    WriteLog "ERFOLG | Exportordner=" & gExportFolder
    WriteLog "ERFOLG | Betroffene Anschreiben=" & CStr(mergeCount)

    MsgBox "Die ARE-Auswertung und der Serienbrief wurden erfolgreich erstellt." & vbCrLf & vbCrLf & _
           "Version: " & TOOL_VERSION & vbCrLf & _
           "ARE-Ausgabedatei:" & vbCrLf & gOutputPath & vbCrLf & vbCrLf & _
           "Alle Ausgaben im Output-Ordner:" & vbCrLf & gExportFolder & vbCrLf & vbCrLf & _
           "Logoquelle: " & gLogoSourceDescription & vbCrLf & _
           "Anschreiben f�r betroffene Gesellschaften: " & CStr(mergeCount) & vbCrLf & _
           "ARE-PDFs: Anschreiben jeweils am Dateiende angehaengt" & vbCrLf & _
           "Gesamt-DOCX: " & fso.GetFileName(aggregateDocxPath) & vbCrLf & _
           "Gesamt-PDF: " & fso.GetFileName(aggregatePdfPath) & vbCrLf & vbCrLf & _
           "Die Quelldateien und die DOCX-Vorlage wurden nicht ver�ndert.", _
           vbInformation, "ARE Generator " & TOOL_VERSION
End Sub

Sub PrepareOverviewTemplate(ByVal xlApp, ByVal fso, ByVal projectFolder)
    Dim templatesFolder

    templatesFolder = fso.BuildPath(CStr(projectFolder), "templates")
    If Not fso.FolderExists(templatesFolder) Then fso.CreateFolder templatesFolder

    gOverviewTemplatePath = fso.BuildPath(templatesFolder, "ARE_Uebersicht_Template.xlsx")
    If Not fso.FileExists(gOverviewTemplatePath) Then
        gStage = "Standard-�bersichtsvorlage erstmals erstellen"
        CreateDefaultOverviewTemplate xlApp, fso, gOverviewTemplatePath
        WriteLog "VORLAGE | Standardvorlage erzeugt: " & gOverviewTemplatePath
    End If

    Set gOverviewTemplateWorkbook = xlApp.Workbooks.Open(CStr(gOverviewTemplatePath), 0, True)
    Set gOverviewTemplateSheet = GetWorksheetOrNothing(gOverviewTemplateWorkbook, "ARE_TEMPLATE")
    If gOverviewTemplateSheet Is Nothing Then
        CloseOverviewTemplateSafely
        Err.Raise -2147221504 + 2020, "ARE Generator", _
                  "Die �bersichtsvorlage enth�lt kein Blatt 'ARE_TEMPLATE'."
    End If

    LoadTemplateConfig gOverviewTemplateWorkbook
    WriteLog "VORLAGE | Verwendet: " & gOverviewTemplatePath
End Sub

Sub CreateDefaultOverviewTemplate(ByVal xlApp, ByVal fso, ByVal templatePath)
    Dim wb
    Dim ws
    Dim infoWs

    Set wb = xlApp.Workbooks.Add
    Set ws = wb.Worksheets(1)
    ws.Name = "ARE_TEMPLATE"

    Do While wb.Worksheets.Count > 1
        wb.Worksheets(wb.Worksheets.Count).Delete
    Loop

    BuildDefaultOverviewTemplateSheet xlApp, ws

    Set infoWs = wb.Worksheets.Add
    infoWs.Name = "CONFIG"
    infoWs.Range("A1").Value = "Einstellung"
    infoWs.Range("B1").Value = "Wert"
    infoWs.Range("A2").Value = "LOGO_ANCHOR"
    infoWs.Range("B2").Value = "A1"
    infoWs.Range("A3").Value = "LOGO_HEIGHT"
    infoWs.Range("B3").Value = 34
    infoWs.Range("A4").Value = "LOGO_LEFT_OFFSET"
    infoWs.Range("B4").Value = 0
    infoWs.Range("A5").Value = "LOGO_TOP_OFFSET"
    infoWs.Range("B5").Value = 2
    infoWs.Range("A7").Value = "Hinweis"
    infoWs.Range("B7").Value = "Formatierung im Blatt ARE_TEMPLATE anpassen; Zeilen 10-14 sind Musterzeilen."
    infoWs.Columns("A").ColumnWidth = 24
    infoWs.Columns("B").ColumnWidth = 80
    infoWs.Range("A1:B1").Font.Bold = True

    On Error Resume Next
    Call infoWs.Move(, ws)
    ws.Activate
    Err.Clear
    On Error GoTo 0

    wb.SaveAs CStr(templatePath), xlOpenXMLWorkbook
    wb.Close False
    Set infoWs = Nothing
    Set ws = Nothing
    Set wb = Nothing
End Sub

Sub BuildDefaultOverviewTemplateSheet(ByVal xlApp, ByVal ws)
    ws.Cells.Clear
    ws.Range("E1:F1").Merge
    ws.Range("E2:F2").Merge
    ws.Range("A4:F4").Merge
    ws.Range("A6:F6").Merge
    ws.Range("A7:F7").Merge
    ws.Range("A10:F10").Merge

    ws.Range("E1").Value = "Einzel�bertritte {{ZEITRAUM}}"
    ws.Range("E2").Value = "ARE {{ARE}} (LTRG {{LTRG}})"
    ws.Range("A4").Value = "�bertragene R�ckstellungen bei Einzel�bertritten"
    ws.Range("A6").Value = "Positive Betr�ge erh�lt die {{GESELLSCHAFT_KURZ}} von der genannten Gesellschaft,"
    ws.Range("A7").Value = "negative Betr�ge gibt die {{GESELLSCHAFT_KURZ}} an die genannte Gesellschaft ab."
    ws.Range("A10").Value = "{{GEGENPARTEI_KURZ}} (ARE {{GEGENPARTEI_ARE}}, LTRG {{GEGENPARTEI_LTRG}})"
    ws.Range("A11").Value = "PNR"
    ws.Range("B11").Value = "alte PNR"
    ws.Range("C11").Value = "�bertritt"
    ws.Range("D11").Value = "Pensionen (alt)" & vbLf & "(Euro)"
    ws.Range("E11").Value = "BSAV" & vbLf & "(Euro)"
    ws.Range("F11").Value = "Summe" & vbLf & "(Euro)"
    ws.Range("A12").Value = "1234567"
    ws.Range("B12").Value = "7654321"
    ws.Range("C12").Value = Date
    ws.Range("D12").Value = 0
    ws.Range("E12").Value = 1000
    ws.Range("F12").Value = 1000
    ws.Range("D13").Formula = "=SUM(D12:D12)"
    ws.Range("E13").Formula = "=SUM(E12:E12)"
    ws.Range("F13").Formula = "=SUM(F12:F12)"

    With ws.Cells
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Color = RGBColor(0, 15, 71)
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlNone
    End With
    With ws.Range("E1:F2")
        .HorizontalAlignment = xlCenter
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With
    With ws.Range("A4:F4")
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
        .Borders.LineStyle = xlNone
    End With
    With ws.Range("A6:F7")
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .Font.Bold = False
        .Font.Size = 9
        .Font.Color = RGBColor(0, 15, 71)
        .WrapText = True
        .ShrinkToFit = False
        .Borders.LineStyle = xlNone
    End With
    With ws.Range("A10:F10")
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    With ws.Range("A11:F11")
        .Font.Bold = True
        .HorizontalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlNone
    End With
    With ws.Range("A12:F12")
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With
    ws.Range("A12:C12").HorizontalAlignment = xlCenter
    ws.Range("D12:F12").HorizontalAlignment = xlRight
    With ws.Range("D13:F13")
        .Font.Bold = True
        .Borders.LineStyle = xlNone
        .Borders(xlEdgeTop).LineStyle = xlContinuous
        .Borders(xlEdgeTop).Weight = xlThin
    End With

    ws.Columns("A").ColumnWidth = 12
    ws.Columns("B").ColumnWidth = 12
    ws.Columns("C").ColumnWidth = 12
    ws.Columns("D").ColumnWidth = 17.5
    ws.Columns("E").ColumnWidth = 12.5
    ws.Columns("F").ColumnWidth = 12.5
    ws.Rows(1).RowHeight = 24
    ws.Rows(2).RowHeight = 20
    ws.Rows(4).RowHeight = 24
    ws.Rows(6).RowHeight = 28
    ws.Rows(7).RowHeight = 28
    ws.Rows(10).RowHeight = 19
    ws.Rows(11).RowHeight = 31
    ws.Rows(12).RowHeight = 15
    ws.Rows(13).RowHeight = 15
    ws.Rows(14).RowHeight = 8
    ws.Columns("A:B").NumberFormat = "0"
    ws.Columns("C").NumberFormat = "dd.mm.yyyy"
    ws.Columns("D:F").NumberFormat = "#,##0;-#,##0"

    With ws.PageSetup
        .Orientation = xlPortrait
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .CenterHorizontally = True
        .LeftMargin = xlApp.CentimetersToPoints(1.2)
        .RightMargin = xlApp.CentimetersToPoints(1.2)
        .TopMargin = xlApp.CentimetersToPoints(1)
        .BottomMargin = xlApp.CentimetersToPoints(1)
        .HeaderMargin = xlApp.CentimetersToPoints(0.4)
        .FooterMargin = xlApp.CentimetersToPoints(0.4)
        .PrintArea = "$A$1:$F$14"
        .PrintGridlines = False
    End With
End Sub

Sub ApplyOverviewTemplateBase(ByVal xlApp, ByVal ws)
    Dim columnNumber
    Dim rowNumber

    If Not IsObject(gOverviewTemplateSheet) Then Exit Sub

    gOverviewTemplateSheet.Range("A1:F14").Copy ws.Range("A1")
    For columnNumber = 1 To 6
        ws.Columns(columnNumber).ColumnWidth = gOverviewTemplateSheet.Columns(columnNumber).ColumnWidth
    Next
    For rowNumber = 1 To 14
        ws.Rows(rowNumber).RowHeight = gOverviewTemplateSheet.Rows(rowNumber).RowHeight
    Next
    CopyTemplatePageSetup gOverviewTemplateSheet, ws
    xlApp.CutCopyMode = False
End Sub

Sub PrepareOverviewSectionRows(ByVal ws, ByVal sectionRow, ByVal headerRow)
    Dim columnNumber

    If Not IsObject(gOverviewTemplateSheet) Then Exit Sub

    On Error Resume Next
    ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).UnMerge
    Err.Clear
    On Error GoTo 0
    ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
    ApplyTemplateRowFormat ws, sectionRow, 10
    ws.Cells(sectionRow, 1).Value = gOverviewTemplateSheet.Cells(10, 1).Value

    ApplyTemplateRowFormat ws, headerRow, 11
    For columnNumber = 1 To 6
        ws.Cells(headerRow, columnNumber).Value = _
            gOverviewTemplateSheet.Cells(11, columnNumber).Value
    Next
End Sub

Sub ApplyTemplateRowFormat(ByVal ws, ByVal targetRow, ByVal templateRow)
    gOverviewTemplateSheet.Range("A" & CStr(templateRow) & ":F" & CStr(templateRow)).Copy
    ws.Range("A" & CStr(targetRow) & ":F" & CStr(targetRow)).PasteSpecial xlPasteFormats
    ws.Rows(targetRow).RowHeight = gOverviewTemplateSheet.Rows(templateRow).RowHeight
    gExcel.CutCopyMode = False
End Sub

Sub CopyTemplatePageSetup(ByVal sourceWs, ByVal targetWs)
    On Error Resume Next
    With targetWs.PageSetup
        .Orientation = sourceWs.PageSetup.Orientation
        .Zoom = sourceWs.PageSetup.Zoom
        .FitToPagesWide = sourceWs.PageSetup.FitToPagesWide
        .FitToPagesTall = sourceWs.PageSetup.FitToPagesTall
        .CenterHorizontally = sourceWs.PageSetup.CenterHorizontally
        .LeftMargin = sourceWs.PageSetup.LeftMargin
        .RightMargin = sourceWs.PageSetup.RightMargin
        .TopMargin = sourceWs.PageSetup.TopMargin
        .BottomMargin = sourceWs.PageSetup.BottomMargin
        .HeaderMargin = sourceWs.PageSetup.HeaderMargin
        .FooterMargin = sourceWs.PageSetup.FooterMargin
    End With
    Err.Clear
    On Error GoTo 0
End Sub

Function ResolveOverviewTemplateText(ByVal templateText, ByVal fallbackText, _
                                     ByVal periodValue, ByVal areValue, ByVal ltrgValue, _
                                     ByVal companyShort, ByVal counterpartyShort, _
                                     ByVal counterpartyAre, ByVal counterpartyLtrg)
    Dim result

    result = SafeString(templateText)
    If Len(Trim(result)) = 0 Then result = CStr(fallbackText)
    result = Replace(result, "{{ZEITRAUM}}", SafeString(periodValue), 1, -1, 1)
    result = Replace(result, "{{ARE}}", DisplayValue(areValue), 1, -1, 1)
    result = Replace(result, "{{LTRG}}", FormatLtrg(CLng(ltrgValue)), 1, -1, 1)
    result = Replace(result, "{{GESELLSCHAFT_KURZ}}", SafeString(companyShort), 1, -1, 1)
    result = Replace(result, "{{GEGENPARTEI_KURZ}}", SafeString(counterpartyShort), 1, -1, 1)
    result = Replace(result, "{{GEGENPARTEI_ARE}}", DisplayValue(counterpartyAre), 1, -1, 1)
    If CLng(counterpartyLtrg) <> 0 Then
        result = Replace(result, "{{GEGENPARTEI_LTRG}}", FormatLtrg(CLng(counterpartyLtrg)), 1, -1, 1)
    Else
        result = Replace(result, "{{GEGENPARTEI_LTRG}}", "", 1, -1, 1)
    End If
    ResolveOverviewTemplateText = result
End Function

Sub SetCellDefaultIfBlank(ByVal cell, ByVal defaultValue)
    If Len(Trim(SafeString(cell.Value))) = 0 Then cell.Value = defaultValue
End Sub

Sub LoadTemplateConfig(ByVal templateWorkbook)
    Dim configWs
    Dim lastRow
    Dim rowNumber
    Dim keyValue

    Set gTemplateConfig = CreateObject("Scripting.Dictionary")
    gTemplateConfig.CompareMode = 1
    Set configWs = GetWorksheetOrNothing(templateWorkbook, "CONFIG")
    If configWs Is Nothing Then Exit Sub

    lastRow = GetUsedLastRowSafe(configWs)
    For rowNumber = 2 To lastRow
        keyValue = UCase(Trim(ReadCellTextSafe(configWs.Cells(rowNumber, 1))))
        If Len(keyValue) > 0 Then
            gTemplateConfig(keyValue) = ReadCellValueSafe(configWs.Cells(rowNumber, 2))
        End If
    Next
End Sub

Function GetTemplateConfigText(ByVal keyName, ByVal defaultValue)
    GetTemplateConfigText = CStr(defaultValue)
    If IsObject(gTemplateConfig) Then
        If gTemplateConfig.Exists(UCase(CStr(keyName))) Then
            If Len(Trim(SafeString(gTemplateConfig.Item(UCase(CStr(keyName)))))) > 0 Then
                GetTemplateConfigText = SafeString(gTemplateConfig.Item(UCase(CStr(keyName))))
            End If
        End If
    End If
End Function

Function GetTemplateConfigNumber(ByVal keyName, ByVal defaultValue)
    Dim value
    GetTemplateConfigNumber = CDbl(defaultValue)
    If IsObject(gTemplateConfig) Then
        If gTemplateConfig.Exists(UCase(CStr(keyName))) Then
            value = gTemplateConfig.Item(UCase(CStr(keyName)))
            If IsNumeric(value) Then GetTemplateConfigNumber = CDbl(value)
        End If
    End If
End Function

Sub CloseOverviewTemplateSafely()
    On Error Resume Next
    If IsObject(gOverviewTemplateWorkbook) Then
        If Not gOverviewTemplateWorkbook Is Nothing Then gOverviewTemplateWorkbook.Close False
    End If
    Set gOverviewTemplateSheet = Nothing
    Set gOverviewTemplateWorkbook = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Function JoinDictionaryKeys(ByVal dictionaryObject, ByVal separator)
    Dim keys
    Dim i
    Dim result

    result = ""
    If Not IsObject(dictionaryObject) Then
        JoinDictionaryKeys = result
        Exit Function
    End If
    If dictionaryObject.Count = 0 Then
        JoinDictionaryKeys = result
        Exit Function
    End If

    keys = dictionaryObject.Keys
    SortNumericKeys keys
    For i = 0 To UBound(keys)
        If Len(result) > 0 Then result = result & CStr(separator)
        result = result & FormatLtrg(CLng(keys(i)))
    Next
    JoinDictionaryKeys = result
End Function

Sub GenerateARESheets(ByVal xlApp, ByVal wb)
    Dim wsOverview
    Dim wsCompanies
    Dim overviewLayout
    Dim companyLayout
    Dim companies
    Dim targets
    Dim transferData()
    Dim targetKeys
    Dim lastTransferRow
    Dim firstTransferRow
    Dim i

    Set wsOverview = GetWorksheetOrNothing(wb, SHEET_OVERVIEW)
    Set wsCompanies = GetWorksheetOrNothing(wb, SHEET_COMPANIES)

    If wsOverview Is Nothing Then
        Err.Raise -2147221504 + 2010, "ARE Generator", _
                  "Das Blatt '" & SHEET_OVERVIEW & "' wurde nicht gefunden."
    End If

    If wsCompanies Is Nothing Then
        Err.Raise -2147221504 + 2011, "ARE Generator", _
                  "Das Blatt '" & SHEET_COMPANIES & "' wurde nicht gefunden."
    End If

    gStage = "Quellbl�tter pr�fen - �bersichtskopf dynamisch erkennen"
    WriteLog "PHASE | " & gStage
    Set overviewLayout = DiscoverOverviewLayout(wsOverview)
    firstTransferRow = CLng(overviewLayout.Item("_header_row")) + 1

    gStage = "Quellbl�tter pr�fen - letzte Datenzeile"
    WriteLog "PHASE | " & gStage
    lastTransferRow = FindLastTransferRow(wsOverview, overviewLayout, firstTransferRow)
    If lastTransferRow < firstTransferRow Then
        Err.Raise -2147221504 + 2012, "ARE Generator", _
                  "Im Blatt '" & wsOverview.Name & "' wurden unterhalb der erkannten Kopfzeile keine �bertritte gefunden."
    End If
    WriteLog "INFO | Erste �bertrittszeile=" & CStr(firstTransferRow) & _
             " | Letzte �bertrittszeile=" & CStr(lastTransferRow)

    gStage = "Quellbl�tter pr�fen - Daten �ber Spaltennamen einlesen"
    WriteLog "PHASE | " & gStage
    LoadTransferData wsOverview, lastTransferRow, overviewLayout, firstTransferRow, transferData

    gStage = "Gesellschaften - Kopfzeile dynamisch erkennen"
    WriteLog "PHASE | " & gStage
    Set companyLayout = DiscoverCompanyLayout(wsCompanies)

    gStage = "Gesellschaften und LTRG einlesen"
    WriteLog "PHASE | " & gStage
    Set companies = LoadCompanies(wsCompanies, companyLayout)
    Set targets = BuildTargetLtrgs(transferData)
    If targets.Count = 0 Then
        Err.Raise -2147221504 + 2013, "ARE Generator", _
                  "Es wurden keine tats�chlichen �bertritte zwischen unterschiedlichen LTRG gefunden."
    End If
    Set gAffectedLtrgs = CloneDictionary(targets)
    WriteLog "INFO | Betroffene LTRG: " & JoinDictionaryKeys(gAffectedLtrgs, ", ")

    gStage = "LTRG-Zuordnungen pr�fen"
    ValidateCompanyAssignments targets, companies
    gStage = "Alte ARE-Bl�tter entfernen"
    DeleteGeneratedSheets wb

    targetKeys = targets.Keys
    SortNumericKeys targetKeys

    For i = 0 To UBound(targetKeys)
        gStage = "ARE-Blatt f�r LTRG " & FormatLtrg(CLng(targetKeys(i))) & " erstellen"
        WriteLog "PHASE | " & gStage
        xlApp.StatusBar = "ARE-Blatt f�r LTRG " & _
                          FormatLtrg(CLng(targetKeys(i))) & " wird erstellt ..."
        CreateARESheet xlApp, wb, wsOverview, overviewLayout, companies, transferData, CLng(targetKeys(i))
    Next
End Sub

Function AddWorksheetAtEnd(ByVal wb)
    Dim ws
    Dim lastSheet
    Dim addErrorNumber
    Dim addErrorDescription
    Dim moveErrorNumber
    Dim moveErrorDescription

    ' Das Hinzufuegen oder Loeschen von Blaettern ist bei geschuetzter
    ' Arbeitsmappenstruktur nicht erlaubt. Eine klare Meldung ist hilfreicher
    ' als der unspezifische Excel-Fehler 1004.
    If CBool(wb.ProtectStructure) Then
        Err.Raise -2147221504 + 2030, "ARE Generator", _
                  "Die Struktur der Arbeitsmappe ist geschuetzt. " & _
                  "Bitte in Excel unter 'Ueberpruefen > Arbeitsmappe schuetzen' " & _
                  "den Strukturschutz aufheben und das Tool erneut starten."
    End If

    ' Wichtig fuer VBScript/Excel-COM:
    ' Keine Platzhalter wie Empty an Worksheets.Add uebergeben. Excel kann
    ' Empty als zuzuweisenden Parameter interpretieren und meldet dann Fehler 1004.
    wb.Activate
    wb.Worksheets(1).Activate

    Set ws = Nothing
    On Error Resume Next
    Err.Clear
    Set ws = wb.Worksheets.Add
    addErrorNumber = Err.Number
    addErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If ws Is Nothing Then
        If addErrorNumber = 0 Then addErrorNumber = -2147221504 + 2031
        Err.Raise addErrorNumber, "Microsoft Excel", _
                  "Ein neues Arbeitsblatt konnte nicht erstellt werden. " & _
                  addErrorDescription
    End If

    ' Worksheets.Add ohne Parameter ist die stabilste COM-Variante. Das neue
    ' Blatt wird zunaechst vor dem aktiven Blatt eingefuegt. Anschliessend wird
    ' lediglich versucht, es ans Ende zu verschieben. Ein Fehlschlag beim
    ' Verschieben ist nicht fachkritisch und darf die Auswertung nicht stoppen.
    If wb.Worksheets.Count > 1 Then
        Set lastSheet = wb.Worksheets(wb.Worksheets.Count)
        If Not (ws Is lastSheet) Then
            On Error Resume Next
            Err.Clear
            Call ws.Move(, lastSheet)
            moveErrorNumber = Err.Number
            moveErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0

            If moveErrorNumber <> 0 Then
                WriteLog "WARNUNG | Neues Blatt wurde erstellt, konnte aber nicht " & _
                         "ans Ende verschoben werden. Nummer=" & _
                         CStr(moveErrorNumber) & " | Beschreibung=" & _
                         moveErrorDescription
            End If
        End If
    End If

    Set AddWorksheetAtEnd = ws
End Function

Sub CreateARESheet(ByVal xlApp, ByVal wb, ByVal wsOverview, ByVal overviewLayout, _
                   ByVal companies, ByRef transferData, ByVal targetLtrg)
    Dim ws
    Dim groups
    Dim targetInfo
    Dim counterpartyInfo
    Dim groupKeys
    Dim rowsInGroup
    Dim descriptor
    Dim targetName
    Dim targetShortName
    Dim sheetName
    Dim newLtrg
    Dim oldLtrg
    Dim validNew
    Dim validOld
    Dim sourceIndex
    Dim direction
    Dim signedPension
    Dim signedBsav
    Dim signedTotal
    Dim currentRow
    Dim sectionRow
    Dim headerRow
    Dim dataStartRow
    Dim dataEndRow
    Dim subtotalRow
    Dim subtotalRefs
    Dim pass
    Dim i
    Dim j
    Dim amount
    Dim shouldWrite
    Dim counterpartyKey
    Dim overviewNameEscaped
    Dim ltrgNewLetter
    Dim ltrgOldLetter
    Dim totalLetter
    Dim bsavLetter
    Dim pensionLetter

    targetInfo = companies.Item(CStr(targetLtrg))
    targetName = CStr(targetInfo(1))
    targetShortName = ShortCompanyName(targetName)

    sheetName = UniqueSheetName(wb, BuildSheetName(targetLtrg, targetInfo(0)))
    Set ws = AddWorksheetAtEnd(wb)
    ws.Name = sheetName
    ApplyOverviewTemplateBase xlApp, ws

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = 1

    For i = 1 To UBound(transferData, 1)
        validNew = TryGetLong(transferData(i, 2), newLtrg)
        validOld = TryGetLong(transferData(i, 4), oldLtrg)

        If validNew And validOld Then
            If newLtrg <> oldLtrg Then
                amount = NzNumber(transferData(i, 10))

                If newLtrg = targetLtrg Then
                    If amount <> 0 Or INCLUDE_ZERO_ON_RECEIVER_SIDE Then
                        AddGroupRecord groups, CStr(oldLtrg), i, 1
                    End If
                End If

                If oldLtrg = targetLtrg Then
                    AddGroupRecord groups, CStr(newLtrg), i, -1
                End If
            End If
        End If
    Next

    ' Zeilen 1 bis 2 bilden den Berichtskopf: Logo links und Metadaten rechts.
    ws.Range("E1:F1").Merge
    ws.Range("E2:F2").Merge
    ws.Range("A4:F4").Merge
    ws.Range("A6:F6").Merge
    ws.Range("A7:F7").Merge

    ws.Range("E1").Value = ResolveOverviewTemplateText( _
        SafeString(ws.Range("E1").Value), _
        "Einzel�bertritte {{ZEITRAUM}}", _
        gReportPeriod, targetInfo(0), targetLtrg, targetShortName, "", "", 0)
    ws.Range("E2").Value = ResolveOverviewTemplateText( _
        SafeString(ws.Range("E2").Value), _
        "ARE {{ARE}} (LTRG {{LTRG}})", _
        gReportPeriod, targetInfo(0), targetLtrg, targetShortName, "", "", 0)
    ws.Range("A4").Value = ResolveOverviewTemplateText( _
        SafeString(ws.Range("A4").Value), _
        "�bertragene R�ckstellungen bei Einzel�bertritten", _
        gReportPeriod, targetInfo(0), targetLtrg, targetShortName, "", "", 0)
    ws.Range("A6").Value = ResolveOverviewTemplateText( _
        SafeString(ws.Range("A6").Value), _
        "Positive Betr�ge erh�lt die {{GESELLSCHAFT_KURZ}} von der genannten Gesellschaft,", _
        gReportPeriod, targetInfo(0), targetLtrg, targetShortName, "", "", 0)
    ws.Range("A7").Value = ResolveOverviewTemplateText( _
        SafeString(ws.Range("A7").Value), _
        "negative Betr�ge gibt die {{GESELLSCHAFT_KURZ}} an die genannte Gesellschaft ab.", _
        gReportPeriod, targetInfo(0), targetLtrg, targetShortName, "", "", 0)

    ws.Range("H1").Value = "CHECK"
    ws.Range("I1").Value = "ORZ, OK"
    ws.Range("H2").Value = targetLtrg
    ws.Range("I2").Value = targetInfo(0)
    ws.Range("J2").Value = targetName
    ws.Range("H3").Value = "CHECK"

    overviewNameEscaped = Replace(wsOverview.Name, "'", "''")
    ltrgNewLetter = ExcelColumnLetter(CLng(overviewLayout.Item("ltrg_new")))
    ltrgOldLetter = ExcelColumnLetter(CLng(overviewLayout.Item("ltrg_old")))

    If overviewLayout.Exists("total") Then
        totalLetter = ExcelColumnLetter(CLng(overviewLayout.Item("total")))
        ws.Range("H4").Formula = _
            "=SUMIFS('" & overviewNameEscaped & "'!$" & totalLetter & ":$" & totalLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & totalLetter & ":$" & totalLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)"
    Else
        bsavLetter = ExcelColumnLetter(CLng(overviewLayout.Item("bsav")))
        pensionLetter = ExcelColumnLetter(CLng(overviewLayout.Item("pension")))
        ws.Range("H4").Formula = _
            "=SUMIFS('" & overviewNameEscaped & "'!$" & bsavLetter & ":$" & bsavLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)+" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & pensionLetter & ":$" & pensionLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & bsavLetter & ":$" & bsavLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & pensionLetter & ":$" & pensionLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)"
    End If

    currentRow = 10
    subtotalRefs = ""

    If groups.Count > 0 Then
        groupKeys = groups.Keys
        SortGroupKeys groupKeys, groups, transferData, targetLtrg

        For i = 0 To UBound(groupKeys)
            counterpartyKey = CStr(groupKeys(i))
            counterpartyInfo = companies.Item(counterpartyKey)
            Set rowsInGroup = groups.Item(counterpartyKey)

            sectionRow = currentRow
            headerRow = sectionRow + 1
            dataStartRow = headerRow + 1

            PrepareOverviewSectionRows ws, sectionRow, headerRow
            ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
            ws.Cells(sectionRow, 1).Value = ResolveOverviewTemplateText( _
                SafeString(ws.Cells(sectionRow, 1).Value), _
                "{{GEGENPARTEI_KURZ}} (ARE {{GEGENPARTEI_ARE}}, LTRG {{GEGENPARTEI_LTRG}})", _
                gReportPeriod, targetInfo(0), targetLtrg, targetShortName, _
                ShortCompanyName(CStr(counterpartyInfo(1))), counterpartyInfo(0), _
                CLng(counterpartyKey))

            ws.Cells(sectionRow, 8).Value = CLng(counterpartyKey)
            ws.Cells(sectionRow, 9).Value = counterpartyInfo(0)
            ws.Cells(sectionRow, 10).Value = CStr(counterpartyInfo(1))

            SetCellDefaultIfBlank ws.Cells(headerRow, 1), "PNR" & vbLf
            SetCellDefaultIfBlank ws.Cells(headerRow, 2), "alte PNR" & vbLf
            SetCellDefaultIfBlank ws.Cells(headerRow, 3), "�bertritt" & vbLf
            SetCellDefaultIfBlank ws.Cells(headerRow, 4), "Pensionen (alt)" & vbLf & "(Euro)"
            SetCellDefaultIfBlank ws.Cells(headerRow, 5), "BSAV" & vbLf & "(Euro)"
            SetCellDefaultIfBlank ws.Cells(headerRow, 6), "Summe" & vbLf & "(Euro)"

            currentRow = dataStartRow

            For pass = 1 To 2
                For j = 0 To rowsInGroup.Count - 1
                    descriptor = rowsInGroup.Item(CStr(j))
                    sourceIndex = CLng(descriptor(0))
                    direction = CLng(descriptor(1))
                    signedTotal = direction * NzNumber(transferData(sourceIndex, 10))

                    shouldWrite = _
                        (pass = 1 And signedTotal > 0) Or _
                        (pass = 2 And signedTotal <= 0)

                    If shouldWrite Then
                        signedPension = direction * NzNumber(transferData(sourceIndex, 9))
                        signedBsav = direction * NzNumber(transferData(sourceIndex, 8))

                        ws.Cells(currentRow, 1).Value = transferData(sourceIndex, 1)
                        ws.Cells(currentRow, 2).Value = transferData(sourceIndex, 3)
                        ws.Cells(currentRow, 3).Value = transferData(sourceIndex, 5)
                        ws.Cells(currentRow, 4).Value = signedPension
                        ws.Cells(currentRow, 5).Value = signedBsav
                        ws.Cells(currentRow, 6).Value = signedTotal

                        currentRow = currentRow + 1
                    End If
                Next
            Next

            dataEndRow = currentRow - 1
            subtotalRow = currentRow

            ws.Cells(subtotalRow, 4).Formula = _
                "=SUM(D" & CStr(dataStartRow) & ":D" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 5).Formula = _
                "=SUM(E" & CStr(dataStartRow) & ":E" & CStr(dataEndRow) & ")"
            ws.Cells(subtotalRow, 6).Formula = _
                "=SUM(F" & CStr(dataStartRow) & ":F" & CStr(dataEndRow) & ")"

            subtotalRefs = subtotalRefs & "," & _
                           ws.Cells(subtotalRow, 6).Address(False, False)

            FormatSection ws, sectionRow, headerRow, dataStartRow, dataEndRow, subtotalRow
            currentRow = subtotalRow + 2
        Next
    End If

    If Len(subtotalRefs) > 0 Then
        ws.Range("I4").Formula = "=H4-SUM(" & Mid(subtotalRefs, 2) & ")"
    Else
        ws.Range("I4").Formula = "=H4"
        If groups.Count = 0 Then ws.Range("A10:F14").ClearContents
    End If

    FormatARESheet xlApp, ws, currentRow - 1
End Sub


Sub BuildExportFolders(ByVal fso, ByVal sourcePath, ByRef excelFolder, _
                       ByRef pdfFolder, ByRef serialFolder, _
                       ByRef individualFolder)
    Dim outputRoot
    Dim baseName
    Dim candidate
    Dim stamp
    Dim counter

    ' Alle Ergebnisse liegen gesammelt neben dem Starter im Ordner Output.
    outputRoot = fso.BuildPath(gProjectFolder, "Output")
    If Not fso.FolderExists(outputRoot) Then fso.CreateFolder outputRoot

    baseName = SanitizeFileName(fso.GetBaseName(sourcePath))
    stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
            "_" & TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & _
            TwoDigits(Second(Now))
    candidate = fso.BuildPath(outputRoot, baseName & "_ARE_Export_" & stamp)

    counter = 2
    Do While fso.FolderExists(candidate) Or fso.FileExists(candidate)
        candidate = fso.BuildPath(outputRoot, baseName & "_ARE_Export_" & _
                                  stamp & "_" & CStr(counter))
        counter = counter + 1
    Loop

    fso.CreateFolder candidate
    gExportFolder = candidate

    excelFolder = fso.BuildPath(candidate, "00_Excel")
    pdfFolder = fso.BuildPath(candidate, "01_ARE_PDF")
    serialFolder = fso.BuildPath(candidate, "02_Serienbrief_Gesamt")
    individualFolder = fso.BuildPath(candidate, "03_Serienbrief_Einzel")

    fso.CreateFolder excelFolder
    fso.CreateFolder pdfFolder
    fso.CreateFolder serialFolder
    fso.CreateFolder individualFolder
End Sub

Sub ExportGeneratedSheetsAsPdf(ByVal wb, ByVal fso, ByVal pdfFolder)
    Dim i
    Dim ws
    Dim pdfPath
    Dim exportCount
    Dim sheetName
    Dim disabledPeerReviewAddIns
    Dim exportErrorNumber
    Dim exportErrorDescription
    Dim exportErrorSource

    exportCount = 0
    exportErrorNumber = 0
    exportErrorDescription = ""
    exportErrorSource = ""

    ' In der Mercer-Umgebung kann das Peer-Review-Add-in einen sichtbaren
    ' "Not Peer Reviewed"-Stempel und einen Rahmen in Druck/PDF-Ausgaben
    ' einblenden. Das Logo selbst wird dagegen direkt per Shapes.AddPicture
    ' aus der PNG/JPG-Datei eingefuegt. Deshalb deaktivieren wir nur ein
    ' eindeutig erkanntes Peer-Review-COM-Add-in fuer die Dauer des Exports.
    Set disabledPeerReviewAddIns = TemporarilyDisablePeerReviewAddIns(gExcel)

    On Error Resume Next
    Err.Clear

    For i = 1 To wb.Worksheets.Count
        Set ws = wb.Worksheets(i)
        sheetName = SafeString(ws.Name)

        If Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", 1) > 0 Then

            gStage = "ARE-PDF fuer Blatt " & sheetName & " bereinigen und exportieren"
            gExcel.StatusBar = gStage & " ..."

            ' Sicherheitsnetz direkt vor jedem PDF-Export. Selbst wenn ein
            ' Add-in oder eine Vorlage vorher ein zusaetzliches Objekt erzeugt
            ' hat, darf im ARE-Bericht nur das explizite Marsh-Logo verbleiben.
            CleanARESheetForPdfExport ws

            pdfPath = UniqueFilePath( _
                fso, _
                pdfFolder, _
                "ERG_VW" & Chr(220) & "_" & SanitizeFileName(sheetName), _
                "pdf" _
            )

            Err.Clear
            ws.ExportAsFixedFormat xlTypePDF, pdfPath, xlQualityStandard, True, False
            If Err.Number <> 0 Then
                exportErrorNumber = Err.Number
                exportErrorDescription = Err.Description
                exportErrorSource = Err.Source
                Err.Clear
                Exit For
            End If

            exportCount = exportCount + 1
            WriteLog "ARE-PDF | " & pdfPath
        End If
    Next

    Err.Clear
    On Error GoTo 0

    ' Add-in-Zustand in derselben Excel-Instanz sofort wiederherstellen.
    RestorePeerReviewAddIns gExcel, disabledPeerReviewAddIns

    If exportErrorNumber <> 0 Then
        Err.Raise exportErrorNumber, exportErrorSource, exportErrorDescription
    End If

    If exportCount = 0 Then
        Err.Raise -2147221504 + 2040, "ARE Generator", _
                  "Es wurden keine erzeugten ARE-Blatter fuer den PDF-Export gefunden."
    End If

    WriteLog "INFO | " & CStr(exportCount) & " ARE-Blaetter als PDF exportiert"
End Sub

Function TemporarilyDisablePeerReviewAddIns(ByVal xlApp)
    Dim disabled
    Dim addInItem
    Dim indexValue
    Dim progId
    Dim descriptionValue
    Dim combinedText
    Dim wasConnected

    Set disabled = CreateObject("Scripting.Dictionary")
    disabled.CompareMode = 1

    On Error Resume Next
    Err.Clear

    For indexValue = 1 To xlApp.COMAddIns.Count
        Set addInItem = Nothing
        Set addInItem = xlApp.COMAddIns.Item(indexValue)
        If Err.Number = 0 And Not addInItem Is Nothing Then
            progId = SafeString(addInItem.ProgId)
            descriptionValue = SafeString(addInItem.Description)
            combinedText = LCase(progId & " " & descriptionValue)

            If InStr(1, combinedText, "peer", 1) > 0 And _
               InStr(1, combinedText, "review", 1) > 0 Then

                wasConnected = False
                Err.Clear
                wasConnected = CBool(addInItem.Connect)
                If Err.Number = 0 And wasConnected Then
                    Err.Clear
                    addInItem.Connect = False
                    If Err.Number = 0 Then
                        If Not disabled.Exists(progId) Then disabled.Add progId, True
                        WriteLog "INFO | Peer-Review-COM-Add-in fuer ARE-PDF-Export temporaer deaktiviert: " & _
                                 progId & " | " & descriptionValue
                    Else
                        WriteLog "WARNUNG | Peer-Review-COM-Add-in konnte nicht deaktiviert werden: " & _
                                 progId & " | " & Err.Description
                    End If
                End If
            End If
        End If
        Err.Clear
    Next

    Err.Clear
    On Error GoTo 0
    Set TemporarilyDisablePeerReviewAddIns = disabled
End Function

Sub RestorePeerReviewAddIns(ByVal xlApp, ByVal disabled)
    Dim addInItem
    Dim indexValue
    Dim progId

    If Not IsObject(disabled) Then Exit Sub
    If disabled Is Nothing Then Exit Sub
    If disabled.Count = 0 Then Exit Sub

    On Error Resume Next
    Err.Clear

    For indexValue = 1 To xlApp.COMAddIns.Count
        Set addInItem = Nothing
        Set addInItem = xlApp.COMAddIns.Item(indexValue)
        If Err.Number = 0 And Not addInItem Is Nothing Then
            progId = SafeString(addInItem.ProgId)
            If disabled.Exists(progId) Then
                Err.Clear
                addInItem.Connect = True
                If Err.Number = 0 Then
                    WriteLog "INFO | Peer-Review-COM-Add-in nach ARE-PDF-Export wieder aktiviert: " & progId
                Else
                    WriteLog "WARNUNG | Peer-Review-COM-Add-in konnte nicht automatisch wieder aktiviert werden: " & _
                             progId & " | " & Err.Description
                End If
            End If
        End If
        Err.Clear
    Next

    Err.Clear
    On Error GoTo 0
End Sub

Sub CleanARESheetForPdfExport(ByVal ws)
    Dim shapeIndex
    Dim shapeName
    Dim lastPrintRow
    Dim rowNumber
    Dim columnNumber
    Dim cellText

    ' Auf einem generierten ARE-Blatt ist das einzige benoetigte Shape das
    ' bewusst eingefuegte Marsh-Logo. Alle anderen Zeichenobjekte werden
    ' unmittelbar vor dem PDF-Export entfernt.
    On Error Resume Next
    For shapeIndex = ws.Shapes.Count To 1 Step -1
        shapeName = SafeString(ws.Shapes(shapeIndex).Name)
        If LCase(shapeName) <> LCase("ARE_Mercer_Logo") Then
            ws.Shapes(shapeIndex).Delete
        End If
        Err.Clear
    Next

    ' Druckkopf/-fuss vollstaendig neutralisieren. So koennen auch ueber
    ' PageSetup eingeblendete Stempel nicht in das ARE-PDF gelangen.
    With ws.PageSetup
        .LeftHeader = ""
        .CenterHeader = ""
        .RightHeader = ""
        .LeftFooter = ""
        .CenterFooter = ""
        .RightFooter = ""
        .PrintComments = xlNone
    End With

    ' Falls ein Add-in den Hinweis als Zellinhalt statt als Shape setzt,
    ' entfernen wir nur den eindeutig erkennbaren Peer-Review-Text.
    lastPrintRow = GetAREPrintLastRow(ws)
    For rowNumber = 1 To lastPrintRow
        For columnNumber = 1 To 6
            cellText = LCase(Trim(SafeString(ws.Cells(rowNumber, columnNumber).Value)))
            If InStr(1, cellText, "not peer review", 1) > 0 Then
                ws.Cells(rowNumber, columnNumber).ClearContents
            End If
        Next
    Next

    ' Ein aeusserer Rahmen um den gesamten Druckbereich gehoert nicht zum
    ' Fachlayout. Abschnitts-/Tabellenrahmen im Inneren bleiben unberuehrt.
    With ws.Range("A1:F" & CStr(lastPrintRow))
        .Borders(xlEdgeLeft).LineStyle = xlNone
        .Borders(xlEdgeTop).LineStyle = xlNone
        .Borders(xlEdgeRight).LineStyle = xlNone
        .Borders(xlEdgeBottom).LineStyle = xlNone
    End With

    Err.Clear
    On Error GoTo 0
End Sub

Function GetAREPrintLastRow(ByVal ws)
    Dim printAreaText
    Dim lastRow
    Dim usedLastRow
    Dim colonPosition
    Dim rightPart
    Dim rowText
    Dim indexValue
    Dim charValue

    lastRow = 0

    On Error Resume Next
    printAreaText = SafeString(ws.PageSetup.PrintArea)
    Err.Clear
    On Error GoTo 0

    ' Typischer PrintArea-Wert: $A$1:$F$44. Daraus die letzte Zeilennummer
    ' extrahieren; bei Sonderfaellen auf UsedRange zurueckfallen.
    colonPosition = InStrRev(printAreaText, ":")
    If colonPosition > 0 Then
        rightPart = Mid(printAreaText, colonPosition + 1)
        rowText = ""
        For indexValue = 1 To Len(rightPart)
            charValue = Mid(rightPart, indexValue, 1)
            If charValue >= "0" And charValue <= "9" Then rowText = rowText & charValue
        Next
        If Len(rowText) > 0 Then
            If IsNumeric(rowText) Then lastRow = CLng(rowText)
        End If
    End If

    If lastRow < 1 Then
        On Error Resume Next
        usedLastRow = CLng(ws.UsedRange.Row) + CLng(ws.UsedRange.Rows.Count) - 1
        If Err.Number = 0 Then lastRow = usedLastRow
        Err.Clear
        On Error GoTo 0
    End If

    If lastRow < 1 Then lastRow = 100
    GetAREPrintLastRow = lastRow
End Function

Sub EnsureWordApplication()
    Dim wordAlive
    Dim probeValue

    wordAlive = False

    ' Eine COM-Referenz kann noch als Objekt existieren, obwohl Word bereits
    ' beendet/abgestuerzt ist. Genau dann entsteht Fehler -2147417848
    ' ("object disconnected from its clients"). Deshalb die Referenz aktiv
    ' anpingen, bevor sie weiterverwendet wird.
    On Error Resume Next
    Err.Clear
    If IsObject(gWord) Then
        probeValue = gWord.Version
        If Err.Number = 0 Then wordAlive = True
    End If
    Err.Clear
    On Error GoTo 0

    If CBool(wordAlive) Then Exit Sub

    On Error Resume Next
    Set gWord = Nothing
    Err.Clear
    On Error GoTo 0

    Set gWord = CreateObject("Word.Application")
    gWord.Visible = False
    gWord.DisplayAlerts = 0
    WriteLog "WORD | Neue bzw. wiederhergestellte Word-Instanz gestartet"
End Sub

Function IsGeneratedARESheet(ByVal sheetName)
    sheetName = SafeString(sheetName)
    IsGeneratedARESheet = _
        (Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
         InStr(1, sheetName, "(LTRG ", 1) > 0)
End Function

Function PrepareARELogos(ByVal xlApp, ByVal wb, ByVal fso, ByVal projectFolder)
    Dim logoCount
    Dim logoPath

    logoCount = 0
    logoPath = FindLocalLogoFile(fso, CStr(projectFolder))

    If Len(logoPath) > 0 Then
        WriteLog "LOGO | Lokale Datei erkannt: " & logoPath
    Else
        WriteLog "WARNUNG | Keine Logo-Datei im Ordner docs gefunden."
        logoPath = xlApp.GetOpenFilename( _
            "Logo-Bild (*.png;*.jpg;*.jpeg),*.png;*.jpg;*.jpeg", _
            1, _
            "Mercer-Logo ausw�hlen - empfohlen: docs\Bild 1.png" _
        )

        If VarType(logoPath) = vbBoolean Then
            Err.Raise -2147221504 + 2041, "ARE Generator", _
                      "Das Mercer-Logo wurde nicht gefunden. Speichern Sie das Logo als " & _
                      "'Bild 1.png', 'Bild 1.jpg' oder 'Bild 1.jpeg' im Ordner docs " & _
                      "oder w�hlen Sie es im Dateidialog aus."
        End If
    End If

    logoCount = InsertLogoFileIntoGeneratedSheets(wb, CStr(logoPath))
    gLogoSourceDescription = "Bilddatei " & fso.GetFileName(CStr(logoPath))

    If logoCount = 0 Then
        Err.Raise -2147221504 + 2042, "ARE Generator", _
                  "Das Mercer-Logo konnte auf keinem ARE-Blatt eingef�gt werden."
    End If

    PrepareARELogos = logoCount
End Function

Function FindLocalLogoFile(ByVal fso, ByVal projectFolder)
    Dim extensionItem
    Dim candidatePath
    Dim preferredNames
    Dim nameItem
    Dim docsFolder
    Dim searchFolders
    Dim folderItem

    FindLocalLogoFile = ""
    preferredNames = Array("Bild 1", "Mercer Logo", "Mercer_Logo")
    docsFolder = fso.BuildPath(CStr(projectFolder), "docs")

    ' Ab Version 1.0.11 ist docs der feste Logo-Ordner.
    ' Der Projektstamm bleibt nur als Abw�rtskompatibilit�t erhalten.
    searchFolders = Array(docsFolder, CStr(projectFolder))

    For Each folderItem In searchFolders
        For Each nameItem In preferredNames
            For Each extensionItem In Array("png", "jpg", "jpeg")
                candidatePath = fso.BuildPath(CStr(folderItem), _
                                CStr(nameItem) & "." & CStr(extensionItem))
                If fso.FileExists(candidatePath) Then
                    FindLocalLogoFile = candidatePath
                    Exit Function
                End If
            Next
        Next
    Next
End Function

Function InsertLogoFileIntoGeneratedSheets(ByVal wb, ByVal logoPath)
    Dim ws
    Dim logoShape
    Dim logoCount

    logoCount = 0

    For Each ws In wb.Worksheets
        If IsGeneratedARESheet(ws.Name) Then
            RemoveExistingARELogo ws
            Set logoShape = Nothing

            On Error Resume Next
            Err.Clear
            Set logoShape = ws.Shapes.AddPicture( _
                CStr(logoPath), msoFalse, msoTrue, _
                ws.Range("A1").Left, ws.Range("A1").Top, -1, -1 _
            )
            Err.Clear
            On Error GoTo 0

            If Not logoShape Is Nothing Then
                PositionARELogo ws, logoShape
                logoCount = logoCount + 1
            End If
        End If
    Next

    InsertLogoFileIntoGeneratedSheets = logoCount
End Function

Sub PositionARELogo(ByVal ws, ByVal logoShape)
    Dim anchorCell
    Dim logoHeight
    Dim leftOffset
    Dim topOffset

    anchorCell = GetTemplateConfigText("LOGO_ANCHOR", "A1")
    logoHeight = GetTemplateConfigNumber("LOGO_HEIGHT", 34)
    ' Migration des bisherigen Standardwerts: 42 pt war optisch zu gross.
    ' Eigene Werte im CONFIG-Blatt bleiben unveraendert; nur der alte Standard 42
    ' wird automatisch auf 34 pt verkleinert.
    If Abs(CDbl(logoHeight) - 42) < 0.01 Then logoHeight = 34
    leftOffset = GetTemplateConfigNumber("LOGO_LEFT_OFFSET", 0)
    topOffset = GetTemplateConfigNumber("LOGO_TOP_OFFSET", 2)

    On Error Resume Next
    logoShape.Name = "ARE_Mercer_Logo"
    logoShape.LockAspectRatio = msoTrue
    logoShape.Height = CDbl(logoHeight)
    logoShape.Left = ws.Range(CStr(anchorCell)).Left + CDbl(leftOffset)
    logoShape.Top = ws.Range(CStr(anchorCell)).Top + CDbl(topOffset)
    logoShape.Placement = 1
    Err.Clear
    On Error GoTo 0
End Sub

Sub RemoveExistingARELogo(ByVal ws)
    Dim shapeIndex
    Dim shapeName
    Dim shapeType
    Dim isPictureInLogoArea

    For shapeIndex = ws.Shapes.Count To 1 Step -1
        shapeName = SafeString(ws.Shapes(shapeIndex).Name)
        shapeType = 0
        isPictureInLogoArea = False

        On Error Resume Next
        Err.Clear
        shapeType = CLng(ws.Shapes(shapeIndex).Type)
        If Err.Number = 0 Then
            If shapeType = msoPicture Or shapeType = msoLinkedPicture Then
                isPictureInLogoArea = _
                    (CDbl(ws.Shapes(shapeIndex).Left) < CDbl(ws.Range("D1").Left) And _
                     CDbl(ws.Shapes(shapeIndex).Top) < CDbl(ws.Range("A5").Top))
            End If
        End If
        Err.Clear
        On Error GoTo 0

        If Left(shapeName, 16) = "ARE_Mercer_Logo" Or isPictureInLogoArea Then
            On Error Resume Next
            ws.Shapes(shapeIndex).Delete
            Err.Clear
            On Error GoTo 0
        End If
    Next
End Sub

Sub GenerateSerialLetters(ByVal xlApp, ByVal fso, ByVal templatePath, _
                          ByVal dataPath, ByVal serialFolder, _
                          ByVal individualFolder, ByVal pdfFolder, _
                          ByRef mergeCount, ByRef aggregateDocxPath, _
                          ByRef aggregatePdfPath)
    Dim nativeErrorNumber
    Dim nativeErrorDescription
    Dim nativeErrorSource

    On Error Resume Next
    Err.Clear
    gAREPdfAttachmentsComplete = False
    GenerateSerialLettersNative xlApp, fso, templatePath, dataPath, _
                                serialFolder, individualFolder, pdfFolder, mergeCount, _
                                aggregateDocxPath, aggregatePdfPath
    nativeErrorNumber = Err.Number
    nativeErrorDescription = Err.Description
    nativeErrorSource = Err.Source
    Err.Clear
    On Error GoTo 0

    If nativeErrorNumber <> 0 Then
        If SerialOutputsComplete(fso, aggregateDocxPath, aggregatePdfPath, _
                                 individualFolder, mergeCount) And _
           CBool(gAREPdfAttachmentsComplete) Then
            WriteLog "WARNUNG | Word-COM meldete nach vollst�ndiger Ausgabe einen Fehler. " & _
                     "Der Lauf wird als erfolgreich gewertet. Nummer=" & _
                     CStr(nativeErrorNumber) & " | Quelle=" & nativeErrorSource & _
                     " | Beschreibung=" & nativeErrorDescription
            gStage = "Serienbrief vollst�ndig erstellt"
            CloseWordSafely
            xlApp.StatusBar = False
            Exit Sub
        End If

        gStage = "Nativer Serienbrief unvollst�ndig - Fallback starten"
        WriteLog "WARNUNG | Nativer Word-Seriendruck unvollst�ndig. " & _
                 "Nummer=" & CStr(nativeErrorNumber) & _
                 " | Quelle=" & nativeErrorSource & _
                 " | Beschreibung=" & nativeErrorDescription & _
                 " | Fallback auf kompatiblen Feldmodus."

        CloseWordSafely
        DeleteFileIfExists fso, aggregateDocxPath
        DeleteFileIfExists fso, aggregatePdfPath
        DeleteFilesInFolder fso, individualFolder
        gAREPdfAttachmentsComplete = False
        GenerateSerialLettersLegacy xlApp, fso, templatePath, dataPath, _
                                    serialFolder, individualFolder, pdfFolder, mergeCount, _
                                    aggregateDocxPath, aggregatePdfPath
    End If
End Sub

Function SerialOutputsComplete(ByVal fso, ByVal aggregateDocxPath, _
                               ByVal aggregatePdfPath, ByVal individualFolder, _
                               ByVal expectedCount)
    Dim pdfCount
    Dim docxCount

    SerialOutputsComplete = False

    If CLng(expectedCount) < 1 Then Exit Function
    If Len(SafeString(aggregateDocxPath)) = 0 Then Exit Function
    If Len(SafeString(aggregatePdfPath)) = 0 Then Exit Function
    If Not FileExistsAndHasContent(fso, CStr(aggregateDocxPath)) Then Exit Function
    If Not FileExistsAndHasContent(fso, CStr(aggregatePdfPath)) Then Exit Function

    pdfCount = CountFilesByExtension(fso, CStr(individualFolder), "pdf")
    docxCount = CountFilesByExtension(fso, CStr(individualFolder), "docx")
    WriteLog "PR�FUNG | Serienbrief-Ausgaben vorhanden: Gesamt-DOCX=ja" & _
             " | Gesamt-PDF=ja | Einzel-PDFs=" & CStr(pdfCount) & _
             " | Einzel-DOCX=" & CStr(docxCount) & _
             " | erwartet=" & CStr(expectedCount)

    If CLng(pdfCount) >= CLng(expectedCount) And _
       CLng(docxCount) >= CLng(expectedCount) Then
        SerialOutputsComplete = True
    End If
End Function

Function FileExistsAndHasContent(ByVal fso, ByVal filePath)
    Dim fileObject

    FileExistsAndHasContent = False

    On Error Resume Next
    If fso.FileExists(CStr(filePath)) Then
        Set fileObject = fso.GetFile(CStr(filePath))
        If Err.Number = 0 Then
            If CLng(fileObject.Size) > 0 Then
                FileExistsAndHasContent = True
            End If
        End If
    End If
    Set fileObject = Nothing
    Err.Clear
    On Error GoTo 0
End Function

Function CountFilesByExtension(ByVal fso, ByVal folderPath, ByVal extensionValue)
    Dim folderItem
    Dim fileItem
    Dim countValue

    countValue = 0

    On Error Resume Next
    If fso.FolderExists(CStr(folderPath)) Then
        Set folderItem = fso.GetFolder(CStr(folderPath))
        For Each fileItem In folderItem.Files
            If LCase(fso.GetExtensionName(fileItem.Name)) = LCase(CStr(extensionValue)) Then
                If CLng(fileItem.Size) > 0 Then countValue = countValue + 1
            End If
        Next
    End If
    Set fileItem = Nothing
    Set folderItem = Nothing
    Err.Clear
    On Error GoTo 0

    CountFilesByExtension = countValue
End Function

Function CountPdfFilesInFolder(ByVal fso, ByVal folderPath)
    CountPdfFilesInFolder = CountFilesByExtension(fso, folderPath, "pdf")
End Function

Sub GenerateSerialLettersNative(ByVal xlApp, ByVal fso, ByVal templatePath, _
                                ByVal dataPath, ByVal serialFolder, _
                                ByVal individualFolder, ByVal pdfFolder, _
                                ByRef mergeCount, ByRef aggregateDocxPath, _
                                ByRef aggregatePdfPath)
    Dim headers
    Dim dataRows
    Dim filteredRows
    Dim rowCount
    Dim filteredCount
    Dim columnCount
    Dim dataSheetName
    Dim mergeDataPath
    Dim mainDoc
    Dim mergedDoc
    Dim aggregateDoc
    Dim mailMerge
    Dim sqlStatement
    Dim recordIndex
    Dim ltrgValue
    Dim areValue
    Dim ltrgNumber
    Dim ltrgColumn
    Dim areColumn
    Dim individualPdfPath
    Dim individualDocxPath
    Dim tempLetterPath
    Dim letterDocsByLtrg

    gStage = "Serienbriefdaten einlesen und auf betroffene Gesellschaften filtern"
    LoadSerialData xlApp, dataPath, headers, dataRows, rowCount, _
                   columnCount, dataSheetName
    FilterSerialDataToAffectedCompanies headers, dataRows, rowCount, columnCount, _
                                        filteredRows, filteredCount, ltrgColumn, areColumn

    If filteredCount < 1 Then
        Err.Raise -2147221504 + 2051, "ARE Generator", _
                  "In der Personendatei wurde keine Zeile f�r eine tats�chlich betroffene LTRG gefunden. " & _
                  "Betroffene LTRG: " & JoinDictionaryKeys(gAffectedLtrgs, ", ")
    End If

    mergeCount = filteredCount
    aggregateDocxPath = UniqueFilePath(fso, serialFolder, "Anschreiben_ARE_Gesamt", "docx")
    aggregatePdfPath = UniqueFilePath(fso, serialFolder, "Anschreiben_ARE_Gesamt", "pdf")

    gStage = "Tempor�re gefilterte Serienbrief-Datenquelle erstellen"
    mergeDataPath = BuildNativeMergeDataSource(xlApp, fso, headers, filteredRows, _
                                                filteredCount, columnCount)

    gStage = "Microsoft Word starten"
    EnsureWordApplication

    Set mainDoc = gWord.Documents.Open(CStr(templatePath), False, True)
    Set mailMerge = mainDoc.MailMerge

    If mailMerge.Fields.Count = 0 Then
        mainDoc.Close wdDoNotSaveChanges
        DeleteFileIfExists fso, mergeDataPath
        Err.Raise -2147221504 + 2052, "ARE Generator", _
                  "In der DOCX-Vorlage wurden keine Word-Seriendruckfelder (MERGEFIELD) gefunden."
    End If

    sqlStatement = "SELECT * FROM [Daten$]"
    mailMerge.OpenDataSource CStr(mergeDataPath), wdOpenFormatAuto, _
                             False, True, True, False, "", "", False, _
                             "", "", "", sqlStatement, "", wdMergeSubTypeOther
    mailMerge.Destination = wdSendToNewDocument
    mailMerge.SuppressBlankLines = True
    Set aggregateDoc = Nothing
    Set letterDocsByLtrg = CreateObject("Scripting.Dictionary")
    letterDocsByLtrg.CompareMode = 1

    For recordIndex = 1 To filteredCount
        gStage = "Anschreiben und �bersicht " & CStr(recordIndex) & _
                 " von " & CStr(filteredCount) & " nativ erstellen"
        xlApp.StatusBar = gStage & " ..."

        mainDoc.Activate
        mailMerge.DataSource.FirstRecord = recordIndex
        mailMerge.DataSource.LastRecord = recordIndex
        mailMerge.Execute False
        Set mergedDoc = gWord.ActiveDocument
        OptimizeMergedLetterLayout mergedDoc

        If Not TryGetLong(filteredRows(recordIndex, ltrgColumn), ltrgNumber) Then
            CloseWordDocumentSafely mergedDoc
            Err.Raise -2147221504 + 2054, "ARE Generator", _
                      "Die LTRG des gefilterten Serienbrief-Datensatzes " & CStr(recordIndex) & _
                      " ist nicht numerisch: '" & SafeString(filteredRows(recordIndex, ltrgColumn)) & "'."
        End If

        ' Vor dem Anhaengen der ARE-Uebersicht eine reine Anschreiben-Kopie sichern.
        ' Diese wird spaeter hinter die jeweilige ARE-PDF gesetzt.
        tempLetterPath = SaveLetterOnlyTempCopy(fso, mergedDoc, ltrgNumber, recordIndex)
        AddLetterTempPath letterDocsByLtrg, ltrgNumber, tempLetterPath

        AppendAREOverviewToDocument xlApp, mergedDoc, ltrgNumber

        ltrgValue = SanitizeFileName(SafeString(filteredRows(recordIndex, ltrgColumn)))
        areValue = SanitizeFileName(SafeString(filteredRows(recordIndex, areColumn)))
        If Len(ltrgValue) = 0 Then ltrgValue = FormatLtrg(ltrgNumber)
        If Len(areValue) = 0 Then areValue = GetAREValueForLtrg(gWorkbook, ltrgNumber)
        If Len(areValue) = 0 Then areValue = "ohne_ARE"

        individualDocxPath = UniqueFilePath(fso, individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, "docx")
        individualPdfPath = UniqueFilePath(fso, individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, "pdf")

        mergedDoc.SaveAs2 individualDocxPath, wdFormatXMLDocument
        mergedDoc.ExportAsFixedFormat individualPdfPath, wdExportFormatPDF
        WriteLog "EINZEL-DOCX-NATIV | LTRG=" & CStr(ltrgNumber) & " | Datei=" & individualDocxPath
        WriteLog "EINZEL-PDF-NATIV | LTRG=" & CStr(ltrgNumber) & " | Datei=" & individualPdfPath

        CloseWordDocumentSafely mergedDoc
        AppendDocumentFileToAggregate gWord, aggregateDoc, individualDocxPath
    Next

    gStage = "ARE-PDFs mit zugehoerigen Anschreiben vervollstaendigen"
    FinalizeAREPdfsWithLetters xlApp, fso, pdfFolder, letterDocsByLtrg

    gStage = "Gesamt-Serienbrief mit angeh�ngten �bersichten speichern"
    OptimizeMergedLetterLayout aggregateDoc
    aggregateDoc.SaveAs2 aggregateDocxPath, wdFormatXMLDocument
    aggregateDoc.ExportAsFixedFormat aggregatePdfPath, wdExportFormatPDF
    CloseWordDocumentSafely aggregateDoc

    CloseWordDocumentSafely mainDoc
    Set mailMerge = Nothing
    DeleteFileIfExists fso, mergeDataPath

    WriteLog "SERIENBRIEF-MODUS | Nativer Microsoft-Word-Seriendruck, gefiltert auf betroffene LTRG"
    WriteLog "SERIENBRIEF-GESAMT-DOCX | " & aggregateDocxPath
    WriteLog "SERIENBRIEF-GESAMT-PDF | " & aggregatePdfPath
    CloseWordSafely
    xlApp.StatusBar = False
End Sub

Function BuildNativeMergeDataSource(ByVal xlApp, ByVal fso, ByRef headers, _
                                    ByRef dataRows, ByVal rowCount, _
                                    ByVal columnCount)
    Dim tempFolder
    Dim tempPath
    Dim tempWorkbook
    Dim tempSheet
    Dim rowIndex
    Dim columnIndex
    Dim stamp

    tempFolder = fso.GetSpecialFolder(2)
    stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
            TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & _
            TwoDigits(Second(Now))
    tempPath = fso.BuildPath(tempFolder, _
        "ARE_Serienbrief_Daten_" & stamp & "_" & CStr(Int(Rnd * 100000)) & ".xlsx")

    Set tempWorkbook = xlApp.Workbooks.Add
    Set tempSheet = tempWorkbook.Worksheets(1)
    tempSheet.Name = "Daten"

    For columnIndex = 1 To columnCount
        tempSheet.Cells(1, columnIndex).Value = SafeString(headers(columnIndex))
    Next

    For rowIndex = 1 To rowCount
        For columnIndex = 1 To columnCount
            tempSheet.Cells(rowIndex + 1, columnIndex).NumberFormat = "@"
            tempSheet.Cells(rowIndex + 1, columnIndex).Value = _
                SafeString(dataRows(rowIndex, columnIndex))
        Next
    Next

    tempWorkbook.SaveAs tempPath, xlOpenXMLWorkbook
    tempWorkbook.Close False
    Set tempSheet = Nothing
    Set tempWorkbook = Nothing

    BuildNativeMergeDataSource = tempPath
End Function

Sub OptimizeMergedLetterLayout(ByVal doc)
    Dim paragraphItem
    Dim paragraphText

    ' Der native Seriendruck �bernimmt das Vorlagenlayout. Diese kleine
    ' Nachbearbeitung verhindert, dass die Schlusszeile "Anlage" wegen
    ' unn�tigem Absatzabstand allein auf eine zweite Seite rutscht.
    For Each paragraphItem In doc.Paragraphs
        paragraphText = Trim(Replace(Replace( _
            SafeString(paragraphItem.Range.Text), vbCr, ""), Chr(7), ""))
        If LCase(Left(paragraphText, 6)) = "anlage" Then
            paragraphItem.Format.SpaceBefore = 0
            paragraphItem.Format.SpaceAfter = 0
            paragraphItem.KeepTogether = True
        End If
    Next

    On Error Resume Next
    doc.Repaginate
    Err.Clear
    On Error GoTo 0
End Sub

Sub DeleteFilesInFolder(ByVal fso, ByVal folderPath)
    Dim folderItem
    Dim fileItem

    On Error Resume Next
    If fso.FolderExists(CStr(folderPath)) Then
        Set folderItem = fso.GetFolder(CStr(folderPath))
        For Each fileItem In folderItem.Files
            fileItem.Delete True
        Next
    End If
    Set fileItem = Nothing
    Set folderItem = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Sub DeleteFileIfExists(ByVal fso, ByVal filePath)
    On Error Resume Next
    If Len(SafeString(filePath)) > 0 Then
        If fso.FileExists(CStr(filePath)) Then fso.DeleteFile CStr(filePath), True
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Sub GenerateSerialLettersLegacy(ByVal xlApp, ByVal fso, ByVal templatePath, _
                          ByVal dataPath, ByVal serialFolder, _
                          ByVal individualFolder, ByVal pdfFolder, _
                          ByRef mergeCount, ByRef aggregateDocxPath, _
                          ByRef aggregatePdfPath)
    Dim headers
    Dim dataRows
    Dim filteredRows
    Dim rowCount
    Dim filteredCount
    Dim columnCount
    Dim dataSheetName
    Dim recordIndex
    Dim personDoc
    Dim aggregateDoc
    Dim individualPdfPath
    Dim individualDocxPath
    Dim areValue
    Dim ltrgValue
    Dim ltrgNumber
    Dim ltrgColumn
    Dim areColumn
    Dim filledFieldCount
    Dim tempLetterPath
    Dim letterDocsByLtrg

    gStage = "Serienbriefdaten einlesen und auf betroffene Gesellschaften filtern"
    LoadSerialData xlApp, dataPath, headers, dataRows, rowCount, columnCount, dataSheetName
    FilterSerialDataToAffectedCompanies headers, dataRows, rowCount, columnCount, _
                                        filteredRows, filteredCount, ltrgColumn, areColumn

    If filteredCount < 1 Then
        Err.Raise -2147221504 + 2051, "ARE Generator", _
                  "In der Personendatei wurde keine Zeile f�r eine tats�chlich betroffene LTRG gefunden."
    End If

    mergeCount = filteredCount
    aggregateDocxPath = UniqueFilePath(fso, serialFolder, "Anschreiben_ARE_Gesamt", "docx")
    aggregatePdfPath = UniqueFilePath(fso, serialFolder, "Anschreiben_ARE_Gesamt", "pdf")

    gStage = "Microsoft Word starten"
    EnsureWordApplication
    Set aggregateDoc = Nothing
    Set letterDocsByLtrg = CreateObject("Scripting.Dictionary")
    letterDocsByLtrg.CompareMode = 1

    For recordIndex = 1 To filteredCount
        gStage = "Anschreiben und �bersicht " & CStr(recordIndex) & _
                 " von " & CStr(filteredCount) & " im Fallback erstellen"
        xlApp.StatusBar = gStage & " ..."

        Set personDoc = gWord.Documents.Open(CStr(templatePath), False, True)
        filledFieldCount = 0
        FillMergeFieldsInDocument personDoc, headers, filteredRows, _
                                  recordIndex, columnCount, filledFieldCount

        If recordIndex = 1 And filledFieldCount = 0 Then
            personDoc.Close wdDoNotSaveChanges
            Set personDoc = Nothing
            Err.Raise -2147221504 + 2052, "ARE Generator", _
                      "In der DOCX-Vorlage wurden keine Word-Seriendruckfelder (MERGEFIELD) gefunden."
        End If

        If Not TryGetLong(filteredRows(recordIndex, ltrgColumn), ltrgNumber) Then
            CloseWordDocumentSafely personDoc
            Err.Raise -2147221504 + 2054, "ARE Generator", _
                      "Die LTRG des gefilterten Serienbrief-Datensatzes " & CStr(recordIndex) & _
                      " ist nicht numerisch."
        End If

        OptimizeMergedLetterLayout personDoc

        ' Reine Anschreiben-Kopie fuer die finale ARE-PDF sichern.
        tempLetterPath = SaveLetterOnlyTempCopy(fso, personDoc, ltrgNumber, recordIndex)
        AddLetterTempPath letterDocsByLtrg, ltrgNumber, tempLetterPath

        AppendAREOverviewToDocument xlApp, personDoc, ltrgNumber

        ltrgValue = SanitizeFileName(SafeString(filteredRows(recordIndex, ltrgColumn)))
        areValue = SanitizeFileName(SafeString(filteredRows(recordIndex, areColumn)))
        If Len(ltrgValue) = 0 Then ltrgValue = FormatLtrg(ltrgNumber)
        If Len(areValue) = 0 Then areValue = GetAREValueForLtrg(gWorkbook, ltrgNumber)
        If Len(areValue) = 0 Then areValue = "ohne_ARE"

        individualDocxPath = UniqueFilePath(fso, individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, "docx")
        individualPdfPath = UniqueFilePath(fso, individualFolder, _
            "Anschrieben_ARE_" & areValue & "_LTRG_" & ltrgValue, "pdf")

        personDoc.SaveAs2 individualDocxPath, wdFormatXMLDocument
        personDoc.ExportAsFixedFormat individualPdfPath, wdExportFormatPDF
        WriteLog "EINZEL-DOCX-FALLBACK | LTRG=" & CStr(ltrgNumber) & " | Datei=" & individualDocxPath
        WriteLog "EINZEL-PDF-FALLBACK | LTRG=" & CStr(ltrgNumber) & " | Datei=" & individualPdfPath

        CloseWordDocumentSafely personDoc
        AppendDocumentFileToAggregate gWord, aggregateDoc, individualDocxPath
    Next

    gStage = "ARE-PDFs mit zugehoerigen Anschreiben vervollstaendigen"
    FinalizeAREPdfsWithLetters xlApp, fso, pdfFolder, letterDocsByLtrg

    gStage = "Gesamt-Serienbrief mit angeh�ngten �bersichten speichern"
    OptimizeMergedLetterLayout aggregateDoc
    aggregateDoc.SaveAs2 aggregateDocxPath, wdFormatXMLDocument
    aggregateDoc.ExportAsFixedFormat aggregatePdfPath, wdExportFormatPDF
    CloseWordDocumentSafely aggregateDoc

    WriteLog "SERIENBRIEF-GESAMT-DOCX | " & aggregateDocxPath
    WriteLog "SERIENBRIEF-GESAMT-PDF | " & aggregatePdfPath
    WriteLog "INFO | Serienbriefdaten: Blatt='" & dataSheetName & _
             "', betroffene Datens�tze=" & CStr(filteredCount) & _
             ", Spalten=" & CStr(columnCount)

    CloseWordSafely
    xlApp.StatusBar = False
End Sub

Sub FilterSerialDataToAffectedCompanies(ByRef headers, ByRef sourceRows, _
                                           ByVal sourceCount, ByVal columnCount, _
                                           ByRef filteredRows, ByRef filteredCount, _
                                           ByRef ltrgColumn, ByRef areColumn)
    Dim rowIndex
    Dim columnIndex
    Dim ltrgNumber

    If Not IsObject(gAffectedLtrgs) Then
        Err.Raise -2147221504 + 2055, "ARE Generator", _
                  "Die Liste der betroffenen LTRG wurde nicht initialisiert."
    End If

    ltrgColumn = FindSerialColumnByRole(headers, columnCount, "ltrg")
    areColumn = FindSerialColumnByRole(headers, columnCount, "are")

    If ltrgColumn = 0 Then
        ltrgColumn = 1
        WriteLog "WARNUNG | Keine Serienbrief-Spalte mit �berschrift LTRG/LTGR/LGTR gefunden. " & _
                 "Fallback auf Spalte A."
    End If
    If areColumn = 0 Then
        If columnCount >= 2 Then
            areColumn = 2
            WriteLog "WARNUNG | Keine Serienbrief-Spalte mit �berschrift ARE gefunden. Fallback auf Spalte B."
        Else
            areColumn = ltrgColumn
        End If
    End If

    filteredCount = 0
    For rowIndex = 1 To sourceCount
        If TryGetLong(sourceRows(rowIndex, ltrgColumn), ltrgNumber) Then
            If gAffectedLtrgs.Exists(CStr(ltrgNumber)) Then filteredCount = filteredCount + 1
        Else
            WriteLog "WARNUNG | Serienbriefzeile " & CStr(rowIndex + 1) & _
                     " ohne g�ltige LTRG wird �bersprungen: '" & _
                     SafeString(sourceRows(rowIndex, ltrgColumn)) & "'."
        End If
    Next

    If filteredCount > 0 Then
        ReDim filteredRows(filteredCount, columnCount)
        filteredCount = 0
        For rowIndex = 1 To sourceCount
            If TryGetLong(sourceRows(rowIndex, ltrgColumn), ltrgNumber) Then
                If gAffectedLtrgs.Exists(CStr(ltrgNumber)) Then
                    filteredCount = filteredCount + 1
                    For columnIndex = 1 To columnCount
                        filteredRows(filteredCount, columnIndex) = sourceRows(rowIndex, columnIndex)
                    Next
                End If
            End If
        Next
    End If

    WriteLog "INFO | Serienbrief gefiltert: Quelle=" & CStr(sourceCount) & _
             " | betroffen=" & CStr(filteredCount) & _
             " | LTRG-Spalte=" & CStr(ltrgColumn) & _
             " | ARE-Spalte=" & CStr(areColumn)
End Sub

Function FindSerialColumnByRole(ByRef headers, ByVal columnCount, ByVal roleName)
    Dim columnIndex
    Dim canonical

    FindSerialColumnByRole = 0
    For columnIndex = 1 To columnCount
        canonical = CanonicalSerialHeader(headers(columnIndex))
        If canonical = LCase(CStr(roleName)) Then
            FindSerialColumnByRole = columnIndex
            Exit Function
        End If
    Next
End Function

Function CanonicalSerialHeader(ByVal rawValue)
    Dim normalized
    Dim compact

    CanonicalSerialHeader = ""
    normalized = NormalizeHeaderCell(rawValue)
    compact = Replace(normalized, " ", "")

    Select Case compact
        Case "ltrg", "ltgr", "lgtr", "ltrgr", "leistungstraeger", "leistungstrager", _
             "ltrgnummer", "ltgrnummer", "lgtrnummer", "ltrgneu", "ltgrneu"
            CanonicalSerialHeader = "ltrg"
        Case "are", "arenummer", "arewert", "arecode", "arekurz", _
             "areneu", "arealt", "arenummerneu", "arecodeneu"
            CanonicalSerialHeader = "are"
    End Select
End Function

Sub AppendAREOverviewToDocument(ByVal xlApp, ByVal doc, ByVal ltrgNumber)
    InsertAREOverviewIntoDocument xlApp, doc, ltrgNumber, True
End Sub

Sub InsertAREOverviewIntoDocument(ByVal xlApp, ByVal doc, ByVal ltrgNumber, _
                                  ByVal addPageBreakBefore)
    Dim ws
    Dim lastRow
    Dim sourceRange
    Dim appendRange
    Dim inlineCountBefore
    Dim shapeCountBefore
    Dim overviewShape
    Dim availableWidth
    Dim availableHeight

    Set ws = FindGeneratedARESheetByLtrg(gWorkbook, CLng(ltrgNumber))
    If ws Is Nothing Then
        Err.Raise -2147221504 + 2056, "ARE Generator", _
                  "Fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " wurde kein generiertes ARE-Uebersichtsblatt gefunden."
    End If

    lastRow = GetAREContentLastRow(ws)
    If lastRow < 1 Then
        Err.Raise -2147221504 + 2057, "ARE Generator", _
                  "Das ARE-Uebersichtsblatt fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " enthaelt keinen druckbaren Inhalt."
    End If

    If CBool(addPageBreakBefore) Then
        gStage = "ARE-Uebersicht fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                 " an Anschreiben anhaengen"
    Else
        gStage = "ARE-Uebersicht fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                 " als erste Seite der finalen ARE-PDF einfuegen"
    End If
    xlApp.StatusBar = gStage & " ..."

    ws.Activate
    Set sourceRange = ws.Range("A1:F" & CStr(lastRow))

    ' Wichtig: KEIN CopyPicture xlScreen verwenden. xlScreen kann sichtbare
    ' Overlays externer Excel-/Peer-Review-Komponenten (z. B.
    ' "Not Peer Reviewed" und einen blauen Rahmen) in die Grafik einbrennen.
    ' Stattdessen wird nur der echte Excel-Zellbereich kopiert.
    On Error Resume Next
    Err.Clear
    sourceRange.Copy
    If Err.Number <> 0 Then
        Dim copyErrNumber
        Dim copyErrDescription

        copyErrNumber = Err.Number
        copyErrDescription = Err.Description
        Err.Clear
        On Error GoTo 0

        Err.Raise copyErrNumber, "ARE Generator", _
                  "Die ARE-Uebersicht fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " konnte nicht aus Excel kopiert werden. " & copyErrDescription
    End If
    On Error GoTo 0
    WriteLog "ARE-KOPIE | LTRG=" & CStr(ltrgNumber) & _
             " | Range.Copy ohne xlScreen/CopyPicture"

    Set appendRange = doc.Range(doc.Content.End - 1, doc.Content.End - 1)
    If CBool(addPageBreakBefore) Then
        appendRange.InsertBreak wdPageBreak
        appendRange.Collapse wdCollapseEnd
    End If

    inlineCountBefore = doc.InlineShapes.Count
    shapeCountBefore = doc.Shapes.Count

    On Error Resume Next
    Err.Clear
    appendRange.PasteSpecial 0, False, wdInLine, False, wdPasteEnhancedMetafile
    If Err.Number <> 0 Then
        Err.Clear
        appendRange.Paste
    End If
    On Error GoTo 0

    Set overviewShape = Nothing
    If doc.InlineShapes.Count > inlineCountBefore Then
        Set overviewShape = doc.InlineShapes(doc.InlineShapes.Count)
    ElseIf doc.Shapes.Count > shapeCountBefore Then
        On Error Resume Next
        Set overviewShape = doc.Shapes(doc.Shapes.Count).ConvertToInlineShape
        Err.Clear
        On Error GoTo 0
    End If

    If overviewShape Is Nothing Then
        Err.Raise -2147221504 + 2058, "ARE Generator", _
                  "Die ARE-Uebersicht fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " konnte nicht in das Word-Dokument eingefuegt werden."
    End If

    On Error Resume Next
    overviewShape.LockAspectRatio = msoTrue
    availableWidth = CDbl(doc.PageSetup.PageWidth) - CDbl(doc.PageSetup.LeftMargin) - _
                     CDbl(doc.PageSetup.RightMargin)
    availableHeight = CDbl(doc.PageSetup.PageHeight) - CDbl(doc.PageSetup.TopMargin) - _
                      CDbl(doc.PageSetup.BottomMargin)
    If CDbl(overviewShape.Width) > availableWidth Then overviewShape.Width = availableWidth
    If CDbl(overviewShape.Height) > availableHeight Then overviewShape.Height = availableHeight
    overviewShape.Range.ParagraphFormat.Alignment = wdAlignParagraphCenter
    doc.Repaginate
    Err.Clear
    On Error GoTo 0

    If CBool(addPageBreakBefore) Then
        WriteLog "ANLAGE | ARE-Uebersicht LTRG=" & CStr(ltrgNumber) & _
                 " als Excel-Zellbereich an Anschreiben angehaengt"
    End If
End Sub

Function SaveLetterOnlyTempCopy(ByVal fso, ByVal letterDoc, ByVal ltrgNumber, _
                                ByVal recordIndex)
    Dim tempFolder
    Dim tempPath
    Dim baseName

    tempFolder = CStr(fso.GetSpecialFolder(2))
    baseName = "ARE_Anschreiben_rein_LTRG_" & FormatLtrg(CLng(ltrgNumber)) & _
               "_" & CStr(recordIndex) & "_" & _
               CStr(Hour(Now)) & TwoDigits(Minute(Now)) & TwoDigits(Second(Now))
    tempPath = UniqueFilePath(fso, tempFolder, baseName, "docx")

    letterDoc.SaveAs2 CStr(tempPath), wdFormatXMLDocument
    SaveLetterOnlyTempCopy = tempPath
    WriteLog "TEMP-ANSCHREIBEN | LTRG=" & CStr(ltrgNumber) & " | Datei=" & tempPath
End Function

Sub AddLetterTempPath(ByVal letterDocsByLtrg, ByVal ltrgNumber, ByVal documentPath)
    Dim key

    key = CStr(CLng(ltrgNumber))
    If letterDocsByLtrg.Exists(key) Then
        letterDocsByLtrg.Item(key) = letterDocsByLtrg.Item(key) & "|" & CStr(documentPath)
    Else
        letterDocsByLtrg.Add key, CStr(documentPath)
    End If
End Sub

Sub FinalizeAREPdfsWithLetters(ByVal xlApp, ByVal fso, ByVal pdfFolder, _
                               ByVal letterDocsByLtrg)
    Dim key
    Dim letterPaths
    Dim letterPath
    Dim letterPdfPaths()
    Dim targetPdfPath
    Dim tempPdfPath
    Dim tempLetterPdfPath
    Dim i
    Dim letterPdfCount
    Dim processedCount
    Dim mergeOk
    Dim mergeMethod

    gAREPdfAttachmentsComplete = False
    processedCount = 0

    If Not IsObject(letterDocsByLtrg) Then Exit Sub
    If letterDocsByLtrg.Count = 0 Then Exit Sub

    ' WICHTIG ab 1.0.16:
    ' Die bereits direkt aus Excel exportierte ARE-PDF wird NICHT mehr in Word
    ' nachgebaut. Genau dieser zweite Rendering-Schritt war der Grund, warum
    ' sichtbare Peer-Review-Overlays ("Not Peer Reviewed" / blauer Rahmen)
    ' erneut in die finale PDF gelangen konnten.
    '
    ' Stattdessen:
    '   1. saubere ARE-PDF beibehalten,
    '   2. Anschreiben separat als PDF exportieren,
    '   3. PDFs auf PDF-Ebene zusammenfuehren.
    ' Primaer wird Adobe Acrobat OLE/PDDoc verwendet. Falls die lokale Acrobat-
    ' Installation das Bearbeiten per OLE nicht erlaubt, folgt ein Word-Fallback,
    ' der die bereits exportierte PDF oeffnet - niemals mehr den Excel-Bildschirm.
    EnsureWordApplication

    For Each key In letterDocsByLtrg.Keys
        gStage = "Finale ARE-PDF fuer LTRG " & FormatLtrg(CLng(key)) & _
                 " auf PDF-Ebene mit Anschreiben zusammenfuehren"
        xlApp.StatusBar = gStage & " ..."

        targetPdfPath = GetAREPdfPathForLtrg(fso, pdfFolder, CLng(key))
        If Not FileExistsAndHasContent(fso, targetPdfPath) Then
            Err.Raise -2147221504 + 2066, "ARE Generator", _
                      "Die saubere ARE-PDF fuer LTRG " & FormatLtrg(CLng(key)) & _
                      " wurde vor dem Zusammenfuehren nicht gefunden."
        End If

        letterPaths = Split(CStr(letterDocsByLtrg.Item(key)), "|")
        ReDim letterPdfPaths(UBound(letterPaths))
        letterPdfCount = 0

        For i = 0 To UBound(letterPaths)
            letterPath = Trim(CStr(letterPaths(i)))
            If Len(letterPath) > 0 Then
                If Not fso.FileExists(letterPath) Then
                    CleanupTempPdfArray fso, letterPdfPaths, letterPdfCount
                    Err.Raise -2147221504 + 2065, "ARE Generator", _
                              "Das temporaere Anschreiben fuer LTRG " & _
                              FormatLtrg(CLng(key)) & " wurde nicht gefunden: " & letterPath
                End If

                tempLetterPdfPath = ExportLetterDocxToTempPdf( _
                    fso, letterPath, CLng(key), letterPdfCount + 1)
                letterPdfPaths(letterPdfCount) = tempLetterPdfPath
                letterPdfCount = letterPdfCount + 1
            End If
        Next

        If letterPdfCount < 1 Then
            CleanupTempPdfArray fso, letterPdfPaths, letterPdfCount
            Err.Raise -2147221504 + 2069, "ARE Generator", _
                      "Fuer LTRG " & FormatLtrg(CLng(key)) & _
                      " wurde kein Anschreiben-PDF fuer die Anlage erzeugt."
        End If

        tempPdfPath = UniqueFilePath(fso, pdfFolder, _
            "__TEMP_ARE_MIT_ANSCHREIBEN_LTRG_" & FormatLtrg(CLng(key)), "pdf")

        mergeMethod = "Adobe Acrobat PDDoc"
        mergeOk = MergePdfsWithAcrobat(fso, targetPdfPath, _
                                        letterPdfPaths, letterPdfCount, tempPdfPath)

        If Not CBool(mergeOk) Then
            WriteLog "WARNUNG | Acrobat-PDF-Merge fuer LTRG=" & CStr(key) & _
                     " nicht verfuegbar. Word-PDF-Fallback wird versucht."
            If fso.FileExists(tempPdfPath) Then fso.DeleteFile tempPdfPath, True
            mergeMethod = "Word PDF-Import Fallback"
            mergeOk = MergeCleanAREPdfWithLettersUsingWord( _
                fso, targetPdfPath, letterPaths, tempPdfPath)
        End If

        CleanupTempPdfArray fso, letterPdfPaths, letterPdfCount

        If Not CBool(mergeOk) Or Not FileExistsAndHasContent(fso, tempPdfPath) Then
            If fso.FileExists(tempPdfPath) Then fso.DeleteFile tempPdfPath, True
            Err.Raise -2147221504 + 2070, "ARE Generator", _
                      "Die ARE-PDF fuer LTRG " & FormatLtrg(CLng(key)) & _
                      " konnte nicht mit dem Anschreiben zusammengefuehrt werden. " & _
                      "Die urspruengliche saubere ARE-PDF wurde nicht veraendert."
        End If

        ' Erst nachdem die neue kombinierte PDF vollstaendig vorliegt, wird die
        ' saubere Einzel-PDF ersetzt. Bei einem Fehler bleibt sie erhalten.
        If fso.FileExists(targetPdfPath) Then fso.DeleteFile targetPdfPath, True
        fso.MoveFile tempPdfPath, targetPdfPath
        processedCount = processedCount + 1

        WriteLog "ARE-PDF+ANSCHREIBEN | LTRG=" & CStr(key) & _
                 " | Methode=" & mergeMethod & " | Datei=" & targetPdfPath
    Next

    CleanupLetterTempFiles fso, letterDocsByLtrg
    gAREPdfAttachmentsComplete = (processedCount = letterDocsByLtrg.Count)
    WriteLog "INFO | " & CStr(processedCount) & _
             " ARE-PDFs ohne Excel-Neurendering mit Anschreiben vervollstaendigt"
End Sub

Function ExportLetterDocxToTempPdf(ByVal fso, ByVal docxPath, _
                                   ByVal ltrgNumber, ByVal sequenceNumber)
    Dim letterDoc
    Dim tempFolder
    Dim tempPdfPath
    Dim exportErrorNumber
    Dim exportErrorDescription

    EnsureWordApplication
    tempFolder = CStr(fso.GetSpecialFolder(2))
    tempPdfPath = UniqueFilePath(fso, tempFolder, _
        "ARE_Anschreiben_PDF_LTRG_" & FormatLtrg(CLng(ltrgNumber)) & _
        "_" & CStr(sequenceNumber), "pdf")

    Set letterDoc = Nothing
    On Error Resume Next
    Err.Clear
    Set letterDoc = gWord.Documents.Open(CStr(docxPath), False, True, False)
    If Err.Number <> 0 Or letterDoc Is Nothing Then
        exportErrorNumber = Err.Number
        exportErrorDescription = Err.Description
        Err.Clear
        On Error GoTo 0
        Err.Raise exportErrorNumber, "ARE Generator", _
                  "Das temporaere Anschreiben konnte nicht fuer den PDF-Export geoeffnet werden: " & _
                  exportErrorDescription
    End If

    Err.Clear
    letterDoc.ExportAsFixedFormat CStr(tempPdfPath), wdExportFormatPDF
    exportErrorNumber = Err.Number
    exportErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    CloseWordDocumentSafely letterDoc

    If exportErrorNumber <> 0 Or Not FileExistsAndHasContent(fso, tempPdfPath) Then
        Err.Raise exportErrorNumber, "ARE Generator", _
                  "Das Anschreiben-PDF fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " konnte nicht erzeugt werden. " & exportErrorDescription
    End If

    ExportLetterDocxToTempPdf = tempPdfPath
    WriteLog "TEMP-ANSCHREIBEN-PDF | LTRG=" & CStr(ltrgNumber) & _
             " | Datei=" & tempPdfPath
End Function

Function MergePdfsWithAcrobat(ByVal fso, ByVal basePdfPath, _
                              ByRef appendPdfPaths, ByVal appendCount, _
                              ByVal outputPdfPath)
    Dim targetDoc
    Dim sourceDoc
    Dim i
    Dim sourcePath
    Dim sourcePages
    Dim targetPages
    Dim openOk
    Dim insertOk
    Dim saveOk
    Dim acrobatErrorNumber
    Dim acrobatErrorDescription

    MergePdfsWithAcrobat = False
    Set targetDoc = Nothing
    Set sourceDoc = Nothing

    On Error Resume Next
    Err.Clear
    Set targetDoc = CreateObject("AcroExch.PDDoc")
    If Err.Number <> 0 Or targetDoc Is Nothing Then
        WriteLog "PDF-MERGE | Adobe Acrobat PDDoc nicht verfuegbar: " & Err.Description
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If

    openOk = targetDoc.Open(CStr(basePdfPath))
    If Err.Number <> 0 Or openOk = 0 Then
        WriteLog "PDF-MERGE | Saubere ARE-PDF konnte in Acrobat nicht geoeffnet werden: " & _
                 CStr(basePdfPath) & " | " & Err.Description
        Err.Clear
        On Error GoTo 0
        Set targetDoc = Nothing
        Exit Function
    End If

    For i = 0 To appendCount - 1
        sourcePath = CStr(appendPdfPaths(i))
        Set sourceDoc = Nothing
        Err.Clear
        Set sourceDoc = CreateObject("AcroExch.PDDoc")
        If Err.Number <> 0 Or sourceDoc Is Nothing Then Exit For

        openOk = sourceDoc.Open(sourcePath)
        If Err.Number <> 0 Or openOk = 0 Then Exit For

        sourcePages = sourceDoc.GetNumPages
        targetPages = targetDoc.GetNumPages
        If Err.Number <> 0 Or sourcePages < 1 Or targetPages < 1 Then Exit For

        ' Adobe OLE: InsertPages(insertAfterPage, sourcePDDoc, startPage,
        '                        numberOfPages, copyBookmarks)
        insertOk = targetDoc.InsertPages(targetPages - 1, sourceDoc, 0, sourcePages, 0)
        sourceDoc.Close
        Set sourceDoc = Nothing

        If Err.Number <> 0 Or insertOk = 0 Then Exit For
    Next

    If i = appendCount Then
        If fso.FileExists(outputPdfPath) Then fso.DeleteFile outputPdfPath, True
        Err.Clear
        ' PDSaveFull (1) + PDSaveCollectGarbage (32) = 33
        saveOk = targetDoc.Save(33, CStr(outputPdfPath))
        acrobatErrorNumber = Err.Number
        acrobatErrorDescription = Err.Description
        targetDoc.Close
        Set targetDoc = Nothing
        Err.Clear
        On Error GoTo 0

        If acrobatErrorNumber = 0 And saveOk <> 0 And _
           FileExistsAndHasContent(fso, outputPdfPath) Then
            MergePdfsWithAcrobat = True
            WriteLog "PDF-MERGE | Acrobat PDDoc erfolgreich | Basis=" & _
                     CStr(basePdfPath) & " | Ziel=" & CStr(outputPdfPath)
        Else
            WriteLog "PDF-MERGE | Acrobat-Speichern fehlgeschlagen | Nummer=" & _
                     CStr(acrobatErrorNumber) & " | " & acrobatErrorDescription
        End If
        Exit Function
    End If

    acrobatErrorNumber = Err.Number
    acrobatErrorDescription = Err.Description
    If Not (sourceDoc Is Nothing) Then sourceDoc.Close
    If Not (targetDoc Is Nothing) Then targetDoc.Close
    Set sourceDoc = Nothing
    Set targetDoc = Nothing
    Err.Clear
    On Error GoTo 0

    WriteLog "PDF-MERGE | Acrobat InsertPages nicht moeglich | Nummer=" & _
             CStr(acrobatErrorNumber) & " | " & acrobatErrorDescription
End Function

Function MergeCleanAREPdfWithLettersUsingWord(ByVal fso, ByVal basePdfPath, _
                                               ByRef letterDocxPaths, _
                                               ByVal outputPdfPath)
    Dim mergeWord
    Dim packageDoc
    Dim insertRange
    Dim letterPath
    Dim i
    Dim openErrorNumber
    Dim openErrorDescription
    Dim insertErrorNumber
    Dim insertErrorDescription
    Dim exportErrorNumber
    Dim exportErrorDescription

    MergeCleanAREPdfWithLettersUsingWord = False
    Set mergeWord = Nothing
    Set packageDoc = Nothing

    ' WICHTIG ab 1.0.17:
    ' Der PDF-Import-Fallback bekommt eine EIGENE Word-Instanz. Er darf die
    ' globale Serienbrief-Word-Instanz gWord niemals beruehren. Word kann beim
    ' Oeffnen/Konvertieren einer PDF intern neu starten oder die COM-Verbindung
    ' trennen; zuvor hat das anschliessend den Serienbrief-Fallback mit
    ' -2147417848 beendet.
    On Error Resume Next
    Err.Clear
    Set mergeWord = CreateObject("Word.Application")
    openErrorNumber = Err.Number
    openErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If openErrorNumber <> 0 Or mergeWord Is Nothing Then
        WriteLog "PDF-MERGE-FALLBACK | Isolierte Word-Instanz konnte nicht gestartet werden | Nummer=" & _
                 CStr(openErrorNumber) & " | " & openErrorDescription
        Exit Function
    End If

    On Error Resume Next
    mergeWord.Visible = False
    mergeWord.DisplayAlerts = 0
    Err.Clear
    Set packageDoc = mergeWord.Documents.Open(CStr(basePdfPath), False, False, False)
    openErrorNumber = Err.Number
    openErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    If openErrorNumber <> 0 Or packageDoc Is Nothing Then
        WriteLog "PDF-MERGE-FALLBACK | Isoliertes Word konnte ARE-PDF nicht oeffnen | Nummer=" & _
                 CStr(openErrorNumber) & " | " & openErrorDescription
        CloseLocalWordSafely mergeWord, packageDoc
        Exit Function
    End If

    insertErrorNumber = 0
    insertErrorDescription = ""

    For i = 0 To UBound(letterDocxPaths)
        letterPath = Trim(CStr(letterDocxPaths(i)))
        If Len(letterPath) > 0 Then
            On Error Resume Next
            Err.Clear
            Set insertRange = packageDoc.Range(packageDoc.Content.End - 1, _
                                               packageDoc.Content.End - 1)
            insertRange.InsertBreak wdSectionBreakNextPage
            insertRange.Collapse wdCollapseEnd
            insertRange.InsertFile CStr(letterPath)
            insertErrorNumber = Err.Number
            insertErrorDescription = Err.Description
            Err.Clear
            On Error GoTo 0

            If insertErrorNumber <> 0 Then Exit For
        End If
    Next

    If insertErrorNumber <> 0 Then
        WriteLog "PDF-MERGE-FALLBACK | Anschreiben konnte nicht in isoliertes Word eingefuegt werden | Nummer=" & _
                 CStr(insertErrorNumber) & " | " & insertErrorDescription
        CloseLocalWordSafely mergeWord, packageDoc
        Exit Function
    End If

    On Error Resume Next
    Err.Clear
    packageDoc.Repaginate
    packageDoc.ExportAsFixedFormat CStr(outputPdfPath), wdExportFormatPDF
    exportErrorNumber = Err.Number
    exportErrorDescription = Err.Description
    Err.Clear
    On Error GoTo 0

    CloseLocalWordSafely mergeWord, packageDoc

    If exportErrorNumber = 0 And FileExistsAndHasContent(fso, outputPdfPath) Then
        MergeCleanAREPdfWithLettersUsingWord = True
        WriteLog "PDF-MERGE-FALLBACK | Isoliertes Word aus sauberer ARE-PDF erfolgreich | Ziel=" & _
                 CStr(outputPdfPath)
    Else
        WriteLog "PDF-MERGE-FALLBACK | Isolierter Word-Export fehlgeschlagen | Nummer=" & _
                 CStr(exportErrorNumber) & " | " & exportErrorDescription
    End If
End Function

Sub CloseLocalWordSafely(ByRef localWord, ByRef localDoc)
    On Error Resume Next

    If IsObject(localDoc) Then
        If Not localDoc Is Nothing Then localDoc.Close wdDoNotSaveChanges
    End If
    Set localDoc = Nothing

    If IsObject(localWord) Then
        If Not localWord Is Nothing Then
            localWord.DisplayAlerts = 0
            localWord.Quit wdDoNotSaveChanges
        End If
    End If
    Set localWord = Nothing

    Err.Clear
    On Error GoTo 0
End Sub

Sub CleanupTempPdfArray(ByVal fso, ByRef pdfPaths, ByVal pdfCount)
    Dim i
    On Error Resume Next
    For i = 0 To pdfCount - 1
        If Len(Trim(CStr(pdfPaths(i)))) > 0 Then
            If fso.FileExists(CStr(pdfPaths(i))) Then fso.DeleteFile CStr(pdfPaths(i)), True
        End If
    Next
    Err.Clear
    On Error GoTo 0
End Sub

Function GetAREPdfPathForLtrg(ByVal fso, ByVal pdfFolder, ByVal ltrgNumber)
    Dim ws
    Dim targetPath

    Set ws = FindGeneratedARESheetByLtrg(gWorkbook, CLng(ltrgNumber))
    If ws Is Nothing Then
        Err.Raise -2147221504 + 2067, "ARE Generator", _
                  "Fuer LTRG " & FormatLtrg(CLng(ltrgNumber)) & _
                  " konnte kein ARE-Blatt fuer die PDF-Zuordnung gefunden werden."
    End If

    targetPath = fso.BuildPath(CStr(pdfFolder), _
        "ERG_VWUe_" & SanitizeFileName(ws.Name) & ".pdf")

    ' Der regulaere Export verwendet den echten Umlaut im Praefix.
    targetPath = fso.BuildPath(CStr(pdfFolder), _
        "ERG_VW" & Chr(220) & "_" & SanitizeFileName(ws.Name) & ".pdf")

    If Not fso.FileExists(targetPath) Then
        Err.Raise -2147221504 + 2068, "ARE Generator", _
                  "Die zuvor exportierte ARE-PDF fuer LTRG " & _
                  FormatLtrg(CLng(ltrgNumber)) & " wurde nicht gefunden: " & targetPath
    End If

    GetAREPdfPathForLtrg = targetPath
End Function

Sub CleanupLetterTempFiles(ByVal fso, ByVal letterDocsByLtrg)
    Dim key
    Dim paths
    Dim i

    On Error Resume Next
    If IsObject(letterDocsByLtrg) Then
        For Each key In letterDocsByLtrg.Keys
            paths = Split(CStr(letterDocsByLtrg.Item(key)), "|")
            For i = 0 To UBound(paths)
                If Len(Trim(CStr(paths(i)))) > 0 Then
                    If fso.FileExists(CStr(paths(i))) Then fso.DeleteFile CStr(paths(i)), True
                End If
            Next
        Next
    End If
    Err.Clear
    On Error GoTo 0
End Sub

Sub AppendDocumentFileToAggregate(ByVal wordApp, ByRef aggregateDoc, ByVal documentPath)
    Dim insertRange

    If aggregateDoc Is Nothing Then
        ' Die erste Einzel-DOCX wird als Basis verwendet. Dadurch bleiben ihre
        ' Kopf-/Fu�zeilen und Seiteneinstellungen auch im Gesamtdokument erhalten.
        Set aggregateDoc = wordApp.Documents.Open(CStr(documentPath), False, False)
    Else
        Set insertRange = aggregateDoc.Range(aggregateDoc.Content.End - 1, _
                                             aggregateDoc.Content.End - 1)
        insertRange.InsertBreak wdSectionBreakNextPage
        insertRange.Collapse wdCollapseEnd
        insertRange.InsertFile CStr(documentPath)
    End If
    Set insertRange = Nothing
End Sub

Function FindGeneratedARESheetByLtrg(ByVal wb, ByVal ltrgNumber)
    Dim ws
    Dim parsedLtrg

    Set FindGeneratedARESheetByLtrg = Nothing
    For Each ws In wb.Worksheets
        If IsGeneratedARESheet(ws.Name) Then
            If TryParseLtrgFromGeneratedSheetName(ws.Name, parsedLtrg) Then
                If CLng(parsedLtrg) = CLng(ltrgNumber) Then
                    Set FindGeneratedARESheetByLtrg = ws
                    Exit Function
                End If
            End If
        End If
    Next
End Function

Function TryParseLtrgFromGeneratedSheetName(ByVal sheetName, ByRef ltrgNumber)
    Dim markerPosition
    Dim closingPosition
    Dim rawValue

    TryParseLtrgFromGeneratedSheetName = False
    markerPosition = InStr(1, CStr(sheetName), "(LTRG ", 1)
    If markerPosition = 0 Then Exit Function
    closingPosition = InStr(markerPosition, CStr(sheetName), ")", 1)
    If closingPosition = 0 Then Exit Function
    rawValue = Mid(CStr(sheetName), markerPosition + 6, closingPosition - markerPosition - 6)
    TryParseLtrgFromGeneratedSheetName = TryGetLong(rawValue, ltrgNumber)
End Function

Function GetAREValueForLtrg(ByVal wb, ByVal ltrgNumber)
    Dim ws
    Dim nameValue
    Dim startPosition
    Dim endPosition

    GetAREValueForLtrg = ""
    Set ws = FindGeneratedARESheetByLtrg(wb, CLng(ltrgNumber))
    If ws Is Nothing Then Exit Function

    nameValue = SafeString(ws.Name)
    If Left(nameValue, 4) <> "ARE " Then Exit Function
    startPosition = 5
    endPosition = InStr(startPosition, nameValue, " (LTRG ", 1)
    If endPosition > startPosition Then
        GetAREValueForLtrg = Trim(Mid(nameValue, startPosition, endPosition - startPosition))
    End If
End Function

Function GetAREContentLastRow(ByVal ws)
    Dim usedLast
    Dim rowNumber
    Dim columnNumber

    GetAREContentLastRow = 0
    usedLast = GetUsedLastRowSafe(ws)
    For rowNumber = usedLast To 1 Step -1
        For columnNumber = 1 To 6
            If CellHasContent(ws.Cells(rowNumber, columnNumber)) Then
                GetAREContentLastRow = rowNumber
                Exit Function
            End If
        Next
    Next
End Function

Sub LoadSerialData(ByVal xlApp, ByVal dataPath, ByRef headers, _
                   ByRef dataRows, ByRef rowCount, ByRef columnCount, _
                   ByRef dataSheetName)
    Dim dataWorkbook
    Dim ws
    Dim usedStartRow
    Dim usedRowCount
    Dim usedStartColumn
    Dim usedColumnCount
    Dim usedLastRow
    Dim usedLastColumn
    Dim lastRow
    Dim lastColumn
    Dim sourceRow
    Dim recordIndex
    Dim columnIndex
    Dim headerText

    Set dataWorkbook = xlApp.Workbooks.Open(CStr(dataPath), 0, True)
    Set ws = dataWorkbook.Worksheets(1)
    dataSheetName = SafeString(ws.Name)

    usedStartRow = CLng(ws.UsedRange.Row)
    usedRowCount = CLng(ws.UsedRange.Rows.Count)
    usedStartColumn = CLng(ws.UsedRange.Column)
    usedColumnCount = CLng(ws.UsedRange.Columns.Count)

    usedLastRow = usedStartRow + usedRowCount - 1
    usedLastColumn = usedStartColumn + usedColumnCount - 1

    lastColumn = FindLastSerialColumn(ws, usedLastColumn)
    lastRow = FindLastSerialRow(ws, usedLastRow, lastColumn)

    If lastColumn < 1 Then
        dataWorkbook.Close False
        Set dataWorkbook = Nothing
        Err.Raise -2147221504 + 2053, "ARE Generator", _
                  "In der ersten Zeile der Personendatei wurden keine Spalten�berschriften gefunden."
    End If

    columnCount = lastColumn
    ReDim headers(columnCount)

    For columnIndex = 1 To columnCount
        headerText = Trim(ReadCellTextSafe(ws.Cells(1, columnIndex)))
        If Len(headerText) = 0 Then
            headerText = "Spalte_" & CStr(columnIndex)
            WriteLog "WARNUNG | Leere Serienbrief-Kopfzelle in Spalte " & _
                     CStr(columnIndex) & " wird als '" & headerText & "' gef�hrt."
        End If
        headers(columnIndex) = headerText
    Next

    rowCount = 0
    For sourceRow = 2 To lastRow
        If SerialRowHasData(ws, sourceRow, columnCount) Then
            rowCount = rowCount + 1
        End If
    Next

    If rowCount > 0 Then
        ReDim dataRows(rowCount, columnCount)
        recordIndex = 0

        For sourceRow = 2 To lastRow
            If SerialRowHasData(ws, sourceRow, columnCount) Then
                recordIndex = recordIndex + 1
                For columnIndex = 1 To columnCount
                    dataRows(recordIndex, columnIndex) = _
                        ReadCellTextSafe(ws.Cells(sourceRow, columnIndex))
                Next
            End If
        Next
    End If

    dataWorkbook.Close False
    Set ws = Nothing
    Set dataWorkbook = Nothing
End Sub

Function FindLastSerialColumn(ByVal ws, ByVal usedLastColumn)
    Dim columnIndex

    FindLastSerialColumn = 0

    For columnIndex = usedLastColumn To 1 Step -1
        If CellHasContent(ws.Cells(1, columnIndex)) Then
            FindLastSerialColumn = columnIndex
            Exit Function
        End If
    Next
End Function

Function FindLastSerialRow(ByVal ws, ByVal usedLastRow, ByVal lastColumn)
    Dim rowIndex
    Dim columnIndex

    FindLastSerialRow = 1
    If lastColumn < 1 Then Exit Function

    For rowIndex = usedLastRow To 2 Step -1
        For columnIndex = 1 To lastColumn
            If CellHasContent(ws.Cells(rowIndex, columnIndex)) Then
                FindLastSerialRow = rowIndex
                Exit Function
            End If
        Next
    Next
End Function

Function SerialRowHasData(ByVal ws, ByVal rowIndex, ByVal columnCount)
    Dim columnIndex

    SerialRowHasData = False

    For columnIndex = 1 To columnCount
        If CellHasContent(ws.Cells(rowIndex, columnIndex)) Then
            SerialRowHasData = True
            Exit Function
        End If
    Next
End Function

Sub FillMergeFieldsInDocument(ByVal doc, ByRef headers, ByRef dataRows, _
                              ByVal recordIndex, ByVal columnCount, _
                              ByRef filledFieldCount)
    Dim storyRange
    Dim currentRange
    Dim nextRange

    filledFieldCount = 0

    For Each storyRange In doc.StoryRanges
        Set currentRange = storyRange

        Do While Not currentRange Is Nothing
            ProcessMergeFieldsInRange currentRange, headers, dataRows, _
                                      recordIndex, columnCount, filledFieldCount

            Set nextRange = Nothing
            On Error Resume Next
            Set nextRange = currentRange.NextStoryRange
            Err.Clear
            On Error GoTo 0

            Set currentRange = nextRange
        Loop
    Next

    ' Zus�tzliche Absicherung f�r Seriendruckfelder in Textfeldern,
    ' insbesondere in Kopf- und Fu�zeilen.
    ProcessDocumentShapeFields doc, headers, dataRows, recordIndex, _
                               columnCount, filledFieldCount
End Sub

Sub ProcessDocumentShapeFields(ByVal doc, ByRef headers, ByRef dataRows, _
                               ByVal recordIndex, ByVal columnCount, _
                               ByRef filledFieldCount)
    Dim shapeItem
    Dim sectionItem
    Dim headerFooter
    Dim textRange

    For Each shapeItem In doc.Shapes
        Set textRange = Nothing
        On Error Resume Next
        If shapeItem.TextFrame.HasText Then
            Set textRange = shapeItem.TextFrame.TextRange
        End If
        Err.Clear
        On Error GoTo 0

        If Not textRange Is Nothing Then
            ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                      recordIndex, columnCount, filledFieldCount
        End If
    Next

    For Each sectionItem In doc.Sections
        For Each headerFooter In sectionItem.Headers
            For Each shapeItem In headerFooter.Shapes
                Set textRange = Nothing
                On Error Resume Next
                If shapeItem.TextFrame.HasText Then
                    Set textRange = shapeItem.TextFrame.TextRange
                End If
                Err.Clear
                On Error GoTo 0

                If Not textRange Is Nothing Then
                    ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                              recordIndex, columnCount, _
                                              filledFieldCount
                End If
            Next
        Next

        For Each headerFooter In sectionItem.Footers
            For Each shapeItem In headerFooter.Shapes
                Set textRange = Nothing
                On Error Resume Next
                If shapeItem.TextFrame.HasText Then
                    Set textRange = shapeItem.TextFrame.TextRange
                End If
                Err.Clear
                On Error GoTo 0

                If Not textRange Is Nothing Then
                    ProcessMergeFieldsInRange textRange, headers, dataRows, _
                                              recordIndex, columnCount, _
                                              filledFieldCount
                End If
            Next
        Next
    Next
End Sub

Sub ProcessMergeFieldsInRange(ByVal targetRange, ByRef headers, _
                              ByRef dataRows, ByVal recordIndex, _
                              ByVal columnCount, ByRef filledFieldCount)
    Dim fieldIndex
    Dim mergeField
    Dim fieldName
    Dim fieldValue
    Dim valueFound

    For fieldIndex = targetRange.Fields.Count To 1 Step -1
        Set mergeField = targetRange.Fields(fieldIndex)

        If CLng(mergeField.Type) = wdFieldMergeField Then
            fieldName = GetMergeFieldName(SafeString(mergeField.Code.Text))
            valueFound = False
            fieldValue = LookupMergeValue( _
                fieldName, headers, dataRows, recordIndex, columnCount, valueFound _
            )

            If Not valueFound And recordIndex = 1 Then
                WriteLog "WARNUNG | Serienbrieffeld ohne passende Excel-Spalte: " & _
                         fieldName
            End If

            mergeField.Result.Text = fieldValue
            mergeField.Unlink
            filledFieldCount = filledFieldCount + 1
        End If
    Next
End Sub

Function GetMergeFieldName(ByVal fieldCode)
    Dim textValue
    Dim rest
    Dim endPosition
    Dim spacePosition
    Dim slashPosition
    Dim cutPosition

    textValue = Trim(SafeString(fieldCode))
    GetMergeFieldName = ""

    If LCase(Left(textValue, 10)) <> "mergefield" Then Exit Function

    rest = Trim(Mid(textValue, 11))
    If Len(rest) = 0 Then Exit Function

    If Left(rest, 1) = Chr(34) Then
        endPosition = InStr(2, rest, Chr(34), 1)
        If endPosition > 1 Then
            GetMergeFieldName = Mid(rest, 2, endPosition - 2)
        End If
        Exit Function
    End If

    spacePosition = InStr(1, rest, " ", 1)
    slashPosition = InStr(1, rest, "\", 1)
    cutPosition = 0

    If spacePosition > 0 Then cutPosition = spacePosition
    If slashPosition > 0 Then
        If cutPosition = 0 Or slashPosition < cutPosition Then
            cutPosition = slashPosition
        End If
    End If

    If cutPosition > 0 Then
        GetMergeFieldName = Trim(Left(rest, cutPosition - 1))
    Else
        GetMergeFieldName = Trim(rest)
    End If
End Function

Function LookupMergeValue(ByVal fieldName, ByRef headers, ByRef dataRows, _
                          ByVal recordIndex, ByVal columnCount, ByRef valueFound)
    Dim columnIndex
    Dim normalizedField

    LookupMergeValue = ""
    valueFound = False

    For columnIndex = 1 To columnCount
        If StrComp(Trim(SafeString(headers(columnIndex))), _
                   Trim(SafeString(fieldName)), 1) = 0 Then
            LookupMergeValue = SafeString(dataRows(recordIndex, columnIndex))
            valueFound = True
            Exit Function
        End If
    Next

    normalizedField = NormalizeMergeKey(fieldName)

    For columnIndex = 1 To columnCount
        If NormalizeMergeKey(headers(columnIndex)) = normalizedField Then
            LookupMergeValue = SafeString(dataRows(recordIndex, columnIndex))
            valueFound = True
            Exit Function
        End If
    Next
End Function

Function NormalizeMergeKey(ByVal value)
    Dim textValue

    textValue = LCase(Trim(SafeString(value)))
    textValue = Replace(textValue, " ", "")
    textValue = Replace(textValue, "_", "")
    textValue = Replace(textValue, "-", "")
    textValue = Replace(textValue, ".", "")
    textValue = Replace(textValue, ":", "")
    textValue = Replace(textValue, vbTab, "")
    textValue = Replace(textValue, vbCr, "")
    textValue = Replace(textValue, vbLf, "")
    textValue = Replace(textValue, Chr(160), "")
    textValue = Replace(textValue, "�", "")
    textValue = Replace(textValue, "�", "")

    NormalizeMergeKey = textValue
End Function

Function SanitizeFileName(ByVal value)
    Dim textValue
    Dim forbidden
    Dim item

    textValue = Trim(SafeString(value))
    forbidden = Array("\", "/", ":", "*", "?", Chr(34), "<", ">", "|")

    For Each item In forbidden
        textValue = Replace(textValue, CStr(item), "-")
    Next

    Do While Len(textValue) > 0 And _
             (Right(textValue, 1) = "." Or Right(textValue, 1) = " ")
        textValue = Left(textValue, Len(textValue) - 1)
    Loop

    Do While InStr(1, textValue, "  ", 1) > 0
        textValue = Replace(textValue, "  ", " ")
    Loop

    If Len(textValue) > 120 Then textValue = Left(textValue, 120)
    SanitizeFileName = textValue
End Function

Function UniqueFilePath(ByVal fso, ByVal folderPath, ByVal baseName, _
                        ByVal extension)
    Dim safeBaseName
    Dim candidate
    Dim counter

    safeBaseName = SanitizeFileName(baseName)
    If Len(safeBaseName) = 0 Then safeBaseName = "Ausgabe"

    candidate = fso.BuildPath(folderPath, safeBaseName & "." & extension)
    counter = 2

    Do While fso.FileExists(candidate) Or fso.FolderExists(candidate)
        candidate = fso.BuildPath( _
            folderPath, safeBaseName & "_" & CStr(counter) & "." & extension _
        )
        counter = counter + 1
    Loop

    UniqueFilePath = candidate
End Function

Sub CloseWordDocumentSafely(ByRef documentObject)
    On Error Resume Next

    If IsObject(documentObject) Then
        If Not documentObject Is Nothing Then
            documentObject.Close wdDoNotSaveChanges
        End If
    End If

    Set documentObject = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Sub CloseWordSafely()
    On Error Resume Next

    If IsObject(gWord) Then
        If Not gWord Is Nothing Then
            Do While gWord.Documents.Count > 0
                gWord.Documents(1).Close wdDoNotSaveChanges
            Loop
            gWord.DisplayAlerts = 0
            gWord.Quit wdDoNotSaveChanges
        End If
    End If

    Set gWord = Nothing
    Err.Clear
    On Error GoTo 0
End Sub

Function LoadCompanies(ByVal ws, ByVal layout)
    Dim dict
    Dim lastRow
    Dim firstDataRow
    Dim r
    Dim ltrg
    Dim isValid
    Dim companyName
    Dim areValue
    Dim existingInfo
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    firstDataRow = CLng(layout.Item("_header_row")) + 1
    lastRow = FindLastCompanyRow(ws, layout, firstDataRow)

    For r = firstDataRow To lastRow
        isValid = TryGetLong(ReadCellValueSafe(ws.Cells(r, CLng(layout.Item("ltrg")))), ltrg)
        If isValid Then
            companyName = SafeString(ReadCellValueSafe(ws.Cells(r, CLng(layout.Item("name")))))
            areValue = ReadCellValueSafe(ws.Cells(r, CLng(layout.Item("are"))))

            If Len(Trim(companyName)) > 0 Then
                key = CStr(ltrg)
                If dict.Exists(key) Then
                    existingInfo = dict.Item(key)
                    If IsBlankValue(areValue) Then areValue = existingInfo(0)
                    If Len(Trim(companyName)) = 0 Then companyName = CStr(existingInfo(1))
                    dict.Item(key) = Array(areValue, companyName)
                Else
                    dict.Add key, Array(areValue, companyName)
                End If
            End If
        End If
    Next

    If dict.Count = 0 Then
        Err.Raise -2147221504 + 2020, "ARE Generator", _
                  "Im Blatt '" & ws.Name & "' wurden keine Gesellschaften gefunden. " & _
                  "Erwartet werden die Spalten LTRG, ARE und Name � unabh�ngig von ihrer Position."
    End If

    WriteLog "INFO | " & CStr(dict.Count) & " Gesellschaftszuordnungen eingelesen"
    Set LoadCompanies = dict
End Function

Function BuildTargetLtrgs(ByRef transferData)
    Dim dict
    Dim i
    Dim newLtrg
    Dim oldLtrg
    Dim validNew
    Dim validOld
    Dim key

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = 1

    For i = 1 To UBound(transferData, 1)
        validNew = TryGetLong(transferData(i, 2), newLtrg)
        validOld = TryGetLong(transferData(i, 4), oldLtrg)

        If validNew And validOld Then
            If CLng(newLtrg) <> CLng(oldLtrg) Then
                key = CStr(newLtrg)
                If Not dict.Exists(key) Then dict.Add key, True
                key = CStr(oldLtrg)
                If Not dict.Exists(key) Then dict.Add key, True
            End If
        End If
    Next

    Set BuildTargetLtrgs = dict
End Function

Sub ValidateCompanyAssignments(ByVal targets, ByVal companies)
    Dim key
    Dim missing

    missing = ""
    For Each key In targets.Keys
        If Not companies.Exists(CStr(key)) Then
            missing = missing & vbCrLf & "- LTRG " & FormatLtrg(CLng(key))
        End If
    Next

    If Len(missing) > 0 Then
        Err.Raise -2147221504 + 2021, "ARE Generator", _
                  "F�r folgende LTRG fehlt eine Zuordnung im Blatt '" & _
                  SHEET_COMPANIES & "':" & missing
    End If
End Sub

Sub AddGroupRecord(ByVal groups, ByVal counterpartyKey, ByVal sourceIndex, ByVal direction)
    Dim rowsInGroup

    If Not groups.Exists(counterpartyKey) Then
        Set rowsInGroup = CreateObject("Scripting.Dictionary")
        rowsInGroup.CompareMode = 1
        groups.Add counterpartyKey, rowsInGroup
    Else
        Set rowsInGroup = groups.Item(counterpartyKey)
    End If

    rowsInGroup.Add CStr(rowsInGroup.Count), Array(sourceIndex, direction)
End Sub

Sub SortNumericKeys(ByRef keys)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If CLng(keys(i)) > CLng(keys(j)) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Sub SortGroupKeys(ByRef keys, ByVal groups, ByRef transferData, ByVal targetLtrg)
    Dim i
    Dim j
    Dim temp

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If GroupKeyComesAfter(CStr(keys(i)), CStr(keys(j)), _
                                  groups, transferData, targetLtrg) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next
    Next
End Sub

Function GroupKeyComesAfter(ByVal firstKey, ByVal secondKey, ByVal groups, _
                            ByRef transferData, ByVal targetLtrg)
    Dim firstRows
    Dim secondRows
    Dim firstHasPositive
    Dim secondHasPositive

    If targetLtrg = CENTRAL_LTRG Then
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
        Exit Function
    End If

    Set firstRows = groups.Item(firstKey)
    Set secondRows = groups.Item(secondKey)

    firstHasPositive = GroupHasPositive(firstRows, transferData)
    secondHasPositive = GroupHasPositive(secondRows, transferData)

    If firstHasPositive <> secondHasPositive Then
        GroupKeyComesAfter = (Not firstHasPositive And secondHasPositive)
    Else
        GroupKeyComesAfter = (CLng(firstKey) > CLng(secondKey))
    End If
End Function

Function GroupHasPositive(ByVal rowsInGroup, ByRef transferData)
    Dim i
    Dim descriptor
    Dim sourceIndex
    Dim direction

    GroupHasPositive = False

    For i = 0 To rowsInGroup.Count - 1
        descriptor = rowsInGroup.Item(CStr(i))
        sourceIndex = CLng(descriptor(0))
        direction = CLng(descriptor(1))

        If direction * NzNumber(transferData(sourceIndex, 10)) > 0 Then
            GroupHasPositive = True
            Exit Function
        End If
    Next
End Function

Sub FormatARESheet(ByVal xlApp, ByVal ws, ByVal lastContentRow)
    Dim maxRow

    maxRow = MaxLong(lastContentRow, 7)

    If Not IsObject(gOverviewTemplateSheet) Then
        With ws.Cells
            .Font.Name = "Arial"
            .Font.Size = 10
            .Font.Color = RGBColor(0, 0, 0)
            .Font.Bold = False
            .Font.Italic = False
            .VerticalAlignment = xlCenter
            .Interior.Pattern = xlNone
        End With
    End If

    With ws.Range("H1:J" & CStr(maxRow))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .Borders.LineStyle = xlNone
    End With
    ws.Range("H1:J1").Font.Bold = True
    ws.Range("H3:I4").Font.Bold = True
    ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0"
    ws.Range("I4").FormatConditions.Delete

    If Not IsObject(gOverviewTemplateSheet) Then
        ws.Columns("A:B").NumberFormat = "0"
        ws.Columns("C").NumberFormat = "dd.mm.yyyy"
        ws.Columns("D:F").NumberFormat = "#,##0;-#,##0"
    End If
    ' Fachliche Layoutvorgabe ab 1.0.13:
    ' - sichtbarer ARE-Bericht in Marsh-Farbe RGB(0,15,71)
    ' - die beiden Erlaeuterungszeilen A6:F7 mit 9 pt und Textumbruch
    ' - Pensionen-(alt)-Spalte etwas breiter
    With ws.Range("A1:F" & CStr(maxRow))
        .Font.Color = RGBColor(0, 15, 71)
    End With
    With ws.Range("A6:F7")
        .Font.Size = 9
        .Font.Color = RGBColor(0, 15, 71)
        .WrapText = True
        .ShrinkToFit = False
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(6).RowHeight = 28
    ws.Rows(7).RowHeight = 28
    ws.Columns("D").ColumnWidth = 17.5

    ws.Columns("H").NumberFormat = "0"
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 9
    ws.Columns("I").ColumnWidth = 9
    ws.Columns("J").ColumnWidth = 40

    With ws.PageSetup
        .PrintArea = "$A$1:$F$" & CStr(maxRow)
        .PrintGridlines = False
        If Not IsObject(gOverviewTemplateSheet) Then
            .Orientation = xlPortrait
            .Zoom = False
            .FitToPagesWide = 1
            .FitToPagesTall = False
            .CenterHorizontally = True
            .LeftMargin = xlApp.CentimetersToPoints(1.2)
            .RightMargin = xlApp.CentimetersToPoints(1.2)
            .TopMargin = xlApp.CentimetersToPoints(1)
            .BottomMargin = xlApp.CentimetersToPoints(1)
            .HeaderMargin = xlApp.CentimetersToPoints(0.4)
            .FooterMargin = xlApp.CentimetersToPoints(0.4)
        End If
    End With

    On Error Resume Next
    ws.Activate
    xlApp.ActiveWindow.View = xlPageBreakPreview
    xlApp.ActiveWindow.Zoom = 58
    xlApp.ActiveWindow.DisplayGridlines = False
    Err.Clear
    On Error GoTo 0
End Sub

Sub FormatSection(ByVal ws, ByVal sectionRow, ByVal headerRow, _
                  ByVal dataStartRow, ByVal dataEndRow, ByVal subtotalRow)
    Dim rowNumber

    If IsObject(gOverviewTemplateSheet) Then
        ApplyTemplateRowFormat ws, sectionRow, 10
        ApplyTemplateRowFormat ws, headerRow, 11
        For rowNumber = dataStartRow To dataEndRow
            ApplyTemplateRowFormat ws, rowNumber, 12
        Next
        ApplyTemplateRowFormat ws, subtotalRow, 13
        ApplyTemplateRowFormat ws, subtotalRow + 1, 14
    Else
        With ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGBColor(0, 0, 0)
            .Font.Bold = True
            .Font.Size = 10
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .Borders.LineStyle = xlContinuous
            .Borders.Weight = xlMedium
        End With
        ws.Rows(sectionRow).RowHeight = 19

        With ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGBColor(0, 0, 0)
            .Font.Bold = True
            .Font.Size = 10
            .HorizontalAlignment = xlCenter
            .VerticalAlignment = xlCenter
            .WrapText = True
            .Borders.LineStyle = xlNone
        End With
        ws.Rows(headerRow).RowHeight = 31

        If dataEndRow >= dataStartRow Then
            With ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 6))
                .Interior.Pattern = xlNone
                .Font.Color = RGBColor(0, 0, 0)
                .Font.Bold = False
                .Borders.LineStyle = xlNone
            End With
            ws.Rows(CStr(dataStartRow) & ":" & CStr(dataEndRow)).RowHeight = 15
        End If

        With ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGBColor(0, 0, 0)
            .Font.Bold = True
            .Borders.LineStyle = xlNone
            .Borders(xlEdgeTop).LineStyle = xlContinuous
            .Borders(xlEdgeTop).Weight = xlThin
        End With
        ws.Rows(subtotalRow).RowHeight = 15
    End If

    With ws.Range(ws.Cells(sectionRow, 8), ws.Cells(sectionRow, 10))
        .Interior.Pattern = xlNone
        .Font.Color = RGBColor(0, 0, 0)
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With

    If Not IsObject(gOverviewTemplateSheet) Then
        If dataEndRow >= dataStartRow Then
            ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 3)).HorizontalAlignment = xlCenter
            ws.Range(ws.Cells(dataStartRow, 4), ws.Cells(dataEndRow, 6)).HorizontalAlignment = xlRight
        End If
    End If

    ' Fachliche Vorgabe: Abschnitt, Tabellenkopf und Summen immer fett.
    ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Font.Bold = True
    ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6)).Font.Bold = True
    ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6)).Font.Bold = True
End Sub

Function DiscoverOverviewLayout(ByVal ws)
    Dim bestMap
    Dim rowMap
    Dim requiredKeys
    Dim optionalKeys
    Dim key
    Dim canonical
    Dim headerValue
    Dim rowNumber
    Dim columnNumber
    Dim usedLastRow
    Dim usedLastColumn
    Dim scanLastRow
    Dim scanLastColumn
    Dim score
    Dim bestScore
    Dim bestRow
    Dim missing

    requiredKeys = Array("pnr_new", "ltrg_new", "pnr_old", "ltrg_old", _
                         "transfer_date", "bsav", "pension")
    optionalKeys = Array("last_cutoff", "months", "total")

    usedLastRow = GetUsedLastRowSafe(ws)
    usedLastColumn = GetUsedLastColumnSafe(ws)
    scanLastRow = MinLong(MaxLong(usedLastRow, 1), HEADER_SCAN_MAX_ROWS)
    scanLastColumn = MinLong(MaxLong(usedLastColumn, 1), HEADER_SCAN_MAX_COLUMNS)

    Set bestMap = Nothing
    bestScore = -1
    bestRow = 0

    For rowNumber = 1 To scanLastRow
        Set rowMap = CreateObject("Scripting.Dictionary")
        rowMap.CompareMode = 1

        For columnNumber = 1 To scanLastColumn
            headerValue = ReadCellValueSafe(ws.Cells(rowNumber, columnNumber))
            canonical = CanonicalOverviewHeader(headerValue)
            If Len(canonical) > 0 Then
                If Not rowMap.Exists(canonical) Then rowMap.Add canonical, columnNumber
            End If
        Next

        score = 0
        For Each key In requiredKeys
            If rowMap.Exists(CStr(key)) Then score = score + 100
        Next
        For Each key In optionalKeys
            If rowMap.Exists(CStr(key)) Then score = score + 10
        Next

        If score > bestScore Then
            bestScore = score
            bestRow = rowNumber
            Set bestMap = CloneDictionary(rowMap)
        End If
    Next

    missing = ""
    If Not (bestMap Is Nothing) Then
        For Each key In requiredKeys
            If Not bestMap.Exists(CStr(key)) Then
                missing = missing & vbCrLf & "- " & OverviewFieldLabel(CStr(key))
            End If
        Next
    Else
        For Each key In requiredKeys
            missing = missing & vbCrLf & "- " & OverviewFieldLabel(CStr(key))
        Next
    End If

    If Len(missing) > 0 Then
        Err.Raise -2147221504 + 2030, "ARE Generator", _
                  "Die ben�tigten Spalten im Blatt '" & ws.Name & "' konnten nicht vollst�ndig erkannt werden." & _
                  vbCrLf & "Die Reihenfolge ist beliebig; zus�tzliche Spalten wie ARE neu/alt sind erlaubt." & _
                  vbCrLf & "Fehlende Felder:" & missing & vbCrLf & _
                  "Beste gefundene Kopfzeile: Zeile " & CStr(bestRow) & "."
    End If

    bestMap.Item("_header_row") = bestRow
    WriteLog "INFO | �bersichtskopf in Zeile " & CStr(bestRow) & " erkannt | " & DescribeLayout(bestMap)
    Set DiscoverOverviewLayout = bestMap
End Function

Function DiscoverCompanyLayout(ByVal ws)
    Dim bestMap
    Dim rowMap
    Dim requiredKeys
    Dim key
    Dim canonical
    Dim headerValue
    Dim rowNumber
    Dim columnNumber
    Dim usedLastRow
    Dim usedLastColumn
    Dim scanLastRow
    Dim scanLastColumn
    Dim score
    Dim bestScore
    Dim bestRow
    Dim missing

    requiredKeys = Array("ltrg", "are", "name")
    usedLastRow = GetUsedLastRowSafe(ws)
    usedLastColumn = GetUsedLastColumnSafe(ws)
    scanLastRow = MinLong(MaxLong(usedLastRow, 1), HEADER_SCAN_MAX_ROWS)
    scanLastColumn = MinLong(MaxLong(usedLastColumn, 1), HEADER_SCAN_MAX_COLUMNS)

    Set bestMap = Nothing
    bestScore = -1
    bestRow = 0

    For rowNumber = 1 To scanLastRow
        Set rowMap = CreateObject("Scripting.Dictionary")
        rowMap.CompareMode = 1

        For columnNumber = 1 To scanLastColumn
            headerValue = ReadCellValueSafe(ws.Cells(rowNumber, columnNumber))
            canonical = CanonicalCompanyHeader(headerValue)
            If Len(canonical) > 0 Then
                If Not rowMap.Exists(canonical) Then rowMap.Add canonical, columnNumber
            End If
        Next

        score = 0
        For Each key In requiredKeys
            If rowMap.Exists(CStr(key)) Then score = score + 100
        Next

        If score > bestScore Then
            bestScore = score
            bestRow = rowNumber
            Set bestMap = CloneDictionary(rowMap)
        End If
    Next

    missing = ""
    If Not (bestMap Is Nothing) Then
        For Each key In requiredKeys
            If Not bestMap.Exists(CStr(key)) Then missing = missing & vbCrLf & "- " & UCase(CStr(key))
        Next
    Else
        For Each key In requiredKeys
            missing = missing & vbCrLf & "- " & UCase(CStr(key))
        Next
    End If

    If Len(missing) > 0 Then
        Err.Raise -2147221504 + 2032, "ARE Generator", _
                  "Die Stammdatenspalten im Blatt '" & ws.Name & "' konnten nicht erkannt werden." & _
                  vbCrLf & "Erforderlich sind LTRG, ARE und Name � unabh�ngig von der Reihenfolge." & _
                  vbCrLf & "Fehlende Felder:" & missing
    End If

    bestMap.Item("_header_row") = bestRow
    WriteLog "INFO | Gesellschaftskopf in Zeile " & CStr(bestRow) & " erkannt | " & DescribeLayout(bestMap)
    Set DiscoverCompanyLayout = bestMap
End Function

Function CanonicalOverviewHeader(ByVal rawValue)
    Dim normalized
    Dim compact

    CanonicalOverviewHeader = ""
    normalized = NormalizeHeaderCell(rawValue)
    compact = Replace(normalized, " ", "")

    Select Case compact
        Case "pnrneu", "personalnummerneu", "personalnrneu"
            CanonicalOverviewHeader = "pnr_new"
            Exit Function
        Case "ltrgneu", "ltgrneu", "lgtrneu", "ltrgrneu", "leistungstraegerneu", "leistungstragerneu"
            CanonicalOverviewHeader = "ltrg_new"
            Exit Function
        Case "pnralt", "personalnummeralt", "personalnralt"
            CanonicalOverviewHeader = "pnr_old"
            Exit Function
        Case "ltrgalt", "ltgralt", "lgtralt", "ltrgralt", "leistungstraegeralt", "leistungstrageralt"
            CanonicalOverviewHeader = "ltrg_old"
            Exit Function
        Case "uebertritt", "uebertrittsdatum", "datumdeseinzeluebertritts", _
             "datumeinzeluebertritt", "datumdeseinzeluebertritt"
            CanonicalOverviewHeader = "transfer_date"
            Exit Function
        Case "letzterstichtag1", "letzterstichtagplus1"
            CanonicalOverviewHeader = "last_cutoff"
            Exit Function
        Case "monatebisuebertritt", "monatebiszumeinzeluebertritt"
            CanonicalOverviewHeader = "months"
            Exit Function
        Case "bsav", "bsaveuro", "uebertragungswertbsav", "uebertragungswertbsaveuro"
            CanonicalOverviewHeader = "bsav"
            Exit Function
        Case "pensionenalt", "pensionenalteuro", "pensionalt", _
             "uebertragungswertpensionenalt", "uebertragungswertpensionenalteuro"
            CanonicalOverviewHeader = "pension"
            Exit Function
        Case "summe", "summeeuro", "gesamt", "gesamtbetrag", "uebertragungswertsumme"
            CanonicalOverviewHeader = "total"
            Exit Function
    End Select

    If InStr(1, compact, "datum", 1) > 0 And InStr(1, compact, "einzeluebertritt", 1) > 0 Then
        CanonicalOverviewHeader = "transfer_date"
    ElseIf InStr(1, compact, "bsav", 1) > 0 And InStr(1, compact, "summe", 1) = 0 Then
        CanonicalOverviewHeader = "bsav"
    ElseIf InStr(1, compact, "pension", 1) > 0 And InStr(1, compact, "alt", 1) > 0 Then
        CanonicalOverviewHeader = "pension"
    End If
End Function

Function CanonicalCompanyHeader(ByVal rawValue)
    Dim normalized
    Dim compact

    CanonicalCompanyHeader = ""
    normalized = NormalizeHeaderCell(rawValue)
    compact = Replace(normalized, " ", "")

    Select Case compact
        Case "ltrg", "ltgr", "lgtr", "ltrgr", "leistungstraeger", "leistungstrager", "ltrgneu", "ltgrneu", "lgtrneu", "ltrgrneu"
            CanonicalCompanyHeader = "ltrg"
        Case "are", "arenummer", "arewert", "arecode"
            CanonicalCompanyHeader = "are"
        Case "name", "gesellschaft", "gesellschaftsname", "firmenname", "unternehmen"
            CanonicalCompanyHeader = "name"
    End Select
End Function

Function NormalizeHeaderCell(ByVal cellText)
    Dim textValue
    Dim punctuation
    Dim item

    textValue = LCase(Trim(SafeString(cellText)))
    textValue = Replace(textValue, vbCr, " ")
    textValue = Replace(textValue, vbLf, " ")
    textValue = Replace(textValue, Chr(160), " ")
    textValue = Replace(textValue, "�", "ae")
    textValue = Replace(textValue, "�", "oe")
    textValue = Replace(textValue, "�", "ue")
    textValue = Replace(textValue, "�", "ss")

    punctuation = Array("(", ")", "[", "]", "{", "}", ":", ";", ",", ".", _
                        "_", "-", "/", "\", "+", "'", Chr(34))
    For Each item In punctuation
        textValue = Replace(textValue, CStr(item), " ")
    Next

    Do While InStr(1, textValue, "  ", 1) > 0
        textValue = Replace(textValue, "  ", " ")
    Loop

    NormalizeHeaderCell = Trim(textValue)
End Function

Function OverviewFieldLabel(ByVal key)
    Select Case key
        Case "pnr_new": OverviewFieldLabel = "PNR neu"
        Case "ltrg_new": OverviewFieldLabel = "LTRG neu"
        Case "pnr_old": OverviewFieldLabel = "PNR alt"
        Case "ltrg_old": OverviewFieldLabel = "LTRG alt"
        Case "transfer_date": OverviewFieldLabel = "Datum des Einzel�bertritts"
        Case "bsav": OverviewFieldLabel = "�bertragungswert BSAV"
        Case "pension": OverviewFieldLabel = "�bertragungswert Pensionen (alt)"
        Case "total": OverviewFieldLabel = "Summe"
        Case Else: OverviewFieldLabel = key
    End Select
End Function

Function CloneDictionary(ByVal source)
    Dim result
    Dim key

    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = 1
    For Each key In source.Keys
        result.Add CStr(key), source.Item(key)
    Next
    Set CloneDictionary = result
End Function

Function DescribeLayout(ByVal layout)
    Dim key
    Dim description

    description = ""
    For Each key In layout.Keys
        If Left(CStr(key), 1) <> "_" Then
            If Len(description) > 0 Then description = description & " | "
            description = description & CStr(key) & "=" & ExcelColumnLetter(CLng(layout.Item(key)))
        End If
    Next
    DescribeLayout = description
End Function

Function GetUsedLastRowSafe(ByVal ws)
    Dim usedStart
    Dim usedCount

    GetUsedLastRowSafe = 1
    On Error Resume Next
    Err.Clear
    usedStart = CLng(ws.UsedRange.Row)
    usedCount = CLng(ws.UsedRange.Rows.Count)
    If Err.Number = 0 Then GetUsedLastRowSafe = usedStart + usedCount - 1
    Err.Clear
    On Error GoTo 0
End Function

Function GetUsedLastColumnSafe(ByVal ws)
    Dim usedStart
    Dim usedCount

    GetUsedLastColumnSafe = 1
    On Error Resume Next
    Err.Clear
    usedStart = CLng(ws.UsedRange.Column)
    usedCount = CLng(ws.UsedRange.Columns.Count)
    If Err.Number = 0 Then GetUsedLastColumnSafe = usedStart + usedCount - 1
    Err.Clear
    On Error GoTo 0
End Function

Function ReadCellTextSafe(ByVal cell)
    Dim value

    ReadCellTextSafe = ""

    ' F�r Kopfzeilen ist Value2 zuverl�ssiger als Text: Text kann wegen einer
    ' schmalen Spalte gek�rzt oder als #### angezeigt werden.
    On Error Resume Next
    Err.Clear
    value = cell.Value2
    If Err.Number <> 0 Then
        Err.Clear
        value = cell.Text
    End If
    On Error GoTo 0

    ReadCellTextSafe = SafeString(value)
End Function

Function ReadCellValueSafe(ByVal cell)
    Dim value
    Dim valueType

    ReadCellValueSafe = Empty

    On Error Resume Next
    Err.Clear
    value = cell.Value2
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = VB_ERROR_TYPE Then Exit Function
    ReadCellValueSafe = value
End Function

Function CellHasContent(ByVal cell)
    Dim value
    Dim valueType

    CellHasContent = False
    value = ReadCellValueSafe(cell)

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    If valueType = 8 Then
        CellHasContent = (Len(Trim(SafeString(value))) > 0)
    Else
        CellHasContent = True
    End If
End Function

Function IsBlankValue(ByVal value)
    Dim valueType

    IsBlankValue = True
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Or valueType = 1 Or valueType = VB_ERROR_TYPE Then Exit Function
    If valueType = 8 Then
        IsBlankValue = (Len(Trim(SafeString(value))) = 0)
    Else
        IsBlankValue = False
    End If
End Function

Function HasNumericValue(ByVal value)
    Dim valueType
    Dim textValue

    HasNumericValue = False
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Or valueType = 1 Or valueType = VB_ERROR_TYPE Then Exit Function
    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then Exit Function
    HasNumericValue = IsNumeric(textValue)
End Function

Function FindLastTransferRow(ByVal ws, ByVal layout, ByVal firstDataRow)
    Dim usedLast
    Dim rowNumber
    Dim key
    Dim fields
    Dim columnNumber

    FindLastTransferRow = firstDataRow - 1
    usedLast = GetUsedLastRowSafe(ws)
    If usedLast < firstDataRow Then Exit Function

    fields = Array("pnr_new", "ltrg_new", "pnr_old", "ltrg_old", _
                   "transfer_date", "bsav", "pension", "total")

    For rowNumber = usedLast To firstDataRow Step -1
        For Each key In fields
            If layout.Exists(CStr(key)) Then
                columnNumber = CLng(layout.Item(CStr(key)))
                If CellHasContent(ws.Cells(rowNumber, columnNumber)) Then
                    FindLastTransferRow = rowNumber
                    Exit Function
                End If
            End If
        Next
    Next
End Function

Function ReadMappedCell(ByVal ws, ByVal rowNumber, ByVal layout, ByVal key)
    ReadMappedCell = Empty
    If layout.Exists(CStr(key)) Then
        ReadMappedCell = ReadCellValueSafe(ws.Cells(rowNumber, CLng(layout.Item(CStr(key)))))
    End If
End Function

Sub LoadTransferData(ByVal ws, ByVal lastRow, ByVal layout, ByVal firstDataRow, ByRef data)
    Dim rowCount
    Dim sourceRow
    Dim targetRow
    Dim bsavValue
    Dim pensionValue
    Dim totalValue

    rowCount = lastRow - firstDataRow + 1
    If rowCount <= 0 Then
        Err.Raise -2147221504 + 2031, "ARE Generator", _
                  "Es konnten keine Datenzeilen eingelesen werden."
    End If

    ReDim data(rowCount, 10)

    targetRow = 1
    For sourceRow = firstDataRow To lastRow
        data(targetRow, 1) = ReadMappedCell(ws, sourceRow, layout, "pnr_new")
        data(targetRow, 2) = ReadMappedCell(ws, sourceRow, layout, "ltrg_new")
        data(targetRow, 3) = ReadMappedCell(ws, sourceRow, layout, "pnr_old")
        data(targetRow, 4) = ReadMappedCell(ws, sourceRow, layout, "ltrg_old")
        data(targetRow, 5) = ReadMappedCell(ws, sourceRow, layout, "transfer_date")
        data(targetRow, 6) = ReadMappedCell(ws, sourceRow, layout, "last_cutoff")
        data(targetRow, 7) = ReadMappedCell(ws, sourceRow, layout, "months")

        bsavValue = ReadMappedCell(ws, sourceRow, layout, "bsav")
        pensionValue = ReadMappedCell(ws, sourceRow, layout, "pension")
        totalValue = ReadMappedCell(ws, sourceRow, layout, "total")

        data(targetRow, 8) = bsavValue
        data(targetRow, 9) = pensionValue
        If HasNumericValue(totalValue) Then
            data(targetRow, 10) = totalValue
        Else
            data(targetRow, 10) = NzNumber(bsavValue) + NzNumber(pensionValue)
        End If

        targetRow = targetRow + 1
    Next

    WriteLog "INFO | " & CStr(rowCount) & " Datenzeilen �ber dynamische Spaltenzuordnung eingelesen"
End Sub

Function FindLastCompanyRow(ByVal ws, ByVal layout, ByVal firstDataRow)
    Dim usedLast
    Dim rowNumber
    Dim ltrgColumn
    Dim nameColumn

    FindLastCompanyRow = firstDataRow - 1
    usedLast = GetUsedLastRowSafe(ws)
    ltrgColumn = CLng(layout.Item("ltrg"))
    nameColumn = CLng(layout.Item("name"))

    For rowNumber = usedLast To firstDataRow Step -1
        If CellHasContent(ws.Cells(rowNumber, ltrgColumn)) Or _
           CellHasContent(ws.Cells(rowNumber, nameColumn)) Then
            FindLastCompanyRow = rowNumber
            Exit Function
        End If
    Next
End Function

Function ExcelColumnLetter(ByVal columnNumber)
    Dim result
    Dim value

    result = ""
    value = CLng(columnNumber)
    Do While value > 0
        value = value - 1
        result = Chr(65 + (value Mod 26)) & result
        value = value \ 26
    Loop
    ExcelColumnLetter = result
End Function

Function GetWorksheetOrNothing(ByVal wb, ByVal sheetName)
    Dim ws
    Dim requested
    Dim candidate

    Set ws = Nothing
    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    If ws Is Nothing Then
        requested = Replace(NormalizeHeaderCell(sheetName), " ", "")
        For Each candidate In wb.Worksheets
            If WorksheetNameMatchesRole(Replace(NormalizeHeaderCell(candidate.Name), " ", ""), requested) Then
                Set ws = candidate
                Exit For
            End If
        Next
    End If

    Set GetWorksheetOrNothing = ws
End Function

Function WorksheetNameMatchesRole(ByVal candidate, ByVal requested)
    WorksheetNameMatchesRole = False

    If candidate = requested Then
        WorksheetNameMatchesRole = True
        Exit Function
    End If

    If requested = "uebersicht" Then
        WorksheetNameMatchesRole = (candidate = "overview" Or candidate = "uebersichtdaten")
    ElseIf requested = "gesellschaften" Then
        WorksheetNameMatchesRole = (candidate = "gesellschaft" Or candidate = "companies" Or _
                                    candidate = "company" Or candidate = "stammdaten")
    End If
End Function

Sub DeleteGeneratedSheets(ByVal wb)
    Dim i
    Dim sheetName

    For i = wb.Worksheets.Count To 1 Step -1
        sheetName = wb.Worksheets(i).Name
        If Left(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", 1) > 0 Then
            wb.Worksheets(i).Delete
        End If
    Next
End Sub

Function BuildSheetName(ByVal ltrg, ByVal areValue)
    BuildSheetName = SafeSheetName( _
        "ARE " & DisplayValue(areValue) & _
        " (LTRG " & FormatLtrg(ltrg) & ")" _
    )
End Function

Function UniqueSheetName(ByVal wb, ByVal requestedName)
    Dim baseName
    Dim candidate
    Dim suffix
    Dim counter

    baseName = SafeSheetName(requestedName)
    candidate = baseName
    counter = 2

    Do While WorksheetExists(wb, candidate)
        suffix = "_" & CStr(counter)
        candidate = Left(baseName, 31 - Len(suffix)) & suffix
        counter = counter + 1
    Loop

    UniqueSheetName = candidate
End Function

Function WorksheetExists(ByVal wb, ByVal sheetName)
    Dim ws
    Set ws = Nothing

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    WorksheetExists = Not (ws Is Nothing)
End Function

Function SafeSheetName(ByVal value)
    Dim forbidden
    Dim item

    forbidden = Array("\", "/", ":", "*", "?", "[", "]")

    For Each item In forbidden
        value = Replace(value, CStr(item), "-")
    Next

    value = Trim(value)
    If Len(value) = 0 Then value = "ARE-Auswertung"
    If Len(value) > 31 Then value = Left(value, 31)

    SafeSheetName = value
End Function

Function FormatLtrg(ByVal ltrg)
    Dim value
    value = CStr(ltrg)
    If Len(value) < 4 Then value = Right("0000" & value, 4)
    FormatLtrg = value
End Function

Function ShortCompanyName(ByVal fullName)
    Dim commaPosition

    fullName = Trim(fullName)
    commaPosition = InStr(1, fullName, ",", 1)

    If commaPosition > 0 Then
        ShortCompanyName = Trim(Left(fullName, commaPosition - 1))
    Else
        ShortCompanyName = fullName
    End If
End Function

Function DisplayValue(ByVal value)
    Dim textValue

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then
        DisplayValue = "n.v."
    Else
        DisplayValue = textValue
    End If
End Function

Function SafeString(ByVal value)
    Dim valueType

    SafeString = ""

    ' Wichtig: VBScript wertet OR-Ausdr�cke vollst�ndig aus. Bei einem
    ' Excel-Fehlerwert kann bereits IsNull(value) einen Type mismatch ausl�sen.
    ' Deshalb wird zuerst ausschlie�lich der Variant-Typ gepr�ft.
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function   ' Empty
    If valueType = 1 Then Exit Function   ' Null
    If valueType = VB_ERROR_TYPE Then Exit Function

    On Error Resume Next
    SafeString = CStr(value)
    If Err.Number <> 0 Then
        Err.Clear
        SafeString = ""
    End If
    On Error GoTo 0
End Function

Function IsVariantError(ByVal value)
    Dim valueType

    IsVariantError = False
    On Error Resume Next
    valueType = VarType(value)
    If Err.Number = 0 Then
        IsVariantError = (valueType = VB_ERROR_TYPE)
    Else
        Err.Clear
        IsVariantError = True
    End If
    On Error GoTo 0
End Function

Function NzNumber(ByVal value)
    Dim valueType
    Dim textValue
    Dim convertedValue

    NzNumber = 0

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then Exit Function
    If Not IsNumeric(textValue) Then Exit Function

    On Error Resume Next
    convertedValue = CDbl(textValue)
    If Err.Number = 0 Then
        NzNumber = convertedValue
    Else
        Err.Clear
        NzNumber = 0
    End If
    On Error GoTo 0
End Function

Function TryGetLong(ByVal value, ByRef result)
    Dim valueType
    Dim textValue
    Dim convertedValue

    TryGetLong = False

    On Error Resume Next
    valueType = VarType(value)
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    If valueType = 0 Then Exit Function
    If valueType = 1 Then Exit Function
    If valueType = VB_ERROR_TYPE Then Exit Function

    textValue = Trim(SafeString(value))
    If Len(textValue) = 0 Then Exit Function
    If Not IsNumeric(textValue) Then Exit Function

    On Error Resume Next
    convertedValue = CLng(CDbl(textValue))
    If Err.Number <> 0 Then
        Err.Clear
        On Error GoTo 0
        Exit Function
    End If
    On Error GoTo 0

    result = convertedValue
    TryGetLong = True
End Function

Function RGBColor(ByVal redValue, ByVal greenValue, ByVal blueValue)
    RGBColor = CLng(redValue) + CLng(greenValue) * 256 + CLng(blueValue) * 65536
End Function

Function MaxLong(ByVal firstValue, ByVal secondValue)
    If CLng(firstValue) >= CLng(secondValue) Then
        MaxLong = CLng(firstValue)
    Else
        MaxLong = CLng(secondValue)
    End If
End Function

Function MinLong(ByVal firstValue, ByVal secondValue)
    If CLng(firstValue) <= CLng(secondValue) Then
        MinLong = CLng(firstValue)
    Else
        MinLong = CLng(secondValue)
    End If
End Function

Sub ResetLog()
    Dim fso
    Dim file

    On Error Resume Next
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set file = fso.CreateTextFile(gLogPath, True, True)
    If Err.Number = 0 Then
        file.WriteLine "ARE Generator Diagnose"
        file.WriteLine "Version: " & TOOL_VERSION
        file.WriteLine "Start: " & CStr(Now)
        file.WriteLine String(72, "-")
        file.Close
    Else
        Err.Clear
    End If
    Set file = Nothing
    Set fso = Nothing
    On Error GoTo 0
End Sub

Sub WriteLog(ByVal message)
    Dim fso
    Dim file

    If Len(SafeString(gLogPath)) = 0 Then Exit Sub

    On Error Resume Next
    Set fso = CreateObject("Scripting.FileSystemObject")
    Set file = fso.OpenTextFile(gLogPath, 8, True, -1)
    If Err.Number = 0 Then
        file.WriteLine CStr(Now) & " | " & SafeString(message)
        file.Close
    Else
        Err.Clear
    End If
    Set file = Nothing
    Set fso = Nothing
    On Error GoTo 0
End Sub

Function SafeDisplayPath(ByVal value)
    Dim textValue

    textValue = SafeString(value)
    If Len(textValue) = 0 Then
        SafeDisplayPath = "<Protokoll konnte nicht angelegt werden>"
    Else
        SafeDisplayPath = textValue
    End If
End Function

Function BuildOutputPath(ByVal fso, ByVal sourcePath, ByVal outputFolder)
    Dim folder
    Dim baseName
    Dim extension
    Dim candidate
    Dim stamp

    folder = CStr(outputFolder)
    baseName = fso.GetBaseName(sourcePath)
    extension = LCase(fso.GetExtensionName(sourcePath))

    candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung." & extension)

    If fso.FileExists(candidate) Then
        stamp = CStr(Year(Now)) & TwoDigits(Month(Now)) & TwoDigits(Day(Now)) & _
                "_" & TwoDigits(Hour(Now)) & TwoDigits(Minute(Now)) & TwoDigits(Second(Now))
        candidate = fso.BuildPath(folder, baseName & "_ARE_Auswertung_" & stamp & "." & extension)
    End If

    BuildOutputPath = candidate
End Function

Function BuildReportPeriod(ByVal baseName)
    Dim regex
    Dim matches
    Dim yearValue
    Dim previousYear

    BuildReportPeriod = "2024/25"
    Set regex = CreateObject("VBScript.RegExp")
    regex.Pattern = "(19|20)[0-9]{2}"
    regex.Global = False
    regex.IgnoreCase = True

    If regex.Test(SafeString(baseName)) Then
        Set matches = regex.Execute(SafeString(baseName))
        yearValue = CLng(matches(0).Value)
        previousYear = yearValue - 1
        BuildReportPeriod = CStr(previousYear) & "/" & Right(CStr(yearValue), 2)
    End If
End Function

Function TwoDigits(ByVal value)
    TwoDigits = Right("0" & CStr(value), 2)
End Function
