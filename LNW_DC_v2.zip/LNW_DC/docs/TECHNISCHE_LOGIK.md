# Technische Logik

## Bereinigung

Bereich: `AJ<erste Datenzeile>:CU<letzte Datenzeile>`

Gelöscht werden nur Excel-Zellen des Typs **Konstante**. Zellen mit Formeln werden nicht überschrieben. Die Headerzeile wird dynamisch über den Header `WWID` erkannt und von der Bereinigung ausgeschlossen.

## Jahresfortschreibung

| Vorjahresende | Neuer Startbestand |
|---|---|
| CL | AJ |
| CM | AK |
| CN | AL |
| CO | AM |
| CP | AN |
| CQ | AO |
| CR | AP |
| CS | AQ |
| CT | AR |
| CU | AS |

Das Mapping erfolgt WWID-genau, nicht zeilenpositionsbezogen.

## DU-Aggregationsschlüssel

`(WWID, Fondsname, Umsatzart)`

Je Schlüssel werden jetzt drei Quellkennzahlen getrennt summiert:

- Anteile: `UmsatzStuecke`
- Zahlungswert: `ZahlBetrag`
- Anlagebetrag: `Anlbetrag`

Dadurch können verschiedene Zielblöcke auf unterschiedliche Wertfelder zugreifen, ohne die bestehende CL:CU-Logik zu verändern.

## Käufe aus Umwandlungen AU:BC

Filter: `Umsatzart = Kauf`

| Ziel | Fondsname | Quellfeld |
|---|---|---|
| AV | DWS EURORENTA | UmsatzStuecke |
| AW | DWS EURORENTA | Anlbetrag |
| AX | DWS INS.-ESG EO MO.M.IC | UmsatzStuecke |
| AY | DWS INS.-ESG EO MO.M.IC | Anlbetrag |
| BB | DWSI-EUR.EQ.HI.CO.FC | UmsatzStuecke |
| BC | DWSI-EUR.EQ.HI.CO.FC | Anlbetrag |

`AU`, `AZ` und `BA` sind in der aktuellen Fachlogik nicht belegt. Konstante Altwerte werden beim Bereinigen entfernt; Formeln bleiben bestehen.

## Bewegungsblock BF:BN

Filter laut aktuellem Fachstand: `Umsatzart = Fondsportfolioanpassung`

| Ziel | Fondsname | Quellfeld |
|---|---|---|
| BF | DWS EURORENTA | UmsatzStuecke |
| BG | DWS EURORENTA | ZahlBetrag |
| BI | DWSI-EUR.EQ.HI.CO.FC | UmsatzStuecke |
| BJ | DWSI-EUR.EQ.HI.CO.FC | ZahlBetrag |
| BK | DWS EURORENTA | UmsatzStuecke |
| BL | DWS EURORENTA | ZahlBetrag |
| BM | DWS INS.-ESG EO MO.M.IC | UmsatzStuecke |
| BN | DWS INS.-ESG EO MO.M.IC | ZahlBetrag |

`BH` ist aktuell nicht belegt.

Hinweis: `BF:BG` heißen fachlich „Ertragsausschüttung“, verwenden nach der aktuell gelieferten Spezifikation aber ebenfalls `Fondsportfolioanpassung`. Diese Regel ist bewusst so umgesetzt und über `movement_type_distribution` konfigurierbar.

## Stichtagsblock CL:CU

Die Endbestände verwenden weiterhin ausschließlich:

- `UmsatzStuecke` für Anteile
- `ZahlBetrag` für Werte

und summieren die in `movement_types_end_balance` konfigurierten Umsatzarten zum jeweiligen Startbestand `AJ:AS`. `Anlbetrag` wird für CL:CU nicht verwendet.

## Schutzmechanismen

- Input-Datei bleibt unverändert.
- Verarbeitung erfolgt nur in einer Kopie.
- Excel-Makros werden durch Nutzung der nativen Excel-Anwendung erhalten.
- Formeln werden weder gelöscht noch mit berechneten Konstanten überschrieben.
- Nicht definierte Spalten erhalten keine erfundenen Werte.
- Bei einem Fehler wird die unvollständige Output-Kopie entfernt.
