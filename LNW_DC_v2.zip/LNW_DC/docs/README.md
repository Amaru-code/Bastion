# LNW DC

## Voraussetzungen

- Windows 10/11
- Microsoft Excel Desktop
- Python 3.11 oder neuer

## Start

1. `install.bat` einmalig ausführen.
2. Danach `start.bat` öffnen.
3. LNW-Template und DU-Datei auswählen.
4. Optional ein Vorjahrestemplate auswählen.
5. Verarbeitung starten.

## Verarbeitungslogik

- Das Input-Template wird niemals direkt geändert.
- Zuerst wird eine neue Kopie im Output-Ordner erzeugt.
- Im Blatt `Import DC LNW` werden ab Spalte AJ bis CU ausschließlich konstante Zellinhalte der Datenzeilen gelöscht.
- Header und Formeln bleiben unangetastet.
- Ohne Vorjahrestemplate werden die ursprünglichen AJ:AS-Werte des aktuellen Templates als Startbestand wieder eingesetzt.
- Mit Vorjahrestemplate erfolgt die WWID-genaue Übergabe `CL:CU -> AJ:AS`.

### Käufe aus Umwandlungen AU:BC

Für `Umsatzart = Kauf` werden folgende Werte aus der DU-Datei aggregiert:

- `AV` DWS EURORENTA Anteile = Summe `UmsatzStuecke`
- `AW` DWS EURORENTA Wert = Summe `Anlbetrag`
- `AX` DWS INS.-ESG EO MO.M.IC Anteile = Summe `UmsatzStuecke`
- `AY` DWS INS.-ESG EO MO.M.IC Wert = Summe `Anlbetrag`
- `BB` DWSI-EUR.EQ.HI.CO.FC Anteile = Summe `UmsatzStuecke`
- `BC` DWSI-EUR.EQ.HI.CO.FC Wert = Summe `Anlbetrag`

Die Spalten `AU`, `AZ` und `BA` erhalten durch diese Logik keinen neuen konstanten Wert. Vorhandene Formeln bleiben erhalten.

### Bewegungsblock BF:BN

Gemäß dem aktuell dokumentierten Fachstand wird für `Umsatzart = Fondsportfolioanpassung` geschrieben:

- `BF` DWS EURORENTA Anteile = Summe `UmsatzStuecke`
- `BG` DWS EURORENTA Wert = Summe `ZahlBetrag`
- `BI:BJ` DWSI-EUR.EQ.HI.CO.FC = `UmsatzStuecke` / `ZahlBetrag`
- `BK:BL` DWS EURORENTA = `UmsatzStuecke` / `ZahlBetrag`
- `BM:BN` DWS INS.-ESG EO MO.M.IC = `UmsatzStuecke` / `ZahlBetrag`

`BH` erhält durch diese Logik keinen neuen konstanten Wert. Vorhandene Formeln bleiben erhalten.

### Stichtagsblock CL:CU

`CL:CU` berechnet Startbestand plus die signierten DU-Summen aus `UmsatzStuecke` bzw. `ZahlBetrag` für:

- Wiederanlage Ertragsaussc
- Fondsportfolioanpassung
- Verkauf wegen Vorabpausch

Die DU-Werte werden so addiert, wie sie in der Quelldatei vorliegen. Negative Verkäufe reduzieren den Bestand automatisch.

Zusätzlich wird eine semikolongetrennte UTF-8-CSV mit allen Werten des Zielblatts erzeugt.

## Fonds-Mapping

- DWSI-EUR.EQ.HI.CO.FC
- DWS EURORENTA
- DWS INS.-ESG EO MO.M.IC
- SIEMENS EUROINVEST AKTIEN
- SIEMENS EUROINVEST RENTEN

## Benötigte DU-Spalten

Die DU-Datei muss die folgenden Header enthalten:

- `WWID`
- `Fondsname`
- `Umsatzart`
- `UmsatzStuecke`
- `ZahlBetrag`
- `Anlbetrag`

Gängige Schreibvarianten der Header werden vom Skript berücksichtigt.

## Konfiguration

In `config/settings.json` können Blattname, CSV-Trennzeichen und relevante Umsatzarten angepasst werden.

## Protokoll

Fehler und Verarbeitungsschritte werden in `logs/lnw_dc.log` gespeichert.
