@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"

if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
set "VENV_DIR=%LOCALAPPDATA%\MercerDataTool\venv"
set "PYTHONW=%VENV_DIR%\Scripts\pythonw.exe"
set "PYTHON=%VENV_DIR%\Scripts\python.exe"

if not exist "%PYTHONW%" (
    echo Die Anwendung ist noch nicht vollstaendig installiert.
    echo INSTALL.bat wird jetzt gestartet.
    echo.
    call "%~dp0INSTALL.bat"
    if errorlevel 1 exit /b 1
)

REM Kurzer Importtest verhindert einen stillen Start bei unvollstaendiger Installation.
"%PYTHON%" -c "import PySide6, openpyxl" >nul 2>&1
if errorlevel 1 (
    echo Die lokale Installation ist unvollstaendig oder beschaedigt.
    echo INSTALL.bat wird zur Reparatur gestartet.
    echo.
    call "%~dp0INSTALL.bat"
    if errorlevel 1 exit /b 1
)

start "" "%PYTHONW%" "%~dp0app\main.py"
exit /b 0
