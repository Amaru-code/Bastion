from __future__ import annotations

import csv
import io
import re
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Sequence

from .settings import SETTINGS
from .wwid_mapping import load_wwid_mapping


MARKER_PREFIXES = (
    ">>>>",
    "<<<<",
    ">>>",
    "<<<",
    "====",
)

METADATA_LABELS = {
    "dateiname",
    "datei name",
    "info",
    "informationen",
    "groesse",
    "größe",
    "dateigroesse",
    "dateigröße",
    "typ",
    "dateityp",
    "erstellungsdatum",
    "erstellt am",
    "geaendert am",
    "geändert am",
    "aenderungsdatum",
    "änderungsdatum",
}

KNOWN_HEADER_TERMS = {
    "erstellungsdatum",
    "vermittlerzentrale",
    "vermittlernummer",
    "kundenidentifikator",
    "kunden_identifikator",
    "depotnummer",
    "unterdepot",
    "wkn",
    "isin",
    "kag",
    "fondsname",
    "depotvariante",
    "anteilspreis",
    "waehrungpreis",
    "währungpreis",
    "produktart",
    "bestandstuecke",
    "bestand_stuecke",
    "bestandbetrag",
    "bestand_betrag",
    "firmenid",
    "dat",
    # DU-spezifische Header
    "wwid",
    "umsatzstuecke",
    "umsatz_stuecke",
    "abgerechneterpreis",
    "anlbetrag",
    "zahlbetrag",
    "umsatzart",
    "devisenkurs",
    "kursdatum",
    "zvf_id_alt",
    "zvu_id_alt",
    # DP-spezifische Header
    "eroeffnungsdatum",
    "währung_bestand",
    "waehrung_bestand",
    "schlusstag",
    "bonus",
    "status",
    "id-mercer",
}


@dataclass
class ParsedTable:
    header: list[str]
    rows: list[list[str]]
    source_sheet: str = ""


def clean_cell(value: object) -> str:
    if value is None:
        return ""
    text = str(value).replace("\u00a0", " ").strip()
    return text


def normalize_header(value: object) -> str:
    text = clean_cell(value).lower()
    text = (
        text.replace("ä", "ae")
        .replace("ö", "oe")
        .replace("ü", "ue")
        .replace("ß", "ss")
    )
    return re.sub(r"[^a-z0-9]+", "", text)


DU_PROFILE_MARKERS = {
    "umsatzstuecke",
    "abgerechneterpreis",
    "anlbetrag",
    "zahlbetrag",
    "umsatzart",
    "devisenkurs",
    "zvfidalt",
    "zvuidalt",
}

DP_PROFILE_MARKERS = {
    "anteilspreis",
    "eroeffnungsdatum",
    "bestandstuecke",
    "bestandbetrag",
    "waehrungbestand",
    "schlusstag",
    "idmercer",
}


def profile_from_filename(source_name: str | Path | None) -> str | None:
    """Erkennt DU/DP zuverlässig am Dateinamen.

    Rohdateien besitzen häufig noch keinen Header. Deshalb hat der Dateiname
    Vorrang vor jeder inhaltlichen Heuristik:

    - DU_... / DU-... / "DU ..." -> DU
    - DP_... / DP-... / "DP ..." -> DP

    Nur wenn der Name keinen eindeutigen Präfix besitzt, wird später auf die
    bisherige Header-/Breitenerkennung zurückgefallen.
    """
    if source_name is None:
        return None

    name = Path(str(source_name)).name.strip().casefold()
    stem = Path(name).stem.strip()

    if re.match(r"^du(?:[_\-\s]|$)", stem):
        return "du"
    if re.match(r"^dp(?:[_\-\s]|$)", stem):
        return "dp"
    return None


def detect_target_profile(
    source_header: Sequence[object],
    *,
    fallback_width: int | None = None,
    source_name: str | Path | None = None,
) -> str:
    """Erkennt automatisch, ob eine Quelldatei eine DU- oder DP-Struktur hat.

    Priorität:
    1. Dateiname (DU_... bzw. DP_...)
    2. fachlich eindeutige Header
    3. Spaltenanzahl als Fallback für Altdateien ohne eindeutigen Namen/Header
    """
    filename_profile = profile_from_filename(source_name)
    if filename_profile is not None:
        return filename_profile

    normalized = {
        normalize_header(value)
        for value in source_header
        if clean_cell(value)
    }

    du_score = len(normalized.intersection(DU_PROFILE_MARKERS))
    dp_score = len(normalized.intersection(DP_PROFILE_MARKERS))

    if du_score >= 2 and du_score > dp_score:
        return "du"
    if dp_score >= 2 and dp_score > du_score:
        return "dp"

    width = fallback_width if fallback_width is not None else len(source_header)
    if width >= 30:
        return "du"
    if width > 0:
        return "dp"

    # Rückwärtskompatibler Standard: die bisherige Struktur war DP.
    return "dp"


def target_headers_for_profile(profile: str) -> tuple[str, ...]:
    if profile == "du":
        return SETTINGS.du_target_headers
    return SETTINGS.dp_target_headers


def target_headers_for_source(
    source_header: Sequence[object],
    *,
    fallback_width: int | None = None,
    source_name: str | Path | None = None,
) -> tuple[str, ...]:
    profile = detect_target_profile(
        source_header,
        fallback_width=fallback_width,
        source_name=source_name,
    )
    return target_headers_for_profile(profile)


def normalize_company_id(value: object) -> str:
    """Normalisiert FirmenIDs für einen robusten exakten Vergleich."""
    return clean_cell(value).upper()


def find_company_id_column(header: Sequence[object], width: int, *, fixed_target_header: bool) -> int | None:
    """Ermittelt die FirmenID-Spalte über den Header oder den konfigurierten Fallback."""
    normalized = [normalize_header(value) for value in header]
    for candidate in ("firmenid", "companyid", "firmen_id", "company_id"):
        candidate_norm = normalize_header(candidate)
        if candidate_norm in normalized:
            return normalized.index(candidate_norm)

    if fixed_target_header and SETTINGS.company_id_column_index < width:
        return SETTINGS.company_id_column_index
    return None


def find_allowed_company_id(
    row: Sequence[object],
    allowed_company_ids: set[str],
    *,
    preferred_indices: Sequence[int | None] = (),
) -> str | None:
    """Findet eine erlaubte FirmenID robust in einer Datenzeile.

    Ältere Quelldateien enthalten die FirmenID nicht immer an derselben
    Position. Daher werden zuerst bekannte/headerbasierte Positionen geprüft
    und anschließend die komplette Zeile nach einem exakten erlaubten Wert
    durchsucht. Der Vergleich bleibt strikt, damit keine ähnlichen IDs
    versehentlich akzeptiert werden.
    """
    checked: set[int] = set()
    for index in preferred_indices:
        if index is None or index in checked or index < 0 or index >= len(row):
            continue
        checked.add(index)
        candidate = normalize_company_id(row[index])
        if candidate in allowed_company_ids:
            return candidate

    for index, value in enumerate(row):
        if index in checked:
            continue
        candidate = normalize_company_id(value)
        if candidate in allowed_company_ids:
            return candidate
    return None


def build_target_mapping(
    source_header: Sequence[object],
    target_header: Sequence[object],
) -> list[int | None] | None:
    """Ordnet Quellspalten anhand ihrer Header der festen Zielstruktur zu.

    Bei zu geringer Header-Übereinstimmung wird bewusst auf die bisherige
    positionsbasierte Zuordnung zurückgefallen.
    """
    if not source_header:
        return None

    source_norm = [normalize_header(value) for value in source_header]
    source_index: dict[str, int] = {}
    for index, name in enumerate(source_norm):
        if name and name not in source_index:
            source_index[name] = index

    target_norm = [normalize_header(value) for value in target_header]
    overlap = sum(1 for name in target_norm if name and name in source_index)
    if overlap < max(5, int(len(target_norm) * 0.35)):
        return None

    mapping: list[int | None] = []
    for target_index, name in enumerate(target_norm):
        mapped_index = source_index.get(name)
        if mapped_index is None and target_index < len(source_header):
            mapped_index = target_index
        mapping.append(mapped_index)
    return mapping


def map_row_to_target(
    row: Sequence[object],
    target_width: int,
    mapping: Sequence[int | None] | None,
) -> list[str]:
    if mapping is None:
        return normalize_row_width(row, target_width)

    result: list[str] = []
    for source_index in mapping[:target_width]:
        if source_index is None or source_index < 0 or source_index >= len(row):
            result.append("")
        else:
            result.append(clean_cell(row[source_index]))
    if len(result) < target_width:
        result.extend([""] * (target_width - len(result)))
    return result


def is_empty_row(row: Sequence[object]) -> bool:
    return not any(clean_cell(value) for value in row)


def first_nonempty(row: Sequence[object]) -> str:
    for value in row:
        text = clean_cell(value)
        if text:
            return text
    return ""


def is_marker_row(row: Sequence[object]) -> bool:
    first = first_nonempty(row).lstrip()
    return bool(first) and first.startswith(MARKER_PREFIXES)


def is_metadata_row(row: Sequence[object]) -> bool:
    cells = [clean_cell(value) for value in row if clean_cell(value)]
    if not cells or len(cells) > 3:
        return False

    first = cells[0].lower().strip().rstrip(":")
    return first in METADATA_LABELS


def is_numeric_like(value: str) -> bool:
    text = value.strip()
    if not text:
        return False
    if re.fullmatch(r"[-+]?\d+(?:[.,]\d+)?", text):
        return True
    if re.fullmatch(r"\d{6,14}", text):
        return True
    if re.fullmatch(r"[A-Z]{2}\d{9,12}", text):
        return True
    return False


def header_match_score(row: Sequence[object], reference: Sequence[str] | None = None) -> int:
    row_norm = {normalize_header(value) for value in row if clean_cell(value)}

    if reference is not None:
        reference_norm = {normalize_header(value) for value in reference if clean_cell(value)}
        return len(reference_norm.intersection(row_norm))

    # Bei automatischer Headererkennung gegen beide fachlichen Zielstrukturen
    # prüfen. So werden DU und DP gleich zuverlässig erkannt.
    scores: list[int] = []
    for reference_values in (SETTINGS.du_target_headers, SETTINGS.dp_target_headers):
        reference_norm = {
            normalize_header(value)
            for value in reference_values
            if clean_cell(value)
        }
        scores.append(len(reference_norm.intersection(row_norm)))
    return max(scores, default=0)


def looks_like_header(row: Sequence[object]) -> bool:
    cells = [clean_cell(value) for value in row if clean_cell(value)]
    if len(cells) < 4:
        return False

    normalized = {normalize_header(value) for value in cells}
    known_hits = len(normalized.intersection({normalize_header(value) for value in KNOWN_HEADER_TERMS}))
    if known_hits >= 3:
        return True

    if header_match_score(cells) >= 5:
        return True

    alpha_cells = sum(any(char.isalpha() for char in value) for value in cells)
    numeric_cells = sum(is_numeric_like(value) for value in cells)
    date_like_first = bool(re.fullmatch(r"\d{8}", cells[0]))

    # A real data row usually starts with YYYYMMDD and contains many numeric fields.
    if date_like_first or numeric_cells >= max(3, len(cells) // 3):
        return False

    return alpha_cells >= max(4, int(len(cells) * 0.65))


def make_unique_headers(headers: Sequence[object]) -> list[str]:
    result: list[str] = []
    counts: dict[str, int] = {}

    for index, raw in enumerate(headers, start=1):
        name = clean_cell(raw) or f"Feld_{index:02d}"
        base = name
        counts[base] = counts.get(base, 0) + 1
        if counts[base] > 1:
            name = f"{base}_{counts[base]}"
        result.append(name)

    return result


def trim_trailing_empty(row: Sequence[object]) -> list[str]:
    values = [clean_cell(value) for value in row]
    while values and not values[-1]:
        values.pop()
    return values


def normalize_row_width(row: Sequence[object], width: int) -> list[str]:
    values = [clean_cell(value) for value in row[:width]]
    if len(values) < width:
        values.extend([""] * (width - len(values)))
    return values


def remove_noise_rows(rows: Iterable[Sequence[object]]) -> list[list[str]]:
    result: list[list[str]] = []
    for row in rows:
        cleaned = trim_trailing_empty(row)
        if not cleaned or is_marker_row(cleaned) or is_metadata_row(cleaned):
            continue
        result.append(cleaned)
    return result


def split_packed_rows(rows: Iterable[Sequence[object]]) -> list[list[str]]:
    """Split rows where an entire semicolon record sits in a single cell."""
    result: list[list[str]] = []
    for row in rows:
        cleaned = trim_trailing_empty(row)
        nonempty = [cell for cell in cleaned if cell]
        if len(nonempty) == 1 and nonempty[0].count(";") >= 3:
            parsed = next(csv.reader([nonempty[0]], delimiter=";", quotechar='"'))
            result.append([clean_cell(value) for value in parsed])
        else:
            result.append(cleaned)
    return result


def extract_table(
    raw_rows: Iterable[Sequence[object]],
    *,
    fixed_target_header: bool,
    apply_company_filter: bool = SETTINGS.apply_company_filter,
    source_name: str | Path | None = None,
) -> ParsedTable:
    rows = split_packed_rows(raw_rows)
    rows = remove_noise_rows(rows)

    if not rows:
        return ParsedTable(header=list(SETTINGS.dp_target_headers) if fixed_target_header else [], rows=[])

    header_index: int | None = None
    for index, row in enumerate(rows[:30]):
        if header_match_score(row) >= 5 or looks_like_header(row):
            header_index = index
            break

    detected_source_header = list(rows[header_index]) if header_index is not None else []

    if fixed_target_header:
        source_width = len(detected_source_header) if detected_source_header else max(len(row) for row in rows)
        profile = detect_target_profile(
            detected_source_header,
            fallback_width=source_width,
            source_name=source_name,
        )
        header = list(target_headers_for_profile(profile))
        data_rows = rows[(header_index + 1) if header_index is not None else 0 :]
        width = len(header)
        source_header = detected_source_header
        source_company_index = find_company_id_column(
            source_header,
            len(source_header),
            fixed_target_header=False,
        )
        target_company_index = find_company_id_column(
            header,
            width,
            fixed_target_header=True,
        )
        target_mapping = build_target_mapping(source_header, header)
    else:
        if header_index is not None:
            header = make_unique_headers(rows[header_index])
            data_rows = rows[header_index + 1 :]
            width = len(header)
        else:
            width = max(len(row) for row in rows)
            header = [f"Feld_{index:02d}" for index in range(1, width + 1)]
            data_rows = rows
        source_header = list(header)
        source_company_index = find_company_id_column(
            source_header,
            width,
            fixed_target_header=False,
        )
        target_company_index = source_company_index
        target_mapping = None

    normalized_header = [normalize_header(value) for value in header]
    normalized_source_header = [normalize_header(value) for value in source_header]
    allowed_company_ids = {normalize_company_id(value) for value in SETTINGS.allowed_company_ids}
    clean_data: list[list[str]] = []

    for row in data_rows:
        if is_empty_row(row) or is_marker_row(row) or is_metadata_row(row):
            continue

        # Wiederholte Header innerhalb oder zwischen Dateien sind niemals Daten.
        fitted_for_header_check = normalize_row_width(row, max(width, len(source_header)))
        row_norm = [normalize_header(value) for value in fitted_for_header_check]
        target_overlap = sum(
            1 for left, right in zip(row_norm, normalized_header, strict=False) if left and left == right
        )
        source_overlap = sum(
            1 for left, right in zip(row_norm, normalized_source_header, strict=False) if left and left == right
        )
        if (
            target_overlap >= max(4, min(8, width // 3))
            or source_overlap >= max(4, min(8, max(1, len(source_header)) // 3))
            or header_match_score(row, header) >= 5
            or (source_header and header_match_score(row, source_header) >= 5)
        ):
            continue

        company_id: str | None = None
        if apply_company_filter:
            company_id = find_allowed_company_id(
                row,
                allowed_company_ids,
                preferred_indices=(source_company_index, SETTINGS.company_id_column_index),
            )
            if company_id is None:
                continue

        fitted = map_row_to_target(row, width, target_mapping)

        # WWID wird zentral aus Depotnummer + Unterdepot ergänzt. Dadurch sind
        # DU- und DP-Dateien unabhängig davon, ob die Quelldatei bereits eine
        # WWID-Spalte besitzt oder ob dort vorher Leer1/Leer2 stand.
        if fixed_target_header:
            header_index_map = {
                normalize_header(name): index
                for index, name in enumerate(header)
                if clean_cell(name)
            }
            wwid_index = header_index_map.get("wwid")
            depot_index = header_index_map.get("depotnummer")
            underdepot_index = header_index_map.get("unterdepot")

            if wwid_index is not None and depot_index is not None:
                existing_wwid = fitted[wwid_index] if wwid_index < len(fitted) else ""
                depot_value = fitted[depot_index] if depot_index < len(fitted) else ""
                underdepot_value = (
                    fitted[underdepot_index]
                    if underdepot_index is not None and underdepot_index < len(fitted)
                    else ""
                )
                resolved_wwid = load_wwid_mapping().resolve(
                    depot_value,
                    underdepot_value,
                    existing_wwid,
                )
                if wwid_index >= len(fitted):
                    fitted.extend([""] * (wwid_index + 1 - len(fitted)))
                fitted[wwid_index] = resolved_wwid

        # Die gefundene FirmenID wird in der festen Zielstruktur garantiert in
        # die Spalte FirmenID geschrieben, auch wenn sie in der Quelldatei an
        # einer abweichenden Position stand.
        if company_id is not None and target_company_index is not None:
            if target_company_index >= len(fitted):
                fitted.extend([""] * (target_company_index + 1 - len(fitted)))
            fitted[target_company_index] = company_id

        if any(fitted):
            clean_data.append(fitted)

    return ParsedTable(header=header, rows=clean_data)


def read_text_with_fallback(file_path: Path) -> str:
    encodings = ("utf-8-sig", "utf-8", "cp1252", "latin-1", "iso-8859-1")
    last_io_error: OSError | None = None

    for attempt in range(3):
        for encoding in encodings:
            try:
                return file_path.read_text(encoding=encoding)
            except UnicodeDecodeError:
                continue
            except (PermissionError, OSError) as exc:
                last_io_error = exc
                break

        if last_io_error is None:
            break
        if attempt < 2:
            time.sleep(0.20 * (attempt + 1))

    if last_io_error is not None:
        raise last_io_error
    return file_path.read_bytes().decode("utf-8", errors="replace")


def detect_separator(content: str) -> str | None:
    sample_lines = [line for line in content.splitlines()[:20] if line.strip()]
    if not sample_lines:
        return None

    sample = "\n".join(sample_lines)
    try:
        dialect = csv.Sniffer().sniff(sample, delimiters=";,\t|")
        return dialect.delimiter
    except csv.Error:
        scores = {separator: sample.count(separator) for separator in (";", "\t", "|", ",")}
        separator = max(scores, key=scores.get)
        return separator if scores[separator] > 0 else None


def parse_text_rows(content: str) -> list[list[str]]:
    separator = detect_separator(content)
    if separator is None:
        return [[line.strip()] for line in content.splitlines() if line.strip()]

    reader = csv.reader(io.StringIO(content), delimiter=separator, quotechar='"')
    return [[clean_cell(value) for value in row] for row in reader if any(clean_cell(value) for value in row)]


def is_probably_text_file(file_path: Path) -> bool:
    try:
        sample = file_path.read_bytes()[:8192]
    except OSError:
        return False

    if not sample:
        return True
    if b"\x00" in sample:
        return False

    for encoding in ("utf-8", "cp1252", "latin-1"):
        try:
            sample.decode(encoding)
            return True
        except UnicodeDecodeError:
            continue
    return False
