from __future__ import annotations

import csv
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path

from .settings import APP_DIR


MAPPING_PATH = APP_DIR / "config" / "wwid_mapping.csv"


def _clean(value: object) -> str:
    if value is None:
        return ""
    text = str(value).replace("\u00a0", " ").strip().strip("'")
    if text.endswith(".0") and text[:-2].isdigit():
        text = text[:-2]
    return text


def normalize_depot(value: object) -> str:
    text = _clean(value)
    return re.sub(r"\s+", "", text)


def normalize_underdepot(value: object) -> str:
    text = _clean(value)
    if not text:
        return ""
    digits = re.sub(r"\D+", "", text)
    if not digits:
        return text
    try:
        return str(int(digits))
    except ValueError:
        return digits


def normalize_wwid(value: object) -> str:
    return _clean(value)


@dataclass(frozen=True)
class WwidMapping:
    exact: dict[tuple[str, str], str]
    depot_fallback: dict[str, str]
    conflicts: dict[tuple[str, str], tuple[str, ...]]

    def resolve(self, depot: object, underdepot: object, existing_wwid: object = "") -> str:
        depot_key = normalize_depot(depot)
        under_key = normalize_underdepot(underdepot)
        existing = normalize_wwid(existing_wwid)

        if not depot_key:
            return existing

        exact_key = (depot_key, under_key)
        if under_key and exact_key in self.exact:
            return self.exact[exact_key]

        # Bei einem bekannten Konflikt niemals raten. Eine bereits vorhandene
        # WWID darf bestehen bleiben, andernfalls bleibt die Zelle leer.
        if under_key and exact_key in self.conflicts:
            if existing and existing in self.conflicts[exact_key]:
                return existing
            return existing

        # Fallback nur dann, wenn dieselbe Depotnummer über alle Unterdepots
        # hinweg eindeutig genau einer WWID gehört.
        mapped = self.depot_fallback.get(depot_key)
        if mapped:
            return mapped

        return existing


@lru_cache(maxsize=1)
def load_wwid_mapping(path: Path = MAPPING_PATH) -> WwidMapping:
    if not path.exists():
        return WwidMapping(exact={}, depot_fallback={}, conflicts={})

    candidates: dict[tuple[str, str], set[str]] = {}
    depot_candidates: dict[str, set[str]] = {}

    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle, delimiter=";")
        if reader.fieldnames is None:
            raise RuntimeError(f"WWID-Mapping besitzt keinen Header: {path}")

        normalized_fields = {str(name).strip().casefold(): name for name in reader.fieldnames}
        wwid_field = normalized_fields.get("wwid")
        dep1_field = normalized_fields.get("depot_01") or normalized_fields.get("depo_01")
        dep2_field = normalized_fields.get("depot_02") or normalized_fields.get("depo_02")
        dep3_field = normalized_fields.get("depot_03") or normalized_fields.get("depo_03")

        if not wwid_field or not dep1_field or not dep2_field or not dep3_field:
            raise RuntimeError(
                "WWID-Mapping benötigt die Spalten WWID, Depot_01, Depo_02 und Depo_03. "
                f"Gefunden: {', '.join(reader.fieldnames)}"
            )

        for row in reader:
            wwid = normalize_wwid(row.get(wwid_field, ""))
            if not wwid:
                continue

            for underdepot, field in (("1", dep1_field), ("2", dep2_field), ("3", dep3_field)):
                depot = normalize_depot(row.get(field, ""))
                if not depot:
                    continue
                candidates.setdefault((depot, underdepot), set()).add(wwid)
                depot_candidates.setdefault(depot, set()).add(wwid)

    exact: dict[tuple[str, str], str] = {}
    conflicts: dict[tuple[str, str], tuple[str, ...]] = {}
    for key, wwids in candidates.items():
        if len(wwids) == 1:
            exact[key] = next(iter(wwids))
        else:
            conflicts[key] = tuple(sorted(wwids))

    depot_fallback = {
        depot: next(iter(wwids))
        for depot, wwids in depot_candidates.items()
        if len(wwids) == 1
    }

    return WwidMapping(
        exact=exact,
        depot_fallback=depot_fallback,
        conflicts=conflicts,
    )
