from __future__ import annotations

import os
from pathlib import Path


FORMAT_EXTENSIONS = {
    "xlsx": ".xlsx",
    "csv": ".csv",
    "txt": ".txt",
    "pdf": ".pdf",
    "docx": ".docx",
}


def human_file_size(size_bytes: int) -> str:
    size = float(size_bytes)
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024 or unit == "GB":
            return f"{size:.0f} {unit}" if unit == "B" else f"{size:.1f} {unit}"
        size /= 1024
    return f"{size_bytes} B"


def unique_output_path(source_path: Path, output_dir: Path, target_format: str) -> Path:
    extension = FORMAT_EXTENSIONS[target_format]
    same_extension = source_path.suffix.lower() == extension
    base_name = f"{source_path.stem}_konvertiert" if same_extension else source_path.stem
    candidate = output_dir / f"{base_name}{extension}"
    counter = 1
    while candidate.exists():
        candidate = output_dir / f"{base_name}_{counter}{extension}"
        counter += 1
    return candidate


def unique_named_path(output_dir: Path, filename: str) -> Path:
    candidate = output_dir / filename
    if not candidate.exists():
        return candidate

    stem = candidate.stem
    suffix = candidate.suffix
    counter = 1
    while candidate.exists():
        candidate = output_dir / f"{stem}_{counter}{suffix}"
        counter += 1
    return candidate


def open_folder(path: Path) -> None:
    path = Path(path)
    if os.name == "nt":
        os.startfile(str(path))  # type: ignore[attr-defined]
    elif os.uname().sysname == "Darwin":
        import subprocess

        subprocess.Popen(["open", str(path)])
    else:
        import subprocess

        subprocess.Popen(["xdg-open", str(path)])
