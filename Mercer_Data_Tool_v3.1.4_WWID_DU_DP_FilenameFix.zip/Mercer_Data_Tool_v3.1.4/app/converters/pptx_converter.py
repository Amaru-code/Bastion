from __future__ import annotations

from pathlib import Path

from app.core.data_parser import ParsedTable
from app.core.spreadsheet_io import write_xlsx_table

from .base_converter import BaseConverter
from .document_helpers import text_to_pdf


class PptxConverter(BaseConverter):
    def _extract_text(self, source_path: Path) -> str:
        from pptx import Presentation

        presentation = Presentation(source_path)
        lines: list[str] = []
        for index, slide in enumerate(presentation.slides, start=1):
            lines.append(f"Folie {index}")
            for shape in slide.shapes:
                text = getattr(shape, "text", "")
                if text:
                    lines.append(text)
            lines.append("")
        return "\n".join(lines)

    def convert_to(self, source_file: Path, output_file: Path, target_format: str) -> Path:
        source_path = self.validate_file(source_file)
        text = self._extract_text(source_path)
        output_file.parent.mkdir(parents=True, exist_ok=True)

        if target_format == "txt":
            output_file.write_text(text, encoding="utf-8")
            return output_file
        if target_format == "pdf":
            return text_to_pdf(text, output_file, source_path.name)
        if target_format == "xlsx":
            rows = [[line] for line in text.splitlines() if line.strip()]
            return write_xlsx_table(ParsedTable(header=["PowerPoint-Inhalt"], rows=rows), output_file, sheet_name="Folien")
        raise ValueError(f"Konvertierung von PPTX zu {target_format.upper()} wird nicht unterstützt.")
