from __future__ import annotations

from abc import ABC, abstractmethod
from pathlib import Path


class BaseConverter(ABC):
    @abstractmethod
    def convert_to(self, source_file: Path, output_file: Path, target_format: str) -> Path:
        raise NotImplementedError

    @staticmethod
    def validate_file(file_path: Path) -> Path:
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Datei nicht gefunden: {path}")
        if not path.is_file():
            raise ValueError(f"Kein gültiger Dateipfad: {path}")
        return path
