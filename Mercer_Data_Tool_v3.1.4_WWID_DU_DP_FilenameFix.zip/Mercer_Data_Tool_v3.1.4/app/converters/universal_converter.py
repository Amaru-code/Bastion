from __future__ import annotations

from pathlib import Path

from app.core.data_parser import is_probably_text_file

from .base_converter import BaseConverter
from .text_converter import TextConverter


class UniversalConverter(BaseConverter):
    def __init__(self) -> None:
        self.text_converter = TextConverter()

    def convert_to(self, source_file: Path, output_file: Path, target_format: str) -> Path:
        source_path = self.validate_file(source_file)
        if is_probably_text_file(source_path):
            return self.text_converter.convert_to(source_path, output_file, target_format)

        # Do not generate artificial file-information rows or source TXT reports.
        raise ValueError(
            "Unbekannte Binärdatei. Dieser Dateityp kann nicht zuverlässig konvertiert werden."
        )
