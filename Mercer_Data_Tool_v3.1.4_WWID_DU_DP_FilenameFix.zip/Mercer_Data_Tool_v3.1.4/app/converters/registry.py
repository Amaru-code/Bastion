from __future__ import annotations

from pathlib import Path

from .base_converter import BaseConverter
from .docx_converter import DocxConverter
from .pdf_converter import PdfConverter
from .pptx_converter import PptxConverter
from .text_converter import TextConverter
from .universal_converter import UniversalConverter
from .xlsx_converter import XlsxConverter


class ConverterRegistry:
    def __init__(self) -> None:
        text = TextConverter()
        excel = XlsxConverter()
        self._registry: dict[str, BaseConverter] = {
            ".xlsx": excel,
            ".xlsm": excel,
            ".xls": excel,
            ".csv": text,
            ".txt": text,
            ".tsv": text,
            ".json": text,
            ".xml": text,
            ".html": text,
            ".htm": text,
            ".md": text,
            ".log": text,
            ".ini": text,
            ".cfg": text,
            ".conf": text,
            ".dat": text,
            ".data": text,
            ".dc": text,
            ".dc+": text,
            ".docx": DocxConverter(),
            ".pdf": PdfConverter(),
            ".pptx": PptxConverter(),
        }
        self._universal = UniversalConverter()

    def get(self, file_path: Path) -> BaseConverter:
        return self._registry.get(file_path.suffix.lower(), self._universal)
