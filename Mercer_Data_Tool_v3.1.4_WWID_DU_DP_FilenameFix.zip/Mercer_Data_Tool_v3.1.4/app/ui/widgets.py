from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PySide6.QtCore import (
    QAbstractTableModel,
    QByteArray,
    QModelIndex,
    QPointF,
    QRectF,
    QSize,
    Qt,
    QTimer,
)
from PySide6.QtGui import QColor, QIcon, QPainter, QPen, QPixmap
from PySide6.QtSvg import QSvgRenderer
from PySide6.QtWidgets import QLabel, QTableView

from app.core.settings import ICONS_DIR


def svg_icon(name: str, color: str = "#002C77", size: int = 20) -> QIcon:
    path = ICONS_DIR / f"{name}.svg"
    if not path.exists():
        return QIcon()

    svg_text = path.read_text(encoding="utf-8")
    svg_text = re.sub(r"<path\s", f'<path fill="{color}" ', svg_text)
    renderer = QSvgRenderer(QByteArray(svg_text.encode("utf-8")))
    pixmap = QPixmap(size, size)
    pixmap.fill(Qt.GlobalColor.transparent)
    painter = QPainter(pixmap)
    renderer.render(painter)
    painter.end()
    return QIcon(pixmap)


class SpinnerWidget(QLabel):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setFixedSize(24, 24)
        self._angle = 0
        self._timer = QTimer(self)
        self._timer.timeout.connect(self._advance)
        self.hide()

    def start(self) -> None:
        self._angle = 0
        self.show()
        self._timer.start(55)

    def stop(self) -> None:
        self._timer.stop()
        self.hide()

    def _advance(self) -> None:
        self._angle = (self._angle + 28) % 360
        self.update()

    def paintEvent(self, event) -> None:  # noqa: N802
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        pen = QPen(QColor("#00A8C7"), 3.2, Qt.PenStyle.SolidLine, Qt.PenCapStyle.RoundCap)
        painter.setPen(pen)
        rect = QRectF(4, 4, self.width() - 8, self.height() - 8)
        painter.drawArc(rect, int((90 - self._angle) * 16), int(-250 * 16))
        painter.end()


@dataclass(frozen=True, slots=True)
class FileRecord:
    path: Path
    file_type: str
    key: str


class FileTableModel(QAbstractTableModel):
    """Performantes Model fuer mehrere hundert oder tausend Dateien.

    QTableWidget erzeugt fuer jede sichtbare Zelle ein eigenes Widget-Objekt und
    kann zusammen mit ResizeToContents beim Hinzufuegen grosser Dateimengen die
    Oberflaeche blockieren. Dieses Model liefert Werte nur bei Bedarf.
    """

    HEADERS = ("Dateiname", "Typ")

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._records: list[FileRecord] = []

    @property
    def records(self) -> tuple[FileRecord, ...]:
        return tuple(self._records)

    @property
    def paths(self) -> list[Path]:
        return [record.path for record in self._records]

    @property
    def keys(self) -> set[str]:
        return {record.key for record in self._records}

    def rowCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self._records)

    def columnCount(self, parent=QModelIndex()) -> int:  # noqa: N802
        return 0 if parent.isValid() else len(self.HEADERS)

    def data(self, index: QModelIndex, role: int = Qt.ItemDataRole.DisplayRole):
        if not index.isValid() or not (0 <= index.row() < len(self._records)):
            return None

        record = self._records[index.row()]
        column = index.column()

        if role == Qt.ItemDataRole.DisplayRole:
            if column == 0:
                return record.path.name
            if column == 1:
                return record.file_type

        if role == Qt.ItemDataRole.ToolTipRole:
            return str(record.path)

        return None

    def headerData(self, section: int, orientation: Qt.Orientation, role: int = Qt.ItemDataRole.DisplayRole):  # noqa: N802
        if orientation == Qt.Orientation.Horizontal and role == Qt.ItemDataRole.DisplayRole:
            if 0 <= section < len(self.HEADERS):
                return self.HEADERS[section]
        return None

    def append_records(self, records: Iterable[FileRecord]) -> None:
        incoming = list(records)
        if not incoming:
            return

        # One model reset is substantially cheaper than creating and resizing
        # hundreds of individual cell widgets. It also avoids repeated layout
        # calculations while a large batch is added.
        self.beginResetModel()
        self._records.extend(incoming)
        self._records.sort(key=lambda record: (record.path.name.casefold(), str(record.path).casefold()))
        self.endResetModel()

    def sort_records(self) -> None:
        self.beginResetModel()
        self._records.sort(key=lambda record: (record.path.name.casefold(), str(record.path).casefold()))
        self.endResetModel()

    def remove_rows(self, rows: Iterable[int]) -> None:
        for row in sorted(set(rows), reverse=True):
            if 0 <= row < len(self._records):
                self.beginRemoveRows(QModelIndex(), row, row)
                self._records.pop(row)
                self.endRemoveRows()

    def clear(self) -> None:
        if not self._records:
            return
        self.beginResetModel()
        self._records.clear()
        self.endResetModel()


class DropTableView(QTableView):
    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.files_dropped_callback = None

    def dragEnterEvent(self, event) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragEnterEvent(event)

    def dragMoveEvent(self, event) -> None:  # noqa: N802
        if event.mimeData().hasUrls():
            event.acceptProposedAction()
        else:
            super().dragMoveEvent(event)

    def dropEvent(self, event) -> None:  # noqa: N802
        paths = [Path(url.toLocalFile()) for url in event.mimeData().urls() if url.isLocalFile()]
        if paths and self.files_dropped_callback:
            self.files_dropped_callback(paths)
        event.acceptProposedAction()
