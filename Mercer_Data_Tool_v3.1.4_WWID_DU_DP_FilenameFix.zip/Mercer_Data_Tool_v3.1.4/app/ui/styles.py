APP_STYLESHEET = r"""
QMainWindow {
    background: #F3F6F9;
}
QWidget {
    color: #1E293B;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QFrame#TopBar {
    background: #002C77;
    border: none;
}
QLabel#AppTitle {
    color: #FFFFFF;
    font-size: 20pt;
    font-weight: 700;
}
QLabel#AppSubtitle {
    color: #C7D7F2;
    font-size: 9.5pt;
}
QLabel#VersionBadge {
    color: #FFFFFF;
    background: rgba(255, 255, 255, 35);
    border: 1px solid rgba(255, 255, 255, 55);
    border-radius: 11px;
    padding: 4px 10px;
    font-size: 8.5pt;
    font-weight: 600;
}
QFrame#Card {
    background: #FFFFFF;
    border: 1px solid #DCE4EC;
    border-radius: 10px;
}
QLabel#SectionTitle {
    color: #002C77;
    font-size: 11pt;
    font-weight: 700;
}
QLabel#SectionHint {
    color: #64748B;
    font-size: 9pt;
}
QLabel#StepBadge {
    min-width: 26px;
    max-width: 26px;
    min-height: 26px;
    max-height: 26px;
    color: #FFFFFF;
    background: #00A8C7;
    border-radius: 13px;
    font-size: 9pt;
    font-weight: 700;
    qproperty-alignment: AlignCenter;
}
QPushButton {
    min-height: 34px;
    border-radius: 6px;
    padding: 0 14px;
    font-weight: 600;
}
QPushButton#PrimaryButton {
    color: #FFFFFF;
    background: #002C77;
    border: 1px solid #002C77;
}
QPushButton#PrimaryButton:hover {
    background: #003D9F;
}
QPushButton#AccentButton {
    color: #FFFFFF;
    background: #00A8C7;
    border: 1px solid #00A8C7;
}
QPushButton#AccentButton:hover {
    background: #008FA9;
}
QPushButton#SecondaryButton {
    color: #002C77;
    background: #FFFFFF;
    border: 1px solid #AFC0D2;
}
QPushButton#SecondaryButton:hover {
    background: #F3F7FB;
    border-color: #7F9AB5;
}
QPushButton#DangerButton {
    color: #B42318;
    background: #FFFFFF;
    border: 1px solid #F0B4AF;
}
QPushButton#DangerButton:hover {
    background: #FFF4F3;
}
QPushButton:disabled {
    color: #97A6B5;
    background: #E9EEF3;
    border-color: #D8E0E8;
}
QLineEdit, QComboBox {
    min-height: 36px;
    background: #FFFFFF;
    border: 1px solid #C9D4DF;
    border-radius: 6px;
    padding: 0 10px;
    selection-background-color: #00A8C7;
}
QLineEdit:focus, QComboBox:focus {
    border: 1px solid #00A8C7;
}
QComboBox::drop-down {
    border: none;
    width: 28px;
}
QTableWidget {
    background: #FFFFFF;
    alternate-background-color: #F7FAFC;
    border: 1px solid #DCE4EC;
    border-radius: 6px;
    gridline-color: #E8EEF4;
    selection-background-color: #DDF4F8;
    selection-color: #12344D;
}
QHeaderView::section {
    color: #334155;
    background: #EEF3F7;
    border: none;
    border-bottom: 1px solid #DCE4EC;
    padding: 8px 10px;
    font-weight: 700;
}
QProgressBar {
    min-height: 10px;
    max-height: 10px;
    background: #E5EBF1;
    border: none;
    border-radius: 5px;
    text-align: center;
}
QProgressBar::chunk {
    background: #00A8C7;
    border-radius: 5px;
}
QLabel#StatusTitle {
    color: #002C77;
    font-size: 10pt;
    font-weight: 700;
}
QLabel#StatusDetail {
    color: #64748B;
    font-size: 9pt;
}
QLabel#StatusChip {
    color: #0F5132;
    background: #DFF3E7;
    border: 1px solid #B7DFC7;
    border-radius: 10px;
    padding: 3px 9px;
    font-size: 8pt;
    font-weight: 600;
}
QToolTip {
    color: #FFFFFF;
    background: #1E293B;
    border: none;
    padding: 5px;
}
"""
