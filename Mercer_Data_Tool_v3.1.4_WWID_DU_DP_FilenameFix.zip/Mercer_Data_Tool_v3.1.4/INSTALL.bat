@echo off
setlocal EnableExtensions DisableDelayedExpansion
cd /d "%~dp0"
title Mercer Data Tool - Installation

set "PYTHONUTF8=1"
set "PYTHONIOENCODING=utf-8"
set "PIP_DISABLE_PIP_VERSION_CHECK=1"
set "PIP_NO_CACHE_DIR=1"
set "PYTHON_CMD="

REM Die virtuelle Umgebung liegt absichtlich in einem kurzen Windows-Pfad.
REM Dadurch scheitert PySide6 nicht an der 260-Zeichen-Grenze alter Windows-Setups.
if not defined LOCALAPPDATA set "LOCALAPPDATA=%USERPROFILE%\AppData\Local"
set "RUNTIME_ROOT=%LOCALAPPDATA%\MercerDataTool"
set "VENV_DIR=%RUNTIME_ROOT%\venv"
set "VENV_PYTHON=%VENV_DIR%\Scripts\python.exe"

cls
echo ============================================================
echo  Mercer Data Converter ^& Merger - Installation
echo ============================================================
echo.
echo Die Anwendung selbst bleibt im entpackten Programmordner.
echo Die Python-Umgebung wird wegen der Windows-Pfadlaenge hier angelegt:
echo.
echo   %VENV_DIR%
echo.
echo Bestehende Python-Installationen werden nicht veraendert.
echo.

REM Python 3.12 wird bevorzugt. Die weiteren Versionen sind ebenfalls geeignet.
for %%V in (3.12 3.11 3.10 3.13) do (
    if not defined PYTHON_CMD (
        py -%%V -c "import sys" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=py -%%V"
    )
)

if not defined PYTHON_CMD (
    where python.exe >nul 2>&1
    if not errorlevel 1 (
        python -c "import sys; raise SystemExit(0 if (3,10) <= sys.version_info[:2] <= (3,13) else 1)" >nul 2>&1
        if not errorlevel 1 set "PYTHON_CMD=python"
    )
)

if not defined PYTHON_CMD (
    echo FEHLER: Keine kompatible Python-Version gefunden.
    echo.
    echo Benoetigt wird Python 3.10, 3.11, 3.12 oder 3.13.
    echo Empfohlen: Python 3.12 mit aktivierter Option "Add Python to PATH".
    echo.
    pause
    exit /b 1
)

echo Verwende: %PYTHON_CMD%
echo.

REM Eine unvollstaendige Altinstallation aus Version 3.0.0 lag direkt im
REM Projektordner und konnte bei langen Ordnernamen PySide6 blockieren.
if exist "%~dp0runtime\venv" (
    echo [0/4] Entferne unvollstaendige Altinstallation im Projektordner ...
    rmdir /s /q "%~dp0runtime\venv" >nul 2>&1
    del /q "%~dp0runtime\installed.txt" >nul 2>&1
    rmdir "%~dp0runtime" >nul 2>&1
)

if not exist "%RUNTIME_ROOT%" mkdir "%RUNTIME_ROOT%"

if not exist "%VENV_PYTHON%" (
    echo [1/4] Erstelle lokale Python-Umgebung im kurzen Systempfad ...
    %PYTHON_CMD% -m venv "%VENV_DIR%"
    if errorlevel 1 goto :install_error
) else (
    echo [1/4] Lokale Python-Umgebung bereits vorhanden.
)

if not exist "%VENV_PYTHON%" goto :install_error

echo [2/4] Aktualisiere Installationswerkzeuge ...
"%VENV_PYTHON%" -m pip install --no-cache-dir --upgrade pip setuptools wheel
if errorlevel 1 goto :install_error

echo [3/4] Installiere benoetigte Pakete ...
"%VENV_PYTHON%" -m pip install --no-cache-dir -r "%~dp0app\requirements.txt"
if errorlevel 1 goto :install_error

echo [4/4] Pruefe Anwendung ...
"%VENV_PYTHON%" -c "import PySide6, openpyxl, xlrd, docx, pptx, pypdf, reportlab; from PySide6.QtSvg import QSvgRenderer; print('Pakete erfolgreich geprueft.')"
if errorlevel 1 goto :install_error

> "%RUNTIME_ROOT%\installed.txt" echo Mercer Data Tool 3.1.2 erfolgreich installiert

echo.
echo ============================================================
echo  Installation erfolgreich
ECHO ============================================================
echo.
echo Die Anwendung kann jetzt mit START.bat geoeffnet werden.
echo.
pause
exit /b 0

:install_error
echo.
echo ============================================================
echo  FEHLER BEI DER INSTALLATION
ECHO ============================================================
echo.
echo Die Installation konnte nicht abgeschlossen werden.
echo.
echo Versuchen Sie bitte zuerst:
echo   1. Dieses Fenster schliessen.
echo   2. INSTALL.bat erneut starten.
echo   3. Internetverbindung und freien Speicher pruefen.
echo.
echo Verwendeter Laufzeitordner:
echo   %VENV_DIR%
echo.
pause
exit /b 1
