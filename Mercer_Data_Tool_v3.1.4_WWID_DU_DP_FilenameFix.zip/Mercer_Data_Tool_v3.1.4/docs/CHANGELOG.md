# Version 3.1.4

- DU/DP-Erkennung priorisiert jetzt den Dateinamen: `DU_...` wird immer als DU, `DP_...` immer als DP verarbeitet.
- Header- und Spaltenbreiten-Erkennung bleibt als Fallback für Dateien ohne eindeutigen Präfix erhalten.
- Gilt für Konvertierung, Konvertieren + Master und Nur zusammenführen.

# Changelog

## 3.1.2

- DU- und DP-Dateien werden anhand ihrer fachlichen Header automatisch unterschieden.
- DU-Dateien erhalten einen eigenen 34-spaltigen Zielheader mit WWID, UmsatzStuecke, Anlbetrag, ZahlBetrag und Umsatzart.
- DP-Dateien erhalten den 26-spaltigen Bestandsheader mit Anteilspreis, Bestand_Stuecke und Bestand_Betrag.
- Die FirmenID-Filterung bleibt für beide Dateitypen headerbasiert erhalten.
- Gemischte Quelldateien werden nicht mehr versehentlich auf denselben Header gezwungen.

## Version 3.1.1

- Dateiauswahl für mehrere hundert Dateien beschleunigt: keine synchronen Datei-Größen- oder Metadatenabfragen mehr.
- Neuer Button `Ordner hinzufügen` für große Stapel aus einem gemeinsamen Quellordner.
- FirmenID-Filter erkennt erlaubte IDs headerbasiert und zusätzlich an jeder Position der Datenzeile.
- Gefundene FirmenIDs werden in der konvertierten Zielstruktur zuverlässig in die Spalte `FirmenID` geschrieben.
- `MERCER_0003` und alle weiteren konfigurierten IDs funktionieren auch bei abweichender Quellspaltenposition.
- XLSX-Ausgabe beschleunigt: kein nachträgliches Formatieren jeder einzelnen Datenzelle und keine zweite vollständige Breitenanalyse.

## 3.0.2

- FirmenID-Filter auf die zehn fachlich freigegebenen Werte korrigiert
- `INTELSK_0003` ergänzt
- nicht mehr gewünschte IDs `MERCER_0004`, `MERCER_0365` und `MERCER_0366` entfernt
- Filter wird bei Einzelkonvertierung, Konvertieren + Master und Nur zusammenführen angewendet
- FirmenID-Vergleich gegen Leerzeichen und Groß-/Kleinschreibung abgesichert

## 3.0.1

- PySide6-Installation gegen Windows-Long-Path-Fehler abgesichert
- virtuelle Umgebung in kurzen Pfad unter `%LOCALAPPDATA%\MercerDataTool\venv` verlegt
- unvollstaendige alte Projekt-Runtime wird bei der Installation entfernt
- pip-Cache fuer die Installation deaktiviert, damit defekte Cache-Eintraege nicht stoeren
- START.bat prueft die Installation und startet bei Bedarf automatisch die Reparatur

## 3.0.0

- bisheriges Converter-Tool und Excel-Merger zu einer Anwendung kombiniert
- professionelle PySide6-Oberfläche mit SVG-Icons
- native skalierbare Darstellung ohne Emoji- oder Custom-Titlebar-Fehler
- drei klare Aktionen: Konvertieren, Konvertieren + Master, Nur zusammenführen
- sichtbare Ladeanimation, Fortschrittsbalken, aktuelle Datei, Zeilenzähler und Laufzeit
- Markerzeilen `>>>> ...` und `<<<<<` vollständig entfernt
- wiederholte Header werden nicht mehr als Daten übernommen
- Metadatenzeilen vor dem Header werden verworfen
- keine automatischen Quelldatei-, Fehler- oder Dateilisten-TXT-Dateien im Ausgabeordner
- saubere Root-Struktur mit ausschließlich BAT-Dateien und Unterordnern

## Version 3.1.0 – Stabilität bei großen Dateimengen

- Dateiauswahl wird in einem separaten Hintergrund-Thread geprüft.
- Performantes Model/View-Tabellenmodell statt tausender einzelner Tabellenzellen-Widgets.
- Keine automatische Spalten-Neuberechnung bei jeder hinzugefügten Datei.
- Masterdateien werden zeilenweise und speicherschonend geschrieben.
- Keine vollständige Master-Datenkopie mehr im Python-Arbeitsspeicher.
- Temporäre Masterdatei wird erst nach erfolgreichem Abschluss atomar übernommen.
- Abbruch entfernt unvollständige Ausgabedateien.
- Kurzzeitige Datei-Sperren werden beim Einlesen bis zu drei Mal erneut versucht.
- Fortschrittssignale werden gebündelt, damit die Oberfläche nicht mit UI-Updates überlastet wird.
- Speicherbereinigung nach jeweils 20 Dateien.
- Excel-Zeilenlimit wird kontrolliert und verständlich gemeldet.
- Große Fehlerlisten werden im Dialog begrenzt, damit das Ergebnisfenster reaktionsfähig bleibt.

## 3.1.3
- Zentrale WWID-Zuordnung aus `app/config/wwid_mapping.csv` ergänzt.
- WWID wird bei DU- und DP-Konvertierungen automatisch über `Depotnummer + Unterdepot` befüllt.
- DP-Zielheader verwendet jetzt `WWID` direkt vor `Depotnummer` statt `Leer2`.
- Bei eindeutiger Depotnummer ist ein Fallback auch ohne Unterdepot möglich.
- Mehrdeutige Zuordnungen werden nicht geraten; bekannte Konflikte sind in `wwid_mapping_KONFLIKTE.txt` dokumentiert.
