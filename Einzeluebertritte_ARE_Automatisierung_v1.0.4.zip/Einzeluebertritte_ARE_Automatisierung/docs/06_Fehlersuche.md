# Fehlersuche

## Fehler 500 „Variable is undefined“

Dieser Fehler konnte in Version 1.0.1 auftreten, weil die VBA-Funktion `IsError(...)` im externen VBScript nicht verfügbar ist.

**Lösung:** Version 1.0.4 oder neuer verwenden. Dort werden Excel-Fehlerwerte über `VarType(value) = 10` erkannt. Der Wert `10` entspricht dem Variant-Untertyp `vbError`.

Ab Version 1.0.4 nennt die Fehlermeldung zusätzlich die aktuelle `Phase`, damit die Fehlerstelle leichter eingegrenzt werden kann.

## „Das Blatt Übersicht wurde nicht gefunden“

Der Blattname muss exakt `Übersicht` lauten. Auch zusätzliche Leerzeichen im Namen führen zu einem Fehler.

## „Das Blatt Gesellschaften wurde nicht gefunden“

Der Stammdatenbereich muss in einem Blatt mit dem exakten Namen `Gesellschaften` liegen.

## „Die Spalten A bis D entsprechen nicht dem erwarteten Aufbau“

Prüfen Sie Zeile 2 im Blatt `Übersicht`:

```text
PNR neu | Ltrg neu | PNR alt | Ltrg alt
```

## „Für folgende LTRG fehlt eine Zuordnung“

Mindestens eine LTRG aus `Übersicht` ist im Blatt `Gesellschaften` nicht mit einem Namen in Spalte F hinterlegt. Die fehlenden LTRG werden in der Meldung genannt.

## Die VBS-Datei startet nicht

Mögliche Ursachen:

- Windows Script Host ist durch die Unternehmensrichtlinie deaktiviert.
- Excel Desktop ist nicht installiert.
- Die ZIP-Datei wurde nicht vollständig entpackt.
- Sicherheitssoftware blockiert `.vbs`-Dateien.

In diesem Fall kann alternativ das VBA-Modul aus dem Ordner `macro` direkt in Excel importiert werden.

## Die Ausgabedatei kann nicht gespeichert werden

Prüfen Sie:

- Schreibrechte im Quellordner
- ob die Datei bereits exklusiv geöffnet ist
- ob der Pfad zu lang ist
- ob OneDrive oder ein Netzlaufwerk gerade synchronisiert bzw. nicht erreichbar ist

## CHECK in I4 ist nicht 0

Dann stimmen die erzeugten Abschnittssummen nicht mit dem Nettosaldo aus `Übersicht` überein. Prüfen Sie insbesondere:

- nicht numerische LTRG
- fehlende oder ungewöhnliche Betragswerte
- nachträgliche Änderungen nach der Generierung
- manuell veränderte Detailzeilen oder Summenformeln

## Excel bleibt nach einem Fehler geöffnet

Das Skript versucht Excel bei einem Fehler zu schließen. Falls Excel oder ein Dialog nicht reagiert, schließen Sie die betroffene Excel-Instanz manuell und starten Sie das Skript erneut.

## Fehler 13 „Type mismatch“ bei „Quellblätter prüfen“

Version 1.0.4 ersetzt den gesamten bisher zusammengefassten Prüfschritt. Die Ursache konnte nicht nur in der Überschriftenprüfung liegen, sondern auch in der Excel-COM-Übergabe der letzten Zeile oder des kompletten Datenbereichs.

Die aktuelle Version:

- liest `Übersicht!A2:D2` einzeln und typgesichert,
- bestimmt die letzte Übertrittszeile ohne verschachtelte `CLng`-/`End(xlUp)`-Ausdrücke,
- übernimmt `Übersicht!A3:J...` Zelle für Zelle,
- behandelt Excel-Fehlerwerte kontrolliert als leer,
- schreibt die genaue Unterphase in `ARE_Generator_Diagnose.log`.

Das Protokoll liegt direkt neben `ARE_Generator_starten.vbs`. Bei einem neuen Fehler bitte die letzten Zeilen dieses Protokolls zusammen mit der Fehlermeldung bereitstellen.

Erwartete Überschriften:

```text
PNR neu | Ltrg neu | PNR alt | Ltrg alt
```
