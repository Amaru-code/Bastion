from __future__ import annotations

import gc
from datetime import datetime
from pathlib import Path
from typing import Callable, Iterable, Iterator

from app.core.data_parser import (
    ParsedTable,
    extract_table,
    normalize_header,
    parse_text_rows,
    read_text_with_fallback,
)
from app.core.file_utils import unique_named_path
from app.core.settings import SETTINGS
from app.core.spreadsheet_io import StreamingXlsxWriter, read_spreadsheet_table


ProgressCallback = Callable[[int, int, str, str, int], None]
CancelCallback = Callable[[], bool]


class MergeCancelled(RuntimeError):
    pass


def _read_merge_table(file_path: Path) -> ParsedTable:
    suffix = file_path.suffix.lower()
    if suffix in {".xlsx", ".xlsm", ".xls"}:
        return read_spreadsheet_table(
            file_path,
            fixed_target_header=True,
            apply_company_filter=True,
        )

    content = read_text_with_fallback(file_path)
    rows = parse_text_rows(content)
    return extract_table(rows, fixed_target_header=True, apply_company_filter=True)


def _iter_aligned_rows(source: ParsedTable, master_header: list[str]) -> Iterator[list[str]]:
    source_norm = [normalize_header(value) for value in source.header]
    master_norm = [normalize_header(value) for value in master_header]

    if source_norm == master_norm:
        yield from source.rows
        return

    source_index = {name: index for index, name in enumerate(source_norm) if name}
    common = sum(1 for name in master_norm if name in source_index)

    # All files are expected to have the same header. A high-overlap mapping
    # still permits harmless spelling/order differences.
    if common < max(4, int(len(master_norm) * 0.60)):
        raise ValueError("Header weicht zu stark von den übrigen Dateien ab.")

    for row in source.rows:
        yield [
            row[source_index[name]] if name in source_index and source_index[name] < len(row) else ""
            for name in master_norm
        ]


def merge_files(
    source_files: Iterable[Path],
    output_dir: Path,
    *,
    progress: ProgressCallback | None = None,
    is_cancelled: CancelCallback | None = None,
) -> tuple[Path, int, list[str]]:
    files = [Path(path) for path in source_files]
    if not files:
        raise ValueError("Es wurden keine Dateien zum Zusammenfassen ausgewählt.")

    output_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    output_file = unique_named_path(output_dir, f"MERCER_MASTER_{timestamp}.xlsx")

    master_header: list[str] | None = None
    writer: StreamingXlsxWriter | None = None
    errors: list[str] = []
    total_files = len(files)
    total_steps = total_files + 1

    try:
        for index, file_path in enumerate(files, start=1):
            if is_cancelled and is_cancelled():
                raise MergeCancelled("Vorgang wurde abgebrochen.")

            current_rows = writer.row_count if writer else 0
            if progress:
                progress(index - 1, total_steps, file_path.name, "Datei wird eingelesen", current_rows)

            try:
                table = _read_merge_table(file_path)
                if not table.header:
                    raise ValueError("Kein Tabellen-Header gefunden.")

                if master_header is None:
                    master_header = list(table.header)
                    writer = StreamingXlsxWriter(
                        output_file,
                        master_header,
                        sheet_name=SETTINGS.master_sheet_name,
                    )
                    rows_to_write: Iterable[list[str]] = table.rows
                else:
                    rows_to_write = _iter_aligned_rows(table, master_header)

                # This is intentionally outside a global in-memory list. Rows
                # are streamed directly into the workbook temp files.
                assert writer is not None
                writer.append_rows(rows_to_write)

            except (MergeCancelled, KeyboardInterrupt):
                raise
            except ValueError as exc:
                # Header/data problems belong to the individual source file.
                errors.append(f"{file_path.name}: {exc}")
            except Exception:
                # I/O, memory and writer failures are not safely recoverable.
                raise
            finally:
                # Release potentially large ParsedTable lists before opening
                # the next source file. A periodic collection keeps memory
                # stable over several hundred files.
                if "table" in locals():
                    del table
                if index % 20 == 0:
                    gc.collect()

            current_rows = writer.row_count if writer else 0
            if progress:
                progress(index, total_steps, file_path.name, "Datei abgeschlossen", current_rows)

        if master_header is None or writer is None:
            raise RuntimeError("Aus den ausgewählten Dateien konnten keine Daten übernommen werden.")

        if is_cancelled and is_cancelled():
            raise MergeCancelled("Vorgang wurde abgebrochen.")

        if progress:
            progress(total_files, total_steps, output_file.name, "Masterdatei wird finalisiert", writer.row_count)

        row_count = writer.row_count
        writer.save()

        if progress:
            progress(total_steps, total_steps, output_file.name, "Masterdatei gespeichert", row_count)

        return output_file, row_count, errors

    except Exception:
        if writer is not None:
            writer.abort()
        try:
            output_file.unlink(missing_ok=True)
        except OSError:
            pass
        raise
