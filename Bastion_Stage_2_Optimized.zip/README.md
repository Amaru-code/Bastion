# Bastion – Stage 2.0

Lokaler Browser-Prototyp eines taktischen Aufbau- und Eroberungsspiels.

## Start

1. ZIP vollständig entpacken.
2. `Start_Game.bat` doppelklicken.
3. Im Startbildschirm auf **Spiel starten** klicken.

Keine Installation, kein Node.js und kein lokaler Server erforderlich.

## Neu in Stage 2.0

- Startbildschirm und Neustart innerhalb des Spiels
- sichtbarer Goldbestand inklusive Upgrade-Kosten
- lokale Burgkapazität direkt am Gebäude und in der Auswahl
- klar markierte 25/50/75/100-Prozent-Auswahl
- Drag-and-drop-Befehle von Gebäude zu Ziel
- 8-Richtungs-Rasterwegfindung
- Felsen und Gebäude blockieren Wege
- zentrales Akademie-Tor muss erobert werden, bevor die Gegenseite erreichbar ist
- temporäre gestrichelte Marschrouten
- sichtbare Upgrade-, Forschungs-, Eroberungs- und Verteidigungseffekte
- vollständige Aufschlüsselung aus Jahreszeiten- und Forschungsmodifikatoren
- aktive Forschungsliste
- 5-Sekunden-Forschungswahl mit automatischer Zufallsauswahl
