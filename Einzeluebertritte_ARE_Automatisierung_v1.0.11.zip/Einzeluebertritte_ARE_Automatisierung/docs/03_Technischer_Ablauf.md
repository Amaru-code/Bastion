# Technischer Ablauf

## Gesamtprozess

1. Excel per COM starten.
2. ARE-Quelldatei auswählen.
3. DOCX-Serienbriefvorlage auswählen.
4. Excel-Personendatei auswählen.
5. Zeitgestempelten Laufordner unter `Output` erstellen.
6. ARE-Quelle schreibgeschützt öffnen und nach `00_Excel` kopieren.
7. Kopfzeilen in `Übersicht` und `Gesellschaften` dynamisch erkennen und eine kanonische Spaltenzuordnung aufbauen.
8. Daten unabhängig von Spaltenreihenfolge und Zusatzspalten einlesen.
9. ARE-Blätter neu aufbauen.
10. Berichtskopf, Portrait-Seiteneinrichtung und Drucklayout setzen.
11. Lokale Logo-Datei `docs/Bild 1.png/.jpg/.jpeg` suchen und in die ARE-Blätter einfügen.
12. Falls kein Bild erkannt wird, PNG/JPG als Fallback auswählen lassen.
13. Arbeitsmappe berechnen und speichern.
14. Jedes ARE-Blatt über `ExportAsFixedFormat` als PDF exportieren.
15. Personendaten aus dem ersten Arbeitsblatt einlesen und leere Zeilen entfernen.
16. Eine temporäre, zusammenhängende Excel-Datenquelle für Word erzeugen.
17. Bevorzugt den nativen Word-Seriendruck mit `SuppressBlankLines = True` ausführen.
18. Gesamt-DOCX, Gesamt-PDF und Einzel-PDFs erzeugen.
19. Vor dem Abschluss prüfen, ob Gesamt-DOCX, Gesamt-PDF und alle Einzel-PDFs vorhanden sind.
20. Temporäre Datenquelle löschen und Word schließen.
21. ARE-Ausgabedatei in Excel geöffnet lassen.

## Serienbrief-Fallback

Falls der native Word-Seriendruck wegen einer lokalen Office-/Treiberkonfiguration nicht geöffnet werden kann, verwendet das Tool automatisch den bisherigen Feldmodus. Der Wechsel wird im Diagnoseprotokoll dokumentiert.

## Feldzuordnung im Fallback

Zuerst wird exakt verglichen. Danach folgt ein normalisierter Vergleich ohne Leerzeichen, Unterstriche, Bindestriche, Punkte und Doppelpunkte.

## Fehlerbehandlung

Der Fehlerdialog enthält Version, genaue Phase, Fehlernummer, Beschreibung, Fehlerquelle und den Pfad zum Diagnoseprotokoll.

## Robuster Word-Abschluss

Word kann nach dem letzten erfolgreich exportierten Datensatz die COM-Verbindung mit Fehler `-2147417848` verlieren. Version 1.0.10 behandelt dies als reinen Bereinigungsfehler, sofern folgende Dateien vollständig vorhanden sind:

- Gesamt-DOCX
- Gesamt-PDF
- mindestens eine Einzel-PDF je Personendatensatz

Nur bei unvollständiger Ausgabe wird der kompatible Fallback gestartet.
