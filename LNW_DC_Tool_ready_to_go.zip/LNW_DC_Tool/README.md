# Intel LNW DC Generator

## Zweck
Das Tool erzeugt aus einem alten makrofähigen LNW-Template und einer DU-Bewegungsdatei eine neue `.xlsm`-Datei. Microsoft Excel wird über COM automatisiert; dadurch bleiben VBA-Projekt, externe Verknüpfungen, Tabellenobjekte, Formatierungen und Makrobestandteile grundsätzlich erhalten.

## Start
1. Ordner entpacken.
2. `install.bat` einmalig starten.
3. `start.bat` starten.
4. Vier Pfade kontrollieren und **LNW-Datei erzeugen** klicken.

Voraussetzungen: Windows, Microsoft Excel Desktop, Python 3.11 oder neuer.

## Implementierte Logik
### Gesichert
- Fachblatt: `Import DC LNW`.
- `AJ:AS`: Start-/Vorstichtagsbestände.
- `CL:CU`: End-/Stichtagswerte.
- `BI:BN`: Umschichtungen.
- Vorjahresübertrag: `CL:CU` → positionsgleich `AJ:AS`.
- `BI/BJ`: DWSI-EUR.EQ.HI.CO.FC, Umsatzart Fondsportfolioanpassung, Summe UmsatzStuecke/ZahlBetrag je WWID.
- `BK/BL`: DWS EURORENTA entsprechend.
- `BM/BN`: DWS INS.-ESG EO MO.M.IC entsprechend.

### Wahrscheinliche Kandidatenlogik
- `CL:CU = AJ:AS + signierte DU-Bewegungen`, jeweils je WWID und aus der Überschrift abgeleitetem Fonds.
- Ob eine Spalte Stücke oder Wert enthält, wird aus Begriffen wie `Anteile`, `Stücke`, `Wert`, `Betrag`, `EUR` abgeleitet.
- Bestehende Formeln werden standardmäßig nicht überschrieben.

### Noch nicht fachlich gesichert
- Vollständige Logik des Blocks `V:AE`.
- Ob alle DU-Umsatzarten bereits mit fachlich korrektem Vorzeichen geliefert werden.
- Exakte Zuordnung aller zehn Fonds-/Kennzahlspalten in `AJ:AS` und `CL:CU`, falls die Header keinen eindeutigen Fondsnamen enthalten.
- Zusätzliche VBA-, Query-, externe Link- oder Hilfsprozesslogik.

## Berichte
Neben der Ausgabedatei wird ein Ordner `<Ausgabename>_report` erzeugt:
- `audit_trail.xlsx`: jede geschriebene Zelle, WWID, Regel, Wert und Herleitung.
- `comparison_differences.xlsx`: jede Abweichung zur vorhandenen 2025-Vergleichsdatei.
- `run_summary.json`: Laufstatus und Kennzahlen.

## Empfohlenes Validierungsverfahren
1. Zuerst mit unveränderten Originaldateien ausführen.
2. Vergleichsdifferenzen nach Spaltenblock gruppieren.
3. `BI:BN` muss bei den drei gesicherten Fonds zuerst nahezu vollständig übereinstimmen.
4. Differenzen in `AJ:AS` zeigen Probleme beim Jahresübertrag oder abweichende WWID-Zeilen.
5. Differenzen in `CL:CU` nach Umsatzart/Fonds analysieren; insbesondere Vorzeichen, Wiederanlage, Verkauf wegen Vorabpauschale und Fondsportfolioanpassung.
6. Differenzen in `V:AE` zunächst als intern berechnete bzw. noch offene Template-Logik behandeln.

## Sicherheit
Das Originaltemplate wird nicht verändert. Das Tool kopiert es zuerst zur Ausgabedatei. Dennoch sollten Originaldateien versioniert oder schreibgeschützt aufbewahrt werden.
