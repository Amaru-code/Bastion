@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1 || (echo Python wurde nicht gefunden. Bitte Python 3.11+ installieren. & pause & exit /b 1)
py -3 -m venv runtime
call runtime\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if errorlevel 1 (echo Installation fehlgeschlagen. & pause & exit /b 1)
echo Installation erfolgreich.
pause
