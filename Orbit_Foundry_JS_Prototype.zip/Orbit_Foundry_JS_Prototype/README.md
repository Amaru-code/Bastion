# Orbit Foundry – lokaler JS-Prototyp

## Start
1. ZIP entpacken.
2. `Start_Game.ps1` per Rechtsklick → **Mit PowerShell ausführen** starten.
3. Alternativ `Start_Game.bat` oder `index.html` doppelklicken.

Es werden keine Pakete, Server, Adminrechte oder Internetverbindungen benötigt.

## Spielziel
Gebäude platzieren, Ressourcen produzieren und die erste Mission abschließen. Speichern/Laden verwendet den lokalen Browser-Speicher.

## Technische Struktur
- `index.html` und `style.css`: Oberfläche
- `src/`: Spielcode
- `assets/`: vorbereitete lokale SVG-Assets
- `data/sectors/`: vorbereitete Sektordaten für spätere Erweiterungen
- `docs/`: kleine Entwicklungsnotizen
