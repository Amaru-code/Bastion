# Entwicklungsnotiz 7

Reservierter Ausbaupunkt für Phase 7.
