# Entwicklungsnotiz 1

Reservierter Ausbaupunkt für Phase 1.
