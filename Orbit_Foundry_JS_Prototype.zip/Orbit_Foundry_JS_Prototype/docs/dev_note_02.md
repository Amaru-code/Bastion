# Entwicklungsnotiz 2

Reservierter Ausbaupunkt für Phase 2.
