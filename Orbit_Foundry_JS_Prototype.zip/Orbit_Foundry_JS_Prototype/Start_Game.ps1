$ErrorActionPreference='Stop'
$here=Split-Path -Parent $MyInvocation.MyCommand.Path
Start-Process (Join-Path $here 'index.html')
Write-Host 'Orbit Foundry wurde im Standardbrowser gestartet.' -ForegroundColor Cyan
