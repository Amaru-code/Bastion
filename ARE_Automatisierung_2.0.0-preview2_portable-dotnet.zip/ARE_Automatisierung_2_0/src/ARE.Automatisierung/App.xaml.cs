using System.Windows;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Services.Core;
using ARE.Automatisierung.Services.Excel;
using ARE.Automatisierung.Services.Pdf;
using ARE.Automatisierung.Services.Run;
using ARE.Automatisierung.Services.Word;
using ARE.Automatisierung.ViewModels;

namespace ARE.Automatisierung;

public partial class App : Application
{
    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        var logger = new AppLogger();
        var dialogs = new DialogService();
        var headerNormalizer = new HeaderNormalizer();
        var sourceReader = new SourceWorkbookReader(headerNormalizer, logger);
        var legacyReader = new LegacyXlsComReader(logger);
        var serialReader = new SerialDataReader(headerNormalizer, legacyReader, logger);
        var engine = new AreEngine(logger);
        var officePreflight = new OfficePreflightService();
        var templateInspector = new DocxTemplateInspector();
        var excelWriter = new ExcelComOutputWriter(logger);
        var wordService = new WordComLetterService(headerNormalizer, logger);
        var pdfMerge = new PdfMergeService(logger);
        var validator = new InputValidator(sourceReader, serialReader, engine, officePreflight, templateInspector, logger);
        var runService = new AreRunService(validator, excelWriter, wordService, pdfMerge, logger);

        var viewModel = new MainViewModel(dialogs, validator, runService, logger);
        var window = new MainWindow { DataContext = viewModel };
        window.Show();
    }
}
