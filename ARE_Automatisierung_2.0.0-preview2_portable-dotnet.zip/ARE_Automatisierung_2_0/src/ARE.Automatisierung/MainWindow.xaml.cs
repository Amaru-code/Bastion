using System.Windows;

namespace ARE.Automatisierung;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
