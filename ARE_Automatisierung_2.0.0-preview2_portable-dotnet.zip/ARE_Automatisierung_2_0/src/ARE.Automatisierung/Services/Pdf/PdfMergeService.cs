using ARE.Automatisierung.Infrastructure;
using PdfSharp.Pdf;
using PdfSharp.Pdf.IO;

namespace ARE.Automatisierung.Services.Pdf;

public sealed class PdfMergeService(AppLogger logger)
{
    public void Merge(IReadOnlyList<string> inputFiles, string outputPath)
    {
        if (inputFiles.Count == 0) throw new InvalidOperationException("Keine PDF-Dateien zum Zusammenführen übergeben.");
        Directory.CreateDirectory(Path.GetDirectoryName(outputPath)!);
        using var output = new PdfDocument();
        foreach (var path in inputFiles)
        {
            if (!File.Exists(path)) throw new FileNotFoundException("PDF zum Zusammenführen fehlt.", path);
            using var input = PdfReader.Open(path, PdfDocumentOpenMode.Import);
            for (var i = 0; i < input.PageCount; i++) output.AddPage(input.Pages[i]);
        }
        output.Save(outputPath);
        logger.Info($"PDF-MERGE | {inputFiles.Count} Dateien -> {outputPath}");
    }
}
