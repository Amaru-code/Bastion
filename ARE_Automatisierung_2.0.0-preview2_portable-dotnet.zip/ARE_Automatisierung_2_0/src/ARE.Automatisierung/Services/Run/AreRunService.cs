using System.Diagnostics;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;
using ARE.Automatisierung.Services.Excel;
using ARE.Automatisierung.Services.Pdf;
using ARE.Automatisierung.Services.Word;

namespace ARE.Automatisierung.Services.Run;

public sealed class AreRunService(
    InputValidator validator,
    ExcelComOutputWriter excelWriter,
    WordComLetterService wordService,
    PdfMergeService pdfMerge,
    AppLogger logger)
{
    public async Task<RunResult> RunAsync(InputSelection input, IProgress<RunProgress>? progress = null, CancellationToken token = default)
    {
        var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss");
        var sourceBase = Path.GetFileNameWithoutExtension(input.AreSourcePath);
        var runFolder = UniqueDirectory(Path.Combine(input.OutputFolder, $"{sourceBase}_ARE_Export_{stamp}"));
        var excelFolder = Path.Combine(runFolder, "00_Excel");
        var arePdfFolder = Path.Combine(runFolder, "01_ARE_PDF");
        var aggregateFolder = Path.Combine(runFolder, "02_Serienbrief_Gesamt");
        var individualFolder = Path.Combine(runFolder, "03_Serienbrief_Einzel");
        var tempFolder = Path.Combine(runFolder, ".temp");
        foreach (var f in new[] { excelFolder, arePdfFolder, aggregateFolder, individualFolder, tempFolder }) Directory.CreateDirectory(f);

        logger.StartRun(runFolder);
        logger.Info($"ARE-QUELLE | {input.AreSourcePath}");
        logger.Info($"SERIENBRIEF-VORLAGE | {input.WordTemplatePath}");
        logger.Info($"PERSONENDATEN | {input.SerialDataPath}");
        logger.Info($"AUSGABE | {runFolder}");

        progress?.Report(new RunProgress(2, "Eingaben validieren"));
        var snapshot = await validator.ValidateAsync(input, progress: null, cancellationToken: token);
        foreach (var warning in snapshot.Warnings) logger.Warn(warning);

        token.ThrowIfCancellationRequested();
        progress?.Report(new RunProgress(15, "Sichere Excel-Ausgabekopie erstellen"));
        var ext = Path.GetExtension(input.AreSourcePath);
        var excelOutputPath = Path.Combine(excelFolder, $"{sourceBase}_ARE_Auswertung{ext}");
        File.Copy(input.AreSourcePath, excelOutputPath, overwrite: false);

        var needArePdf = input.CreateArePdfs || input.CreateLetters;
        progress?.Report(new RunProgress(25, "ARE-Blätter und PDFs erzeugen"));
        var arePdfByLtrg = await excelWriter.WriteAsync(
            excelOutputPath,
            snapshot.Reports,
            arePdfFolder,
            input.LogoPath,
            needArePdf,
            progress,
            token);

        var individualDocx = new List<string>();
        var individualPdf = new List<string>();
        if (input.CreateLetters)
        {
            var reportByLtrg = snapshot.Reports.ToDictionary(r => r.Target.Ltrg);
            var serialRows = snapshot.AffectedSerialRecords;
            if (serialRows.Count == 0)
                logger.Warn("Keine betroffenen Serienbriefzeilen gefunden; Einzelanschreiben werden übersprungen.");

            for (var i = 0; i < serialRows.Count; i++)
            {
                token.ThrowIfCancellationRequested();
                var record = serialRows[i];
                if (!record.Ltrg.HasValue || !reportByLtrg.TryGetValue(record.Ltrg.Value, out var report)) continue;
                if (!arePdfByLtrg.TryGetValue(report.Target.Ltrg, out var arePdf))
                    throw new InvalidOperationException($"ARE-PDF für LTRG {report.Target.LtrgText} wurde nicht erzeugt.");

                var areForName = string.IsNullOrWhiteSpace(record.Are) ? report.Target.Are : record.Are;
                var baseName = $"Anschrieben_ARE_{SanitizeFileName(string.IsNullOrWhiteSpace(areForName) ? "n.v." : areForName)}_LTRG_{report.Target.LtrgText}";
                var finalDocx = UniqueFilePath(individualFolder, baseName, ".docx");
                var finalPdf = Path.ChangeExtension(finalDocx, ".pdf");
                if (File.Exists(finalPdf)) finalPdf = UniqueFilePath(individualFolder, Path.GetFileNameWithoutExtension(finalPdf), ".pdf");
                var letterPdf = Path.Combine(tempFolder, $"letter_{i + 1:000}_{report.Target.LtrgText}.pdf");

                var pct = 67 + 24d * (i + 1) / Math.Max(1, serialRows.Count);
                progress?.Report(new RunProgress(pct, "Anschreiben erzeugen", $"{i + 1}/{serialRows.Count} · LTRG {report.Target.LtrgText}"));

                await CreateWithRetryAsync(input.WordTemplatePath, record, report, finalDocx, letterPdf, input.LogoPath, token);
                pdfMerge.Merge([letterPdf, arePdf], finalPdf);
                individualDocx.Add(finalDocx);
                individualPdf.Add(finalPdf);
                logger.Info($"EINZELPAKET | LTRG={report.Target.LtrgText} | DOCX={finalDocx} | PDF={finalPdf}");
            }
        }

        string? aggregateDocx = null;
        string? aggregatePdf = null;
        if (input.CreateAggregate && individualDocx.Count > 0)
        {
            progress?.Report(new RunProgress(94, "Gesamtdokumente aufbauen"));
            aggregateDocx = Path.Combine(aggregateFolder, "Anschreiben_ARE_Gesamt.docx");
            aggregatePdf = Path.Combine(aggregateFolder, "Anschreiben_ARE_Gesamt.pdf");
            await wordService.BuildAggregateDocxAsync(individualDocx, aggregateDocx, token);
            pdfMerge.Merge(individualPdf, aggregatePdf);
        }

        if (!input.CreateExcelOutput)
        {
            try { File.Delete(excelOutputPath); } catch { }
        }
        if (!input.CreateArePdfs && !input.CreateLetters)
        {
            try { if (Directory.Exists(arePdfFolder)) Directory.Delete(arePdfFolder, true); } catch { }
        }
        try { Directory.Delete(tempFolder, true); } catch { }

        progress?.Report(new RunProgress(100, "Verarbeitung abgeschlossen", runFolder));
        logger.Info("FERTIG | Verarbeitung erfolgreich abgeschlossen");

        return new RunResult
        {
            RunFolder = runFolder,
            ExcelOutputPath = excelOutputPath,
            ArePdfPaths = arePdfByLtrg.Values.ToArray(),
            IndividualDocxPaths = individualDocx,
            IndividualPdfPaths = individualPdf,
            AggregateDocxPath = aggregateDocx,
            AggregatePdfPath = aggregatePdf
        };
    }

    private async Task CreateWithRetryAsync(string templatePath, SerialRecord record, AreReport report, string finalDocx, string letterPdf, string? logoPath, CancellationToken token)
    {
        try
        {
            await wordService.CreateIndividualPackageAsync(templatePath, record, report, finalDocx, letterPdf, logoPath, token);
        }
        catch (Exception first)
        {
            logger.Warn($"WORD-RETRY | LTRG {report.Target.LtrgText} | erster Versuch fehlgeschlagen: {first.Message}");
            try { if (File.Exists(finalDocx)) File.Delete(finalDocx); } catch { }
            try { if (File.Exists(letterPdf)) File.Delete(letterPdf); } catch { }
            await wordService.CreateIndividualPackageAsync(templatePath, record, report, finalDocx, letterPdf, logoPath, token);
        }
    }

    public static void OpenFolder(string path)
    {
        if (!Directory.Exists(path)) return;
        Process.Start(new ProcessStartInfo("explorer.exe", $"\"{path}\"") { UseShellExecute = true });
    }

    private static string UniqueDirectory(string path)
    {
        if (!Directory.Exists(path)) { Directory.CreateDirectory(path); return path; }
        for (var i = 2; ; i++)
        {
            var candidate = path + "_" + i;
            if (Directory.Exists(candidate)) continue;
            Directory.CreateDirectory(candidate);
            return candidate;
        }
    }

    private static string UniqueFilePath(string folder, string baseName, string extension)
    {
        var candidate = Path.Combine(folder, baseName + extension);
        if (!File.Exists(candidate)) return candidate;
        for (var i = 2; ; i++)
        {
            candidate = Path.Combine(folder, $"{baseName}_{i}{extension}");
            if (!File.Exists(candidate)) return candidate;
        }
    }

    private static string SanitizeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '-');
        return value.Trim();
    }
}
