using System.Text.RegularExpressions;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;

namespace ARE.Automatisierung.Services.Word;

public sealed partial class WordComLetterService(HeaderNormalizer normalizer, AppLogger logger)
{
    private const int WdDoNotSaveChanges = 0;
    private const int WdFormatXmlDocument = 12;
    private const int WdExportFormatPdf = 17;
    private const int WdSectionBreakNextPage = 2;
    private const int WdCollapseEnd = 0;
    private const int WdPageBreak = 7;
    private const int WdAlignParagraphCenter = 1;
    private const int WdAlignParagraphLeft = 0;
    private const int WdAlignParagraphRight = 2;
    private const int WdAutoFitWindow = 2;
    private const int WdHeaderFooterPrimary = 1;
    private const int WdHeaderFooterFirstPage = 2;
    private const int WdHeaderFooterEvenPages = 3;
    private static readonly int MarshNavy = Rgb(0, 15, 71);

    [GeneratedRegex(@"MERGEFIELD\s+(?:""([^""]+)""|([^\\\s]+))", RegexOptions.IgnoreCase)]
    private static partial Regex MergeFieldRegex();

    public Task CreateIndividualPackageAsync(
        string templatePath,
        SerialRecord record,
        AreReport report,
        string finalDocxPath,
        string letterOnlyPdfPath,
        string? logoPath,
        CancellationToken token = default) =>
        StaThreadRunner.RunAsync(() => CreateIndividualPackage(templatePath, record, report, finalDocxPath, letterOnlyPdfPath, logoPath), token);

    public Task BuildAggregateDocxAsync(IReadOnlyList<string> documents, string outputPath, CancellationToken token = default) =>
        StaThreadRunner.RunAsync(() => BuildAggregateDocx(documents, outputPath), token);

    private void CreateIndividualPackage(string templatePath, SerialRecord record, AreReport report, string finalDocxPath, string letterOnlyPdfPath, string? logoPath)
    {
        var wordType = Type.GetTypeFromProgID("Word.Application") ??
            throw new InvalidOperationException("Microsoft Word Desktop wurde nicht gefunden. Word wird als unsichtbare Rendering-Schicht für die Anschreiben benötigt.");
        dynamic? word = null;
        dynamic? doc = null;
        try
        {
            word = Activator.CreateInstance(wordType)!;
            word.Visible = false;
            word.DisplayAlerts = 0;
            doc = word.Documents.Open(templatePath, false, false, false);
            FillMergeFields(doc, record.Values);
            NormalizeAnlageParagraphs(doc);

            Directory.CreateDirectory(Path.GetDirectoryName(finalDocxPath)!);
            Directory.CreateDirectory(Path.GetDirectoryName(letterOnlyPdfPath)!);

            doc.ExportAsFixedFormat(letterOnlyPdfPath, WdExportFormatPdf);
            AppendAreAppendix(doc, report, logoPath);
            doc.SaveAs2(finalDocxPath, WdFormatXmlDocument);
            logger.Info($"WORD | Einzel-DOCX: {finalDocxPath}");
        }
        finally
        {
            try { if (doc is not null) doc.Close(WdDoNotSaveChanges); } catch { }
            try { if (word is not null) word.Quit(WdDoNotSaveChanges); } catch { }
            ComHelpers.FinalRelease(doc);
            ComHelpers.FinalRelease(word);
        }
    }

    private void FillMergeFields(dynamic doc, IReadOnlyDictionary<string, string> values)
    {
        var lookup = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        foreach (var kv in values)
        {
            lookup[kv.Key] = kv.Value ?? "";
            lookup[normalizer.MergeKey(kv.Key)] = kv.Value ?? "";
        }

        ProcessRangeFields(doc.Content, lookup);
        ProcessShapes(doc.Shapes, lookup);

        for (var s = 1; s <= (int)doc.Sections.Count; s++)
        {
            dynamic? section = null;
            try
            {
                section = doc.Sections[s];
                foreach (var kind in new[] { WdHeaderFooterPrimary, WdHeaderFooterFirstPage, WdHeaderFooterEvenPages })
                {
                    TryProcessHeaderFooter(section.Headers, kind, lookup);
                    TryProcessHeaderFooter(section.Footers, kind, lookup);
                }
            }
            finally { ComHelpers.FinalRelease(section); }
        }
    }

    private void TryProcessHeaderFooter(dynamic collection, int index, IReadOnlyDictionary<string, string> lookup)
    {
        dynamic? hf = null;
        try
        {
            hf = collection[index];
            if (!(bool)hf.Exists) return;
            ProcessRangeFields(hf.Range, lookup);
            ProcessShapes(hf.Shapes, lookup);
        }
        catch { }
        finally { ComHelpers.FinalRelease(hf); }
    }

    private void ProcessRangeFields(dynamic range, IReadOnlyDictionary<string, string> lookup)
    {
        dynamic? fields = null;
        try
        {
            fields = range.Fields;
            for (var i = (int)fields.Count; i >= 1; i--)
            {
                dynamic? field = null;
                try
                {
                    field = fields[i];
                    var code = Convert.ToString(field.Code.Text) ?? "";
                    var match = MergeFieldRegex().Match(code);
                    if (!match.Success) continue;
                    var name = (match.Groups[1].Success ? match.Groups[1].Value : match.Groups[2].Value).Trim();
                    var value = Lookup(name, lookup);
                    field.Result.Text = value;
                    field.Unlink();
                }
                catch { }
                finally { ComHelpers.FinalRelease(field); }
            }
        }
        catch { }
        finally { ComHelpers.FinalRelease(fields); }
    }

    private void ProcessShapes(dynamic shapes, IReadOnlyDictionary<string, string> lookup)
    {
        try
        {
            for (var i = 1; i <= (int)shapes.Count; i++)
            {
                dynamic? shape = null;
                dynamic? textRange = null;
                try
                {
                    shape = shapes[i];
                    if ((int)shape.TextFrame.HasText != 0)
                    {
                        textRange = shape.TextFrame.TextRange;
                        ProcessRangeFields(textRange, lookup);
                    }
                }
                catch { }
                finally
                {
                    ComHelpers.FinalRelease(textRange);
                    ComHelpers.FinalRelease(shape);
                }
            }
        }
        catch { }
    }

    private string Lookup(string fieldName, IReadOnlyDictionary<string, string> lookup)
    {
        if (lookup.TryGetValue(fieldName, out var exact)) return exact;
        return lookup.TryGetValue(normalizer.MergeKey(fieldName), out var normalized) ? normalized : "";
    }

    private static void NormalizeAnlageParagraphs(dynamic doc)
    {
        try
        {
            for (var i = 1; i <= (int)doc.Paragraphs.Count; i++)
            {
                dynamic? paragraph = null;
                try
                {
                    paragraph = doc.Paragraphs[i];
                    var text = (Convert.ToString(paragraph.Range.Text) ?? "").Trim();
                    if (text.StartsWith("Anlage", StringComparison.OrdinalIgnoreCase))
                    {
                        paragraph.Format.SpaceAfter = 0;
                        paragraph.Format.SpaceBefore = 0;
                    }
                }
                finally { ComHelpers.FinalRelease(paragraph); }
            }
        }
        catch { }
    }

    private static void AppendAreAppendix(dynamic doc, AreReport report, string? logoPath)
    {
        dynamic? end = null;
        try
        {
            end = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
            end.InsertBreak(WdSectionBreakNextPage);
        }
        finally { ComHelpers.FinalRelease(end); }

        dynamic? section = null;
        try
        {
            section = doc.Sections[doc.Sections.Count];
            ClearAndUnlink(section.Headers);
            ClearAndUnlink(section.Footers);
            section.PageSetup.LeftMargin = CmToPoints(1.2);
            section.PageSetup.RightMargin = CmToPoints(1.2);
            section.PageSetup.TopMargin = CmToPoints(1.0);
            section.PageSetup.BottomMargin = CmToPoints(1.0);
        }
        finally { ComHelpers.FinalRelease(section); }

        if (!string.IsNullOrWhiteSpace(logoPath) && File.Exists(logoPath))
        {
            dynamic? r = null;
            dynamic? pic = null;
            try
            {
                r = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
                pic = doc.InlineShapes.AddPicture(logoPath, false, true, r);
                pic.LockAspectRatio = -1;
                pic.Height = 34;
                r.InsertParagraphAfter();
            }
            catch { }
            finally { ComHelpers.FinalRelease(pic); ComHelpers.FinalRelease(r); }
        }

        AddParagraph(doc, $"Einzelübertritte {report.ReportPeriod}", 10, false, WdAlignParagraphRight);
        AddParagraph(doc, $"ARE {(string.IsNullOrWhiteSpace(report.Target.Are) ? "n.v." : report.Target.Are)} (LTRG {report.Target.LtrgText})", 10, false, WdAlignParagraphRight);
        AddParagraph(doc, "Übertragene Rückstellungen bei Einzelübertritten", 15, true, WdAlignParagraphCenter, 8);
        AddParagraph(doc, $"Positive Beträge erhält die {report.Target.ShortName} von der genannten Gesellschaft,", 9, false, WdAlignParagraphLeft, 0);
        AddParagraph(doc, $"negative Beträge gibt die {report.Target.ShortName} an die genannte Gesellschaft ab.", 9, false, WdAlignParagraphLeft, 8);

        foreach (var group in report.Groups)
        {
            AddParagraph(doc, $"{group.Counterparty.ShortName} (ARE {(string.IsNullOrWhiteSpace(group.Counterparty.Are) ? "n.v." : group.Counterparty.Are)}, LTRG {group.Counterparty.LtrgText})", 10, true, WdAlignParagraphCenter, 2);
            AddAreTable(doc, group);
            AddParagraph(doc, "", 5, false, WdAlignParagraphLeft, 2);
        }
    }

    private static void AddAreTable(dynamic doc, AreGroup group)
    {
        dynamic? range = null;
        dynamic? table = null;
        try
        {
            range = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
            var rowCount = group.Rows.Count + 2;
            table = doc.Tables.Add(range, rowCount, 6);
            table.AllowAutoFit = true;
            table.AutoFitBehavior(WdAutoFitWindow);
            table.Range.Font.Name = "Arial";
            table.Range.Font.Size = 9;
            table.Range.Font.Color = MarshNavy;
            table.Borders.Enable = 0;

            var headers = new[] { "PNR", "alte PNR", "Übertritt", "Pensionen (alt)\n(Euro)", "BSAV\n(Euro)", "Summe\n(Euro)" };
            for (var c = 1; c <= 6; c++)
            {
                dynamic? cell = table.Cell(1, c);
                cell.Range.Text = headers[c - 1];
                cell.Range.Bold = true;
                cell.Range.ParagraphFormat.Alignment = WdAlignParagraphCenter;
                ComHelpers.FinalRelease(cell);
            }

            for (var r = 0; r < group.Rows.Count; r++)
            {
                var item = group.Rows[r];
                SetCell(table, r + 2, 1, item.Pnr, WdAlignParagraphCenter, false);
                SetCell(table, r + 2, 2, item.OldPnr, WdAlignParagraphCenter, false);
                SetCell(table, r + 2, 3, item.TransferDate?.ToString("dd.MM.yyyy") ?? "", WdAlignParagraphCenter, false);
                SetCell(table, r + 2, 4, item.Pension.ToString("N0"), WdAlignParagraphRight, false);
                SetCell(table, r + 2, 5, item.Bsav.ToString("N0"), WdAlignParagraphRight, false);
                SetCell(table, r + 2, 6, item.Total.ToString("N0"), WdAlignParagraphRight, false);
            }

            var subtotal = rowCount;
            SetCell(table, subtotal, 4, group.PensionSubtotal.ToString("N0"), WdAlignParagraphRight, true);
            SetCell(table, subtotal, 5, group.BsavSubtotal.ToString("N0"), WdAlignParagraphRight, true);
            SetCell(table, subtotal, 6, group.TotalSubtotal.ToString("N0"), WdAlignParagraphRight, true);
            table.Rows[subtotal].Borders[-1].LineStyle = 1;
        }
        finally
        {
            ComHelpers.FinalRelease(table);
            ComHelpers.FinalRelease(range);
        }
    }

    private static void SetCell(dynamic table, int row, int col, string text, int alignment, bool bold)
    {
        dynamic? cell = null;
        try
        {
            cell = table.Cell(row, col);
            cell.Range.Text = text;
            cell.Range.Bold = bold;
            cell.Range.ParagraphFormat.Alignment = alignment;
        }
        finally { ComHelpers.FinalRelease(cell); }
    }

    private static void AddParagraph(dynamic doc, string text, int size, bool bold, int alignment, int spaceAfter = 4)
    {
        dynamic? range = null;
        try
        {
            range = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
            range.Text = text + Environment.NewLine;
            range.Font.Name = "Arial";
            range.Font.Size = size;
            range.Font.Bold = bold;
            range.Font.Color = MarshNavy;
            range.ParagraphFormat.Alignment = alignment;
            range.ParagraphFormat.SpaceAfter = spaceAfter;
        }
        finally { ComHelpers.FinalRelease(range); }
    }

    private static void ClearAndUnlink(dynamic collection)
    {
        foreach (var kind in new[] { WdHeaderFooterPrimary, WdHeaderFooterFirstPage, WdHeaderFooterEvenPages })
        {
            dynamic? hf = null;
            try
            {
                hf = collection[kind];
                if ((bool)hf.Exists)
                {
                    hf.LinkToPrevious = false;
                    hf.Range.Text = "";
                }
            }
            catch { }
            finally { ComHelpers.FinalRelease(hf); }
        }
    }

    private void BuildAggregateDocx(IReadOnlyList<string> documents, string outputPath)
    {
        if (documents.Count == 0) return;
        var wordType = Type.GetTypeFromProgID("Word.Application") ?? throw new InvalidOperationException("Microsoft Word wurde nicht gefunden.");
        dynamic? word = null;
        dynamic? doc = null;
        try
        {
            word = Activator.CreateInstance(wordType)!;
            word.Visible = false;
            word.DisplayAlerts = 0;
            doc = word.Documents.Add();
            for (var i = 0; i < documents.Count; i++)
            {
                dynamic? range = null;
                try
                {
                    range = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
                    range.InsertFile(documents[i]);
                    if (i < documents.Count - 1)
                    {
                        range = doc.Range(doc.Content.End - 1, doc.Content.End - 1);
                        range.InsertBreak(WdPageBreak);
                    }
                }
                finally { ComHelpers.FinalRelease(range); }
            }
            doc.SaveAs2(outputPath, WdFormatXmlDocument);
            logger.Info($"WORD | Gesamt-DOCX: {outputPath}");
        }
        finally
        {
            try { if (doc is not null) doc.Close(WdDoNotSaveChanges); } catch { }
            try { if (word is not null) word.Quit(WdDoNotSaveChanges); } catch { }
            ComHelpers.FinalRelease(doc);
            ComHelpers.FinalRelease(word);
        }
    }

    private static float CmToPoints(double cm) => (float)(cm * 28.3464567);
    private static int Rgb(int r, int g, int b) => r + g * 256 + b * 65536;
}
