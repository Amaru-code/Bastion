using ClosedXML.Excel;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;

namespace ARE.Automatisierung.Services.Excel;

public sealed class SourceWorkbookReader(HeaderNormalizer normalizer, AppLogger logger)
{
    private static readonly string[] RequiredOverview = ["pnr_new", "ltrg_new", "pnr_old", "ltrg_old", "transfer_date", "bsav", "pension"];
    private static readonly string[] OptionalOverview = ["last_cutoff", "months", "total"];
    private static readonly string[] RequiredCompany = ["ltrg", "are", "name"];

    public Task<SourceData> ReadAsync(string path, CancellationToken cancellationToken = default) => Task.Run(() => Read(path, cancellationToken), cancellationToken);

    private SourceData Read(string path, CancellationToken cancellationToken)
    {
        using var workbook = new XLWorkbook(path);
        var overview = FindWorksheet(workbook, "Übersicht") ?? throw new InvalidOperationException("Das Blatt 'Übersicht' wurde nicht gefunden.");
        var companiesSheet = FindWorksheet(workbook, "Gesellschaften") ?? throw new InvalidOperationException("Das Blatt 'Gesellschaften' wurde nicht gefunden.");

        var overviewLayout = DiscoverLayout(overview, normalizer.CanonicalOverview, RequiredOverview, OptionalOverview, "Übersicht");
        var companyLayout = DiscoverLayout(companiesSheet, normalizer.CanonicalCompany, RequiredCompany, [], "Gesellschaften");

        var transfers = ReadTransfers(overview, overviewLayout, cancellationToken);
        var companies = ReadCompanies(companiesSheet, companyLayout, cancellationToken);
        var period = ReportPeriodResolver.Resolve(Path.GetFileNameWithoutExtension(path));

        logger.Info($"QUELLE | Übersichtskopf Zeile {overviewLayout.HeaderRow} | {Describe(overviewLayout.Columns)}");
        logger.Info($"QUELLE | Gesellschaftskopf Zeile {companyLayout.HeaderRow} | {Describe(companyLayout.Columns)}");
        logger.Info($"QUELLE | Übertritte={transfers.Count} | Gesellschaften={companies.Count} | Zeitraum={period}");

        return new SourceData
        {
            Transfers = transfers,
            Companies = companies,
            ReportPeriod = period,
            OverviewHeaderRow = overviewLayout.HeaderRow,
            OverviewColumns = overviewLayout.Columns,
            CompanyHeaderRow = companyLayout.HeaderRow,
            CompanyColumns = companyLayout.Columns
        };
    }

    private static IXLWorksheet? FindWorksheet(XLWorkbook workbook, string requested)
    {
        var target = NormalizeSheetName(requested);
        return workbook.Worksheets.FirstOrDefault(w => NormalizeSheetName(w.Name) == target);
    }

    private static string NormalizeSheetName(string value)
    {
        var t = value.Trim().ToLowerInvariant().Replace("ä", "ae").Replace("ö", "oe").Replace("ü", "ue").Replace("ß", "ss");
        return new string(t.Where(char.IsLetterOrDigit).ToArray());
    }

    private Layout DiscoverLayout(IXLWorksheet ws, Func<string?, string> canonicalizer, IReadOnlyList<string> required, IReadOnlyList<string> optional, string role)
    {
        var lastRow = Math.Min(ws.LastRowUsed()?.RowNumber() ?? 1, 30);
        var lastCol = Math.Min(ws.LastColumnUsed()?.ColumnNumber() ?? 1, 100);
        Dictionary<string, int>? best = null;
        var bestScore = -1;
        var bestRow = 0;

        for (var row = 1; row <= lastRow; row++)
        {
            var map = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            for (var col = 1; col <= lastCol; col++)
            {
                var canonical = canonicalizer(CellText(ws.Cell(row, col)));
                if (!string.IsNullOrWhiteSpace(canonical) && !map.ContainsKey(canonical)) map[canonical] = col;
            }
            var score = required.Count(map.ContainsKey) * 100 + optional.Count(map.ContainsKey) * 10;
            if (score > bestScore)
            {
                bestScore = score;
                bestRow = row;
                best = map;
            }
        }

        best ??= new Dictionary<string, int>();
        var missing = required.Where(x => !best.ContainsKey(x)).ToArray();
        if (missing.Length > 0)
            throw new InvalidOperationException($"Die benötigten Spalten im Blatt '{role}' konnten nicht vollständig erkannt werden. Beste Kopfzeile: {bestRow}. Fehlend: {string.Join(", ", missing)}");
        return new Layout(bestRow, best);
    }

    private List<TransferRecord> ReadTransfers(IXLWorksheet ws, Layout layout, CancellationToken token)
    {
        var first = layout.HeaderRow + 1;
        var last = ws.LastRowUsed()?.RowNumber() ?? first - 1;
        var list = new List<TransferRecord>();

        for (var row = first; row <= last; row++)
        {
            token.ThrowIfCancellationRequested();
            var newValue = ReadCell(ws.Cell(row, layout.Columns["ltrg_new"]));
            var oldValue = ReadCell(ws.Cell(row, layout.Columns["ltrg_old"]));
            if (!HeaderNormalizer.TryParseLtrg(newValue, out var ltrgNew) || !HeaderNormalizer.TryParseLtrg(oldValue, out var ltrgOld)) continue;

            var pnrNew = CellText(ws.Cell(row, layout.Columns["pnr_new"]));
            var pnrOld = CellText(ws.Cell(row, layout.Columns["pnr_old"]));
            var date = CellDate(ws.Cell(row, layout.Columns["transfer_date"]));
            var bsav = CellDouble(ws.Cell(row, layout.Columns["bsav"]));
            var pension = CellDouble(ws.Cell(row, layout.Columns["pension"]));
            var total = layout.Columns.TryGetValue("total", out var totalCol) && !ws.Cell(row, totalCol).IsEmpty()
                ? CellDouble(ws.Cell(row, totalCol))
                : bsav + pension;

            list.Add(new TransferRecord(row, pnrNew, ltrgNew, pnrOld, ltrgOld, date, bsav, pension, total));
        }
        if (list.Count == 0) throw new InvalidOperationException("Unterhalb der erkannten Übersicht-Kopfzeile wurden keine gültigen Übertritte gefunden.");
        return list;
    }

    private Dictionary<long, CompanyInfo> ReadCompanies(IXLWorksheet ws, Layout layout, CancellationToken token)
    {
        var first = layout.HeaderRow + 1;
        var last = ws.LastRowUsed()?.RowNumber() ?? first - 1;
        var dict = new Dictionary<long, CompanyInfo>();
        for (var row = first; row <= last; row++)
        {
            token.ThrowIfCancellationRequested();
            if (!HeaderNormalizer.TryParseLtrg(ReadCell(ws.Cell(row, layout.Columns["ltrg"])), out var ltrg)) continue;
            var name = CellText(ws.Cell(row, layout.Columns["name"])).Trim();
            if (string.IsNullOrWhiteSpace(name)) continue;
            var are = CellText(ws.Cell(row, layout.Columns["are"])).Trim();
            if (dict.TryGetValue(ltrg, out var existing))
                dict[ltrg] = new CompanyInfo(ltrg, string.IsNullOrWhiteSpace(are) ? existing.Are : are, string.IsNullOrWhiteSpace(name) ? existing.Name : name);
            else
                dict[ltrg] = new CompanyInfo(ltrg, are, name);
        }
        if (dict.Count == 0) throw new InvalidOperationException("Im Blatt 'Gesellschaften' wurden keine gültigen Zuordnungen gefunden.");
        return dict;
    }

    internal static object? ReadCell(IXLCell cell)
    {
        if (cell.IsEmpty()) return null;
        return cell.DataType switch
        {
            XLDataType.Number => cell.GetDouble(),
            XLDataType.DateTime => cell.GetDateTime(),
            XLDataType.Boolean => cell.GetBoolean(),
            _ => cell.GetFormattedString()
        };
    }

    internal static string CellText(IXLCell cell)
    {
        if (cell.IsEmpty()) return "";
        try { return cell.GetFormattedString(); }
        catch { return cell.Value.ToString(); }
    }

    private static double CellDouble(IXLCell cell)
    {
        if (cell.IsEmpty()) return 0;
        if (cell.TryGetValue<double>(out var d)) return d;
        var text = CellText(cell).Trim();
        if (double.TryParse(text, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.CurrentCulture, out d)) return d;
        if (double.TryParse(text.Replace(',', '.'), System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out d)) return d;
        return 0;
    }

    private static DateTime? CellDate(IXLCell cell)
    {
        if (cell.IsEmpty()) return null;
        if (cell.TryGetValue<DateTime>(out var dt)) return dt;
        if (cell.TryGetValue<double>(out var d) && d > 0)
        {
            try { return DateTime.FromOADate(d); } catch { }
        }
        return DateTime.TryParse(CellText(cell), out dt) ? dt : null;
    }

    private static string Describe(IReadOnlyDictionary<string, int> columns) => string.Join(" | ", columns.OrderBy(x => x.Value).Select(x => $"{x.Key}={ColumnLetter(x.Value)}"));
    private static string ColumnLetter(int number)
    {
        var s = "";
        while (number > 0) { number--; s = (char)('A' + number % 26) + s; number /= 26; }
        return s;
    }

    private sealed record Layout(int HeaderRow, Dictionary<string, int> Columns);
}
