using ARE.Automatisierung.Infrastructure;

namespace ARE.Automatisierung.Services.Excel;

public sealed class LegacyXlsComReader(AppLogger logger)
{
    public Task<(string[] Headers, List<string[]> Rows)> ReadAsync(string path, CancellationToken token = default) =>
        StaThreadRunner.RunAsync(() => Read(path), token);

    private (string[] Headers, List<string[]> Rows) Read(string path)
    {
        var excelType = Type.GetTypeFromProgID("Excel.Application") ?? throw new InvalidOperationException("Microsoft Excel wurde für das Lesen der alten XLS-Datei nicht gefunden.");
        dynamic? excel = null;
        dynamic? wb = null;
        dynamic? ws = null;
        try
        {
            excel = Activator.CreateInstance(excelType)!;
            excel.Visible = false;
            excel.DisplayAlerts = false;
            excel.ScreenUpdating = false;
            wb = excel.Workbooks.Open(path, 0, true);
            ws = wb.Worksheets[1];
            dynamic used = ws.UsedRange;
            var rows = (int)used.Rows.Count;
            var cols = (int)used.Columns.Count;
            object[,] values = used.Value2;
            var headers = new string[cols];
            for (var c = 1; c <= cols; c++) headers[c - 1] = Convert.ToString(values[1, c]) ?? "";
            var result = new List<string[]>();
            for (var r = 2; r <= rows; r++)
            {
                var row = new string[cols];
                var any = false;
                for (var c = 1; c <= cols; c++)
                {
                    row[c - 1] = Convert.ToString(values[r, c]) ?? "";
                    if (!string.IsNullOrWhiteSpace(row[c - 1])) any = true;
                }
                if (any) result.Add(row);
            }
            ComHelpers.FinalRelease(used);
            logger.Info($"XLS-FALLBACK | {result.Count} Datenzeilen über unsichtbares Excel gelesen");
            return (headers, result);
        }
        finally
        {
            try { if (wb is not null) wb.Close(false); } catch { }
            try { if (excel is not null) excel.Quit(); } catch { }
            ComHelpers.FinalRelease(ws);
            ComHelpers.FinalRelease(wb);
            ComHelpers.FinalRelease(excel);
        }
    }
}
