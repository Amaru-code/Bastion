using ClosedXML.Excel;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;

namespace ARE.Automatisierung.Services.Excel;

public sealed class SerialDataReader(HeaderNormalizer normalizer, LegacyXlsComReader legacyReader, AppLogger logger)
{
    public async Task<IReadOnlyList<SerialRecord>> ReadAsync(string path, CancellationToken token = default)
    {
        if (Path.GetExtension(path).Equals(".xls", StringComparison.OrdinalIgnoreCase))
        {
            var (headers, rows) = await legacyReader.ReadAsync(path, token);
            return Build(headers, rows, 2);
        }
        return await Task.Run(() => ReadOpenXml(path, token), token);
    }

    private IReadOnlyList<SerialRecord> ReadOpenXml(string path, CancellationToken token)
    {
        using var wb = new XLWorkbook(path);
        var ws = wb.Worksheets.First();
        var lastCol = ws.LastColumnUsed()?.ColumnNumber() ?? 1;
        var lastRow = ws.LastRowUsed()?.RowNumber() ?? 1;
        var headers = Enumerable.Range(1, lastCol).Select(c => SourceWorkbookReader.CellText(ws.Cell(1, c))).ToArray();
        var rows = new List<string[]>();
        for (var r = 2; r <= lastRow; r++)
        {
            token.ThrowIfCancellationRequested();
            var row = new string[lastCol];
            var any = false;
            for (var c = 1; c <= lastCol; c++)
            {
                row[c - 1] = SourceWorkbookReader.CellText(ws.Cell(r, c));
                if (!string.IsNullOrWhiteSpace(row[c - 1])) any = true;
            }
            if (any) rows.Add(row);
        }
        return Build(headers, rows, 2);
    }

    private IReadOnlyList<SerialRecord> Build(string[] headers, List<string[]> rows, int firstSourceRow)
    {
        var ltrgIndex = Array.FindIndex(headers, normalizer.IsSerialLtrgHeader);
        if (ltrgIndex < 0) { ltrgIndex = 0; logger.Warn("Serienbriefdaten: keine LTRG-Überschrift erkannt; Fallback Spalte A wird verwendet."); }
        var areIndex = Array.FindIndex(headers, normalizer.IsSerialAreHeader);
        if (areIndex < 0 && headers.Length > 1) { areIndex = 1; logger.Warn("Serienbriefdaten: keine ARE-Überschrift erkannt; Fallback Spalte B wird verwendet."); }

        var result = new List<SerialRecord>();
        for (var i = 0; i < rows.Count; i++)
        {
            var values = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            for (var c = 0; c < headers.Length && c < rows[i].Length; c++)
            {
                var name = string.IsNullOrWhiteSpace(headers[c]) ? $"Spalte_{c + 1}" : headers[c];
                if (!values.ContainsKey(name)) values[name] = rows[i][c] ?? "";
            }
            long? ltrg = null;
            if (ltrgIndex < rows[i].Length && HeaderNormalizer.TryParseLtrg(rows[i][ltrgIndex], out var parsed)) ltrg = parsed;
            var are = areIndex >= 0 && areIndex < rows[i].Length ? rows[i][areIndex] ?? "" : "";
            result.Add(new SerialRecord { SourceRow = firstSourceRow + i, Values = values, Ltrg = ltrg, Are = are });
        }
        logger.Info($"SERIENBRIEF | Zeilen={result.Count} | LTRG-Spalte={ltrgIndex + 1} | ARE-Spalte={(areIndex >= 0 ? areIndex + 1 : 0)}");
        return result;
    }
}
