using System.IO.Compression;

namespace ARE.Automatisierung.Services.Core;

public sealed class DocxTemplateInspector
{
    public int CountMergeFields(string path)
    {
        try
        {
            using var archive = ZipFile.OpenRead(path);
            var count = 0;
            foreach (var entry in archive.Entries)
            {
                var name = entry.FullName;
                if (!name.Equals("word/document.xml", StringComparison.OrdinalIgnoreCase) &&
                    !name.StartsWith("word/header", StringComparison.OrdinalIgnoreCase) &&
                    !name.StartsWith("word/footer", StringComparison.OrdinalIgnoreCase))
                    continue;

                using var reader = new StreamReader(entry.Open());
                var xml = reader.ReadToEnd();
                var index = 0;
                while ((index = xml.IndexOf("MERGEFIELD", index, StringComparison.OrdinalIgnoreCase)) >= 0)
                {
                    count++;
                    index += "MERGEFIELD".Length;
                }
            }
            return count;
        }
        catch (InvalidDataException ex)
        {
            throw new InvalidOperationException("Die ausgewählte Word-Vorlage ist keine gültige DOCX-Datei oder ist beschädigt.", ex);
        }
    }
}
