using System.Text.RegularExpressions;

namespace ARE.Automatisierung.Services.Core;

public static partial class ReportPeriodResolver
{
    [GeneratedRegex(@"(19|20)\d{2}")]
    private static partial Regex YearRegex();

    public static string Resolve(string fileNameWithoutExtension)
    {
        var match = YearRegex().Match(fileNameWithoutExtension ?? "");
        if (!match.Success || !int.TryParse(match.Value, out var year)) return "2024/25";
        return $"{year - 1}/{year % 100:00}";
    }
}
