using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;

namespace ARE.Automatisierung.Services.Core;

public sealed class HeaderNormalizer
{
    public string Normalize(string? value)
    {
        var text = (value ?? "").Trim().ToLowerInvariant()
            .Replace("ä", "ae").Replace("ö", "oe").Replace("ü", "ue").Replace("ß", "ss")
            .Replace('\r', ' ').Replace('\n', ' ').Replace('\u00A0', ' ');

        var sb = new StringBuilder(text.Length);
        foreach (var ch in text)
            sb.Append(char.IsLetterOrDigit(ch) ? ch : ' ');
        return Regex.Replace(sb.ToString(), @"\s+", " ").Trim();
    }

    public string Compact(string? value) => Normalize(value).Replace(" ", "");

    public string CanonicalOverview(string? raw)
    {
        var c = Compact(raw);
        return c switch
        {
            "pnrneu" or "personalnummerneu" or "personalnrneu" => "pnr_new",
            "ltrgneu" or "ltgrneu" or "lgtrneu" or "ltrgrneu" or "leistungstraegerneu" or "leistungstragerneu" => "ltrg_new",
            "pnralt" or "personalnummeralt" or "personalnralt" => "pnr_old",
            "ltrgalt" or "ltgralt" or "lgtralt" or "ltrgralt" or "leistungstraegeralt" or "leistungstrageralt" => "ltrg_old",
            "uebertritt" or "uebertrittsdatum" or "datumdeseinzeluebertritts" or "datumeinzeluebertritt" => "transfer_date",
            "letzterstichtag1" or "letzterstichtagplus1" => "last_cutoff",
            "monatebisuebertritt" or "monatebiszumeinzeluebertritt" => "months",
            "bsav" or "bsaveuro" or "uebertragungswertbsav" or "uebertragungswertbsaveuro" => "bsav",
            "pensionenalt" or "pensionenalteuro" or "pensionalt" or "uebertragungswertpensionenalt" or "uebertragungswertpensionenalteuro" => "pension",
            "summe" or "summeeuro" or "gesamt" or "gesamtbetrag" or "uebertragungswertsumme" => "total",
            _ when c.Contains("datum") && c.Contains("einzeluebertritt") => "transfer_date",
            _ when c.Contains("bsav") && !c.Contains("summe") => "bsav",
            _ when c.Contains("pension") && c.Contains("alt") => "pension",
            _ => ""
        };
    }

    public string CanonicalCompany(string? raw)
    {
        var c = Compact(raw);
        return c switch
        {
            "ltrg" or "ltgr" or "lgtr" or "ltrgr" or "leistungstraeger" or "leistungstrager" or "ltrgneu" or "ltgrneu" or "lgtrneu" or "ltrgrneu" => "ltrg",
            "are" or "arenummer" or "arewert" or "arecode" => "are",
            "name" or "gesellschaft" or "gesellschaftsname" or "firmenname" or "unternehmen" => "name",
            _ => ""
        };
    }

    public bool IsSerialLtrgHeader(string? raw)
    {
        var c = Compact(raw);
        return c is "ltrg" or "ltgr" or "lgtr" or "ltrgr" or "leistungstraeger" or "leistungstrager" or "leistungstraegernummer";
    }

    public bool IsSerialAreHeader(string? raw)
    {
        var c = Compact(raw);
        return c is "are" or "arenummer" or "arecode" or "arewert";
    }

    public string MergeKey(string? raw)
    {
        var normalized = Normalize(raw);
        return normalized.Replace(" ", "").Replace("_", "").Replace("-", "").Replace(".", "").Replace(":", "");
    }

    public static bool TryParseLtrg(object? value, out long result)
    {
        result = 0;
        if (value is null) return false;
        if (value is long l) { result = l; return true; }
        if (value is int i) { result = i; return true; }
        if (value is double d && !double.IsNaN(d) && !double.IsInfinity(d)) { result = Convert.ToInt64(Math.Round(d)); return true; }
        if (value is decimal m) { result = Convert.ToInt64(Math.Round(m)); return true; }

        var text = Convert.ToString(value, CultureInfo.CurrentCulture)?.Trim();
        if (string.IsNullOrWhiteSpace(text)) return false;
        if (long.TryParse(text, NumberStyles.Integer | NumberStyles.AllowThousands, CultureInfo.CurrentCulture, out result)) return true;
        if (double.TryParse(text, NumberStyles.Any, CultureInfo.CurrentCulture, out var local))
        {
            result = Convert.ToInt64(Math.Round(local));
            return true;
        }
        if (double.TryParse(text.Replace(',', '.'), NumberStyles.Any, CultureInfo.InvariantCulture, out var inv))
        {
            result = Convert.ToInt64(Math.Round(inv));
            return true;
        }
        return false;
    }
}
