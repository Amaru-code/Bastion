namespace ARE.Automatisierung.Services.Core;

public sealed class OfficePreflightService
{
    public void Validate(bool needsExcel, bool needsWord)
    {
        if (needsExcel && Type.GetTypeFromProgID("Excel.Application") is null)
            throw new InvalidOperationException("Microsoft Excel Desktop wurde nicht gefunden. Für die finale Excel-/ARE-PDF-Ausgabe wird Excel als unsichtbare Rendering-Schicht benötigt.");

        if (needsWord && Type.GetTypeFromProgID("Word.Application") is null)
            throw new InvalidOperationException("Microsoft Word Desktop wurde nicht gefunden. Für die Anschreiben wird Word als unsichtbare Rendering-Schicht benötigt.");
    }
}
