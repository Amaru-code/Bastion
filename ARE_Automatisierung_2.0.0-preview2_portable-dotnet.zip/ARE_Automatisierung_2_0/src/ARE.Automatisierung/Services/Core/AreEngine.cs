using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;

namespace ARE.Automatisierung.Services.Core;

public sealed class AreEngine(AppLogger logger)
{
    private const long CentralLtrg = 100;
    private const bool IncludeZeroOnReceiverSide = false;

    public IReadOnlyList<AreReport> BuildReports(SourceData source)
    {
        var targets = new SortedSet<long>();
        foreach (var t in source.Transfers)
        {
            if (t.LtrgNew == t.LtrgOld) continue;
            targets.Add(t.LtrgNew);
            targets.Add(t.LtrgOld);
        }
        if (targets.Count == 0) throw new InvalidOperationException("Es wurden keine tatsächlichen Übertritte zwischen unterschiedlichen LTRG gefunden.");

        var missing = targets.Where(x => !source.Companies.ContainsKey(x)).ToArray();
        if (missing.Length > 0)
            throw new InvalidOperationException("Für folgende LTRG fehlt die Zuordnung im Blatt 'Gesellschaften': " + string.Join(", ", missing.Select(FormatLtrg)));

        var reports = new List<AreReport>(targets.Count);
        foreach (var target in targets)
            reports.Add(BuildReport(source, target));

        logger.Info($"FACHLOGIK | {reports.Count} ARE-Berichte aufgebaut | LTRG: {string.Join(", ", targets.Select(FormatLtrg))}");
        return reports;
    }

    private static AreReport BuildReport(SourceData source, long target)
    {
        var groupRows = new Dictionary<long, List<AreRow>>();
        double net = 0;

        foreach (var t in source.Transfers)
        {
            if (t.LtrgNew == t.LtrgOld) continue;
            if (t.LtrgNew == target) net += t.Total;
            if (t.LtrgOld == target) net -= t.Total;

            if (t.LtrgNew == target && (Math.Abs(t.Total) > 0.0000001 || IncludeZeroOnReceiverSide))
                Add(groupRows, t.LtrgOld, ToRow(t, +1));
            if (t.LtrgOld == target)
                Add(groupRows, t.LtrgNew, ToRow(t, -1));
        }

        var groups = groupRows.Select(kvp => new AreGroup
        {
            Counterparty = source.Companies[kvp.Key]
        }).ToDictionary(x => x.Counterparty.Ltrg);

        foreach (var kvp in groupRows)
        {
            foreach (var row in kvp.Value.Where(x => x.Total > 0)) groups[kvp.Key].Rows.Add(row);
            foreach (var row in kvp.Value.Where(x => x.Total <= 0)) groups[kvp.Key].Rows.Add(row);
        }

        IEnumerable<AreGroup> ordered = groups.Values;
        ordered = target == CentralLtrg
            ? ordered.OrderBy(g => g.Counterparty.Ltrg)
            : ordered.OrderByDescending(g => g.HasPositive).ThenBy(g => g.Counterparty.Ltrg);

        var report = new AreReport
        {
            Target = source.Companies[target],
            ReportPeriod = source.ReportPeriod,
            NetBalance = net
        };
        report.Groups.AddRange(ordered);
        return report;
    }

    private static AreRow ToRow(TransferRecord t, int direction) => new(
        t.SourceRow,
        t.PnrNew,
        t.PnrOld,
        t.TransferDate,
        direction * t.Pension,
        direction * t.Bsav,
        direction * t.Total);

    private static void Add(Dictionary<long, List<AreRow>> groups, long counterparty, AreRow row)
    {
        if (!groups.TryGetValue(counterparty, out var list)) groups[counterparty] = list = [];
        list.Add(row);
    }

    public static string FormatLtrg(long value) => value < 10000 ? value.ToString("0000") : value.ToString();
}
