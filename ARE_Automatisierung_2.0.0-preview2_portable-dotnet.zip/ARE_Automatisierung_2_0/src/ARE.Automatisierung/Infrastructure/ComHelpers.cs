using System.Runtime.InteropServices;

namespace ARE.Automatisierung.Infrastructure;

public static class ComHelpers
{
    public static void FinalRelease(object? comObject)
    {
        if (comObject is null) return;
        try
        {
            if (Marshal.IsComObject(comObject)) Marshal.FinalReleaseComObject(comObject);
        }
        catch { }
    }
}
