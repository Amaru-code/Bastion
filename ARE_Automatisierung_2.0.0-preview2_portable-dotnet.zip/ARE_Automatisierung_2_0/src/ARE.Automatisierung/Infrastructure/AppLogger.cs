using System.Collections.Concurrent;
using System.Text;

namespace ARE.Automatisierung.Infrastructure;

public sealed class AppLogger
{
    private readonly ConcurrentQueue<string> _lines = new();
    public event Action<string>? LineWritten;
    public string? CurrentLogPath { get; private set; }

    public void StartRun(string folder)
    {
        Directory.CreateDirectory(folder);
        CurrentLogPath = Path.Combine(folder, "ARE_Automatisierung_Diagnose.log");
        File.WriteAllText(CurrentLogPath,
            $"ARE Automatisierung Diagnose{Environment.NewLine}Version: 2.0.0-preview2{Environment.NewLine}Start: {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}{new string('-', 80)}{Environment.NewLine}",
            Encoding.UTF8);
        Info("START | Version 2.0.0-preview2");
    }

    public void Info(string message) => Write("INFO", message);
    public void Warn(string message) => Write("WARNUNG", message);
    public void Error(string message) => Write("FEHLER", message);

    private void Write(string level, string message)
    {
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {level} | {message}";
        _lines.Enqueue(line);
        if (_lines.Count > 500) _lines.TryDequeue(out _);
        if (!string.IsNullOrWhiteSpace(CurrentLogPath))
        {
            try { File.AppendAllText(CurrentLogPath, line + Environment.NewLine, Encoding.UTF8); }
            catch { /* logging must never abort the run */ }
        }
        LineWritten?.Invoke(line);
    }
}
