namespace ARE.Automatisierung.Models;

public sealed record TransferRecord(
    int SourceRow,
    string PnrNew,
    long LtrgNew,
    string PnrOld,
    long LtrgOld,
    DateTime? TransferDate,
    double Bsav,
    double Pension,
    double Total);
