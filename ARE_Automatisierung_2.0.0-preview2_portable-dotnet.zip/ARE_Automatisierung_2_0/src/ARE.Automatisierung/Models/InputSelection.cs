namespace ARE.Automatisierung.Models;

public sealed record InputSelection(
    string AreSourcePath,
    string WordTemplatePath,
    string SerialDataPath,
    string OutputFolder,
    string? LogoPath,
    bool CreateExcelOutput = true,
    bool CreateArePdfs = true,
    bool CreateLetters = true,
    bool CreateAggregate = true);
