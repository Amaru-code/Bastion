namespace ARE.Automatisierung.Models;

public sealed class SourceData
{
    public required IReadOnlyList<TransferRecord> Transfers { get; init; }
    public required IReadOnlyDictionary<long, CompanyInfo> Companies { get; init; }
    public required string ReportPeriod { get; init; }
    public required int OverviewHeaderRow { get; init; }
    public required IReadOnlyDictionary<string, int> OverviewColumns { get; init; }
    public required int CompanyHeaderRow { get; init; }
    public required IReadOnlyDictionary<string, int> CompanyColumns { get; init; }
}
