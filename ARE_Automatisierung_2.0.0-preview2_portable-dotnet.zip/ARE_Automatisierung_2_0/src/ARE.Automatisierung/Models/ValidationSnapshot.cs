namespace ARE.Automatisierung.Models;

public sealed class PreviewItem
{
    public required long Ltrg { get; init; }
    public required string Are { get; init; }
    public required string Company { get; init; }
    public required int GroupCount { get; init; }
    public required int PositionCount { get; init; }
    public required double NetBalance { get; init; }
    public required int LetterCount { get; init; }
    public string LtrgText => Ltrg < 10000 ? Ltrg.ToString("0000") : Ltrg.ToString();
}

public sealed class ValidationSnapshot
{
    public required InputSelection Input { get; init; }
    public required SourceData Source { get; init; }
    public required IReadOnlyList<AreReport> Reports { get; init; }
    public required IReadOnlyList<SerialRecord> SerialRecords { get; init; }
    public required IReadOnlyList<SerialRecord> AffectedSerialRecords { get; init; }
    public required IReadOnlyList<PreviewItem> Preview { get; init; }
    public List<string> Warnings { get; } = [];
}
