namespace ARE.Automatisierung.Models;

public sealed record CompanyInfo(long Ltrg, string Are, string Name)
{
    public string ShortName
    {
        get
        {
            var text = Name.Trim();
            var comma = text.IndexOf(',');
            return comma > 0 ? text[..comma].Trim() : text;
        }
    }
    public string LtrgText => Ltrg < 10000 ? Ltrg.ToString("0000") : Ltrg.ToString();
}
