namespace ARE.Automatisierung.Models;

public sealed record RunProgress(double Percent, string Stage, string? Detail = null);

public sealed class RunResult
{
    public required string RunFolder { get; init; }
    public required string ExcelOutputPath { get; init; }
    public required IReadOnlyList<string> ArePdfPaths { get; init; }
    public required IReadOnlyList<string> IndividualDocxPaths { get; init; }
    public required IReadOnlyList<string> IndividualPdfPaths { get; init; }
    public string? AggregateDocxPath { get; init; }
    public string? AggregatePdfPath { get; init; }
}
