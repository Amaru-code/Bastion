namespace ARE.Automatisierung.Models;

public sealed class SerialRecord
{
    public required int SourceRow { get; init; }
    public required IReadOnlyDictionary<string, string> Values { get; init; }
    public long? Ltrg { get; init; }
    public string Are { get; init; } = "";
}
