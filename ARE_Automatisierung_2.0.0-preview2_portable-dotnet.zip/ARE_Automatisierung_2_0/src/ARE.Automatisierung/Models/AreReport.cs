namespace ARE.Automatisierung.Models;

public sealed record AreRow(
    int SourceRow,
    string Pnr,
    string OldPnr,
    DateTime? TransferDate,
    double Pension,
    double Bsav,
    double Total);

public sealed class AreGroup
{
    public required CompanyInfo Counterparty { get; init; }
    public List<AreRow> Rows { get; } = [];
    public double PensionSubtotal => Rows.Sum(x => x.Pension);
    public double BsavSubtotal => Rows.Sum(x => x.Bsav);
    public double TotalSubtotal => Rows.Sum(x => x.Total);
    public bool HasPositive => Rows.Any(x => x.Total > 0);
}

public sealed class AreReport
{
    public required CompanyInfo Target { get; init; }
    public required string ReportPeriod { get; init; }
    public List<AreGroup> Groups { get; } = [];
    public double NetBalance { get; init; }
    public double DisplayedBalance => Groups.Sum(g => g.TotalSubtotal);
    public double ControlDelta => NetBalance - DisplayedBalance;
    public int PositionCount => Groups.Sum(g => g.Rows.Count);
    public string SheetName => BuildSheetName(Target);

    private static string BuildSheetName(CompanyInfo company)
    {
        var name = $"ARE {(string.IsNullOrWhiteSpace(company.Are) ? "n.v." : company.Are)} (LTRG {company.LtrgText})";
        foreach (var c in new[] { '\\', '/', ':', '*', '?', '[', ']' }) name = name.Replace(c, '-');
        return name.Length <= 31 ? name : name[..31];
    }
}
