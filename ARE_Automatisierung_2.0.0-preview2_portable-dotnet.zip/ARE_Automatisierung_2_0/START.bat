@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0

set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
set "DOTNET_CMD="

rem 1) Bereits publizierte Self-Contained-Version bevorzugen.
if exist "%~dp0publish\ARE.Automatisierung.exe" (
    start "" "%~dp0publish\ARE.Automatisierung.exe"
    exit /b 0
)

rem 2) Bereits lokal gebaute Release-Version starten.
if exist "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe" (
    start "" "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe"
    exit /b 0
)

rem 3) Portables SDK im Projekt verwenden, wenn vorhanden.
if exist "%~dp0tools\dotnet\dotnet.exe" (
    "%~dp0tools\dotnet\dotnet.exe" --list-sdks | findstr /R /B "10\." >nul 2>&1
    if not errorlevel 1 set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
)

rem 4) Sonst systemweit installiertes .NET 10 SDK verwenden.
if not defined DOTNET_CMD (
    where dotnet.exe >nul 2>&1
    if not errorlevel 1 (
        dotnet --list-sdks | findstr /R /B "10\." >nul 2>&1
        if not errorlevel 1 set "DOTNET_CMD=dotnet"
    )
)

rem 5) Kein SDK vorhanden: portable Installation automatisch versuchen.
if not defined DOTNET_CMD (
    echo ============================================================
    echo  Kein .NET 10 SDK gefunden
    echo ============================================================
    echo.
    echo Das Projekt kann das offizielle Microsoft .NET 10 SDK
    echo lokal in tools\dotnet installieren. Keine Adminrechte noetig.
    echo.
    echo Starte portables SDK-Setup ...
    echo.
    call "%~dp0INSTALL_DOTNET10_PORTABLE.bat"
    if errorlevel 1 goto :NO_SDK

    if exist "%~dp0tools\dotnet\dotnet.exe" (
        "%~dp0tools\dotnet\dotnet.exe" --list-sdks | findstr /R /B "10\." >nul 2>&1
        if not errorlevel 1 set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
    )
)

if not defined DOTNET_CMD goto :NO_SDK

set "DOTNET_ROOT=%~dp0tools\dotnet"
if /I "%DOTNET_CMD%"=="dotnet" set "DOTNET_ROOT="

if defined DOTNET_ROOT set "PATH=%DOTNET_ROOT%;%PATH%"

 echo ============================================================
 echo  ARE Automatisierung 2.0 - erster Build
 echo ============================================================
 echo.
 echo SDK:
 "%DOTNET_CMD%" --version
 echo.
 echo Es wurde noch keine kompilierte Version gefunden.
 echo Das Projekt wird einmalig in Release gebaut.
 echo.

"%DOTNET_CMD%" restore "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj"
if errorlevel 1 goto :RESTORE_ERROR

"%DOTNET_CMD%" build "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" -c Release --no-restore
if errorlevel 1 goto :BUILD_ERROR

start "" "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe"
exit /b 0

:NO_SDK
echo.
echo FEHLER: Das .NET 10 SDK konnte nicht bereitgestellt werden.
echo.
echo Manuelle Alternative:
echo 1. dotnet-sdk-10.0.400-win-x64.zip von Microsoft herunterladen.
echo 2. Die ZIP direkt in diesen Projektordner legen.
echo 3. INSTALL_DOTNET10_PORTABLE.bat starten.
echo 4. Danach START.bat erneut starten.
echo.
echo Direkter Microsoft-Link:
echo https://builds.dotnet.microsoft.com/dotnet/Sdk/10.0.400/dotnet-sdk-10.0.400-win-x64.zip
echo.
pause
exit /b 1

:RESTORE_ERROR
echo.
echo FEHLER: NuGet-Pakete konnten nicht wiederhergestellt werden.
echo In einer Unternehmensumgebung kann dafuer ein interner Artifactory-/NuGet-Feed erforderlich sein.
echo Siehe docs\04_NuGet_und_Artifactory.md
echo.
pause
exit /b 1

:BUILD_ERROR
echo.
echo FEHLER: Das Projekt konnte nicht kompiliert werden.
echo.
pause
exit /b 1
