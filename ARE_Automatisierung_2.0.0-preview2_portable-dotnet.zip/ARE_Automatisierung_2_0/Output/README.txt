Dieser Ordner ist der Standard-Ausgabeordner der ARE Automatisierung 2.0.
Jeder Lauf erhält einen eigenen Zeitstempel-Unterordner.
