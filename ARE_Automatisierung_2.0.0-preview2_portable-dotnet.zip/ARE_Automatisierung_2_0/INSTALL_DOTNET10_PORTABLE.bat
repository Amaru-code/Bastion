@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0 - .NET 10 Portable Setup

set "POWERSHELL=powershell.exe"
where %POWERSHELL% >nul 2>&1
if errorlevel 1 (
    echo FEHLER: Windows PowerShell wurde nicht gefunden.
    echo.
    echo Bitte die offizielle Datei
    echo dotnet-sdk-10.0.400-win-x64.zip
    echo herunterladen und entpacken nach:
    echo %~dp0tools\dotnet
    echo.
    pause
    exit /b 1
)

%POWERSHELL% -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0tools\install-dotnet10-portable.ps1"
set "RC=%ERRORLEVEL%"
if not "%RC%"=="0" (
    echo.
    echo Das portable .NET-Setup ist fehlgeschlagen.
    echo Siehe die Meldung oben.
    pause
)
exit /b %RC%
