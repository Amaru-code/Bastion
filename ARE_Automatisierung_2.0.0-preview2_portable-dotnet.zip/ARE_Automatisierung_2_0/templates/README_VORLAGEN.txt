ARE Automatisierung 2.0

Die Word-Serienbriefvorlage wird pro Lauf in der Oberfläche ausgewählt.
Ein Mercer-Logo kann ebenfalls vorab ausgewählt werden (PNG/JPG/JPEG).

Die alte Datei ARE_Uebersicht_Template.xlsx wird in v2.0.0-preview2 noch nicht als
Formatvorlage eingelesen. Das ARE-Layout ist aktuell als klar definierter C#-Renderer
implementiert. Die Architektur ist so getrennt, dass ein Template-Provider später
wieder ergänzt werden kann, ohne die Fachlogik zu verändern.
