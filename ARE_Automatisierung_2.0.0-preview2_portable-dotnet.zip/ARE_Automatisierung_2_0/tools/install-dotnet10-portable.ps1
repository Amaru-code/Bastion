$ErrorActionPreference = 'Stop'

$SdkVersion = '10.0.400'
$FileName = "dotnet-sdk-$SdkVersion-win-x64.zip"
$DownloadUrl = "https://builds.dotnet.microsoft.com/dotnet/Sdk/$SdkVersion/$FileName"
$ExpectedSha512 = '9b8b88590e4da131bfd0da7aa089d0fc04d5418d5f8607ec13d55dc5a17b4399afd54d496c12657fa05c6c6546dc5eab930f26ac6c50f2d3a7712c0fb378c366'

$ProjectRoot = Split-Path -Parent $PSScriptRoot
$DotnetDir = Join-Path $PSScriptRoot 'dotnet'
$ZipAtRoot = Join-Path $ProjectRoot $FileName
$CacheDir = Join-Path $PSScriptRoot '.cache'
$ZipInCache = Join-Path $CacheDir $FileName

Write-Host '============================================================'
Write-Host ' ARE Automatisierung 2.0 - .NET 10 Portable Setup'
Write-Host '============================================================'
Write-Host ''
Write-Host "SDK:       $SdkVersion"
Write-Host "Ziel:      $DotnetDir"
Write-Host 'Installation: lokal/portable, keine Adminrechte erforderlich'
Write-Host ''

$ExistingDotnet = Join-Path $DotnetDir 'dotnet.exe'
if (Test-Path $ExistingDotnet) {
    $sdks = & $ExistingDotnet --list-sdks 2>$null
    if ($LASTEXITCODE -eq 0 -and ($sdks -match '^10\.')) {
        Write-Host 'Ein lokales .NET 10 SDK ist bereits vorhanden.'
        & $ExistingDotnet --version
        exit 0
    }
}

New-Item -ItemType Directory -Force -Path $CacheDir | Out-Null

if (Test-Path $ZipAtRoot) {
    $ZipPath = $ZipAtRoot
    Write-Host "Lokale SDK-ZIP gefunden: $ZipPath"
} elseif (Test-Path $ZipInCache) {
    $ZipPath = $ZipInCache
    Write-Host "Bereits heruntergeladene SDK-ZIP gefunden: $ZipPath"
} else {
    $ZipPath = $ZipInCache
    Write-Host 'Lade das offizielle Microsoft .NET 10 SDK herunter ...'
    Write-Host $DownloadUrl
    Write-Host ''
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -UseBasicParsing -Uri $DownloadUrl -OutFile $ZipPath
    } catch {
        Write-Host ''
        Write-Host 'FEHLER: Der Download wurde vom Netzwerk/Proxy blockiert.' -ForegroundColor Red
        Write-Host ''
        Write-Host 'Alternative:'
        Write-Host "1. Lade $FileName manuell von Microsoft herunter."
        Write-Host "2. Lege die ZIP direkt hier ab: $ProjectRoot"
        Write-Host '3. Starte INSTALL_DOTNET10_PORTABLE.bat erneut.'
        Write-Host ''
        Write-Host "Direktlink: $DownloadUrl"
        throw
    }
}

Write-Host 'Pruefe SHA512 ...'
$ActualHash = (Get-FileHash -Path $ZipPath -Algorithm SHA512).Hash.ToLowerInvariant()
if ($ActualHash -ne $ExpectedSha512) {
    throw "SHA512 stimmt nicht. Erwartet: $ExpectedSha512 / Ist: $ActualHash"
}
Write-Host 'SHA512 korrekt.'

if (Test-Path $DotnetDir) {
    Remove-Item -Recurse -Force $DotnetDir
}
New-Item -ItemType Directory -Force -Path $DotnetDir | Out-Null

Write-Host 'Entpacke SDK ...'
Expand-Archive -LiteralPath $ZipPath -DestinationPath $DotnetDir -Force

$DotnetExe = Join-Path $DotnetDir 'dotnet.exe'
if (-not (Test-Path $DotnetExe)) {
    throw "dotnet.exe wurde nach dem Entpacken nicht gefunden: $DotnetExe"
}

$sdks = & $DotnetExe --list-sdks
if ($LASTEXITCODE -ne 0 -or -not ($sdks -match '^10\.')) {
    throw 'Das entpackte SDK konnte nicht erfolgreich verifiziert werden.'
}

Write-Host ''
Write-Host '============================================================'
Write-Host ' .NET 10 SDK portable ist bereit.'
Write-Host '============================================================'
& $DotnetExe --version
Write-Host ''
Write-Host 'Du kannst jetzt START.bat ausfuehren.'

# Eine automatisch geladene Cache-ZIP wird nach erfolgreicher Installation entfernt.
# Eine manuell in den Projektordner gelegte ZIP bleibt unangetastet.
if ($ZipPath -eq $ZipInCache -and (Test-Path $ZipInCache)) {
    Remove-Item -Force $ZipInCache -ErrorAction SilentlyContinue
}
exit 0
