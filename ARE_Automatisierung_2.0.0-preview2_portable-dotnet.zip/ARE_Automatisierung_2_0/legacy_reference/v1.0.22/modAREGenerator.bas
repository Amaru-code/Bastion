Attribute VB_Name = "modAREGenerator"
Option Explicit

' Version 1.0.22 - direkter Excel-Modus.
' Der vollst�ndige Serienbrief-/Vorlagenworkflow l�uft �ber ARE_Generator_starten.vbs.

Private Const SHEET_OVERVIEW As String = "�bersicht"
Private Const SHEET_COMPANIES As String = "Gesellschaften"
Private Const GENERATED_PREFIX As String = "ARE "
Private Const FIRST_DATA_ROW As Long = 3
Private Const HEADER_SCAN_MAX_ROWS As Long = 30
Private Const HEADER_SCAN_MAX_COLUMNS As Long = 100
Private Const CENTRAL_LTRG As Long = 100

' Entspricht dem gelieferten Final-Beispiel:
' Ein �bertritt mit Summe 0 wird auf der Empf�ngerseite nicht dargestellt,
' auf der Abgeberseite aber weiterhin ber�cksichtigt.
Private Const INCLUDE_ZERO_ON_RECEIVER_SIDE As Boolean = False

Public Sub Erstelle_ARE_Blaetter()

    Dim wb As Workbook
    Dim wsOverview As Worksheet
    Dim wsCompanies As Worksheet
    Dim overviewLayout As Object
    Dim companyLayout As Object
    Dim companies As Object
    Dim targetLtrgs As Object
    Dim transferData As Variant
    Dim targetKeys As Variant
    Dim lastTransferRow As Long
    Dim firstTransferRow As Long
    Dim i As Long
    Dim oldCalculation As XlCalculation
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim errorDescription As String

    Set wb = ThisWorkbook

    oldCalculation = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts

    On Error GoTo Fehler

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "ARE-Bl�tter werden vorbereitet ..."

    Set wsOverview = GetWorksheetOrNothing(wb, SHEET_OVERVIEW)
    Set wsCompanies = GetWorksheetOrNothing(wb, SHEET_COMPANIES)

    If wsOverview Is Nothing Then
        Err.Raise vbObjectError + 1000, , _
                  "Das Blatt '" & SHEET_OVERVIEW & "' wurde nicht gefunden."
    End If

    If wsCompanies Is Nothing Then
        Err.Raise vbObjectError + 1001, , _
                  "Das Blatt '" & SHEET_COMPANIES & "' wurde nicht gefunden."
    End If

    Set overviewLayout = DiscoverOverviewLayout(wsOverview)
    firstTransferRow = CLng(overviewLayout("_header_row")) + 1

    lastTransferRow = LastTransferRow(wsOverview, overviewLayout, firstTransferRow)
    If lastTransferRow < firstTransferRow Then
        Err.Raise vbObjectError + 1002, , _
                  "Im Blatt '" & wsOverview.Name & "' wurden unterhalb der erkannten Kopfzeile keine �bertritte gefunden."
    End If

    transferData = LoadTransferDataDynamic(wsOverview, overviewLayout, firstTransferRow, lastTransferRow)

    Set companyLayout = DiscoverCompanyLayout(wsCompanies)
    Set companies = LoadCompanies(wsCompanies, companyLayout)
    Set targetLtrgs = BuildTargetLtrgs(transferData)

    ValidateCompanyAssignments targetLtrgs, companies

    DeleteGeneratedSheets wb

    targetKeys = targetLtrgs.Keys
    SortNumericKeys targetKeys

    For i = LBound(targetKeys) To UBound(targetKeys)
        Application.StatusBar = _
            "ARE-Blatt f�r LTRG " & FormatLtrg(CLng(targetKeys(i))) & " wird erstellt ..."
        CreateARESheet wb, wsOverview, overviewLayout, companies, transferData, CLng(targetKeys(i))
    Next i

    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull

    Application.StatusBar = False
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.Calculation = oldCalculation

    MsgBox targetLtrgs.Count & _
           " ARE-Bl�tter wurden erfolgreich erstellt." & vbCrLf & vbCrLf & _
           "Die Bl�tter '" & SHEET_OVERVIEW & "', 'CHECK' und '" & _
           SHEET_COMPANIES & "' wurden nicht ver�ndert.", _
           vbInformation, "ARE-Auswertung fertig"

    Exit Sub

Fehler:
    errorDescription = Err.Description
    On Error Resume Next
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.Calculation = oldCalculation
    On Error GoTo 0

    MsgBox "Die ARE-Bl�tter konnten nicht erstellt werden." & vbCrLf & vbCrLf & _
           "Fehler: " & errorDescription, _
           vbCritical, "ARE-Auswertung"
End Sub

Public Sub Loesche_ARE_Blaetter()
    Dim oldDisplayAlerts As Boolean
    Dim errorDescription As String

    oldDisplayAlerts = Application.DisplayAlerts
    On Error GoTo Fehler

    Application.DisplayAlerts = False
    DeleteGeneratedSheets ThisWorkbook
    Application.DisplayAlerts = oldDisplayAlerts

    MsgBox "Alle automatisch erzeugten ARE-Bl�tter wurden gel�scht.", _
           vbInformation, "ARE-Auswertung"
    Exit Sub

Fehler:
    errorDescription = Err.Description
    Application.DisplayAlerts = oldDisplayAlerts
    MsgBox "Die ARE-Bl�tter konnten nicht gel�scht werden." & vbCrLf & _
           errorDescription, vbCritical, "ARE-Auswertung"
End Sub

Public Sub Exportiere_ARE_Blaetter_Als_PDF()
    Const msoFileDialogFolderPicker As Long = 4
    Const xlTypePDF As Long = 0
    Const xlQualityStandard As Long = 0

    Dim dialog As FileDialog
    Dim folderPath As String
    Dim ws As Worksheet
    Dim pdfPath As String
    Dim exportCount As Long
    Dim oldScreenUpdating As Boolean
    Dim errorDescription As String

    oldScreenUpdating = Application.ScreenUpdating
    On Error GoTo Fehler

    Set dialog = Application.FileDialog(msoFileDialogFolderPicker)
    With dialog
        .Title = "Ordner f�r die ARE-PDF-Dateien ausw�hlen"
        .AllowMultiSelect = False
        If .Show <> -1 Then Exit Sub
        folderPath = .SelectedItems(1)
    End With

    If Right$(folderPath, 1) <> Application.PathSeparator Then
        folderPath = folderPath & Application.PathSeparator
    End If

    Application.ScreenUpdating = False

    For Each ws In ThisWorkbook.Worksheets
        If Left$(ws.Name, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, ws.Name, "(LTRG ", vbTextCompare) > 0 Then

            pdfPath = UniqueVbaFilePath( _
                folderPath, _
                "ERG_VW�_" & SanitizeVbaFileName(ws.Name), _
                "pdf" _
            )

            ws.ExportAsFixedFormat _
                Type:=xlTypePDF, _
                Filename:=pdfPath, _
                Quality:=xlQualityStandard, _
                IncludeDocProperties:=True, _
                IgnorePrintAreas:=False, _
                OpenAfterPublish:=False

            exportCount = exportCount + 1
        End If
    Next ws

    Application.ScreenUpdating = oldScreenUpdating

    MsgBox exportCount & " ARE-Bl�tter wurden als einzelne PDF-Dateien exportiert.", _
           vbInformation, "ARE-PDF-Export"
    Exit Sub

Fehler:
    errorDescription = Err.Description
    Application.ScreenUpdating = oldScreenUpdating
    MsgBox "Die ARE-PDF-Dateien konnten nicht vollst�ndig erstellt werden." & _
           vbCrLf & vbCrLf & errorDescription, vbCritical, "ARE-PDF-Export"
End Sub

Private Sub CreateARESheet(ByVal wb As Workbook, _
                           ByVal wsOverview As Worksheet, _
                           ByVal overviewLayout As Object, _
                           ByVal companies As Object, _
                           ByRef transferData As Variant, _
                           ByVal targetLtrg As Long)

    Dim ws As Worksheet
    Dim groups As Object
    Dim targetInfo As Variant
    Dim counterpartyInfo As Variant
    Dim groupKeys As Variant
    Dim rowsInGroup As Collection
    Dim descriptor As Variant
    Dim targetKey As String
    Dim counterpartyKey As String
    Dim targetName As String
    Dim targetShortName As String
    Dim sheetName As String
    Dim newLtrg As Long
    Dim oldLtrg As Long
    Dim rowIndex As Long
    Dim sourceIndex As Long
    Dim direction As Long
    Dim signedPension As Double
    Dim signedBsav As Double
    Dim signedTotal As Double
    Dim currentRow As Long
    Dim sectionRow As Long
    Dim headerRow As Long
    Dim dataStartRow As Long
    Dim dataEndRow As Long
    Dim subtotalRow As Long
    Dim subtotalRefs As String
    Dim pass As Long
    Dim i As Long
    Dim j As Long
    Dim amount As Double
    Dim shouldWrite As Boolean
    Dim overviewNameEscaped As String
    Dim ltrgNewLetter As String
    Dim ltrgOldLetter As String
    Dim totalLetter As String
    Dim bsavLetter As String
    Dim pensionLetter As String

    targetKey = CStr(targetLtrg)
    targetInfo = companies(targetKey)
    targetName = CStr(targetInfo(1))
    targetShortName = ShortCompanyName(targetName)

    sheetName = BuildSheetName(targetLtrg, targetInfo(0))
    If wb.ProtectStructure Then
        Err.Raise vbObjectError + 2030, "ARE Generator", _
                  "Die Struktur der Arbeitsmappe ist gesch�tzt. " & _
                  "Bitte den Strukturschutz aufheben und das Makro erneut starten."
    End If

    Set ws = wb.Worksheets.Add
    On Error Resume Next
    ws.Move After:=wb.Worksheets(wb.Worksheets.Count)
    On Error GoTo 0
    ws.Name = sheetName

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = vbTextCompare

    For i = LBound(transferData, 1) To UBound(transferData, 1)

        If TryGetLong(transferData(i, 2), newLtrg) And _
           TryGetLong(transferData(i, 4), oldLtrg) Then

            If newLtrg <> oldLtrg Then
                amount = NzNumber(transferData(i, 10))

                If newLtrg = targetLtrg Then
                    If amount <> 0 Or INCLUDE_ZERO_ON_RECEIVER_SIDE Then
                        AddGroupRecord groups, CStr(oldLtrg), i, 1
                    End If
                End If

                If oldLtrg = targetLtrg Then
                    AddGroupRecord groups, CStr(newLtrg), i, -1
                End If
            End If
        End If
    Next i

    ' Berichtskopf. A1:B2 bleibt f�r das Mercer-Logo reserviert.
    ws.Range("E1:F1").Merge
    ws.Range("E2:F2").Merge
    ws.Range("A4:F4").Merge
    ws.Range("A6:F6").Merge
    ws.Range("A7:F7").Merge

    ws.Range("E1").Value = "Einzel�bertritte " & BuildVbaReportPeriod(wb.Name)
    ws.Range("E2").Value = "ARE " & DisplayValue(targetInfo(0)) & _
                           " (LTRG " & FormatLtrg(targetLtrg) & ")"
    ws.Range("A4").Value = "�bertragene R�ckstellungen bei Einzel�bertritten"
    ws.Range("A6").Value = _
        "Positive Betr�ge erh�lt die " & targetShortName & _
        " von der genannten Gesellschaft,"
    ws.Range("A7").Value = _
        "negative Betr�ge gibt die " & targetShortName & _
        " an die genannte Gesellschaft ab."

    ws.Range("H1").Value = "CHECK"
    ws.Range("I1").Value = "ORZ, OK"
    ws.Range("H2").Value = targetLtrg
    ws.Range("I2").Value = targetInfo(0)
    ws.Range("J2").Value = targetName
    ws.Range("H3").Value = "CHECK"

    overviewNameEscaped = Replace(wsOverview.Name, "'", "''")
    ltrgNewLetter = ExcelColumnLetter(CLng(overviewLayout("ltrg_new")))
    ltrgOldLetter = ExcelColumnLetter(CLng(overviewLayout("ltrg_old")))

    If overviewLayout.Exists("total") Then
        totalLetter = ExcelColumnLetter(CLng(overviewLayout("total")))
        ws.Range("H4").Formula = _
            "=SUMIFS('" & overviewNameEscaped & "'!$" & totalLetter & ":$" & totalLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & totalLetter & ":$" & totalLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)"
    Else
        bsavLetter = ExcelColumnLetter(CLng(overviewLayout("bsav")))
        pensionLetter = ExcelColumnLetter(CLng(overviewLayout("pension")))
        ws.Range("H4").Formula = _
            "=SUMIFS('" & overviewNameEscaped & "'!$" & bsavLetter & ":$" & bsavLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)+" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & pensionLetter & ":$" & pensionLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgNewLetter & ":$" & ltrgNewLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & bsavLetter & ":$" & bsavLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)-" & _
            "SUMIFS('" & overviewNameEscaped & "'!$" & pensionLetter & ":$" & pensionLetter & "," & _
            "'" & overviewNameEscaped & "'!$" & ltrgOldLetter & ":$" & ltrgOldLetter & ",$H$2)"
    End If

    currentRow = 10

    If groups.Count > 0 Then
        groupKeys = groups.Keys
        SortGroupKeys groupKeys, groups, transferData, targetLtrg

        For i = LBound(groupKeys) To UBound(groupKeys)

            counterpartyKey = CStr(groupKeys(i))
            counterpartyInfo = companies(counterpartyKey)
            Set rowsInGroup = groups(counterpartyKey)

            sectionRow = currentRow
            headerRow = sectionRow + 1
            dataStartRow = headerRow + 1

            ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
            ws.Cells(sectionRow, 1).Value = _
                ShortCompanyName(CStr(counterpartyInfo(1))) & _
                " (ARE " & DisplayValue(counterpartyInfo(0)) & _
                ", LTRG " & FormatLtrg(CLng(counterpartyKey)) & ")"

            ws.Cells(sectionRow, 8).Value = CLng(counterpartyKey)
            ws.Cells(sectionRow, 9).Value = counterpartyInfo(0)
            ws.Cells(sectionRow, 10).Value = CStr(counterpartyInfo(1))

            ws.Cells(headerRow, 1).Value = "PNR" & vbLf
            ws.Cells(headerRow, 2).Value = "alte PNR" & vbLf
            ws.Cells(headerRow, 3).Value = "�bertritt" & vbLf
            ws.Cells(headerRow, 4).Value = "Pensionen (alt)" & vbLf & "(Euro)"
            ws.Cells(headerRow, 5).Value = "BSAV" & vbLf & "(Euro)"
            ws.Cells(headerRow, 6).Value = "Summe" & vbLf & "(Euro)"

            currentRow = dataStartRow

            ' Positive Positionen zuerst, anschlie�end negative bzw. Nullpositionen.
            For pass = 1 To 2
                For j = 1 To rowsInGroup.Count

                    descriptor = rowsInGroup.Item(j)
                    sourceIndex = CLng(descriptor(0))
                    direction = CLng(descriptor(1))
                    signedTotal = direction * NzNumber(transferData(sourceIndex, 10))

                    shouldWrite = _
                        (pass = 1 And signedTotal > 0) Or _
                        (pass = 2 And signedTotal <= 0)

                    If shouldWrite Then
                        signedPension = direction * NzNumber(transferData(sourceIndex, 9))
                        signedBsav = direction * NzNumber(transferData(sourceIndex, 8))

                        ws.Cells(currentRow, 1).Value = transferData(sourceIndex, 1)
                        ws.Cells(currentRow, 2).Value = transferData(sourceIndex, 3)
                        ws.Cells(currentRow, 3).Value = transferData(sourceIndex, 5)
                        ws.Cells(currentRow, 4).Value = signedPension
                        ws.Cells(currentRow, 5).Value = signedBsav
                        ws.Cells(currentRow, 6).Value = signedTotal

                        currentRow = currentRow + 1
                    End If
                Next j
            Next pass

            dataEndRow = currentRow - 1
            subtotalRow = currentRow

            ws.Cells(subtotalRow, 4).Formula = _
                "=SUM(D" & dataStartRow & ":D" & dataEndRow & ")"
            ws.Cells(subtotalRow, 5).Formula = _
                "=SUM(E" & dataStartRow & ":E" & dataEndRow & ")"
            ws.Cells(subtotalRow, 6).Formula = _
                "=SUM(F" & dataStartRow & ":F" & dataEndRow & ")"

            subtotalRefs = subtotalRefs & "," & _
                           ws.Cells(subtotalRow, 6).Address(False, False)

            FormatSection ws, sectionRow, headerRow, _
                          dataStartRow, dataEndRow, subtotalRow

            currentRow = subtotalRow + 2
        Next i
    End If

    If Len(subtotalRefs) > 0 Then
        ws.Range("I4").Formula = _
            "=H4-SUM(" & Mid$(subtotalRefs, 2) & ")"
    Else
        ws.Range("I4").Formula = "=H4"
    End If

    FormatARESheet ws, currentRow - 1
End Sub

Private Function LoadCompanies(ByVal ws As Worksheet, _
                               ByVal layout As Object) As Object
    Dim dict As Object
    Dim lastRow As Long
    Dim firstDataRow As Long
    Dim r As Long
    Dim ltrg As Long
    Dim companyName As String
    Dim areValue As Variant
    Dim existingInfo As Variant
    Dim key As String

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    firstDataRow = CLng(layout("_header_row")) + 1
    lastRow = LastCompanyRow(ws, layout, firstDataRow)

    For r = firstDataRow To lastRow
        If TryGetLong(ws.Cells(r, CLng(layout("ltrg"))).Value2, ltrg) Then
            companyName = SafeStringVba(ws.Cells(r, CLng(layout("name"))).Value2)
            areValue = ws.Cells(r, CLng(layout("are"))).Value2

            If Len(Trim$(companyName)) > 0 Then
                key = CStr(ltrg)
                If dict.Exists(key) Then
                    existingInfo = dict(key)
                    If IsBlankValueVba(areValue) Then areValue = existingInfo(0)
                End If
                dict(key) = Array(areValue, companyName)
            End If
        End If
    Next r

    If dict.Count = 0 Then
        Err.Raise vbObjectError + 1010, , _
                  "Im Blatt '" & ws.Name & "' wurden keine Gesellschaften gefunden. " & _
                  "Erwartet werden LTRG, ARE und Name � unabh�ngig von ihrer Position."
    End If

    Set LoadCompanies = dict
End Function

Private Function BuildTargetLtrgs(ByRef transferData As Variant) As Object
    Dim dict As Object
    Dim i As Long
    Dim newLtrg As Long
    Dim oldLtrg As Long
    Dim validNew As Boolean
    Dim validOld As Boolean

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    For i = LBound(transferData, 1) To UBound(transferData, 1)
        validNew = TryGetLong(transferData(i, 2), newLtrg)
        validOld = TryGetLong(transferData(i, 4), oldLtrg)

        If validNew And validOld Then
            If newLtrg <> oldLtrg Then
                dict(CStr(newLtrg)) = True
                dict(CStr(oldLtrg)) = True
            End If
        End If
    Next i

    Set BuildTargetLtrgs = dict
End Function

Private Sub ValidateCompanyAssignments(ByVal targetLtrgs As Object, _
                                       ByVal companies As Object)
    Dim key As Variant
    Dim missing As String

    For Each key In targetLtrgs.Keys
        If Not companies.Exists(CStr(key)) Then
            missing = missing & vbCrLf & "� LTRG " & FormatLtrg(CLng(key))
        End If
    Next key

    If Len(missing) > 0 Then
        Err.Raise vbObjectError + 1011, , _
                  "F�r folgende LTRG fehlt eine Zuordnung im Blatt '" & _
                  SHEET_COMPANIES & "':" & missing
    End If
End Sub

Private Sub AddGroupRecord(ByVal groups As Object, _
                           ByVal counterpartyKey As String, _
                           ByVal sourceIndex As Long, _
                           ByVal direction As Long)
    Dim rowsInGroup As Collection

    If Not groups.Exists(counterpartyKey) Then
        Set rowsInGroup = New Collection
        groups.Add counterpartyKey, rowsInGroup
    Else
        Set rowsInGroup = groups(counterpartyKey)
    End If

    rowsInGroup.Add Array(sourceIndex, direction)
End Sub

Private Sub SortGroupKeys(ByRef keys As Variant, _
                          ByVal groups As Object, _
                          ByRef transferData As Variant, _
                          ByVal targetLtrg As Long)
    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If GroupKeyComesAfter(CStr(keys(i)), CStr(keys(j)), _
                                  groups, transferData, targetLtrg) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Function GroupKeyComesAfter(ByVal firstKey As String, _
                                    ByVal secondKey As String, _
                                    ByVal groups As Object, _
                                    ByRef transferData As Variant, _
                                    ByVal targetLtrg As Long) As Boolean
    Dim firstHasPositive As Boolean
    Dim secondHasPositive As Boolean
    Dim firstRows As Collection
    Dim secondRows As Collection

    ' Das gelieferte Final-Beispiel sortiert das zentrale Blatt LTRG 0100
    ' rein nach LTRG. Bei den �brigen Bl�ttern stehen positive Gruppen zuerst.
    If targetLtrg = CENTRAL_LTRG Then
        GroupKeyComesAfter = CLng(firstKey) > CLng(secondKey)
        Exit Function
    End If

    Set firstRows = groups(firstKey)
    Set secondRows = groups(secondKey)

    firstHasPositive = GroupHasPositive(firstRows, transferData)
    secondHasPositive = GroupHasPositive(secondRows, transferData)

    If firstHasPositive <> secondHasPositive Then
        GroupKeyComesAfter = (Not firstHasPositive And secondHasPositive)
    Else
        GroupKeyComesAfter = CLng(firstKey) > CLng(secondKey)
    End If
End Function

Private Function GroupHasPositive(ByVal rowsInGroup As Collection, _
                                  ByRef transferData As Variant) As Boolean
    Dim descriptor As Variant
    Dim i As Long
    Dim sourceIndex As Long
    Dim direction As Long

    For i = 1 To rowsInGroup.Count
        descriptor = rowsInGroup.Item(i)
        sourceIndex = CLng(descriptor(0))
        direction = CLng(descriptor(1))

        If direction * NzNumber(transferData(sourceIndex, 10)) > 0 Then
            GroupHasPositive = True
            Exit Function
        End If
    Next i
End Function

Private Sub SortNumericKeys(ByRef keys As Variant)
    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If CLng(keys(i)) > CLng(keys(j)) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Sub FormatARESheet(ByVal ws As Worksheet, ByVal lastContentRow As Long)

    Dim maxRow As Long

    maxRow = Application.Max(lastContentRow, 7)

    With ws.Cells
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlNone
    End With

    With ws.Range("E1:F2")
        .Font.Size = 10
        .Font.Bold = False
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(1).RowHeight = 24
    ws.Rows(2).RowHeight = 20

    With ws.Range("A4:F4")
        .Font.Bold = True
        .Font.Size = 15
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(4).RowHeight = 24

    With ws.Range("A6:F7")
        .Font.Size = 10
        .Font.Bold = False
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .WrapText = False
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(6).RowHeight = 16
    ws.Rows(7).RowHeight = 16

    With ws.Range("H1:J" & maxRow)
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .Borders.LineStyle = xlNone
    End With
    ws.Range("H1:J1").Font.Bold = True
    ws.Range("H3:I4").Font.Bold = True
    ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0"
    ws.Range("I4").FormatConditions.Delete

    ws.Columns("A").ColumnWidth = 12
    ws.Columns("B").ColumnWidth = 12
    ws.Columns("C").ColumnWidth = 12
    ws.Columns("D").ColumnWidth = 15.5
    ws.Columns("E").ColumnWidth = 12.5
    ws.Columns("F").ColumnWidth = 12.5
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 9
    ws.Columns("I").ColumnWidth = 9
    ws.Columns("J").ColumnWidth = 40

    ws.Columns("A:B").NumberFormat = "0"
    ws.Columns("C").NumberFormat = "dd.mm.yyyy"
    ws.Columns("D:F").NumberFormat = "#,##0;-#,##0"

    ' Layoutvorgabe 1.0.13: Marsh-Farbe, Textumbruch und breitere Pensionen-Spalte.
    ws.Range("A1:F" & maxRow).Font.Color = RGB(0, 15, 71)
    With ws.Range("A6:F7")
        .Font.Size = 9
        .Font.Color = RGB(0, 15, 71)
        .WrapText = True
        .ShrinkToFit = False
        .VerticalAlignment = xlCenter
    End With
    ws.Rows(6).RowHeight = 28
    ws.Rows(7).RowHeight = 28
    ws.Columns("D").ColumnWidth = 17.5
    ws.Columns("H").NumberFormat = "0"
    ws.Range("A1:J" & maxRow).WrapText = False
    ws.Range("A6:F7").WrapText = True

    With ws.PageSetup
        .Orientation = xlPortrait
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .CenterHorizontally = True
        .LeftMargin = Application.CentimetersToPoints(1.2)
        .RightMargin = Application.CentimetersToPoints(1.2)
        .TopMargin = Application.CentimetersToPoints(1)
        .BottomMargin = Application.CentimetersToPoints(1)
        .HeaderMargin = Application.CentimetersToPoints(0.4)
        .FooterMargin = Application.CentimetersToPoints(0.4)
        .PrintArea = "$A$1:$F$" & maxRow
        .PrintGridlines = False
    End With

    On Error Resume Next
    ws.Activate
    Application.ActiveWindow.View = xlPageBreakPreview
    Application.ActiveWindow.Zoom = 58
    Application.ActiveWindow.DisplayGridlines = False
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub FormatSection(ByVal ws As Worksheet, _
                          ByVal sectionRow As Long, _
                          ByVal headerRow As Long, _
                          ByVal dataStartRow As Long, _
                          ByVal dataEndRow As Long, _
                          ByVal subtotalRow As Long)

    With ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 15, 71)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    ws.Rows(sectionRow).RowHeight = 19

    With ws.Range(ws.Cells(sectionRow, 8), ws.Cells(sectionRow, 10))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 15, 71)
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With

    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 15, 71)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(headerRow).RowHeight = 31

    If dataEndRow >= dataStartRow Then
        With ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGB(0, 0, 0)
            .Font.Bold = False
            .Borders.LineStyle = xlNone
        End With

        ws.Range(ws.Cells(dataStartRow, 1), _
                 ws.Cells(dataEndRow, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(dataStartRow, 4), _
                 ws.Cells(dataEndRow, 6)).HorizontalAlignment = xlRight
        ws.Rows(dataStartRow & ":" & dataEndRow).RowHeight = 15
    End If

    With ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = True
        .Borders.LineStyle = xlNone
        .Borders(xlEdgeTop).LineStyle = xlContinuous
        .Borders(xlEdgeTop).Weight = xlThin
    End With
    ws.Rows(subtotalRow).RowHeight = 15
End Sub

Private Function DiscoverOverviewLayout(ByVal ws As Worksheet) As Object
    Dim bestMap As Object
    Dim rowMap As Object
    Dim requiredKeys As Variant
    Dim optionalKeys As Variant
    Dim key As Variant
    Dim canonical As String
    Dim rowNumber As Long
    Dim columnNumber As Long
    Dim scanLastRow As Long
    Dim scanLastColumn As Long
    Dim score As Long
    Dim bestScore As Long
    Dim bestRow As Long
    Dim missing As String

    requiredKeys = Array("pnr_new", "ltrg_new", "pnr_old", "ltrg_old", _
                         "transfer_date", "bsav", "pension")
    optionalKeys = Array("last_cutoff", "months", "total")

    scanLastRow = WorksheetFunction.Min(LastUsedRowSafe(ws), HEADER_SCAN_MAX_ROWS)
    scanLastColumn = WorksheetFunction.Min(LastUsedColumnSafe(ws), HEADER_SCAN_MAX_COLUMNS)
    bestScore = -1

    For rowNumber = 1 To scanLastRow
        Set rowMap = CreateObject("Scripting.Dictionary")
        rowMap.CompareMode = vbTextCompare

        For columnNumber = 1 To scanLastColumn
            canonical = CanonicalOverviewHeader(ws.Cells(rowNumber, columnNumber).Value2)
            If Len(canonical) > 0 Then
                If Not rowMap.Exists(canonical) Then rowMap.Add canonical, columnNumber
            End If
        Next columnNumber

        score = 0
        For Each key In requiredKeys
            If rowMap.Exists(CStr(key)) Then score = score + 100
        Next key
        For Each key In optionalKeys
            If rowMap.Exists(CStr(key)) Then score = score + 10
        Next key

        If score > bestScore Then
            bestScore = score
            bestRow = rowNumber
            Set bestMap = CloneDictionaryVba(rowMap)
        End If
    Next rowNumber

    If bestMap Is Nothing Then
        For Each key In requiredKeys
            missing = missing & vbCrLf & "- " & OverviewFieldLabel(CStr(key))
        Next key
    Else
        For Each key In requiredKeys
            If Not bestMap.Exists(CStr(key)) Then
                missing = missing & vbCrLf & "- " & OverviewFieldLabel(CStr(key))
            End If
        Next key
    End If

    If Len(missing) > 0 Then
        Err.Raise vbObjectError + 1020, , _
                  "Die ben�tigten Spalten im Blatt '" & ws.Name & "' konnten nicht vollst�ndig erkannt werden." & _
                  vbCrLf & "Die Reihenfolge ist beliebig; zus�tzliche Spalten wie ARE neu/alt sind erlaubt." & _
                  vbCrLf & "Fehlende Felder:" & missing
    End If

    bestMap("_header_row") = bestRow
    Set DiscoverOverviewLayout = bestMap
End Function

Private Function DiscoverCompanyLayout(ByVal ws As Worksheet) As Object
    Dim bestMap As Object
    Dim rowMap As Object
    Dim requiredKeys As Variant
    Dim key As Variant
    Dim canonical As String
    Dim rowNumber As Long
    Dim columnNumber As Long
    Dim scanLastRow As Long
    Dim scanLastColumn As Long
    Dim score As Long
    Dim bestScore As Long
    Dim bestRow As Long
    Dim missing As String

    requiredKeys = Array("ltrg", "are", "name")
    scanLastRow = WorksheetFunction.Min(LastUsedRowSafe(ws), HEADER_SCAN_MAX_ROWS)
    scanLastColumn = WorksheetFunction.Min(LastUsedColumnSafe(ws), HEADER_SCAN_MAX_COLUMNS)
    bestScore = -1

    For rowNumber = 1 To scanLastRow
        Set rowMap = CreateObject("Scripting.Dictionary")
        rowMap.CompareMode = vbTextCompare

        For columnNumber = 1 To scanLastColumn
            canonical = CanonicalCompanyHeader(ws.Cells(rowNumber, columnNumber).Value2)
            If Len(canonical) > 0 Then
                If Not rowMap.Exists(canonical) Then rowMap.Add canonical, columnNumber
            End If
        Next columnNumber

        score = 0
        For Each key In requiredKeys
            If rowMap.Exists(CStr(key)) Then score = score + 100
        Next key

        If score > bestScore Then
            bestScore = score
            bestRow = rowNumber
            Set bestMap = CloneDictionaryVba(rowMap)
        End If
    Next rowNumber

    If bestMap Is Nothing Then
        For Each key In requiredKeys
            missing = missing & vbCrLf & "- " & UCase$(CStr(key))
        Next key
    Else
        For Each key In requiredKeys
            If Not bestMap.Exists(CStr(key)) Then missing = missing & vbCrLf & "- " & UCase$(CStr(key))
        Next key
    End If

    If Len(missing) > 0 Then
        Err.Raise vbObjectError + 1021, , _
                  "Im Blatt '" & ws.Name & "' m�ssen LTRG, ARE und Name vorhanden sein � unabh�ngig von der Reihenfolge." & _
                  vbCrLf & "Fehlende Felder:" & missing
    End If

    bestMap("_header_row") = bestRow
    Set DiscoverCompanyLayout = bestMap
End Function

Private Function CanonicalOverviewHeader(ByVal rawValue As Variant) As String
    Dim compact As String
    compact = Replace$(NormalizeHeaderCellVba(rawValue), " ", "")

    Select Case compact
        Case "pnrneu", "personalnummerneu", "personalnrneu": CanonicalOverviewHeader = "pnr_new"
        Case "ltrgneu", "ltgrneu", "lgtrneu", "ltrgrneu", "leistungstraegerneu", "leistungstragerneu": CanonicalOverviewHeader = "ltrg_new"
        Case "pnralt", "personalnummeralt", "personalnralt": CanonicalOverviewHeader = "pnr_old"
        Case "ltrgalt", "ltgralt", "lgtralt", "ltrgralt", "leistungstraegeralt", "leistungstrageralt": CanonicalOverviewHeader = "ltrg_old"
        Case "uebertritt", "uebertrittsdatum", "datumdeseinzeluebertritts", "datumeinzeluebertritt", "datumdeseinzeluebertritt": CanonicalOverviewHeader = "transfer_date"
        Case "letzterstichtag1", "letzterstichtagplus1": CanonicalOverviewHeader = "last_cutoff"
        Case "monatebisuebertritt", "monatebiszumeinzeluebertritt": CanonicalOverviewHeader = "months"
        Case "bsav", "bsaveuro", "uebertragungswertbsav", "uebertragungswertbsaveuro": CanonicalOverviewHeader = "bsav"
        Case "pensionenalt", "pensionenalteuro", "pensionalt", "uebertragungswertpensionenalt", "uebertragungswertpensionenalteuro": CanonicalOverviewHeader = "pension"
        Case "summe", "summeeuro", "gesamt", "gesamtbetrag", "uebertragungswertsumme": CanonicalOverviewHeader = "total"
        Case Else
            If InStr(1, compact, "datum", vbTextCompare) > 0 And InStr(1, compact, "einzeluebertritt", vbTextCompare) > 0 Then
                CanonicalOverviewHeader = "transfer_date"
            ElseIf InStr(1, compact, "bsav", vbTextCompare) > 0 And InStr(1, compact, "summe", vbTextCompare) = 0 Then
                CanonicalOverviewHeader = "bsav"
            ElseIf InStr(1, compact, "pension", vbTextCompare) > 0 And InStr(1, compact, "alt", vbTextCompare) > 0 Then
                CanonicalOverviewHeader = "pension"
            End If
    End Select
End Function

Private Function CanonicalCompanyHeader(ByVal rawValue As Variant) As String
    Dim compact As String
    compact = Replace$(NormalizeHeaderCellVba(rawValue), " ", "")

    Select Case compact
        Case "ltrg", "ltgr", "lgtr", "ltrgr", "leistungstraeger", "leistungstrager", "ltrgneu", "ltgrneu", "lgtrneu", "ltrgrneu": CanonicalCompanyHeader = "ltrg"
        Case "are", "arenummer", "arewert", "arecode": CanonicalCompanyHeader = "are"
        Case "name", "gesellschaft", "gesellschaftsname", "firmenname", "unternehmen": CanonicalCompanyHeader = "name"
    End Select
End Function

Private Function NormalizeHeaderCellVba(ByVal rawValue As Variant) As String
    Dim textValue As String
    Dim punctuation As Variant
    Dim item As Variant

    If IsUnavailableVariantVba(rawValue) Then Exit Function
    textValue = LCase$(Trim$(CStr(rawValue)))
    textValue = Replace$(textValue, vbCr, " ")
    textValue = Replace$(textValue, vbLf, " ")
    textValue = Replace$(textValue, Chr$(160), " ")
    textValue = Replace$(textValue, "�", "ae")
    textValue = Replace$(textValue, "�", "oe")
    textValue = Replace$(textValue, "�", "ue")
    textValue = Replace$(textValue, "�", "ss")

    punctuation = Array("(", ")", "[", "]", "{", "}", ":", ";", ",", ".", "_", "-", "/", "\", "+", "'", Chr$(34))
    For Each item In punctuation
        textValue = Replace$(textValue, CStr(item), " ")
    Next item
    Do While InStr(1, textValue, "  ", vbBinaryCompare) > 0
        textValue = Replace$(textValue, "  ", " ")
    Loop
    NormalizeHeaderCellVba = Trim$(textValue)
End Function

Private Function OverviewFieldLabel(ByVal key As String) As String
    Select Case key
        Case "pnr_new": OverviewFieldLabel = "PNR neu"
        Case "ltrg_new": OverviewFieldLabel = "LTRG neu"
        Case "pnr_old": OverviewFieldLabel = "PNR alt"
        Case "ltrg_old": OverviewFieldLabel = "LTRG alt"
        Case "transfer_date": OverviewFieldLabel = "Datum des Einzel�bertritts"
        Case "bsav": OverviewFieldLabel = "�bertragungswert BSAV"
        Case "pension": OverviewFieldLabel = "�bertragungswert Pensionen (alt)"
        Case Else: OverviewFieldLabel = key
    End Select
End Function

Private Function CloneDictionaryVba(ByVal source As Object) As Object
    Dim result As Object
    Dim key As Variant
    Set result = CreateObject("Scripting.Dictionary")
    result.CompareMode = vbTextCompare
    For Each key In source.Keys
        result.Add CStr(key), source(key)
    Next key
    Set CloneDictionaryVba = result
End Function

Private Function LastUsedRowSafe(ByVal ws As Worksheet) As Long
    Dim lastCell As Range
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlValues, _
                                 LookAt:=xlPart, SearchOrder:=xlByRows, _
                                 SearchDirection:=xlPrevious, MatchCase:=False)
    If lastCell Is Nothing Then LastUsedRowSafe = 1 Else LastUsedRowSafe = lastCell.Row
End Function

Private Function LastUsedColumnSafe(ByVal ws As Worksheet) As Long
    Dim lastCell As Range
    Set lastCell = ws.Cells.Find(What:="*", After:=ws.Cells(1, 1), LookIn:=xlValues, _
                                 LookAt:=xlPart, SearchOrder:=xlByColumns, _
                                 SearchDirection:=xlPrevious, MatchCase:=False)
    If lastCell Is Nothing Then LastUsedColumnSafe = 1 Else LastUsedColumnSafe = lastCell.Column
End Function

Private Function LastTransferRow(ByVal ws As Worksheet, ByVal layout As Object, _
                                 ByVal firstDataRow As Long) As Long
    Dim rowNumber As Long
    Dim fields As Variant
    Dim key As Variant
    fields = Array("pnr_new", "ltrg_new", "pnr_old", "ltrg_old", "transfer_date", "bsav", "pension", "total")

    For rowNumber = LastUsedRowSafe(ws) To firstDataRow Step -1
        For Each key In fields
            If layout.Exists(CStr(key)) Then
                If Len(Trim$(SafeStringVba(ws.Cells(rowNumber, CLng(layout(CStr(key)))).Value2))) > 0 Then
                    LastTransferRow = rowNumber
                    Exit Function
                End If
            End If
        Next key
    Next rowNumber
    LastTransferRow = firstDataRow - 1
End Function

Private Function LoadTransferDataDynamic(ByVal ws As Worksheet, ByVal layout As Object, _
                                         ByVal firstDataRow As Long, ByVal lastRow As Long) As Variant
    Dim data() As Variant
    Dim sourceRow As Long
    Dim targetRow As Long
    Dim rowCount As Long
    Dim bsavValue As Variant
    Dim pensionValue As Variant
    Dim totalValue As Variant

    rowCount = lastRow - firstDataRow + 1
    ReDim data(1 To rowCount, 1 To 10)

    For sourceRow = firstDataRow To lastRow
        targetRow = sourceRow - firstDataRow + 1
        data(targetRow, 1) = MappedValueVba(ws, sourceRow, layout, "pnr_new")
        data(targetRow, 2) = MappedValueVba(ws, sourceRow, layout, "ltrg_new")
        data(targetRow, 3) = MappedValueVba(ws, sourceRow, layout, "pnr_old")
        data(targetRow, 4) = MappedValueVba(ws, sourceRow, layout, "ltrg_old")
        data(targetRow, 5) = MappedValueVba(ws, sourceRow, layout, "transfer_date")
        data(targetRow, 6) = MappedValueVba(ws, sourceRow, layout, "last_cutoff")
        data(targetRow, 7) = MappedValueVba(ws, sourceRow, layout, "months")
        bsavValue = MappedValueVba(ws, sourceRow, layout, "bsav")
        pensionValue = MappedValueVba(ws, sourceRow, layout, "pension")
        totalValue = MappedValueVba(ws, sourceRow, layout, "total")
        data(targetRow, 8) = bsavValue
        data(targetRow, 9) = pensionValue
        If HasNumericValueVba(totalValue) Then
            data(targetRow, 10) = totalValue
        Else
            data(targetRow, 10) = NzNumber(bsavValue) + NzNumber(pensionValue)
        End If
    Next sourceRow

    LoadTransferDataDynamic = data
End Function

Private Function MappedValueVba(ByVal ws As Worksheet, ByVal rowNumber As Long, _
                                ByVal layout As Object, ByVal key As String) As Variant
    If layout.Exists(key) Then MappedValueVba = ws.Cells(rowNumber, CLng(layout(key))).Value2
End Function

Private Function LastCompanyRow(ByVal ws As Worksheet, ByVal layout As Object, _
                                ByVal firstDataRow As Long) As Long
    Dim rowNumber As Long
    For rowNumber = LastUsedRowSafe(ws) To firstDataRow Step -1
        If Len(Trim$(SafeStringVba(ws.Cells(rowNumber, CLng(layout("ltrg"))).Value2))) > 0 Or _
           Len(Trim$(SafeStringVba(ws.Cells(rowNumber, CLng(layout("name"))).Value2))) > 0 Then
            LastCompanyRow = rowNumber
            Exit Function
        End If
    Next rowNumber
    LastCompanyRow = firstDataRow - 1
End Function

Private Function IsUnavailableVariantVba(ByVal value As Variant) As Boolean
    Dim valueType As VbVarType
    On Error GoTo NichtVerfuegbar
    valueType = VarType(value)
    IsUnavailableVariantVba = (valueType = vbEmpty Or valueType = vbNull Or valueType = vbError)
    Exit Function
NichtVerfuegbar:
    IsUnavailableVariantVba = True
End Function

Private Function SafeStringVba(ByVal value As Variant) As String
    If IsUnavailableVariantVba(value) Then Exit Function
    On Error Resume Next
    SafeStringVba = CStr(value)
    On Error GoTo 0
End Function

Private Function IsBlankValueVba(ByVal value As Variant) As Boolean
    If IsUnavailableVariantVba(value) Then
        IsBlankValueVba = True
    Else
        IsBlankValueVba = (Len(Trim$(SafeStringVba(value))) = 0)
    End If
End Function

Private Function HasNumericValueVba(ByVal value As Variant) As Boolean
    If IsUnavailableVariantVba(value) Then Exit Function
    If Len(Trim$(SafeStringVba(value))) = 0 Then Exit Function
    On Error Resume Next
    HasNumericValueVba = IsNumeric(value)
    On Error GoTo 0
End Function

Private Function ExcelColumnLetter(ByVal columnNumber As Long) As String
    Do While columnNumber > 0
        columnNumber = columnNumber - 1
        ExcelColumnLetter = Chr$(65 + (columnNumber Mod 26)) & ExcelColumnLetter
        columnNumber = columnNumber \ 26
    Loop
End Function

Private Function GetWorksheetOrNothing(ByVal wb As Workbook, _
                                       ByVal sheetName As String) As Worksheet
    Dim ws As Worksheet
    Dim requested As String
    Dim candidate As String

    On Error Resume Next
    Set ws = wb.Worksheets(sheetName)
    On Error GoTo 0

    If ws Is Nothing Then
        requested = Replace$(NormalizeHeaderCellVba(sheetName), " ", "")
        For Each ws In wb.Worksheets
            candidate = Replace$(NormalizeHeaderCellVba(ws.Name), " ", "")
            If WorksheetNameMatchesRoleVba(candidate, requested) Then
                Set GetWorksheetOrNothing = ws
                Exit Function
            End If
        Next ws
    Else
        Set GetWorksheetOrNothing = ws
    End If
End Function

Private Function WorksheetNameMatchesRoleVba(ByVal candidate As String, _
                                              ByVal requested As String) As Boolean
    If candidate = requested Then
        WorksheetNameMatchesRoleVba = True
    ElseIf requested = "uebersicht" Then
        WorksheetNameMatchesRoleVba = (candidate = "overview" Or candidate = "uebersichtdaten")
    ElseIf requested = "gesellschaften" Then
        WorksheetNameMatchesRoleVba = (candidate = "gesellschaft" Or candidate = "companies" Or _
                                        candidate = "company" Or candidate = "stammdaten")
    End If
End Function

Private Sub DeleteGeneratedSheets(ByVal wb As Workbook)
    Dim i As Long
    Dim sheetName As String

    For i = wb.Worksheets.Count To 1 Step -1
        sheetName = wb.Worksheets(i).Name

        If Left$(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", vbTextCompare) > 0 Then
            wb.Worksheets(i).Delete
        End If
    Next i
End Sub

Private Function BuildSheetName(ByVal ltrg As Long, _
                                ByVal areValue As Variant) As String
    BuildSheetName = SafeSheetName( _
        "ARE " & DisplayValue(areValue) & _
        " (LTRG " & FormatLtrg(ltrg) & ")" _
    )
End Function

Private Function SafeSheetName(ByVal value As String) As String
    Dim forbidden As Variant
    Dim item As Variant

    forbidden = Array("\", "/", ":", "*", "?", "[", "]")

    For Each item In forbidden
        value = Replace(value, CStr(item), "-")
    Next item

    value = Trim$(value)
    If Len(value) = 0 Then value = "ARE-Auswertung"
    If Len(value) > 31 Then value = Left$(value, 31)

    SafeSheetName = value
End Function

Private Function FormatLtrg(ByVal ltrg As Long) As String
    FormatLtrg = Format$(ltrg, "0000")
End Function

Private Function ShortCompanyName(ByVal fullName As String) As String
    Dim commaPosition As Long

    fullName = Trim$(fullName)
    commaPosition = InStr(1, fullName, ",", vbTextCompare)

    If commaPosition > 0 Then
        ShortCompanyName = Trim$(Left$(fullName, commaPosition - 1))
    Else
        ShortCompanyName = fullName
    End If
End Function

Private Function DisplayValue(ByVal value As Variant) As String
    If IsUnavailableVariantVba(value) Then
        DisplayValue = "n.v."
    ElseIf Len(Trim$(SafeStringVba(value))) = 0 Then
        DisplayValue = "n.v."
    Else
        DisplayValue = Trim$(SafeStringVba(value))
    End If
End Function

Private Function NzNumber(ByVal value As Variant) As Double
    If Not HasNumericValueVba(value) Then Exit Function
    On Error Resume Next
    NzNumber = CDbl(value)
    On Error GoTo 0
End Function

Private Function TryGetLong(ByVal value As Variant, ByRef result As Long) As Boolean
    If Not HasNumericValueVba(value) Then Exit Function
    On Error Resume Next
    result = CLng(CDbl(value))
    If Err.Number = 0 Then TryGetLong = True
    Err.Clear
    On Error GoTo 0
End Function

Private Function BuildVbaReportPeriod(ByVal workbookName As String) As String
    Dim regex As Object
    Dim matches As Object
    Dim yearValue As Long

    BuildVbaReportPeriod = "2024/25"
    Set regex = CreateObject("VBScript.RegExp")
    regex.Pattern = "(19|20)[0-9]{2}"
    regex.Global = False

    If regex.Test(workbookName) Then
        Set matches = regex.Execute(workbookName)
        yearValue = CLng(matches(0).Value)
        BuildVbaReportPeriod = CStr(yearValue - 1) & "/" & Right$(CStr(yearValue), 2)
    End If
End Function

Private Function SanitizeVbaFileName(ByVal value As String) As String
    Dim forbidden As Variant
    Dim item As Variant

    value = Trim$(value)
    forbidden = Array("\", "/", ":", "*", "?", """", "<", ">", "|")

    For Each item In forbidden
        value = Replace$(value, CStr(item), "-")
    Next item

    Do While Len(value) > 0 And _
             (Right$(value, 1) = "." Or Right$(value, 1) = " ")
        value = Left$(value, Len(value) - 1)
    Loop

    If Len(value) > 120 Then value = Left$(value, 120)
    SanitizeVbaFileName = value
End Function

Private Function UniqueVbaFilePath(ByVal folderPath As String, _
                                   ByVal baseName As String, _
                                   ByVal extension As String) As String
    Dim candidate As String
    Dim counter As Long

    If Len(baseName) = 0 Then baseName = "Ausgabe"

    candidate = folderPath & baseName & "." & extension
    counter = 2

    Do While Len(Dir$(candidate)) > 0
        candidate = folderPath & baseName & "_" & counter & "." & extension
        counter = counter + 1
    Loop

    UniqueVbaFilePath = candidate
End Function

