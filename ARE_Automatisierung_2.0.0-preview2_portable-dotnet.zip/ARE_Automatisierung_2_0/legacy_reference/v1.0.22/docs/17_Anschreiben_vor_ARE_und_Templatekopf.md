# Anschreiben vor ARE und Erhalt des Templatekopfs – Version 1.0.19

## Ziel

Die finale Personen-PDF soll nicht mehr mit der ARE-Übersicht beginnen. Stattdessen gilt:

1. Anschreiben
2. zugehörige ARE-Übersicht

## Warum Logo und Absender zuvor fehlten

Beim bisherigen Fallback wurde die ARE-PDF als Basis in Word geöffnet und das Anschreiben anschließend als weiterer Abschnitt eingefügt. Word behandelte das Anschreiben dadurch nicht mehr wie die erste Seite des ursprünglichen Templates. Vorlagen mit unterschiedlichem Kopf für die erste Seite konnten daher statt Marsh-Logo und Absenderblock einen Zweitseitenkopf wie `Seite 2` anzeigen.

## Neue Verarbeitung

Das Tool exportiert jedes Anschreiben zuerst direkt aus dem ausgefüllten Word-Template. Damit wird dessen erste Seite unverändert gerendert. Danach wird die bereits fertige ARE-PDF auf PDF-Ebene angehängt.

Die ARE-PDF selbst bleibt separat im Ordner `01_ARE_PDF` erhalten. Die fertige Kombination liegt unter `03_Serienbrief_Einzel`.
