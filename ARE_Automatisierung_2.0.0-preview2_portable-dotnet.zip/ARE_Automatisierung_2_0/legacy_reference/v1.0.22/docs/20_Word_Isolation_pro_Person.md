# Version 1.0.22 – Word-Isolation pro Person

Der Fehler `-2147417848` bedeutet, dass eine vorhandene Word-COM-Referenz von ihrer Word-Instanz getrennt wurde. Da der erste Datensatz bereits korrekt erzeugt wurde, lag das Problem nicht in Daten- oder Layoutlogik, sondern in der Wiederverwendung derselben Word-Instanz für den Folgedatensatz.

Ab 1.0.22 gilt:

1. Für jede betroffene Person wird eine eigene Word-Instanz gestartet.
2. Die Originalvorlage wird darin geöffnet und die MERGEFIELDs werden ersetzt.
3. Das reine DOCX wird gespeichert.
4. Die ARE-Übersicht wird angehängt und die finale PDF exportiert.
5. Word wird für diesen Datensatz vollständig geschlossen.
6. Bei einem COM-Abbruch wird genau dieser Datensatz einmal mit einer neuen Word-Instanz wiederholt.
7. Erst nachdem alle Einzeldateien erfolgreich erstellt sind, werden Gesamt-DOCX und Gesamt-PDF separat aufgebaut.

Damit kann ein Word-Abbruch nach Person 1 Person 2 oder 3 nicht mehr blockieren.
