# Version 1.0.21 – VBA/VBScript-only Layoutfix

Diese Version behebt drei Layoutprobleme ohne Python oder zusätzliche PDF-Bibliothek.

## Footer

Der rechtliche Marsh-Block wird, falls er als normaler Dokumentinhalt oder Textfeld vorliegt, in die echte First-Page-Fußzeile des Anschreibens verschoben. Die nachfolgende ARE-Seite wird als eigene Word-Sektion angelegt und erbt keine Kopf- oder Fußzeilen.

## Logo

Die Logo-Höhe der Word-Anschreibenvorlage wird automatisch erkannt. Wenn im ARE-Template weiterhin der Standardwert für `LOGO_HEIGHT` verwendet wird, übernimmt das ARE-Logo diese physische Höhe. Beim Einfügen der ARE-Seite in das Anschreiben wird das Logo separat mit derselben Höhe gesetzt.

## ARE-Summen

Die ARE-Seite wird nicht mehr über Word aus einer PDF zurückkonvertiert. Stattdessen kopiert Excel den bereinigten Bereich `A:F` mit `CopyPicture` und `xlPrinter` als druckgetreue Vektorgrafik. Word erhält dadurch ein fertiges Bild der Tabelle; Zahlen, Summenzeilen, Spaltenbreiten und Linien können nicht neu umbrochen werden.

## Laufzeit

Der Workflow bleibt vollständig VBA/VBScript-basiert. Python, `pypdf` oder andere zusätzliche PDF-Bibliotheken sind nicht erforderlich.
