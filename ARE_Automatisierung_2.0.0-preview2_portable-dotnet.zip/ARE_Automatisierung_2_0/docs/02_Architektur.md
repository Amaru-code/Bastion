# 02 – Architektur

## Zielbild

```text
WPF UI
  │
  ├─ InputValidator
  │    ├─ SourceWorkbookReader (ClosedXML, kein Excel)
  │    ├─ SerialDataReader (ClosedXML; .xls-Fallback via hidden Excel)
  │    └─ AreEngine (reine C#-Fachlogik)
  │
  └─ AreRunService
       ├─ ExcelComOutputWriter (einmalige hidden Office-Kompatibilität)
       ├─ WordComLetterService (isoliert pro Person)
       └─ PdfMergeService (PDFsharp)
```

## Warum der Hybridansatz?

Die größten VBA/VBS-Kosten entstanden durch COM-getriebene Datenanalyse und viele Zellzugriffe. Diese Arbeit liegt jetzt in C#-Objekten im Arbeitsspeicher.

Für den finalen Output bleibt Excel bewusst als dünner Adapter erhalten:

- XLSM-Makros werden durch Excel selbst sicher erhalten.
- das bestehende Excel-Drucklayout kann weiterhin als PDF gerendert werden.
- die Office-Instanz ist unsichtbar und wird nur einmal für die Ausgabekopie geöffnet.

Word bleibt ausschließlich für die originale DOCX-Vorlage/Renderingtreue zuständig. PDF-Merges erfolgen nicht mehr mit Word oder Acrobat.

## Threads

Excel und Word COM laufen auf expliziten STA-Threads (`StaThreadRunner`). Damit bleibt die WPF-Oberfläche responsiv und Office erhält das erwartete Apartment-Modell.
