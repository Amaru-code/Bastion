# 03 – Migration von v1.0.22 auf v2

## Portierte Regeln

- Blätter `Übersicht` und `Gesellschaften`
- dynamische Kopfzeilensuche (erste 30 Zeilen / 100 Spalten)
- Überschriftenvarianten für LTRG/LTGR/LGTR/LTRGR
- ARE und Gesellschaftsname ausschließlich über `Gesellschaften`
- Betroffenenliste aus `LTRG neu` und `LTRG alt`, nur bei unterschiedlichen LTRG
- Empfänger: positives Vorzeichen
- Abgeber: negatives Vorzeichen
- Nullsumme wird auf Empfängerseite nicht angezeigt, auf Abgeberseite schon
- Gruppen nach Gegen-LTRG
- LTRG 0100: numerische Gruppensortierung
- übrige LTRG: Gruppen mit positiven Positionen zuerst, dann numerisch
- innerhalb einer Gruppe positive Positionen vor <= 0
- Kontrollsaldo = Summe empfangen - Summe abgegeben
- Serienbriefdaten nur für betroffene LTRG
- mehrere Serienbriefzeilen je LTRG erlaubt
- Word-Instanz pro Person + Retry
- finale PDF-Reihenfolge Anschreiben -> ARE

## Geänderte technische Umsetzung

- kein VBS-Startdialog mehr
- keine Fachlogik in Excel/VBA
- kein Adobe Acrobat OLE
- kein Word-PDF-Import
- kein sichtbares Excel
- PDF-Merge via PDFsharp
