# 07 – Nächste Ausbaustufen

Die neue Architektur ermöglicht ohne Umbau der Fachlogik unter anderem:

- Drag & Drop aller Eingaben
- automatische Dateierkennung in einem gewählten Ordner
- gespeicherte Profile für wiederkehrende Dateipfade
- Auswahl einzelner LTRG vor dem Start
- detaillierte Vorab-Fehlerliste mit direkter Zeilenreferenz
- Run-Historie und Wiederholung eines früheren Laufs
- konfigurierbare `ARE_Uebersicht_Template.xlsx` über einen Template-Provider
- vollständiger OpenXML-Excel-Writer für xlsx ohne Excel COM
- serverfähiger Headless-Modus / CLI
- Unit- und Golden-File-Tests für ARE-Berichte
