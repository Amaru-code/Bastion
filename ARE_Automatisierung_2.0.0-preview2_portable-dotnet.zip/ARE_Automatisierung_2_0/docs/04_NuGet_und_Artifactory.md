# 04 – NuGet und Artifactory

Die Anwendung benötigt beim **Build** zwei NuGet-Pakete:

- `ClosedXML 0.105.1`
- `PDFsharp 6.2.4`

Beim späteren self-contained Publish sind die benötigten Assemblies im `publish`-Ordner enthalten. Kollegen müssen dann keine NuGet-Pakete herunterladen.

## Unternehmensumgebung

Falls `dotnet restore` keinen Zugriff auf nuget.org hat, muss der interne NuGet-Artifactory-Feed verwendet werden. Das Projekt überschreibt bewusst keine globalen NuGet-Einstellungen.

Eine Vorlage liegt als `NuGet.Artifactory.example.config` im Projektstamm.

Beispiel für einen Build mit einer freigegebenen Config:

```powershell
dotnet restore .\src\ARE.Automatisierung\ARE.Automatisierung.csproj --configfile C:\Pfad\NuGet.Config
```

Danach:

```powershell
dotnet publish .\src\ARE.Automatisierung\ARE.Automatisierung.csproj -c Release -r win-x64 --self-contained true --no-restore -o .\publish
```
