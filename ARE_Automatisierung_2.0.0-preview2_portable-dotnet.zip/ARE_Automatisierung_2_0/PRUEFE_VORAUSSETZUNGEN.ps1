$ErrorActionPreference = 'SilentlyContinue'
Write-Host 'ARE Automatisierung 2.0 - Voraussetzungen' -ForegroundColor Cyan
Write-Host ('=' * 56)

$projectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$localDotnet = Join-Path $projectRoot 'tools\dotnet\dotnet.exe'

if (Test-Path $localDotnet) {
    Write-Host '[OK] Portables dotnet gefunden:' $localDotnet
    & $localDotnet --list-sdks | ForEach-Object { Write-Host '     SDK' $_ }
} else {
    $dotnet = Get-Command dotnet.exe
    if ($dotnet) {
        Write-Host '[OK] Systemweites dotnet gefunden:' $dotnet.Source
        dotnet --list-sdks | ForEach-Object { Write-Host '     SDK' $_ }
    } else {
        Write-Host '[INFO] Kein SDK gefunden. START.bat kann .NET 10 SDK 10.0.400 portabel bereitstellen.'
    }
}

$excel = [type]::GetTypeFromProgID('Excel.Application')
$word  = [type]::GetTypeFromProgID('Word.Application')
if ($excel) { Write-Host '[OK] Microsoft Excel COM verfügbar' } else { Write-Host '[FEHLT] Microsoft Excel Desktop/COM' -ForegroundColor Red }
if ($word)  { Write-Host '[OK] Microsoft Word COM verfügbar' }  else { Write-Host '[FEHLT] Microsoft Word Desktop/COM' -ForegroundColor Red }

Write-Host ''
Write-Host 'Hinweis: Die Quelldatenanalyse läuft ohne Excel. Excel/Word werden nur unsichtbar für die Office-kompatible Ausgabe verwendet.'
