@echo off
setlocal
cd /d "%~dp0"
title DC LNW Importer V1.4.1

"%~dp0DC_LNW_Importer.exe"
if errorlevel 1 (
    echo.
    echo Der Hauptimport wurde mit einem Fehler beendet.
    pause
    exit /b 1
)

echo.
echo Erzwinge jetzt die AJ-Werte 1:1 aus 03_final_import.csv ...
"%~dp0AJ_CSV_Force_Fix.exe"
if errorlevel 1 (
    echo.
    echo Die AJ-Nachkorrektur ist fehlgeschlagen.
    pause
    exit /b 1
)

echo.
echo Gesamtprozess erfolgreich abgeschlossen.
pause
