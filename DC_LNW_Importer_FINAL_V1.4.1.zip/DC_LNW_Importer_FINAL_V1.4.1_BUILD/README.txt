DC LNW Importer – Version 1.4.1
================================

START
-----
1. ZIP vollständig entpacken.
2. start.bat doppelklicken.
3. Template-Datei auswählen.
4. DU-Datei auswählen.

KORREKTUR IN V1.4.1
-------------------
Die Datenaufbereitung und die übrigen Excel-Spalten bleiben unverändert.

Nach dem Hauptimport wird AJ_CSV_Force_Fix.exe automatisch ausgeführt.
Diese Nachkorrektur:

1. findet die gerade erzeugte Auswertung im Output-Ordner,
2. liest WWID und AJ direkt aus 03_final_import.csv,
3. findet im erzeugten XLSM das Worksheet mit dem WWID-Header,
4. entfernt für jede gefundene WWID den bisherigen AJ-Zellknoten vollständig,
5. entfernt damit insbesondere alte Template-Werte und alte AJ-Formeln,
6. erstellt AJ neu als festen numerischen Wert aus der CSV,
7. prüft jede geschriebene AJ-Zelle gegen den CSV-Wert.

WICHTIG
-------
AJ ist der erste Datenwert nach WWID und wurde in der bisherigen Import-Schleife
übersprungen. Die Farbe, Power Query, Makros und Berechnungsoptionen waren nicht
die Ursache.

Die Format-ID der bestehenden AJ-Zelle wird übernommen. Dadurch bleibt die
optische Formatierung der Spalte erhalten, während der Zellinhalt ersetzt wird.

SICHERUNG
---------
Vor der AJ-Nachkorrektur wird die vom Hauptimport erzeugte XLSM zusätzlich als
*.vor_AJ_Fix.bak im selben Auswertungsordner gesichert.

AUSGABEN
--------
Unter output/Auswertung_YYYYMMDD_HHMMSS entstehen weiterhin:
- 03_final_import.csv
- 04_kontrolle.csv
- *_DC_LNW_Output.xlsm
- ZUSAMMENFASSUNG.txt
- processing.log

Zusätzlich:
- AJ_FIX_PROTOKOLL.txt
- *_DC_LNW_Output.xlsm.vor_AJ_Fix.bak

VORAUSSETZUNGEN
---------------
- Windows 10 oder Windows 11
- Keine Go- oder Python-Installation erforderlich
