using System.Collections.ObjectModel;
using System.Windows;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;
using ARE.Automatisierung.Services.Run;

namespace ARE.Automatisierung.ViewModels;

public sealed class MainViewModel : ObservableObject
{
    private readonly DialogService _dialogs;
    private readonly InputValidator _validator;
    private readonly AreRunService _runService;
    private readonly AppLogger _logger;

    private string _areSourcePath = "";
    private string _wordTemplatePath = "";
    private string _serialDataPath = "";
    private string _logoPath = "";
    private string _outputFolder;
    private string _statusMessage = "Bitte alle benötigten Dateien auswählen und anschließend die Eingaben prüfen.";
    private double _progressValue;
    private bool _isBusy;
    private bool _createExcelOutput = true;
    private bool _createArePdfs = true;
    private bool _createLetters = true;
    private bool _createAggregate = true;
    private string? _lastOutputFolder;

    public MainViewModel(DialogService dialogs, InputValidator validator, AreRunService runService, AppLogger logger)
    {
        _dialogs = dialogs;
        _validator = validator;
        _runService = runService;
        _logger = logger;
        _outputFolder = Path.Combine(Environment.CurrentDirectory, "Output");

        BrowseAreSourceCommand = new RelayCommand(BrowseAreSource, () => !IsBusy);
        BrowseWordTemplateCommand = new RelayCommand(BrowseWordTemplate, () => !IsBusy);
        BrowseSerialDataCommand = new RelayCommand(BrowseSerialData, () => !IsBusy);
        BrowseLogoCommand = new RelayCommand(BrowseLogo, () => !IsBusy);
        BrowseOutputFolderCommand = new RelayCommand(BrowseOutputFolder, () => !IsBusy);
        ValidateCommand = new AsyncRelayCommand(ValidateAsync, () => !IsBusy);
        RunCommand = new AsyncRelayCommand(RunAsync, () => !IsBusy);
        OpenLastOutputCommand = new RelayCommand(() => { if (!string.IsNullOrWhiteSpace(_lastOutputFolder)) AreRunService.OpenFolder(_lastOutputFolder); }, () => Directory.Exists(_lastOutputFolder));
        OpenCurrentLogCommand = new RelayCommand(
            () => { if (!string.IsNullOrWhiteSpace(_logger.PersistentLogPath)) AreRunService.OpenFile(_logger.PersistentLogPath); },
            () => File.Exists(_logger.PersistentLogPath));

        _logger.LineWritten += line => Application.Current.Dispatcher.BeginInvoke(() =>
        {
            LogLines.Add(line);
            while (LogLines.Count > 250) LogLines.RemoveAt(0);
            OpenCurrentLogCommand.RaiseCanExecuteChanged();
        });
    }

    public ObservableCollection<PreviewItem> PreviewItems { get; } = [];
    public ObservableCollection<string> LogLines { get; } = [];

    public RelayCommand BrowseAreSourceCommand { get; }
    public RelayCommand BrowseWordTemplateCommand { get; }
    public RelayCommand BrowseSerialDataCommand { get; }
    public RelayCommand BrowseLogoCommand { get; }
    public RelayCommand BrowseOutputFolderCommand { get; }
    public AsyncRelayCommand ValidateCommand { get; }
    public AsyncRelayCommand RunCommand { get; }
    public RelayCommand OpenLastOutputCommand { get; }
    public RelayCommand OpenCurrentLogCommand { get; }

    public string AreSourcePath { get => _areSourcePath; set => SetProperty(ref _areSourcePath, value); }
    public string WordTemplatePath { get => _wordTemplatePath; set => SetProperty(ref _wordTemplatePath, value); }
    public string SerialDataPath { get => _serialDataPath; set => SetProperty(ref _serialDataPath, value); }
    public string LogoPath { get => _logoPath; set => SetProperty(ref _logoPath, value); }
    public string OutputFolder { get => _outputFolder; set => SetProperty(ref _outputFolder, value); }
    public string StatusMessage { get => _statusMessage; set => SetProperty(ref _statusMessage, value); }
    public double ProgressValue { get => _progressValue; set => SetProperty(ref _progressValue, value); }
    public bool CreateExcelOutput { get => _createExcelOutput; set => SetProperty(ref _createExcelOutput, value); }
    public bool CreateArePdfs { get => _createArePdfs; set => SetProperty(ref _createArePdfs, value); }
    public bool CreateLetters { get => _createLetters; set => SetProperty(ref _createLetters, value); }
    public bool CreateAggregate { get => _createAggregate; set => SetProperty(ref _createAggregate, value); }

    public bool IsBusy
    {
        get => _isBusy;
        private set
        {
            if (!SetProperty(ref _isBusy, value)) return;
            RaiseCommands();
        }
    }

    private void BrowseAreSource()
    {
        var path = _dialogs.SelectFile("ARE-Quelldatei mit Übersicht und Gesellschaften auswählen", "Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm");
        if (path is not null) AreSourcePath = path;
    }

    private void BrowseWordTemplate()
    {
        var path = _dialogs.SelectFile("DOCX-Serienbriefvorlage auswählen", "Word-Dokumente (*.docx)|*.docx");
        if (path is not null) WordTemplatePath = path;
    }

    private void BrowseSerialData()
    {
        var path = _dialogs.SelectFile("Excel-Datei mit Serienbrief-/Empfängerdaten auswählen", "Excel-Dateien (*.xlsx;*.xlsm;*.xls)|*.xlsx;*.xlsm;*.xls");
        if (path is not null) SerialDataPath = path;
    }

    private void BrowseLogo()
    {
        var path = _dialogs.SelectFile("Mercer-Logo auswählen (optional)", "Bilddateien (*.png;*.jpg;*.jpeg)|*.png;*.jpg;*.jpeg");
        if (path is not null) LogoPath = path;
    }

    private void BrowseOutputFolder()
    {
        var path = _dialogs.SelectFolder("Ausgabeordner auswählen", OutputFolder);
        if (path is not null) OutputFolder = path;
    }

    private async Task ValidateAsync()
    {
        IsBusy = true;
        ProgressValue = 0;
        PreviewItems.Clear();
        try
        {
            var progress = CreateProgress();
            var snapshot = await _validator.ValidateAsync(BuildInput(), progress);
            foreach (var item in snapshot.Preview) PreviewItems.Add(item);
            StatusMessage = snapshot.Warnings.Count == 0
                ? $"Bereit: {snapshot.Reports.Count} betroffene Gesellschaften, {snapshot.AffectedSerialRecords.Count} Anschreiben."
                : $"Prüfung erfolgreich mit {snapshot.Warnings.Count} Hinweis(en). Details rechts im Diagnosebereich.";
            foreach (var warning in snapshot.Warnings) _logger.Warn(warning);
        }
        catch (Exception ex)
        {
            StatusMessage = "Prüfung fehlgeschlagen: " + ex.Message;
            _logger.Error(ex.ToString());
            MessageBox.Show(ex.Message, "ARE Automatisierung – Prüfung", MessageBoxButton.OK, MessageBoxImage.Error);
        }
        finally
        {
            IsBusy = false;
        }
    }

    private async Task RunAsync()
    {
        IsBusy = true;
        ProgressValue = 0;
        PreviewItems.Clear();
        try
        {
            var progress = CreateProgress();
            var result = await _runService.RunAsync(BuildInput(), progress);
            _lastOutputFolder = result.RunFolder;
            OpenLastOutputCommand.RaiseCanExecuteChanged();
            OpenCurrentLogCommand.RaiseCanExecuteChanged();
            StatusMessage = $"Fertig. Ausgabe: {result.RunFolder}";
            MessageBox.Show($"Die ARE-Auswertung wurde erfolgreich erstellt.\n\n{result.RunFolder}", "ARE Automatisierung", MessageBoxButton.OK, MessageBoxImage.Information);
        }
        catch (Exception ex)
        {
            StatusMessage = "Verarbeitung fehlgeschlagen: " + ex.Message;
            _logger.Error(ex.ToString());
            var logPath = _logger.PersistentLogPath ?? _logger.CurrentLogPath ?? "noch kein Laufprotokoll";
            MessageBox.Show(
                $"Die ARE-Auswertung konnte nicht erstellt werden.\n\n{ex.Message}\n\nSeparate Logdatei:\n{logPath}",
                "ARE Automatisierung",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            OpenCurrentLogCommand.RaiseCanExecuteChanged();
        }
        finally
        {
            IsBusy = false;
        }
    }

    private Progress<RunProgress> CreateProgress() => new(p =>
    {
        ProgressValue = Math.Clamp(p.Percent, 0, 100);
        StatusMessage = string.IsNullOrWhiteSpace(p.Detail) ? p.Stage : $"{p.Stage} – {p.Detail}";
    });

    private InputSelection BuildInput() => new(
        AreSourcePath.Trim(),
        WordTemplatePath.Trim(),
        SerialDataPath.Trim(),
        OutputFolder.Trim(),
        string.IsNullOrWhiteSpace(LogoPath) ? null : LogoPath.Trim(),
        CreateExcelOutput,
        CreateArePdfs,
        CreateLetters,
        CreateAggregate);

    private void RaiseCommands()
    {
        BrowseAreSourceCommand.RaiseCanExecuteChanged();
        BrowseWordTemplateCommand.RaiseCanExecuteChanged();
        BrowseSerialDataCommand.RaiseCanExecuteChanged();
        BrowseLogoCommand.RaiseCanExecuteChanged();
        BrowseOutputFolderCommand.RaiseCanExecuteChanged();
        ValidateCommand.RaiseCanExecuteChanged();
        RunCommand.RaiseCanExecuteChanged();
        OpenLastOutputCommand.RaiseCanExecuteChanged();
        OpenCurrentLogCommand.RaiseCanExecuteChanged();
    }
}
