using System.Windows;
using System.Windows.Threading;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Services.Core;
using ARE.Automatisierung.Services.Excel;
using ARE.Automatisierung.Services.Pdf;
using ARE.Automatisierung.Services.Run;
using ARE.Automatisierung.Services.Word;
using ARE.Automatisierung.ViewModels;

namespace ARE.Automatisierung;

public partial class App : Application
{
    private AppLogger? _logger;

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        _logger = new AppLogger();
        _logger.StartSession();

        // Sicherheitsnetz: Auch Fehler außerhalb des normalen RunAsync-Catch landen
        // in der persistenten Logdatei unter .\Logs.
        DispatcherUnhandledException += OnDispatcherUnhandledException;
        AppDomain.CurrentDomain.UnhandledException += OnUnhandledException;
        TaskScheduler.UnobservedTaskException += OnUnobservedTaskException;

        var dialogs = new DialogService();
        var headerNormalizer = new HeaderNormalizer();
        var sourceReader = new SourceWorkbookReader(headerNormalizer, _logger);
        var legacyReader = new LegacyXlsComReader(_logger);
        var serialReader = new SerialDataReader(headerNormalizer, legacyReader, _logger);
        var engine = new AreEngine(_logger);
        var officePreflight = new OfficePreflightService();
        var templateInspector = new DocxTemplateInspector();
        var excelWriter = new ExcelComOutputWriter(_logger);
        var wordService = new WordComLetterService(headerNormalizer, _logger);
        var pdfMerge = new PdfMergeService(_logger);
        var validator = new InputValidator(sourceReader, serialReader, engine, officePreflight, templateInspector, _logger);
        var runService = new AreRunService(validator, excelWriter, wordService, pdfMerge, _logger);

        var viewModel = new MainViewModel(dialogs, validator, runService, _logger);
        var window = new MainWindow { DataContext = viewModel };
        window.Show();
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        _logger?.Error("UNBEHANDELT-WPF | " + e.Exception);
        // Nicht pauschal weiterlaufen: der normale WPF-Abbruchmechanismus bleibt erhalten.
        e.Handled = false;
    }

    private void OnUnhandledException(object? sender, UnhandledExceptionEventArgs e)
    {
        _logger?.Error("UNBEHANDELT-APPDOMAIN | " + (e.ExceptionObject?.ToString() ?? "unbekannter Fehler"));
    }

    private void OnUnobservedTaskException(object? sender, UnobservedTaskExceptionEventArgs e)
    {
        _logger?.Error("UNBEHANDELT-TASK | " + e.Exception);
        e.SetObserved();
    }
}
