using System.Runtime.InteropServices;
using ARE.Automatisierung.Infrastructure;
using ARE.Automatisierung.Models;
using ARE.Automatisierung.Services.Core;

namespace ARE.Automatisierung.Services.Excel;

public sealed class ExcelComOutputWriter(AppLogger logger)
{
    private const int XlTypePdf = 0;
    private const int XlQualityStandard = 0;
    private const int XlPortrait = 1;
    private const int XlCenter = -4108;
    private const int XlLeft = -4131;
    private const int XlRight = -4152;
    private const int XlContinuous = 1;
    private const int XlThin = 2;
    private const int XlMedium = -4138;
    private const int XlManual = -4135;
    private const int XlAutomatic = -4105;
    private const int MsoFalse = 0;
    private const int MsoTrue = -1;
    private static readonly int MarshNavy = Rgb(0, 15, 71);

    public Task<IReadOnlyDictionary<long, string>> WriteAsync(
        string workbookPath,
        IReadOnlyList<AreReport> reports,
        string pdfFolder,
        string? logoPath,
        bool createPdfs,
        IProgress<RunProgress>? progress = null,
        CancellationToken token = default) =>
        StaThreadRunner.RunAsync<IReadOnlyDictionary<long, string>>(() => Write(workbookPath, reports, pdfFolder, logoPath, createPdfs, progress), token);

    private IReadOnlyDictionary<long, string> Write(
        string workbookPath,
        IReadOnlyList<AreReport> reports,
        string pdfFolder,
        string? logoPath,
        bool createPdfs,
        IProgress<RunProgress>? progress)
    {
        var excelType = Type.GetTypeFromProgID("Excel.Application") ??
            throw new InvalidOperationException("Microsoft Excel Desktop wurde nicht gefunden. Für die finale XLSX/XLSM-Ausgabe und den druckgetreuen PDF-Export wird Excel als unsichtbare Rendering-Schicht benötigt.");

        dynamic? excel = null;
        dynamic? wb = null;
        var pdfs = new Dictionary<long, string>();
        var stage = "Excel initialisieren";
        object? oldCalculation = null;
        var workbookSaved = false;

        try
        {
            Directory.CreateDirectory(pdfFolder);
            logger.Info($"EXCEL | Start | Datei={workbookPath} | Pfadlänge={workbookPath.Length}");

            stage = "Excel.Application starten";
            logger.Info($"EXCEL-PHASE | {stage}");
            excel = Activator.CreateInstance(excelType)!;
            excel.Visible = false;
            excel.DisplayAlerts = false;
            excel.ScreenUpdating = false;
            excel.EnableEvents = false;

            // Calculation erst NACH dem Öffnen einer Arbeitsmappe setzen.
            // Excel kann sonst mit dem generischen Fehler 1004 / 0x800A03EC abbrechen.
            stage = "Ausgabearbeitsmappe öffnen";
            logger.Info($"EXCEL-PHASE | {stage}");
            COMException? openError = null;
            for (var attempt = 1; attempt <= 2 && wb is null; attempt++)
            {
                try
                {
                    wb = excel.Workbooks.Open(workbookPath, 0, false);
                }
                catch (COMException ex)
                {
                    openError = ex;
                    logger.Warn($"EXCEL | Workbooks.Open Versuch {attempt} fehlgeschlagen | HRESULT=0x{ex.HResult:X8} | {ex.Message}");
                    if (attempt < 2) Thread.Sleep(400);
                }
            }

            if (wb is null)
            {
                var hint = workbookPath.Length > 210
                    ? " Der Pfad ist für Excel ungewöhnlich lang; preview4 verwendet deshalb zusätzlich kurze Ausgabeordner und Dateinamen."
                    : string.Empty;
                var openHresult = openError?.HResult ?? 0;
                throw new InvalidOperationException(
                    $"Excel konnte die Ausgabekopie nicht öffnen. HRESULT=0x{openHresult:X8}.{hint} Datei: {workbookPath}",
                    openError);
            }

            stage = "Excel-Berechnungsmodus vorbereiten";
            logger.Info($"EXCEL-PHASE | {stage}");
            try
            {
                oldCalculation = excel.Calculation;
                excel.Calculation = XlManual;
            }
            catch (COMException ex)
            {
                // Der Berechnungsmodus ist eine Optimierung, keine fachliche Voraussetzung.
                logger.Warn($"EXCEL | Berechnungsmodus konnte nicht auf manuell gesetzt werden; Verarbeitung läuft weiter. HRESULT=0x{ex.HResult:X8} | {ex.Message}");
            }

            stage = "Alte ARE-Blätter entfernen";
            logger.Info($"EXCEL-PHASE | {stage}");
            DeleteOldAreSheets(wb);

            for (var i = 0; i < reports.Count; i++)
            {
                var report = reports[i];
                progress?.Report(new RunProgress(45 + 20d * (i + 1) / Math.Max(1, reports.Count), "ARE-Blätter erzeugen", $"LTRG {report.Target.LtrgText}"));
                dynamic? ws = null;
                try
                {
                    stage = $"Arbeitsblatt für LTRG {report.Target.LtrgText} anlegen";
                    logger.Info($"EXCEL-PHASE | {stage}");
                    ws = AddWorksheetAtEnd(wb);
                    ws.Name = UniqueSheetName(wb, report.SheetName);

                    stage = $"Arbeitsblatt für LTRG {report.Target.LtrgText} befüllen";
                    logger.Info($"EXCEL-PHASE | {stage}");
                    BuildSheet(excel, ws, report, logoPath);

                    if (createPdfs)
                    {
                        stage = $"ARE-PDF für LTRG {report.Target.LtrgText} exportieren";
                        logger.Info($"EXCEL-PHASE | {stage}");
                        var sheetName = Convert.ToString(ws.Name) ?? report.SheetName;
                        var pdfPath = Path.Combine(pdfFolder, $"ERG_VWÜ_{SanitizeFileName(sheetName)}.pdf");
                        ws.ExportAsFixedFormat(XlTypePdf, pdfPath, XlQualityStandard, true, false);
                        pdfs[report.Target.Ltrg] = pdfPath;
                        logger.Info($"ARE-PDF | {pdfPath}");
                    }
                }
                finally
                {
                    ComHelpers.FinalRelease(ws);
                }
            }

            stage = "Ausgabearbeitsmappe speichern";
            logger.Info($"EXCEL-PHASE | {stage}");
            try
            {
                excel.Calculation = XlAutomatic;
                excel.CalculateFull();
            }
            catch (COMException ex)
            {
                logger.Warn($"EXCEL | Vollberechnung konnte nicht erzwungen werden; Speichern wird fortgesetzt. HRESULT=0x{ex.HResult:X8} | {ex.Message}");
            }

            wb.Save();
            workbookSaved = true;
            logger.Info($"EXCEL | Ausgabekopie gespeichert: {workbookPath}");
            return pdfs;
        }
        catch (COMException ex)
        {
            logger.Error($"EXCEL-COM | Phase={stage} | HRESULT=0x{ex.HResult:X8} | {ex.Message}");
            throw new InvalidOperationException(
                $"Excel-Fehler in der Phase „{stage}“ (HRESULT 0x{ex.HResult:X8}). " +
                $"Details stehen in der separaten Logdatei: {logger.PersistentLogPath ?? logger.CurrentLogPath}",
                ex);
        }
        catch (Exception ex)
        {
            logger.Error($"EXCEL | Phase={stage} | {ex}");
            throw;
        }
        finally
        {
            try
            {
                if (wb is not null) wb.Close(workbookSaved);
            }
            catch { }

            try
            {
                if (excel is not null)
                {
                    try
                    {
                        if (oldCalculation is not null) excel.Calculation = oldCalculation;
                    }
                    catch { }
                    try { excel.ScreenUpdating = true; } catch { }
                    try { excel.EnableEvents = true; } catch { }
                    try { excel.DisplayAlerts = true; } catch { }
                    excel.Quit();
                }
            }
            catch { }

            ComHelpers.FinalRelease(wb);
            ComHelpers.FinalRelease(excel);
        }
    }

    private dynamic AddWorksheetAtEnd(dynamic wb)
    {
        if (Convert.ToBoolean(wb.ProtectStructure))
            throw new InvalidOperationException("Die Struktur der Arbeitsmappe ist geschützt. Bitte den Arbeitsmappenschutz in Excel aufheben und erneut starten.");

        wb.Activate();

        dynamic? anchor = null;
        try
        {
            // Nicht blind Worksheets[1].Activate() verwenden: das erste Blatt kann
            // verborgen sein. Wir aktivieren das erste sichtbare Arbeitsblatt.
            for (var i = 1; i <= (int)wb.Worksheets.Count; i++)
            {
                dynamic? candidate = null;
                try
                {
                    candidate = wb.Worksheets[i];
                    if (Convert.ToInt32(candidate.Visible) == -1)
                    {
                        anchor = candidate;
                        candidate = null; // ownership transferred to anchor
                        break;
                    }
                }
                finally
                {
                    ComHelpers.FinalRelease(candidate);
                }
            }

            if (anchor is not null) anchor.Activate();

            dynamic? ws = null;
            COMException? firstError = null;
            for (var attempt = 1; attempt <= 2 && ws is null; attempt++)
            {
                try
                {
                    ws = wb.Worksheets.Add();
                }
                catch (COMException ex)
                {
                    firstError ??= ex;
                    logger.Warn($"EXCEL | Worksheets.Add Versuch {attempt} fehlgeschlagen | HRESULT=0x{ex.HResult:X8} | {ex.Message}");
                    if (attempt < 2) Thread.Sleep(300);
                }
            }

            if (ws is null)
            {
                var hresult = firstError?.HResult ?? 0;
                throw new InvalidOperationException(
                    $"Excel konnte kein neues ARE-Arbeitsblatt anlegen. " +
                    $"HRESULT=0x{hresult:X8}. Prüfen Sie insbesondere den Arbeitsmappenschutz.",
                    firstError);
            }

            if ((int)wb.Worksheets.Count > 1)
            {
                dynamic? last = null;
                try
                {
                    last = wb.Worksheets[wb.Worksheets.Count];
                    var isAlreadyLast = string.Equals(Convert.ToString(ws.Name), Convert.ToString(last.Name), StringComparison.OrdinalIgnoreCase);
                    if (!isAlreadyLast)
                    {
                        try { ws.Move(Type.Missing, last); }
                        catch (COMException ex)
                        {
                            // Reihenfolge ist fachlich nicht kritisch.
                            logger.Warn($"EXCEL | Neues ARE-Blatt konnte nicht ans Ende verschoben werden | HRESULT=0x{ex.HResult:X8} | {ex.Message}");
                        }
                    }
                }
                finally { ComHelpers.FinalRelease(last); }
            }

            return ws;
        }
        finally
        {
            ComHelpers.FinalRelease(anchor);
        }
    }

    private static void DeleteOldAreSheets(dynamic wb)
    {
        for (var i = (int)wb.Worksheets.Count; i >= 1; i--)
        {
            dynamic? ws = null;
            try
            {
                ws = wb.Worksheets[i];
                var name = Convert.ToString(ws.Name) ?? "";
                if (name.StartsWith("ARE ", StringComparison.OrdinalIgnoreCase)) ws.Delete();
            }
            finally { ComHelpers.FinalRelease(ws); }
        }
    }

    private void BuildSheet(dynamic excel, dynamic ws, AreReport report, string? logoPath)
    {
        ws.Cells.Clear();
        ws.Range("E1:F1").Merge();
        ws.Range("E2:F2").Merge();
        ws.Range("A4:F4").Merge();
        ws.Range("A6:F6").Merge();
        ws.Range("A7:F7").Merge();

        ws.Range("E1").Value2 = $"Einzelübertritte {report.ReportPeriod}";
        ws.Range("E2").Value2 = $"ARE {(string.IsNullOrWhiteSpace(report.Target.Are) ? "n.v." : report.Target.Are)} (LTRG {report.Target.LtrgText})";
        ws.Range("A4").Value2 = "Übertragene Rückstellungen bei Einzelübertritten";
        ws.Range("A6").Value2 = $"Positive Beträge erhält die {report.Target.ShortName} von der genannten Gesellschaft,";
        ws.Range("A7").Value2 = $"negative Beträge gibt die {report.Target.ShortName} an die genannte Gesellschaft ab.";

        ws.Range("H1").Value2 = "CHECK";
        ws.Range("I1").Value2 = "ORZ, OK";
        ws.Range("H2").Value2 = report.Target.Ltrg;
        ws.Range("I2").Value2 = report.Target.Are;
        ws.Range("J2").Value2 = report.Target.Name;
        ws.Range("H3").Value2 = "CHECK";
        ws.Range("H4").Value2 = report.NetBalance;
        ws.Range("I4").Value2 = report.ControlDelta;

        dynamic all = ws.Cells;
        all.Font.Name = "Arial";
        all.Font.Size = 10;
        all.VerticalAlignment = XlCenter;
        ComHelpers.FinalRelease(all);

        ws.Range("A1:F5000").Font.Color = MarshNavy;
        ws.Range("E1:F2").HorizontalAlignment = XlCenter;
        ws.Range("A4:F4").Font.Bold = true;
        ws.Range("A4:F4").Font.Size = 15;
        ws.Range("A4:F4").HorizontalAlignment = XlCenter;
        ws.Range("A6:F7").Font.Size = 9;
        ws.Range("A6:F7").WrapText = true;
        ws.Range("A6:F7").HorizontalAlignment = XlLeft;
        ws.Rows[6].RowHeight = 28;
        ws.Rows[7].RowHeight = 28;

        ws.Columns["A"].ColumnWidth = 12;
        ws.Columns["B"].ColumnWidth = 12;
        ws.Columns["C"].ColumnWidth = 12;
        ws.Columns["D"].ColumnWidth = 17.5;
        ws.Columns["E"].ColumnWidth = 12.5;
        ws.Columns["F"].ColumnWidth = 12.5;
        ws.Columns["G"].ColumnWidth = 3;
        ws.Columns["H"].ColumnWidth = 9;
        ws.Columns["I"].ColumnWidth = 9;
        ws.Columns["J"].ColumnWidth = 40;
        ws.Columns["A:B"].NumberFormat = "0";
        ws.Columns["C"].NumberFormat = "dd.mm.yyyy";
        ws.Columns["D:F"].NumberFormat = "#,##0;-#,##0";
        ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0";

        var currentRow = 10;
        foreach (var group in report.Groups)
        {
            var sectionRow = currentRow;
            var headerRow = sectionRow + 1;
            var dataStart = headerRow + 1;
            var dataEnd = dataStart + group.Rows.Count - 1;
            var subtotalRow = dataEnd + 1;

            ws.Range(ws.Cells[sectionRow, 1], ws.Cells[sectionRow, 6]).Merge();
            ws.Cells[sectionRow, 1].Value2 = $"{group.Counterparty.ShortName} (ARE {(string.IsNullOrWhiteSpace(group.Counterparty.Are) ? "n.v." : group.Counterparty.Are)}, LTRG {group.Counterparty.LtrgText})";
            ws.Cells[sectionRow, 8].Value2 = group.Counterparty.Ltrg;
            ws.Cells[sectionRow, 9].Value2 = group.Counterparty.Are;
            ws.Cells[sectionRow, 10].Value2 = group.Counterparty.Name;

            var headings = new object[1, 6] { { "PNR", "alte PNR", "Übertritt", "Pensionen (alt)\n(Euro)", "BSAV\n(Euro)", "Summe\n(Euro)" } };
            ws.Range(ws.Cells[headerRow, 1], ws.Cells[headerRow, 6]).Value2 = headings;

            if (group.Rows.Count > 0)
            {
                var matrix = new object[group.Rows.Count, 6];
                for (var r = 0; r < group.Rows.Count; r++)
                {
                    var row = group.Rows[r];
                    matrix[r, 0] = row.Pnr;
                    matrix[r, 1] = row.OldPnr;
                    matrix[r, 2] = row.TransferDate.HasValue
                        ? row.TransferDate.Value.ToOADate()
                        : string.Empty;
                    matrix[r, 3] = row.Pension;
                    matrix[r, 4] = row.Bsav;
                    matrix[r, 5] = row.Total;
                }
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 6]).Value2 = matrix;
            }

            ws.Cells[subtotalRow, 4].Value2 = group.PensionSubtotal;
            ws.Cells[subtotalRow, 5].Value2 = group.BsavSubtotal;
            ws.Cells[subtotalRow, 6].Value2 = group.TotalSubtotal;

            dynamic section = ws.Range(ws.Cells[sectionRow, 1], ws.Cells[sectionRow, 6]);
            section.Font.Bold = true;
            section.HorizontalAlignment = XlCenter;
            section.Borders.LineStyle = XlContinuous;
            section.Borders.Weight = XlMedium;
            ws.Rows[sectionRow].RowHeight = 19;
            ComHelpers.FinalRelease(section);

            dynamic header = ws.Range(ws.Cells[headerRow, 1], ws.Cells[headerRow, 6]);
            header.Font.Bold = true;
            header.HorizontalAlignment = XlCenter;
            header.WrapText = true;
            ws.Rows[headerRow].RowHeight = 31;
            ComHelpers.FinalRelease(header);

            if (group.Rows.Count > 0)
            {
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 3]).HorizontalAlignment = XlCenter;
                ws.Range(ws.Cells[dataStart, 4], ws.Cells[dataEnd, 6]).HorizontalAlignment = XlRight;
                ws.Range(ws.Cells[dataStart, 1], ws.Cells[dataEnd, 6]).RowHeight = 15;
            }
            dynamic subtotal = ws.Range(ws.Cells[subtotalRow, 4], ws.Cells[subtotalRow, 6]);
            subtotal.Font.Bold = true;
            subtotal.Borders.LineStyle = 0;
            subtotal.Borders[8].LineStyle = XlContinuous;
            subtotal.Borders[8].Weight = XlThin;
            ComHelpers.FinalRelease(subtotal);
            ws.Rows[subtotalRow].RowHeight = 15;
            ws.Rows[subtotalRow + 1].RowHeight = 8;

            currentRow = subtotalRow + 2;
        }

        var lastContentRow = Math.Max(7, currentRow - 1);
        ws.Range($"A1:F{lastContentRow}").Font.Color = MarshNavy;
        ConfigurePageSetupSafely(excel, ws, lastContentRow, report.Target.LtrgText);

        if (!string.IsNullOrWhiteSpace(logoPath) && File.Exists(logoPath))
        {
            try
            {
                dynamic anchor = ws.Range("A1");
                dynamic picture = ws.Shapes.AddPicture(logoPath, MsoFalse, MsoTrue, anchor.Left, anchor.Top + 2, -1, -1);
                picture.Name = "ARE_Mercer_Logo";
                picture.LockAspectRatio = MsoTrue;
                picture.Height = 34;
                ComHelpers.FinalRelease(picture);
                ComHelpers.FinalRelease(anchor);
            }
            catch { /* logo is optional in v2 */ }
        }
    }

    private void ConfigurePageSetupSafely(dynamic excel, dynamic ws, int lastContentRow, string ltrgText)
    {
        try
        {
            // PageSetup kann auf einigen Firmenrechnern Fehler 1004 werfen,
            // z.B. bei einem nicht verfügbaren Standarddrucker. Layoutoptionen
            // dürfen deshalb die fachliche Erstellung des ARE-Blatts nicht stoppen.
            dynamic pageSetup = ws.PageSetup;
            try
            {
                pageSetup.PrintArea = $"$A$1:$F${lastContentRow}";
                pageSetup.PrintGridlines = false;
                pageSetup.Orientation = XlPortrait;
                pageSetup.Zoom = false;
                pageSetup.FitToPagesWide = 1;
                pageSetup.FitToPagesTall = false;
                pageSetup.CenterHorizontally = true;
                pageSetup.LeftMargin = excel.CentimetersToPoints(1.2);
                pageSetup.RightMargin = excel.CentimetersToPoints(1.2);
                pageSetup.TopMargin = excel.CentimetersToPoints(1.0);
                pageSetup.BottomMargin = excel.CentimetersToPoints(1.0);
                pageSetup.HeaderMargin = excel.CentimetersToPoints(0.4);
                pageSetup.FooterMargin = excel.CentimetersToPoints(0.4);
            }
            finally
            {
                ComHelpers.FinalRelease(pageSetup);
            }
        }
        catch (COMException ex)
        {
            logger.Warn($"EXCEL | PageSetup für LTRG {ltrgText} teilweise übersprungen | HRESULT=0x{ex.HResult:X8} | {ex.Message}");
        }
    }

    private static string UniqueSheetName(dynamic wb, string requested)
    {
        var baseName = requested.Length <= 31 ? requested : requested[..31];
        var candidate = baseName;
        var counter = 2;
        while (SheetExists(wb, candidate))
        {
            var suffix = $"_{counter++}";
            candidate = baseName[..Math.Min(baseName.Length, 31 - suffix.Length)] + suffix;
        }
        return candidate;
    }

    private static bool SheetExists(dynamic wb, string name)
    {
        for (var i = 1; i <= (int)wb.Worksheets.Count; i++)
        {
            dynamic? ws = null;
            try
            {
                ws = wb.Worksheets[i];
                if (string.Equals(Convert.ToString(ws.Name), name, StringComparison.OrdinalIgnoreCase)) return true;
            }
            finally { ComHelpers.FinalRelease(ws); }
        }
        return false;
    }

    private static string SanitizeFileName(string value)
    {
        foreach (var c in Path.GetInvalidFileNameChars()) value = value.Replace(c, '-');
        return value;
    }

    private static int Rgb(int r, int g, int b) => r + g * 256 + b * 65536;
}
