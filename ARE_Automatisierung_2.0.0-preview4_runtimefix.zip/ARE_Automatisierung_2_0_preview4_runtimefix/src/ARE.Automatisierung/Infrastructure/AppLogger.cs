using System.Collections.Concurrent;
using System.Text;

namespace ARE.Automatisierung.Infrastructure;

public sealed class AppLogger
{
    private const string Version = "2.0.0-preview4";
    private readonly ConcurrentQueue<string> _lines = new();
    private readonly object _fileLock = new();
    private readonly List<string> _activeLogPaths = [];

    public event Action<string>? LineWritten;
    public string? CurrentLogPath { get; private set; }
    public string? PersistentLogPath { get; private set; }

    /// <summary>
    /// Starts a persistent application-session log. It is intentionally independent
    /// of the selected output folder, so validation and runtime failures always leave
    /// a copyable log behind.
    /// </summary>
    public void StartSession()
    {
        if (!string.IsNullOrWhiteSpace(PersistentLogPath)) return;

        var stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss_fff");
        var persistentFolder = ResolvePersistentLogFolder();
        Directory.CreateDirectory(persistentFolder);
        PersistentLogPath = Path.Combine(persistentFolder, $"ARE_Automatisierung_{stamp}.log");

        lock (_fileLock)
        {
            _activeLogPaths.Clear();
            AddLogPathIfWritable(PersistentLogPath);
        }

        WriteHeader(PersistentLogPath);
        Info($"START | Version {Version}");
        Info($"LOGDATEI | {PersistentLogPath}");
    }

    /// <summary>
    /// Adds a second diagnostic copy inside the concrete run/output folder.
    /// The persistent session log remains active in parallel.
    /// </summary>
    public void StartRun(string runFolder)
    {
        StartSession();
        Directory.CreateDirectory(runFolder);

        var previousRunLog = CurrentLogPath;
        CurrentLogPath = Path.Combine(runFolder, "ARE_Automatisierung_Diagnose.log");

        lock (_fileLock)
        {
            if (!string.IsNullOrWhiteSpace(previousRunLog))
                _activeLogPaths.RemoveAll(p => string.Equals(p, previousRunLog, StringComparison.OrdinalIgnoreCase));
            AddLogPathIfWritable(CurrentLogPath);
        }

        WriteHeader(CurrentLogPath);
        Info($"LAUF-BEGINN | {DateTime.Now:yyyy-MM-dd HH:mm:ss}");
        Info($"LAUFPROTOKOLL | {CurrentLogPath}");
    }

    public void Info(string message) => Write("INFO", message);
    public void Warn(string message) => Write("WARNUNG", message);
    public void Error(string message) => Write("FEHLER", message);

    private string ResolvePersistentLogFolder()
    {
        var preferred = Path.Combine(Environment.CurrentDirectory, "Logs");
        try
        {
            Directory.CreateDirectory(preferred);
            var testFile = Path.Combine(preferred, $".write_test_{Guid.NewGuid():N}.tmp");
            File.WriteAllText(testFile, "ok", Encoding.UTF8);
            File.Delete(testFile);
            return preferred;
        }
        catch
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "ARE_Automatisierung",
                "Logs");
        }
    }

    private void AddLogPathIfWritable(string path)
    {
        if (_activeLogPaths.Any(p => string.Equals(p, path, StringComparison.OrdinalIgnoreCase))) return;

        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(path)!);
            File.WriteAllText(path, string.Empty, Encoding.UTF8);
            _activeLogPaths.Add(path);
        }
        catch
        {
            // Logging must never abort the business process.
        }
    }

    private static void WriteHeader(string? path)
    {
        if (string.IsNullOrWhiteSpace(path)) return;

        var header =
            $"ARE Automatisierung Diagnose{Environment.NewLine}" +
            $"Version: {Version}{Environment.NewLine}" +
            $"Zeit: {DateTime.Now:yyyy-MM-dd HH:mm:ss}{Environment.NewLine}" +
            $"Computer: {Environment.MachineName}{Environment.NewLine}" +
            $"Benutzer: {Environment.UserName}{Environment.NewLine}" +
            $"Arbeitsordner: {Environment.CurrentDirectory}{Environment.NewLine}" +
            new string('-', 100) + Environment.NewLine;

        try { File.AppendAllText(path, header, Encoding.UTF8); }
        catch { }
    }

    private void Write(string level, string message)
    {
        var line = $"{DateTime.Now:yyyy-MM-dd HH:mm:ss} | {level} | {message}";
        _lines.Enqueue(line);
        if (_lines.Count > 500) _lines.TryDequeue(out _);

        lock (_fileLock)
        {
            foreach (var path in _activeLogPaths.ToArray())
            {
                try { File.AppendAllText(path, line + Environment.NewLine, Encoding.UTF8); }
                catch { _activeLogPaths.Remove(path); }
            }
        }

        LineWritten?.Invoke(line);
    }
}
