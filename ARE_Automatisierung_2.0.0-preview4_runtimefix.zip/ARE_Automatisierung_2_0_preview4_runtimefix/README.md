# ARE Automatisierung 2.0

**Version:** 2.0.0-preview4  
**Technologie:** C# 14 / .NET 10 LTS / WPF

Neuaufbau der bisherigen VBA/VBScript-Lösung `Einzelübertritte_ARE_Automatisierung v1.0.22` als Windows-Desktopanwendung.

## Was sich gegenüber v1 geändert hat

- Alle benötigten Dateien werden **vor dem Lauf** in einer Oberfläche ausgewählt.
- XLSX/XLSM-Quelldaten werden mit ClosedXML direkt im Speicher gelesen; kein Excel-Fenster muss dafür geöffnet werden.
- Die Fachlogik ist vollständig von Excel/Word getrennt und als testbare C#-Klassen implementiert.
- Excel wird nur noch **einmal unsichtbar** als finaler Office-Kompatibilitäts-/Rendering-Adapter verwendet. Dadurch bleiben insbesondere XLSM-Makros erhalten und ARE-PDFs entsprechen der Excel-Druckdarstellung.
- Word läuft unsichtbar und – entsprechend der stabilen v1.0.22-Strategie – pro Person isoliert. Bei einem COM-Abbruch wird genau der Datensatz einmal wiederholt.
- Das PDF-Zusammenfügen erfolgt mit PDFsharp direkt auf PDF-Ebene: **Anschreiben zuerst, ARE danach**. Kein Adobe Acrobat und kein Word-PDF-Import erforderlich.
- Fortschritt, Vorschau, Warnungen und Diagnose werden direkt in der App angezeigt.

## Schnellstart

1. Projekt komplett entpacken.
2. `START.bat` doppelklicken.
3. Beim ersten Start verwendet `START.bat` ein vorhandenes .NET-10-SDK. Fehlt es, wird automatisch das portable Setup `INSTALL_DOTNET10_PORTABLE.bat` gestartet (lokal im Projekt, keine Adminrechte).
4. In der App auswählen:
   - ARE-Quelldatei (`.xlsx` / `.xlsm`)
   - Word-Vorlage (`.docx`)
   - Serienbriefdaten (`.xlsx` / `.xlsm` / `.xls`)
   - optional Mercer-Logo
   - Ausgabeordner
5. `Eingaben prüfen` verwenden.
6. Vorschau kontrollieren.
7. `Verarbeitung starten`.

Für die spätere Verteilung an Kollegen empfiehlt sich einmalig `PUBLISH_WIN_X64.bat`. Danach liegt unter `publish/` eine **self-contained** Windows-Version. Auf Kollegenrechnern ist dann kein .NET SDK erforderlich.

## Voraussetzungen

### Laufzeit bei self-contained Publish

- Windows 10/11 x64
- Microsoft Excel Desktop
- Microsoft Word Desktop
- Schreibrecht im Projekt-/Ausgabeordner

### Nur für Build/Entwicklung

- .NET 10 SDK **nur zum Entwickeln/ersten Build**; `START.bat` kann SDK 10.0.400 portabel im Projekt bereitstellen. Für einen Self-Contained-Publish brauchen Kollegen später gar kein .NET.
- Zugriff auf die NuGet-Pakete `ClosedXML 0.105.1` und `PDFsharp 6.2.4`
- in Unternehmensumgebungen ggf. interner NuGet-/Artifactory-Feed

## Ausgabestruktur

```text
Output/
└── <Quelle>_ARE_Export_<YYYYMMDD_HHMMSS>/
    ├── 00_Excel/
    │   └── <Quelle>_ARE_Auswertung.xlsx/.xlsm
    ├── 01_ARE_PDF/
    │   └── ERG_VWÜ_<ARE-Blatt>.pdf
    ├── 02_Serienbrief_Gesamt/
    │   ├── Anschreiben_ARE_Gesamt.docx
    │   └── Anschreiben_ARE_Gesamt.pdf
    ├── 03_Serienbrief_Einzel/
    │   ├── Anschrieben_ARE_<ARE>_LTRG_<LTRG>.docx
    │   └── Anschrieben_ARE_<ARE>_LTRG_<LTRG>.pdf
    └── ARE_Automatisierung_Diagnose.log
```

## Projektstruktur

```text
src/ARE.Automatisierung/
├── Models/                 Datenmodelle ohne Office-Abhängigkeiten
├── Services/Core/          Headererkennung, Validierung, ARE-Fachlogik
├── Services/Excel/         direkter Excel-Read + unsichtbarer Output-Renderer
├── Services/Word/          MERGEFIELDs + DOCX-Erzeugung über isoliertes Word COM
├── Services/Pdf/           PDFsharp-Zusammenführung
├── Services/Run/           Orchestrierung eines kompletten Laufs
├── Infrastructure/         Commands, Logging, STA/COM-Helfer, Dialoge
└── ViewModels/             WPF-Präsentationslogik
```

Die alte v1.0.22 liegt unter `legacy_reference/` nur als fachlich-technische Referenz und wird von v2 nicht ausgeführt.

## Sicherheitsprinzip

Die Original-ARE-Datei, die Serienbriefdaten und die DOCX-Vorlage werden nicht überschrieben. Für die Excel-Ausgabe wird zuerst eine Kopie erstellt und nur diese verändert.

## Status preview2

Die Kernfachlogik und der komplette Ausgabepfad sind umgesetzt. Da Excel-/Word-COM nur unter Windows mit installiertem Office ausführbar ist, muss der erste Praxistest auf dem Zielrechner erfolgen. Siehe `docs/05_Testplan.md`.

## Laufzeitdiagnose ab preview4

Jede Programmsitzung schreibt sofort eine separate Logdatei nach:

`Logs\ARE_Automatisierung_YYYYMMDD_HHMMSS_mmm.log`

Sobald ein konkreter Lauf gestartet wird, wird parallel eine zweite Kopie in den jeweiligen Exportordner geschrieben:

`ARE_Export_YYYYMMDD_HHMMSS\ARE_Automatisierung_Diagnose.log`

Die separate Logdatei kann direkt in der Oberfläche über **Separate Logdatei öffnen** geöffnet werden.

### Excel-Fehler 1004 / 0x800A03EC

preview4 härtet den Excel-COM-Teil gegen mehrere typische Ursachen:

- `Application.Calculation` wird erst nach dem Öffnen der Ausgabearbeitsmappe gesetzt.
- Der Berechnungsmodus ist nicht mehr laufkritisch.
- `Workbooks.Open` und `Worksheets.Add` besitzen einen Retry.
- Das erste sichtbare Arbeitsblatt wird als COM-Anker verwendet.
- PageSetup-Fehler, z. B. bei nicht verfügbarem Standarddrucker, brechen die Fachlogik nicht mehr ab.
- Ausgabeordner und Excel-Dateiname sind deutlich kürzer, damit klassische Excel-Pfadgrenzen nicht getroffen werden.
- Jede Excel-Phase und jedes HRESULT wird in die Logdatei geschrieben.
