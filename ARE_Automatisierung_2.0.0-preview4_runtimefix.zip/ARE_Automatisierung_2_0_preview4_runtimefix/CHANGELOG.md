# Changelog

## 2.0.0-preview4 - 2026-08-20

- Laufzeitfix für Excel COMException `0x800A03EC` / Fehler 1004.
- `Application.Calculation` wird erst nach erfolgreichem Öffnen der Arbeitsmappe gesetzt und ist nicht mehr laufkritisch.
- Excel-COM-Phasen werden einzeln protokolliert, inklusive HRESULT.
- `Worksheets.Add` mit sichtbarem Ankerblatt und Retry gehärtet.
- PageSetup-Fehler (z. B. nicht verfügbarer Standarddrucker) brechen die Fachlogik nicht mehr ab.
- Kürzere Ausgabeordner/-dateinamen zur Vermeidung klassischer Excel-Pfadprobleme.
- Separate dauerhafte Logdatei unter `Logs\ARE_Automatisierung_YYYYMMDD_HHMMSS.log`.
- Zusätzliches Laufprotokoll verbleibt im jeweiligen Exportordner.
- Neuer GUI-Button `Separate Logdatei öffnen`.

## 2.0.0-preview1 - 2026-08-20

- vollständige neue C#/.NET/WPF-Projektarchitektur
- Dateiauswahl aller Inputs vor dem Prozess
- Validierungs-/Vorschauansicht
- dynamische Übersicht-/Gesellschaften-Spaltenerkennung portiert
- LTRG-/ARE-/Gesellschaftslogik aus v1.0.22 portiert
- Vorzeichen-, Gruppierungs-, Nullbetrag- und Kontrollsaldo-Logik portiert
- XLSX/XLSM direkt über ClosedXML lesbar
- XLS-Fallback über unsichtbares Excel COM
- Excel-Ausgabekopie über isolierten unsichtbaren COM-Renderer
- ARE-PDF-Export direkt aus Excel-Druckdarstellung
- Word MERGEFIELD-Ersetzung inkl. Header/Footer/Text-Shapes
- Word-Isolation pro Person und Retry
- native ARE-Anlage im DOCX
- finale Einzel-/Gesamt-PDFs via PDFsharp ohne Adobe/Word-PDF-Import
- START.bat und self-contained Publish-Skript

## 2.0.0-preview3
- Portables .NET 10 SDK 10.0.400 kann ohne Administratorrechte lokal unter `tools/dotnet` installiert werden.
- `START.bat` erkennt zuerst lokalen Publish/Build, danach lokales SDK, danach systemweites SDK.
- Fehlt das SDK, wird `INSTALL_DOTNET10_PORTABLE.bat` automatisch gestartet.
- Offline-/Firmennetz-Fallback: offizielle SDK-ZIP kann manuell in den Projektordner gelegt werden.
- Microsoft-SHA512-Pruefung vor dem Entpacken integriert.
- `PUBLISH_WIN_X64.bat` nutzt ebenfalls das portable SDK.
