@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title ARE Automatisierung 2.0 - Publish
set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
set "DOTNET_CMD="

if exist "%~dp0tools\dotnet\dotnet.exe" (
    "%~dp0tools\dotnet\dotnet.exe" --list-sdks | findstr /R /B "10\." >nul 2>&1
    if not errorlevel 1 set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
)

if not defined DOTNET_CMD (
    where dotnet.exe >nul 2>&1
    if not errorlevel 1 (
        dotnet --list-sdks | findstr /R /B "10\." >nul 2>&1
        if not errorlevel 1 set "DOTNET_CMD=dotnet"
    )
)

if not defined DOTNET_CMD (
    echo Kein .NET 10 SDK gefunden. Starte portables Setup ...
    call "%~dp0INSTALL_DOTNET10_PORTABLE.bat"
    if errorlevel 1 exit /b 1
    set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
)

if exist "%~dp0publish" rmdir /s /q "%~dp0publish"
mkdir "%~dp0publish"

echo NuGet Restore ...
"%DOTNET_CMD%" restore "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj"
if errorlevel 1 goto :ERROR

echo Self-Contained Windows x64 Publish ...
"%DOTNET_CMD%" publish "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" ^
  -c Release ^
  -r win-x64 ^
  --self-contained true ^
  --no-restore ^
  -p:PublishSingleFile=false ^
  -p:DebugType=None ^
  -p:DebugSymbols=false ^
  -o "%~dp0publish"
if errorlevel 1 goto :ERROR

if not exist "%~dp0publish\Output" mkdir "%~dp0publish\Output"
copy /y "%~dp0VERSION.txt" "%~dp0publish\VERSION.txt" >nul

echo.
echo ============================================================
echo  Fertig: publish\ARE.Automatisierung.exe
echo ============================================================
echo Der publish-Ordner kann zusammen mit START.bat verteilt werden.
echo Auf dem Zielrechner ist dann KEIN .NET SDK und KEINE .NET Runtime erforderlich.
echo Microsoft Excel und Word Desktop bleiben fuer Rendering/Kompatibilitaet erforderlich.
echo.
pause
exit /b 0

:ERROR
echo.
echo Publish fehlgeschlagen. Bei Restore-Problemen siehe:
echo docs\04_NuGet_und_Artifactory.md
echo.
pause
exit /b 1
