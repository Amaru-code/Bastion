Hier legt ARE Automatisierung 2.0 fuer jeden Lauf eine separate, dauerhafte Logdatei ab:

ARE_Automatisierung_YYYYMMDD_HHMMSS.log

Das Protokoll bleibt auch bei einem Laufzeitfehler erhalten.
In der Anwendung kann die aktuelle Datei ueber "Separate Logdatei oeffnen" geoeffnet werden.
