@echo off
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
title ARE Automatisierung 2.0

set "DOTNET_CLI_TELEMETRY_OPTOUT=1"
set "DOTNET_NOLOGO=1"
set "DOTNET_CMD="
set "PROJECT_VERSION=unknown"
if exist "%~dp0VERSION.txt" set /p PROJECT_VERSION=<"%~dp0VERSION.txt"

rem Eine publizierte Version nur starten, wenn sie nachweislich zur aktuellen
rem Projektversion gehoert. So wird beim Ueberschreiben eines alten Projektordners
rem niemals versehentlich eine alte EXE gestartet.
if exist "%~dp0publish\ARE.Automatisierung.exe" if exist "%~dp0publish\VERSION.txt" (
    set "PUBLISH_VERSION="
    set /p PUBLISH_VERSION=<"%~dp0publish\VERSION.txt"
    if /I "!PUBLISH_VERSION!"=="%PROJECT_VERSION%" (
        start "" "%~dp0publish\ARE.Automatisierung.exe"
        exit /b 0
    )
)

rem Portables SDK im Projekt verwenden, wenn vorhanden.
if exist "%~dp0tools\dotnet\dotnet.exe" (
    "%~dp0tools\dotnet\dotnet.exe" --list-sdks | findstr /R /B "10\." >nul 2>&1
    if not errorlevel 1 set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
)

rem Sonst systemweit installiertes .NET 10 SDK verwenden.
if not defined DOTNET_CMD (
    where dotnet.exe >nul 2>&1
    if not errorlevel 1 (
        dotnet --list-sdks | findstr /R /B "10\." >nul 2>&1
        if not errorlevel 1 set "DOTNET_CMD=dotnet"
    )
)

rem Kein SDK vorhanden: portable Installation automatisch versuchen.
if not defined DOTNET_CMD (
    echo ============================================================
    echo  Kein .NET 10 SDK gefunden
    echo ============================================================
    echo.
    echo Das Projekt kann das offizielle Microsoft .NET 10 SDK
    echo lokal in tools\dotnet installieren. Keine Adminrechte noetig.
    echo.
    echo Starte portables SDK-Setup ...
    echo.
    call "%~dp0INSTALL_DOTNET10_PORTABLE.bat"
    if errorlevel 1 goto :NO_SDK

    if exist "%~dp0tools\dotnet\dotnet.exe" (
        "%~dp0tools\dotnet\dotnet.exe" --list-sdks | findstr /R /B "10\." >nul 2>&1
        if not errorlevel 1 set "DOTNET_CMD=%~dp0tools\dotnet\dotnet.exe"
    )
)

if not defined DOTNET_CMD goto :NO_SDK

set "DOTNET_ROOT=%~dp0tools\dotnet"
if /I "%DOTNET_CMD%"=="dotnet" set "DOTNET_ROOT="
if defined DOTNET_ROOT set "PATH=%DOTNET_ROOT%;%PATH%"

echo ============================================================
echo  ARE Automatisierung 2.0 - Build / Start
echo ============================================================
echo.
echo Projektversion: %PROJECT_VERSION%
echo SDK:
"%DOTNET_CMD%" --version
echo.
echo Der Release-Build wird inkrementell aktualisiert.
echo Dadurch wird nach einem Projektupdate nie eine alte EXE gestartet.
echo.

"%DOTNET_CMD%" build "%~dp0src\ARE.Automatisierung\ARE.Automatisierung.csproj" -c Release --nologo > "%~dp0BUILD_TEST.log" 2>&1
set "BUILD_RC=%ERRORLEVEL%"
type "%~dp0BUILD_TEST.log"
if not "%BUILD_RC%"=="0" goto :BUILD_ERROR

start "" "%~dp0src\ARE.Automatisierung\bin\Release\net10.0-windows\ARE.Automatisierung.exe"
exit /b 0

:NO_SDK
echo.
echo FEHLER: Das .NET 10 SDK konnte nicht bereitgestellt werden.
echo.
echo Manuelle Alternative:
echo 1. dotnet-sdk-10.0.400-win-x64.zip von Microsoft herunterladen.
echo 2. Die ZIP direkt in diesen Projektordner legen.
echo 3. INSTALL_DOTNET10_PORTABLE.bat starten.
echo 4. Danach START.bat erneut starten.
echo.
pause
exit /b 1

:BUILD_ERROR
echo.
echo FEHLER: Das Projekt konnte nicht kompiliert werden.
echo Build-Log: %~dp0BUILD_TEST.log
echo.
pause
exit /b 1
