﻿# DC LNW Datenaufbereitung v1.0.1 - Parserfix
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutputRoot = Join-Path $Root 'output'
$LogPath = Join-Path $Root 'processing.log'
$TargetSheetName = 'Import DC LNW'
$CultureDE = [Globalization.CultureInfo]::GetCultureInfo('de-DE')
$Utf8Bom = New-Object System.Text.UTF8Encoding($true)

New-Item -ItemType Directory -Path $OutputRoot -Force | Out-Null
[IO.File]::WriteAllText($LogPath, '', $Utf8Bom)

function Write-Log([string]$Text) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Text
    Write-Host $line
    [IO.File]::AppendAllText($LogPath, $line + [Environment]::NewLine, $Utf8Bom)
}

function Stop-WithError([string]$Text) { throw $Text }

function Select-ExcelFile([string]$Title) {
    $dialog = New-Object System.Windows.Forms.OpenFileDialog
    $dialog.Title = $Title
    $dialog.Filter = 'Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'
    $dialog.Multiselect = $false
    $dialog.CheckFileExists = $true
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) {
        Stop-WithError 'Dateiauswahl wurde abgebrochen.'
    }
    return $dialog.FileName
}

function Normalize-Text([object]$Value) {
    if ($null -eq $Value) { return '' }
    return (([string]$Value).Trim().ToLowerInvariant() -replace '[\s\-_]+', ' ').Trim()
}

function Normalize-WWID([object]$Value) {
    if ($null -eq $Value) { return '' }
    $text = ([string]$Value).Trim()
    if ($text -match '^\d+([\.,]0+)?$') {
        $text = $text -replace '[\.,]0+$', ''
        $text = $text.TrimStart('0')
        if ($text -eq '') { return '0' }
        return $text
    }
    return $text.ToUpperInvariant()
}

function Get-ArrayValue($Array, [int]$Row, [int]$Column) {
    if ($Array -is [System.Array] -and $Array.Rank -eq 2) {
        return $Array.GetValue($Row, $Column)
    }
    if ($Row -eq 1 -and $Column -eq 1) { return $Array }
    return $null
}

function Convert-ToNumber([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return 0.0 }
    if ($Value -is [byte] -or $Value -is [int16] -or $Value -is [int32] -or $Value -is [int64] -or
        $Value -is [single] -or $Value -is [double] -or $Value -is [decimal]) {
        return [double]$Value
    }
    $text = ([string]$Value).Trim().Replace([char]0xA0, '')
    $number = 0.0
    foreach ($culture in @($CultureDE, [Globalization.CultureInfo]::InvariantCulture)) {
        if ([double]::TryParse($text, [Globalization.NumberStyles]::Any, $culture, [ref]$number)) {
            return $number
        }
    }
    return 0.0
}

function Is-NumericOrEmpty([object]$Value) {
    if ($null -eq $Value -or [string]::IsNullOrWhiteSpace([string]$Value)) { return $true }
    if ($Value -is [ValueType]) { return $true }
    $text = ([string]$Value).Trim().Replace([char]0xA0, '')
    $number = 0.0
    return [double]::TryParse($text, [Globalization.NumberStyles]::Any, $CultureDE, [ref]$number) -or
           [double]::TryParse($text, [Globalization.NumberStyles]::Any, [Globalization.CultureInfo]::InvariantCulture, [ref]$number)
}

function Format-CsvValue([object]$Value) {
    if ($null -eq $Value) { return '' }
    if ($Value -is [double] -or $Value -is [single] -or $Value -is [decimal]) {
        return ([double]$Value).ToString('0.#################', $CultureDE)
    }
    if ($Value -is [byte] -or $Value -is [int16] -or $Value -is [int32] -or $Value -is [int64]) {
        return ([string]$Value)
    }
    return ([string]$Value).Trim()
}

function Escape-Csv([object]$Value) {
    $text = Format-CsvValue $Value
    if ($text.Contains('"')) { $text = $text.Replace('"', '""') }
    if ($text.Contains(';') -or $text.Contains('"') -or $text.Contains("`r") -or $text.Contains("`n")) {
        return '"' + $text + '"'
    }
    return $text
}

function Write-CsvLine([IO.StreamWriter]$Writer, [object[]]$Values) {
    $cells = foreach ($value in $Values) { Escape-Csv $value }
    $Writer.WriteLine(($cells -join ';'))
}

function Find-HeaderCell($Sheet, [string[]]$Aliases, [int]$MaxRows = 200) {
    $used = $Sheet.UsedRange
    $firstRow = [int]$used.Row
    $firstColumn = [int]$used.Column
    $rowCount = [Math]::Min([int]$used.Rows.Count, $MaxRows)
    $columnCount = [int]$used.Columns.Count
    if ($rowCount -lt 1 -or $columnCount -lt 1) { return $null }

    $values = $Sheet.Range(
        $Sheet.Cells.Item($firstRow, $firstColumn),
        $Sheet.Cells.Item($firstRow + $rowCount - 1, $firstColumn + $columnCount - 1)
    ).Value2
    $wanted = @($Aliases | ForEach-Object { Normalize-Text $_ })

    for ($r = 1; $r -le $rowCount; $r++) {
        for ($c = 1; $c -le $columnCount; $c++) {
            if ($wanted -contains (Normalize-Text (Get-ArrayValue $values $r $c))) {
                return [pscustomobject]@{ Row = $firstRow + $r - 1; Column = $firstColumn + $c - 1 }
            }
        }
    }
    return $null
}

function Find-DUColumns($Workbook) {
    $aliases = @{
        WWID  = @('WWID')
        Fund  = @('Fondsname', 'Fonds Name', 'Fonds')
        Type  = @('Umsatzart', 'Umsatz Art')
        Units = @('UmsatzStuecke', 'Umsatzstücke', 'Umsatz Stuecke', 'Umsatz Stücke')
        Value = @('ZahlBetrag', 'Zahl Betrag')
    }

    foreach ($sheet in @($Workbook.Worksheets)) {
        $used = $sheet.UsedRange
        $firstRow = [int]$used.Row
        $firstColumn = [int]$used.Column
        $rowCount = [Math]::Min([int]$used.Rows.Count, 100)
        $columnCount = [int]$used.Columns.Count
        if ($rowCount -lt 1 -or $columnCount -lt 1) { continue }

        $values = $sheet.Range(
            $sheet.Cells.Item($firstRow, $firstColumn),
            $sheet.Cells.Item($firstRow + $rowCount - 1, $firstColumn + $columnCount - 1)
        ).Value2

        for ($r = 1; $r -le $rowCount; $r++) {
            $found = @{}
            for ($c = 1; $c -le $columnCount; $c++) {
                $cellText = Normalize-Text (Get-ArrayValue $values $r $c)
                foreach ($key in $aliases.Keys) {
                    $normalizedAliases = @($aliases[$key] | ForEach-Object { Normalize-Text $_ })
                    if ($normalizedAliases -contains $cellText) { $found[$key] = $firstColumn + $c - 1 }
                }
            }
            if ($found.Count -eq 5) {
                return [pscustomobject]@{
                    Sheet = $sheet; HeaderRow = $firstRow + $r - 1
                    WWID = $found.WWID; Fund = $found.Fund; Type = $found.Type
                    Units = $found.Units; Value = $found.Value
                }
            }
        }
    }
    Stop-WithError 'In der DU-Datei wurden die Spalten WWID, Fondsname, Umsatzart, UmsatzStuecke und ZahlBetrag nicht gemeinsam gefunden.'
}

function Read-DUAggregates($Columns) {
    $result = @{}
    $sheet = $Columns.Sheet
    $firstDataRow = $Columns.HeaderRow + 1
    $lastDataRow = [int]$sheet.Cells.Item($sheet.Rows.Count, $Columns.WWID).End(-4162).Row
    if ($lastDataRow -lt $firstDataRow) { return $result }

    $neededColumns = @($Columns.WWID, $Columns.Fund, $Columns.Type, $Columns.Units, $Columns.Value)
    $minimumColumn = ($neededColumns | Measure-Object -Minimum).Minimum
    $maximumColumn = ($neededColumns | Measure-Object -Maximum).Maximum
    $values = $sheet.Range(
        $sheet.Cells.Item($firstDataRow, $minimumColumn),
        $sheet.Cells.Item($lastDataRow, $maximumColumn)
    ).Value2

    $relevantTypes = @(
        Normalize-Text 'Wiederanlage Ertragsaussc'
        Normalize-Text 'Fondsportfolioanpassung'
        Normalize-Text 'Verkauf wegen Vorabpausch'
    )
    $reallocationType = Normalize-Text 'Fondsportfolioanpassung'
    $processedRows = 0

    for ($r = 1; $r -le ($lastDataRow - $firstDataRow + 1); $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $values $r ($Columns.WWID - $minimumColumn + 1))
        $fund = Normalize-Text (Get-ArrayValue $values $r ($Columns.Fund - $minimumColumn + 1))
        $type = Normalize-Text (Get-ArrayValue $values $r ($Columns.Type - $minimumColumn + 1))
        if ($wwid -eq '' -or $fund -eq '') { continue }
        $processedRows++

        if (-not $result.ContainsKey($wwid)) { $result[$wwid] = @{} }
        if (-not $result[$wwid].ContainsKey($fund)) {
            $result[$wwid][$fund] = [pscustomobject]@{
                MoveUnits = 0.0; MoveValue = 0.0; ReallocationUnits = 0.0; ReallocationValue = 0.0
            }
        }

        $units = Convert-ToNumber (Get-ArrayValue $values $r ($Columns.Units - $minimumColumn + 1))
        $value = Convert-ToNumber (Get-ArrayValue $values $r ($Columns.Value - $minimumColumn + 1))
        $aggregate = $result[$wwid][$fund]

        # DU-Werte werden mit ihrem vorhandenen Vorzeichen summiert. Es wird kein Vorzeichen erfunden oder umgedreht.
        if ($relevantTypes -contains $type) {
            $aggregate.MoveUnits += $units
            $aggregate.MoveValue += $value
        }
        if ($type -eq $reallocationType) {
            $aggregate.ReallocationUnits += $units
            $aggregate.ReallocationValue += $value
        }
    }

    return [pscustomobject]@{ Data = $result; ProcessedRows = $processedRows; FirstRow = $firstDataRow; LastRow = $lastDataRow }
}

function Get-FundAggregate($FundMap, [string]$FundName) {
    $empty = [pscustomobject]@{ MoveUnits = 0.0; MoveValue = 0.0; ReallocationUnits = 0.0; ReallocationValue = 0.0 }
    if ($null -eq $FundMap) { return $empty }
    $key = Normalize-Text $FundName
    if ($FundMap.ContainsKey($key)) { return $FundMap[$key] }
    return $empty
}

$excel = $null
$templateBook = $null
$duBook = $null
$templateSheet = $null
$writers = @()

try {
    Write-Log 'Dateiauswahl wird geöffnet.'
    $templatePath = Select-ExcelFile '1/2 – Template-Datei auswählen'
    Write-Log ('Template gewählt: ' + $templatePath)
    $duPath = Select-ExcelFile '2/2 – DU-Datei auswählen'
    Write-Log ('DU-Datei gewählt: ' + $duPath)

    if ([IO.Path]::GetFullPath($templatePath) -eq [IO.Path]::GetFullPath($duPath)) {
        Stop-WithError 'Template und DU-Datei dürfen nicht dieselbe Datei sein.'
    }

    $runName = 'Auswertung_{0}' -f (Get-Date -Format 'yyyyMMdd_HHmmss')
    $runDir = Join-Path $OutputRoot $runName
    New-Item -ItemType Directory -Path $runDir -Force | Out-Null

    Write-Log 'Microsoft Excel wird ausschließlich zum blockweisen Lesen der Dateien gestartet.'
    $excel = New-Object -ComObject Excel.Application
    $excel.Visible = $false
    $excel.DisplayAlerts = $false
    $excel.AskToUpdateLinks = $false
    $excel.EnableEvents = $false
    $excel.ScreenUpdating = $false
    try { $excel.AutomationSecurity = 3 } catch {}
    try { $excel.Calculation = -4135 } catch {}

    Write-Log 'Template wird schreibgeschützt geöffnet.'
    $templateBook = $excel.Workbooks.Open($templatePath, 0, $true)
    try { $templateSheet = $templateBook.Worksheets.Item($TargetSheetName) }
    catch { Stop-WithError "Das Sheet '$TargetSheetName' wurde im Template nicht gefunden." }

    $wwidHeader = Find-HeaderCell $templateSheet @('WWID')
    if ($null -eq $wwidHeader) { Stop-WithError "Der WWID-Header wurde im Sheet '$TargetSheetName' nicht gefunden." }

    $firstTemplateRow = $wwidHeader.Row + 1
    $lastTemplateRow = [int]$templateSheet.Cells.Item($templateSheet.Rows.Count, $wwidHeader.Column).End(-4162).Row
    if ($lastTemplateRow -lt $firstTemplateRow) { Stop-WithError 'Im Template wurden unterhalb des WWID-Headers keine Datenzeilen gefunden.' }
    $templateRowCount = $lastTemplateRow - $firstTemplateRow + 1
    Write-Log ("Template-Datenbereich erkannt: $templateRowCount Zeilen.")

    # CL:CU = Excel-Spalten 90 bis 99. Sie werden nur gelesen, nie verändert.
    $wwidValues = $templateSheet.Range(
        $templateSheet.Cells.Item($firstTemplateRow, $wwidHeader.Column),
        $templateSheet.Cells.Item($lastTemplateRow, $wwidHeader.Column)
    ).Value2
    $originalCLCU = $templateSheet.Range(
        $templateSheet.Cells.Item($firstTemplateRow, 90),
        $templateSheet.Cells.Item($lastTemplateRow, 99)
    ).Value2
    Write-Log 'Originalwerte CL:CU wurden unverändert aus dem Input-Template gelesen.'

    Write-Log 'DU-Datei wird schreibgeschützt geöffnet.'
    $duBook = $excel.Workbooks.Open($duPath, 0, $true)
    $duColumns = Find-DUColumns $duBook
    Write-Log ("DU-Header erkannt: Sheet '$($duColumns.Sheet.Name)', Zeile $($duColumns.HeaderRow).")
    $duResult = Read-DUAggregates $duColumns
    $aggregates = $duResult.Data
    Write-Log ("DU-Aggregation abgeschlossen: $($duResult.ProcessedRows) Datenzeilen, $($aggregates.Count) WWIDs.")

    $startPath = Join-Path $runDir '01_template_startbestand.csv'
    $duDetailPath = Join-Path $runDir '02_du_aggregation.csv'
    $finalPath = Join-Path $runDir '03_final_import.csv'
    $checkPath = Join-Path $runDir '04_kontrolle.csv'

    $startWriter = New-Object IO.StreamWriter($startPath, $false, $Utf8Bom)
    $duWriter = New-Object IO.StreamWriter($duDetailPath, $false, $Utf8Bom)
    $finalWriter = New-Object IO.StreamWriter($finalPath, $false, $Utf8Bom)
    $checkWriter = New-Object IO.StreamWriter($checkPath, $false, $Utf8Bom)
    $writers = @($startWriter, $duWriter, $finalWriter, $checkWriter)

    $startHeaders = @('WWID','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS')
    $duHeaders = @(
        'WWID',
        'BI_DWSI_Umschichtung_Anteile','BJ_DWSI_Umschichtung_Wert',
        'BK_Eurorenta_Umschichtung_Anteile','BL_Eurorenta_Umschichtung_Wert',
        'BM_Geldmarkt_Umschichtung_Anteile','BN_Geldmarkt_Umschichtung_Wert',
        'DWSI_Bewegung_Anteile','DWSI_Bewegung_Wert',
        'Eurorenta_Bewegung_Anteile','Eurorenta_Bewegung_Wert',
        'Geldmarkt_Bewegung_Anteile','Geldmarkt_Bewegung_Wert',
        'Aktienfonds_Bewegung_Anteile','Aktienfonds_Bewegung_Wert',
        'Rentenfonds_Bewegung_Anteile','Rentenfonds_Bewegung_Wert'
    )
    $finalHeaders = @('WWID','AJ','AK','AL','AM','AN','AO','AP','AQ','AR','AS','BI','BJ','BK','BL','BM','BN','CL','CM','CN','CO','CP','CQ','CR','CS','CT','CU')
    $checkHeaders = @('WWID','Template_Zeile','DU_Daten_gefunden','Startwerte_nichtnumerisch','Hinweis')

    Write-CsvLine $startWriter $startHeaders
    Write-CsvLine $duWriter $duHeaders
    Write-CsvLine $finalWriter $finalHeaders
    Write-CsvLine $checkWriter $checkHeaders

    $fundNames = @(
        'DWSI-EUR.EQ.HI.CO.FC',
        'DWS EURORENTA',
        'DWS INS.-ESG EO MO.M.IC',
        'SIEMENS EUROINVEST AKTIEN',
        'SIEMENS EUROINVEST RENTEN'
    )

    $rowsWithWWID = 0
    $rowsWithDU = 0
    $nonNumericRows = 0

    Write-Log 'CSV-Dateien werden zeilenweise erzeugt.'
    for ($r = 1; $r -le $templateRowCount; $r++) {
        $wwid = Normalize-WWID (Get-ArrayValue $wwidValues $r 1)
        if ($wwid -eq '') { continue }
        $rowsWithWWID++

        # EXAKTE 1:1-KOPIE: AJ:AS erhält in der CSV ausschließlich die ursprünglichen Werte CL:CU.
        $start = @()
        for ($c = 1; $c -le 10; $c++) { $start += (Get-ArrayValue $originalCLCU $r $c) }
        Write-CsvLine $startWriter (@($wwid) + $start)

        $fundMap = $null
        $duFound = $aggregates.ContainsKey($wwid)
        if ($duFound) { $fundMap = $aggregates[$wwid]; $rowsWithDU++ }

        $fundAgg = @()
        foreach ($fundName in $fundNames) { $fundAgg += (Get-FundAggregate $fundMap $fundName) }

        $biBn = @(
            $fundAgg[0].ReallocationUnits, $fundAgg[0].ReallocationValue,
            $fundAgg[1].ReallocationUnits, $fundAgg[1].ReallocationValue,
            $fundAgg[2].ReallocationUnits, $fundAgg[2].ReallocationValue
        )
        $movements = @()
        foreach ($aggregate in $fundAgg) { $movements += @($aggregate.MoveUnits, $aggregate.MoveValue) }
        Write-CsvLine $duWriter (@($wwid) + $biBn + $movements)

        $end = @()
        $nonNumeric = @()
        for ($i = 0; $i -lt 10; $i++) {
            $rawStart = $start[$i]
            $movement = [double]$movements[$i]
            if (-not (Is-NumericOrEmpty $rawStart)) { $nonNumeric += @($i + 1) }

            if (($null -eq $rawStart -or [string]::IsNullOrWhiteSpace([string]$rawStart)) -and [Math]::Abs($movement) -lt 0.0000000000001) {
                $end += ''
            }
            else {
                $end += ((Convert-ToNumber $rawStart) + $movement)
            }
        }

        $hint = ''
        if ($nonNumeric.Count -gt 0) {
            $nonNumericRows++
            $hint = 'Nichtnumerische Startwerte an Position(en): ' + ($nonNumeric -join ',')
        }
        elseif (-not $duFound) { $hint = 'Keine passende WWID in der DU-Datei; Endbestand entspricht Startbestand.' }

        Write-CsvLine $finalWriter (@($wwid) + $start + $biBn + $end)
        Write-CsvLine $checkWriter @($wwid, ($firstTemplateRow + $r - 1), $(if ($duFound) {'JA'} else {'NEIN'}), $nonNumeric.Count, $hint)
    }

    foreach ($writer in $writers) { $writer.Flush(); $writer.Close() }
    $writers = @()

    $summaryPath = Join-Path $runDir 'ZUSAMMENFASSUNG.txt'
    $summary = @"
DC LNW DATENAUFBEREITUNG
========================

Template:
$templatePath

DU-Datei:
$duPath

Ergebnislogik:
- AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Templates, exakt 1:1.
- BI:BN = Fondsportfolioanpassung aus der DU-Datei.
- CL:CU = AJ:AS plus die bereits vorzeichenbehafteten DU-Summen aus:
  Wiederanlage Ertragsaussc, Fondsportfolioanpassung, Verkauf wegen Vorabpausch.
- Es wurde keine Excel-Datei verändert und keine neue XLSM-Datei geschrieben.

Verarbeitete Template-Zeilen mit WWID: $rowsWithWWID
Davon mit DU-Daten: $rowsWithDU
Davon ohne DU-Daten: $($rowsWithWWID - $rowsWithDU)
Zeilen mit nichtnumerischen Startwerten: $nonNumericRows

Dateien:
01_template_startbestand.csv
02_du_aggregation.csv
03_final_import.csv
04_kontrolle.csv
"@
    [IO.File]::WriteAllText($summaryPath, $summary, $Utf8Bom)

    $duBook.Close($false); $duBook = $null
    $templateBook.Close($false); $templateBook = $null
    $excel.Quit(); $excel = $null

    Write-Log ("FERTIG. Ergebnisordner: $runDir")
    Start-Process explorer.exe -ArgumentList "`"$runDir`""
    [System.Windows.Forms.MessageBox]::Show(
        "Datenaufbereitung erfolgreich abgeschlossen.`n`nErgebnisordner:`n$runDir",
        'DC LNW Datenaufbereitung', 'OK', 'Information'
    ) | Out-Null
    exit 0
}
catch {
    $message = $_.Exception.Message
    Write-Log ('FEHLER: ' + $message)
    [System.Windows.Forms.MessageBox]::Show(
        "$message`n`nDetails stehen in:`n$LogPath",
        'DC LNW Datenaufbereitung – Fehler', 'OK', 'Error'
    ) | Out-Null
    exit 1
}
finally {
    foreach ($writer in $writers) { try { $writer.Close() } catch {} }
    if ($null -ne $duBook) { try { $duBook.Close($false) } catch {} }
    if ($null -ne $templateBook) { try { $templateBook.Close($false) } catch {} }
    if ($null -ne $excel) { try { $excel.Quit() } catch {} }
    foreach ($obj in @($templateSheet, $duBook, $templateBook, $excel)) {
        if ($null -ne $obj -and [Runtime.InteropServices.Marshal]::IsComObject($obj)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($obj) } catch {}
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}
