DC LNW DATENAUFBEREITUNG – VERSION 1.0.1
=========================================

START
-----
1. ZIP vollständig entpacken.
2. Microsoft Excel schließen.
3. start.bat doppelklicken.
4. Zuerst das Template, danach die DU-Datei auswählen.

Das Tool verändert keine Excel-Datei. Es liest die Daten und erzeugt im
Unterordner output einen neuen Auswertungsordner mit vier CSV-Dateien.

FESTE LOGIK
-----------
AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Templates, exakt 1:1.
BI:BN = Fondsportfolioanpassungen aus der DU-Datei.
CL:CU = Startwerte plus bereits vorzeichenbehaftete relevante DU-Bewegungen.

KEINE INSTALLATION
------------------
Es wird weder Go noch Python benötigt. Es gibt keine install.bat.
Voraussetzungen: Windows, Windows PowerShell und Microsoft Excel Desktop.

FEHLERPROTOKOLL
---------------
processing.log liegt direkt neben start.bat.

VERSION 1.0.1
-------------
Korrigiert einen PowerShell-Parserfehler beim Initialisieren der Logdatei.
