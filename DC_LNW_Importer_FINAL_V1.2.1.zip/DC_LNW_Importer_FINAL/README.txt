DC LNW Importer – FINAL V1.2.1
================================

START
-----
1. ZIP vollständig entpacken.
2. start.bat doppelt anklicken.
3. Template-Datei auswählen.
4. DU-Datei auswählen.

Es ist keine Installation von Go, Python oder PowerShell-Modulen erforderlich.

VERARBEITUNG
------------
- Das ausgewählte Template bleibt unverändert.
- Im Ordner output wird pro Lauf ein eigener Unterordner angelegt.
- Das Sheet "Import DC LNW" wird verarbeitet.
- Konstante Datenwerte im Datenbereich ab AJ werden geleert.
- Header und Formeln bleiben bestehen.
- AJ:AS erhält die ursprünglichen Werte aus CL:CU des Input-Templates exakt 1:1.
- BI:BN erhält die DU-Umschichtungssummen.
- CL:CU erhält die berechneten Endbestände.
- Die Zuordnung erfolgt anhand der WWID.

PATCH V1.2.1
------------
Leere Excel-Zellen, die im XLSM intern noch keinen eigenen Zellknoten besitzen,
werden beim Import automatisch angelegt. Sie werden nicht mehr fälschlich als
"fehlende Zielzellen" gemeldet. Vorhandene Formeln werden weiterhin geschützt.

OUTPUT
------
- *_DC_LNW_Output.xlsm
- 03_final_import.csv
- 04_kontrolle.csv
- processing.log
- ZUSAMMENFASSUNG.txt
