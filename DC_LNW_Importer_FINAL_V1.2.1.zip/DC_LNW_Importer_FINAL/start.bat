@echo off
setlocal
cd /d "%~dp0"
start "" "DC_LNW_Importer.exe"
exit /b 0
