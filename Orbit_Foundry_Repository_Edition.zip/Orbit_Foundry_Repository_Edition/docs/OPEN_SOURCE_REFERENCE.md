# Open-Source-Referenz

Untersuchte Inspiration:
- Projekt: 13th Century City Builder
- Repository: js13kGames/13th-century-city-builder
- Originalautor: Aniike-t
- Technik: JavaScript, HTML, CSS

Übernommene allgemeine Designideen: Rasterplatzierung, Ressourcenverwaltung, Gebäude, Forschung, Zeitfortschritt und Meldungen.

Orbit Foundry ist eine eigenständige Neuimplementierung mit eigener Oberfläche, eigenen Regeln und selbst erzeugten SVG-Platzhalterassets. Der Originalcode und die Originalgrafiken sind nicht Bestandteil dieses Pakets. Vor einer späteren direkten Übernahme fremder Dateien muss die jeweilige Lizenzdatei erneut vollständig geprüft und beibehalten werden.
