# Roadmap

## Nächster sinnvoller Meilenstein
1. Gebäude abreißen und verbessern
2. Wege, Reichweiten und Nachbarschaftsboni
3. Arbeiterzuweisung
4. echte Produktionsketten
5. mehrere Sektoren/Planeten
6. Technologiebaum mit Abhängigkeiten
7. Kampagnenereignisse und Entscheidungen
8. Sound, Animationen und eigene Pixelgrafik
9. Export/Import von Spielständen als JSON
10. automatisierte Balancing-Simulationen
