$ErrorActionPreference = 'Stop'
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$Index = Join-Path $Root 'index.html'
if (-not (Test-Path $Index)) { throw "index.html wurde nicht gefunden: $Index" }
Start-Process $Index
