# Orbit Foundry – Repository Edition

Installationsfreies, lokales JavaScript-Aufbauspiel. Entpacken und `Start_Game.ps1`, `Start_Game.bat` oder `index.html` starten.

## Enthaltene Systeme
- 15×10-Bauraster
- 7 Gebäudetypen
- Metall, Energie, Nahrung, Forschung, Credits
- Bevölkerung, Moral und Lagerkapazität
- Produktionszyklus mit Energieverbrauch
- Forschung und Freischaltungen
- 5-stufige Mission
- Zufallsereignisse
- Pause, Speichern, Laden und Zurücksetzen
- vollständig offline, ohne npm oder Engine

## Steuerung
- Gebäudeschaltfläche wählen, dann auf das Raster klicken
- Rechtsklick hebt die Auswahl auf
- Leertaste pausiert

## Technischer Hinweis
Diese Edition wurde als wartbare Neuimplementierung der typischen Mechaniken eines City Builders erstellt. Das öffentlich untersuchte Referenzprojekt ist in `docs/OPEN_SOURCE_REFERENCE.md` dokumentiert. Dessen Quellcode und Assets wurden nicht in diese ZIP kopiert.
