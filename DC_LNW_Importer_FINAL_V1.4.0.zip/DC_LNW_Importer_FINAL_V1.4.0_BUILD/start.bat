@echo off
setlocal
cd /d "%~dp0"
title DC LNW Importer
"%~dp0DC_LNW_Importer.exe"
if errorlevel 1 pause
