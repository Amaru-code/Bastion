DC LNW Importer – Finale Version 1.4.0
======================================

START
-----
1. ZIP vollständig entpacken.
2. start.bat doppelklicken.
3. Template-Datei auswählen.
4. DU-Datei auswählen.

VERBINDLICHE IMPORTREIHENFOLGE
------------------------------
1. Die korrekten Werte für 03_final_import.csv werden berechnet.
2. Das ausgewählte Template wird als separate XLSM-Ausgabedatei kopiert.
3. Im Sheet "Import DC LNW" werden in jeder Datenzeile zuerst ALLE vorhandenen
   Zellknoten in AJ:AS, BI:BN und CL:CU vollständig entfernt.
   Das gilt für alte Werte, Formeln und leere Zellknoten.
4. Erst nach dieser vollständigen Löschung werden die Zielzellen exakt einmal
   aus den berechneten CSV-Werten neu aufgebaut.
5. Jede geschriebene Zielzelle wird vor dem Speichern gegen den berechneten Wert
   geprüft.

Dadurch kann kein alter Wert aus dem Input-Template in den Zielbereichen stehen
bleiben oder von Excel bevorzugt werden.

FACHLICHE LOGIK
---------------
- AJ:AS = ursprüngliche Werte aus CL:CU des ausgewählten Input-Templates, exakt 1:1.
- BI:BN = aggregierte DU-Werte für Fondsportfolioanpassung.
- CL:CU = bestätigte Endbestände aus der Datenaufbereitung.

SCHUTZ
------
- Header bleiben unverändert.
- Formeln außerhalb von AJ:AS, BI:BN und CL:CU bleiben erhalten.
- Sonstige konstante Daten ab AJ werden im Datenbereich entfernt.
- Andere Sheets werden nicht verändert.
- Das Input-Template wird nicht verändert.

AUSGABEN
--------
Unter output/Auswertung_YYYYMMDD_HHMMSS entstehen:
- 03_final_import.csv
- 04_kontrolle.csv
- *_DC_LNW_Output.xlsm
- ZUSAMMENFASSUNG.txt
- processing.log

VORAUSSETZUNGEN
---------------
- Windows 10 oder Windows 11
- Keine Go- oder Python-Installation erforderlich
- Windows PowerShell wird ausschließlich für den nativen Dateiauswahldialog genutzt
