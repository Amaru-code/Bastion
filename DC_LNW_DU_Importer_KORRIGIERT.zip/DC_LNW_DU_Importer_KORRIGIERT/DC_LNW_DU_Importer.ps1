Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms

$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$OutputDir = Join-Path $Root 'output'
$LogPath = Join-Path $Root 'importer.log'
$TargetSheetName = 'Import DC LNW'
New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
'' | Set-Content -LiteralPath $LogPath -Encoding UTF8

function Log([string]$Text) {
    $line = '[{0}] {1}' -f (Get-Date -Format 'HH:mm:ss'), $Text
    Write-Host $line
    Add-Content -LiteralPath $LogPath -Value $line -Encoding UTF8
}
function Fail([string]$Text) { throw $Text }
function Pick-Excel([string]$Title) {
    $d = New-Object System.Windows.Forms.OpenFileDialog
    $d.Title = $Title
    $d.Filter = 'Excel-Dateien (*.xlsx;*.xlsm)|*.xlsx;*.xlsm'
    $d.Multiselect = $false
    $d.CheckFileExists = $true
    if ($d.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { Fail 'Dateiauswahl abgebrochen.' }
    return $d.FileName
}
function Norm([object]$v) {
    if ($null -eq $v) { return '' }
    return (([string]$v).Trim().ToLowerInvariant() -replace '[\s\-_]+',' ').Trim()
}
function Norm-WWID([object]$v) {
    if ($null -eq $v) { return '' }
    $s = ([string]$v).Trim()
    if ($s -match '^\d+([\.,]0+)?$') {
        $s = $s -replace '[\.,]0+$',''
        $s = $s.TrimStart('0')
        if ($s -eq '') { return '0' }
        return $s
    }
    return $s.ToUpperInvariant()
}
function Col([string]$s) {
    $n=0
    foreach($c in $s.ToUpperInvariant().ToCharArray()) { $n=$n*26+([int][char]$c-[int][char]'A'+1) }
    return $n
}
function ArrGet($a,[int]$r,[int]$c) {
    if ($a -is [System.Array] -and $a.Rank -eq 2) { return $a.GetValue($r,$c) }
    if ($r -eq 1 -and $c -eq 1) { return $a }
    return $null
}
function New-OneBasedArray([int]$rows,[int]$cols) {
    return [Array]::CreateInstance([object], @($rows,$cols), @(1,1))
}
function ToNumber([object]$v) {
    if ($null -eq $v -or [string]::IsNullOrWhiteSpace([string]$v)) { return 0.0 }
    if ($v -is [ValueType]) { return [double]$v }
    $s=([string]$v).Trim().Replace([char]0xA0,'')
    $x=0.0
    foreach($culture in @([Globalization.CultureInfo]::GetCultureInfo('de-DE'),[Globalization.CultureInfo]::InvariantCulture)) {
        if([double]::TryParse($s,[Globalization.NumberStyles]::Any,$culture,[ref]$x)){return $x}
    }
    return 0.0
}
function Find-Header($sheet,[string[]]$aliases,[int]$maxRows=200) {
    $used=$sheet.UsedRange
    $fr=[int]$used.Row; $fc=[int]$used.Column
    $rc=[Math]::Min([int]$used.Rows.Count,$maxRows); $cc=[int]$used.Columns.Count
    $vals=$sheet.Range($sheet.Cells.Item($fr,$fc),$sheet.Cells.Item($fr+$rc-1,$fc+$cc-1)).Value2
    $wanted=@($aliases|ForEach-Object{Norm $_})
    for($r=1;$r-le $rc;$r++) { for($c=1;$c-le $cc;$c++) {
        if($wanted -contains (Norm (ArrGet $vals $r $c))) { return [pscustomobject]@{Row=$fr+$r-1;Col=$fc+$c-1} }
    }}
    return $null
}
function Find-DUColumns($wb) {
    $map=@{
      WWID=@('WWID'); Fund=@('Fondsname','Fonds Name','Fonds'); Type=@('Umsatzart','Umsatz Art');
      Units=@('UmsatzStuecke','Umsatzstücke','Umsatz Stuecke','Umsatz Stücke'); Value=@('ZahlBetrag','Zahl Betrag')
    }
    foreach($sh in @($wb.Worksheets)) {
        $used=$sh.UsedRange; $fr=[int]$used.Row; $fc=[int]$used.Column
        $rc=[Math]::Min([int]$used.Rows.Count,100); $cc=[int]$used.Columns.Count
        if($rc-lt 1-or$cc-lt 1){continue}
        $vals=$sh.Range($sh.Cells.Item($fr,$fc),$sh.Cells.Item($fr+$rc-1,$fc+$cc-1)).Value2
        for($r=1;$r-le$rc;$r++) {
            $found=@{}
            for($c=1;$c-le$cc;$c++) {
                $t=Norm (ArrGet $vals $r $c)
                foreach($k in $map.Keys) { if(@($map[$k]|ForEach-Object{Norm $_}) -contains $t){$found[$k]=$fc+$c-1} }
            }
            if($found.Count-eq 5){return [pscustomobject]@{Sheet=$sh;HeaderRow=$fr+$r-1;WWID=$found.WWID;Fund=$found.Fund;Type=$found.Type;Units=$found.Units;Value=$found.Value}}
        }
    }
    Fail 'DU-Header WWID, Fondsname, Umsatzart, UmsatzStuecke und ZahlBetrag wurden nicht gefunden.'
}
function Read-DUAggregates($dc) {
    $result=@{}; $sh=$dc.Sheet
    $first=$dc.HeaderRow+1
    $last=[int]$sh.Cells.Item($sh.Rows.Count,$dc.WWID).End(-4162).Row
    if($last-lt$first){return $result}
    $cols=@($dc.WWID,$dc.Fund,$dc.Type,$dc.Units,$dc.Value)
    $min=($cols|Measure-Object -Minimum).Minimum; $max=($cols|Measure-Object -Maximum).Maximum
    $vals=$sh.Range($sh.Cells.Item($first,$min),$sh.Cells.Item($last,$max)).Value2
    $movements=@('wiederanlage ertragsaussc','fondsportfolioanpassung','verkauf wegen vorabpausch')
    for($r=1;$r-le($last-$first+1);$r++) {
        $wwid=Norm-WWID (ArrGet $vals $r ($dc.WWID-$min+1)); $fund=Norm (ArrGet $vals $r ($dc.Fund-$min+1)); $type=Norm (ArrGet $vals $r ($dc.Type-$min+1))
        if($wwid-eq''-or$fund-eq''){continue}
        if(-not$result.ContainsKey($wwid)){$result[$wwid]=@{}}
        if(-not$result[$wwid].ContainsKey($fund)){$result[$wwid][$fund]=[pscustomobject]@{MoveUnits=0.0;MoveValue=0.0;ReUnits=0.0;ReValue=0.0}}
        $u=ToNumber (ArrGet $vals $r ($dc.Units-$min+1)); $v=ToNumber (ArrGet $vals $r ($dc.Value-$min+1)); $x=$result[$wwid][$fund]
        if($movements -contains $type){$x.MoveUnits+=$u;$x.MoveValue+=$v}
        if($type-eq'fondsportfolioanpassung'){$x.ReUnits+=$u;$x.ReValue+=$v}
    }
    return $result
}

$excel=$null; $templateBook=$null; $duBook=$null; $target=$null
try {
    Log 'Dateiauswahl wird geöffnet.'
    $template=Pick-Excel '1/2 – Template-Datei auswählen'
    Log ('Template gewählt: '+$template)
    $du=Pick-Excel '2/2 – DU-Datei auswählen'
    Log ('DU-Datei gewählt: '+$du)
    if([IO.Path]::GetFullPath($template)-eq[IO.Path]::GetFullPath($du)){Fail 'Template und DU-Datei dürfen nicht dieselbe Datei sein.'}

    $name=([IO.Path]::GetFileNameWithoutExtension($template)-replace '[<>:"/\\|?*]','_')
    $output=Join-Path $OutputDir ('{0}_DU_Import_{1}.xlsm' -f $name,(Get-Date -Format 'yyyyMMdd_HHmmss'))

    Log 'Excel wird gestartet.'
    $excel=New-Object -ComObject Excel.Application
    $excel.Visible=$false; $excel.DisplayAlerts=$false; $excel.AskToUpdateLinks=$false; $excel.EnableEvents=$false; $excel.ScreenUpdating=$false
    try{$excel.AutomationSecurity=3}catch{}
    try{$excel.Calculation=-4135}catch{}

    Log 'Template wird geöffnet.'
    $templateBook=$excel.Workbooks.Open($template,0,$false)
    Log 'Neue XLSM-Ausgabedatei wird erstellt.'
    $templateBook.SaveAs($output,52)
    Log 'DU-Datei wird geöffnet.'
    $duBook=$excel.Workbooks.Open($du,0,$true)

    try{$target=$templateBook.Worksheets.Item($TargetSheetName)}catch{Fail "Sheet '$TargetSheetName' wurde nicht gefunden."}
    $wwidHeader=Find-Header $target @('WWID')
    if($null-eq$wwidHeader){Fail "WWID-Header im Sheet '$TargetSheetName' wurde nicht gefunden."}
    $first=$wwidHeader.Row+1; $last=[int]$target.Cells.Item($target.Rows.Count,$wwidHeader.Col).End(-4162).Row
    if($last-lt$first){Fail 'Keine Datenzeilen unterhalb des WWID-Headers gefunden.'}
    $rows=$last-$first+1
    Log ("Zielbereich: $rows Datenzeilen.")

    $AJ=Col 'AJ';$AS=Col 'AS';$BI=Col 'BI';$BN=Col 'BN';$CL=Col 'CL';$CU=Col 'CU'

    # WICHTIG: Diese Werte werden vor jeder Änderung exakt aus dem Input-Template gelesen.
    Log 'Originalwerte CL:CU werden unverändert zwischengespeichert.'
    $originalCLCU=$target.Range($target.Cells.Item($first,$CL),$target.Cells.Item($last,$CU)).Value2

    Log 'Nicht-Formelwerte im Datenbereich AJ:CU werden geleert; Header und Formeln bleiben bestehen.'
    $clear=$target.Range($target.Cells.Item($first,$AJ),$target.Cells.Item($last,$CU))
    try{$constants=$clear.SpecialCells(2);$constants.ClearContents();[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($constants)}catch{
        if($_.Exception.Message-notmatch'No cells were found|Keine Zellen gefunden'){throw}
    }

    # EXAKTE 1:1-ZUORDNUNG. KEINE DU-WERTE, KEINE RECHNUNG.
    Log 'AJ:AS erhält jetzt ausschließlich die ursprünglichen Werte aus CL:CU – 1:1 und ohne Berechnung.'
    $target.Range($target.Cells.Item($first,$AJ),$target.Cells.Item($last,$AS)).Value2=$originalCLCU

    Log 'DU-Spalten werden erkannt und aggregiert.'
    $dc=Find-DUColumns $duBook; $agg=Read-DUAggregates $dc
    Log ("DU-Aggregation abgeschlossen: $($agg.Count) WWIDs.")

    $wwids=$target.Range($target.Cells.Item($first,$wwidHeader.Col),$target.Cells.Item($last,$wwidHeader.Col)).Value2
    $starts=$target.Range($target.Cells.Item($first,$AJ),$target.Cells.Item($last,$AS)).Value2
    $biOut=New-OneBasedArray $rows 6; $clOut=New-OneBasedArray $rows 10
    $funds=@(
      [pscustomobject]@{Name='DWSI-EUR.EQ.HI.CO.FC'},[pscustomobject]@{Name='DWS EURORENTA'},[pscustomobject]@{Name='DWS INS.-ESG EO MO.M.IC'},
      [pscustomobject]@{Name='SIEMENS EUROINVEST AKTIEN'},[pscustomobject]@{Name='SIEMENS EUROINVEST RENTEN'}
    )
    for($r=1;$r-le$rows;$r++) {
        $wwid=Norm-WWID (ArrGet $wwids $r 1); $fm=@{}
        if($wwid-ne''-and$agg.ContainsKey($wwid)){$fm=$agg[$wwid]}
        for($f=0;$f-lt5;$f++) {
            $x=[pscustomobject]@{MoveUnits=0.0;MoveValue=0.0;ReUnits=0.0;ReValue=0.0}; $key=Norm $funds[$f].Name
            if($fm.ContainsKey($key)){$x=$fm[$key]}
            $su=ToNumber (ArrGet $starts $r ($f*2+1)); $sv=ToNumber (ArrGet $starts $r ($f*2+2))
            $clOut.SetValue(($su+$x.MoveUnits),$r,$f*2+1); $clOut.SetValue(($sv+$x.MoveValue),$r,$f*2+2)
            if($f-lt3){$biOut.SetValue($x.ReUnits,$r,$f*2+1);$biOut.SetValue($x.ReValue,$r,$f*2+2)}
        }
    }

    Log 'BI:BN wird aus den DU-Umschichtungen geschrieben.'
    $target.Range($target.Cells.Item($first,$BI),$target.Cells.Item($last,$BN)).Value2=$biOut
    Log 'CL:CU wird aus AJ:AS plus den signierten DU-Bewegungen geschrieben.'
    $target.Range($target.Cells.Item($first,$CL),$target.Cells.Item($last,$CU)).Value2=$clOut

    Log 'Ausgabedatei wird gespeichert.'
    $templateBook.Save()
    $duBook.Close($false);$duBook=$null
    $templateBook.Close($true);$templateBook=$null
    $excel.Quit();$excel=$null
    Log ('FERTIG: '+$output)
    Start-Process explorer.exe -ArgumentList "/select,`"$output`""
    [System.Windows.Forms.MessageBox]::Show("Datei erfolgreich erstellt:`n`n$output",'DC LNW DU Importer','OK','Information')|Out-Null
    exit 0
}
catch {
    $msg=$_.Exception.Message
    Log ('FEHLER: '+$msg)
    [System.Windows.Forms.MessageBox]::Show("$msg`n`nDetails: $LogPath",'DC LNW DU Importer – Fehler','OK','Error')|Out-Null
    exit 1
}
finally {
    if($null-ne$duBook){try{$duBook.Close($false)}catch{}}
    if($null-ne$templateBook){try{$templateBook.Close($false)}catch{}}
    if($null-ne$excel){try{$excel.Quit()}catch{}}
    foreach($o in @($target,$duBook,$templateBook,$excel)){if($null-ne$o-and[Runtime.InteropServices.Marshal]::IsComObject($o)){try{[void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($o)}catch{}}}
    [GC]::Collect();[GC]::WaitForPendingFinalizers()
}
