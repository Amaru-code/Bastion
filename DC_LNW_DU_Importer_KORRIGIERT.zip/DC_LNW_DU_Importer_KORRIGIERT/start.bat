@echo off
setlocal EnableExtensions
cd /d "%~dp0"
title DC LNW DU Importer
if not exist "output" mkdir "output"
cls
echo ============================================================
echo  DC LNW DU Importer
echo ============================================================
echo.
powershell.exe -NoLogo -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0DC_LNW_DU_Importer.ps1"
set "RC=%ERRORLEVEL%"
echo.
if not "%RC%"=="0" (
  echo Verarbeitung mit Fehler beendet. Details stehen in importer.log.
) else (
  echo Verarbeitung erfolgreich beendet.
)
echo.
pause
exit /b %RC%
