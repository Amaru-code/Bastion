DC LNW DU IMPORTER – KORRIGIERTE PORTABLE VERSION

Start:
1. ZIP vollständig entpacken.
2. Alle Excel-Dateien schließen.
3. start.bat doppelklicken.
4. Zuerst das Template, danach die DU-Datei auswählen.

Es ist keine Go-Installation nötig. Es gibt keine install.bat und keine Go-Dateien.
Microsoft Excel Desktop muss installiert sein.

Verarbeitungslogik:
- Die gewählte Template-Datei wird als neue XLSM-Datei im Ordner output angelegt.
- Sheet: Import DC LNW.
- Header bleiben bestehen.
- AJ:AS erhält exakt und zeilenweise die ursprünglichen Werte aus CL:CU des ausgewählten Templates.
- Für AJ:AS findet keinerlei Addition, Subtraktion oder DU-Verarbeitung statt.
- BI:BN enthält die DU-Umschichtungen gemäß WWID, Fondsname und Umsatzart Fondsportfolioanpassung.
- CL:CU wird anschließend aus AJ:AS plus den signierten relevanten DU-Bewegungen berechnet.
- Formeln werden beim Leeren nicht gelöscht.

Das Fenster und importer.log zeigen jeden Verarbeitungsschritt.
