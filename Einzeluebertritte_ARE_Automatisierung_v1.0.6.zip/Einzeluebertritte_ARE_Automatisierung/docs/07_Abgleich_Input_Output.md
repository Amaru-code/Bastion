# Abgleich von Input und Output

## Strukturänderung

Der analysierte Input enthält die Arbeitsblätter:

- `Übersicht`
- `CHECK`
- `Gesellschaften`

Der Output behält diese Blätter bei und ergänzt je beteiligter Gesellschaft ein eigenes ARE-Blatt.

## Erzeugte Blattbezeichnungen im Beispieldatensatz

Für die bereitgestellten Beispieldaten ergeben sich unter anderem:

```text
ARE 7020 (LTRG 0100)
ARE 562k (LTRG 3065)
ARE 439q (LTRG 3080)
ARE 438q (LTRG 3082)
ARE 489q (LTRG 3096)
ARE 524k (LTRG 3099)
ARE 5026 (LTRG 3103)
ARE 427q (LTRG 9935)
```

## Wiederkehrender Blattaufbau

Jedes erzeugte Blatt enthält:

- Titel und Erläuterung in A1 bis F4
- LTRG, ARE und Gesellschaftsname in H2 bis J2
- Nettokontrolle in H4
- Differenzkontrolle in I4
- ab Zeile 7 gruppierte Gegen-Gesellschaften
- Detailspalten PNR, alte PNR, Übertritt, Pensionen, BSAV und Summe
- Abschnittssummen unter den Detailzeilen

## Bewusste Vereinheitlichung

Der Generator rekonstruiert die wiederkehrende Fach- und Tabellenlogik. Manuelle Einzelkorrekturen, individuelle Kommentare sowie rein optische Leerzeilen am Ende einzelner Beispielblätter werden nicht als fachliche Regel interpretiert.


## Optischer Abgleich ab Version 1.0.6

Zusätzlich zur Datenstruktur wird nun auch das sichtbare Referenzlayout nachgebildet. Insbesondere wurden die früheren blauen und grünen Flächen entfernt, die Tabellenbreite reduziert und der technische Kontrollbereich aus dem Druckbereich ausgeschlossen.
