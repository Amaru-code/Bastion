# Formatierung der ARE-Blätter

## Ziel

Version 1.0.6 bildet das kompakte Erscheinungsbild des gelieferten Referenzblatts nach. Die Formatierung ist bewusst schlicht und für Prüfung sowie Ausdruck optimiert.

## Bereich A:F – Bericht

- Schriftart: Arial
- Grundschriftgröße: 10 pt
- Titel in A1:F1: fett, 12 pt, linksbündig
- Erläuterungen in A3:F4: 9 pt, nicht kursiv
- Abschnittsüberschriften: weiß, fett, zentriert und kräftig eingerahmt
- Tabellenköpfe: weiß, schwarz, fett und zentriert
- Detailzeilen: ohne farbige Füllung und ohne vollständiges Zellraster
- Betragsspalten D:F: rechtsbündig
- Zwischensummen: fett mit einfacher oberer Trennlinie
- Negative Beträge: schwarz

## Kompakte Abmessungen

Die Spalten A:F werden bewusst schmaler als in Version 1.0.5 angelegt. Auch Titel-, Abschnitts-, Kopf-, Detail- und Summenzeilen erhalten feste kompakte Höhen. Dadurch stehen mehr Abschnitte gleichzeitig auf dem Bildschirm und das Blatt entspricht der gelieferten Referenzdarstellung.

## Bereich H:J – technische Kontrolle

LTRG, ARE, Gesellschaftsname sowie die Kontrollformeln bleiben erhalten. Dieser Bereich:

- besitzt keine farbigen Füllungen,
- besitzt keine Rahmen,
- liegt außerhalb des Druckbereichs.

## Druck- und Bildschirmansicht

Der Druckbereich ist auf A:F begrenzt. Die erzeugten Blätter werden in der Seitenumbruchvorschau bei 58 % Zoom gespeichert. Dadurch erscheint:

- der Berichtsbereich A:F weiß,
- der Kontrollbereich H:J grau außerhalb des Druckbereichs,
- die Seitenbegrenzung als blaue Linie,
- die Excel-Seitenkennzeichnung wie im Referenzbild.

Die Seitenumbruchvorschau ist lediglich eine gespeicherte Ansicht. Sie verändert keine Daten.
