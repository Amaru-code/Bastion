# Grenzen und Nicht-Ziele

## Was das Tool bewusst nicht verändert

- `Übersicht`
- `CHECK`
- `Gesellschaften`
- vorhandene Quelldaten, Formeln oder Pivot-Tabellen dieser Blätter
- externe Dateien oder Datenbanken

## Was nicht automatisch übernommen wird

Manuelle Kommentare oder individuelle Prüfhinweise aus einem bereits bearbeiteten Ziel, beispielsweise spezielle ORZ-Texte, werden nicht fachlich rekonstruiert. Neu erzeugte Blätter erhalten den einheitlichen Hinweis `ORZ, OK`.

## Keine automatische Aktualisierung einzelner Zeilen

Die ARE-Blätter sind ein erzeugter Bericht und keine live verknüpfte Detailansicht. Werden Zeilen in `Übersicht` geändert, hinzugefügt oder gelöscht, muss der Generator erneut ausgeführt werden.

## Löschen vorhandener ARE-Blätter

Vor dem Neuaufbau werden Blätter gelöscht, deren Name:

- mit `ARE ` beginnt und
- `(LTRG ` enthält.

In der VBS-Variante geschieht dies nur in der neu angelegten Ausgabekopie. In der direkten VBA-Variante geschieht es in der aktuell geöffneten Arbeitsmappe.

## Fehlende Stammdaten

Fehlt für eine verwendete LTRG ein Gesellschaftsname, wird die Verarbeitung abgebrochen. Das Tool erfindet keine Gesellschaftsnamen oder ARE-Werte.

## Formatabweichungen

Die Formatierung bildet die Zielstruktur nach, kann aber je nach Excel-Version, Standardschrift, Druckertreiber und lokalen Excel-Einstellungen geringfügig anders aussehen.

## Keine fachliche Plausibilisierung

Das Tool prüft nicht, ob:

- ein Übertritt inhaltlich zulässig ist,
- PNR fachlich korrekt sind,
- ein Datum in der richtigen Periode liegt,
- BSAV plus Pensionen exakt der Summe entspricht.

Es übernimmt die vorhandenen Daten und wendet die definierte Richtungs- und Gruppierungslogik an.
