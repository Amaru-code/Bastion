# Fachlogik

## Ziel

Für jede in den Übertrittsdaten vorkommende LTRG wird ein eigenes gesellschaftsbezogenes ARE-Blatt erzeugt. Das Blatt zeigt, von welchen Gesellschaften Rückstellungen empfangen oder an welche Gesellschaften Rückstellungen abgegeben wurden.

## Verwendete Quelldaten

Aus `Übersicht` werden verwendet:

| Spalte | Bedeutung | Verwendung |
|---|---|---|
| A | PNR neu | PNR im ARE-Blatt |
| B | LTRG neu | empfangende Gesellschaft |
| C | PNR alt | alte PNR im ARE-Blatt |
| D | LTRG alt | abgebende Gesellschaft |
| E | Datum des Einzelübertritts | Spalte Übertritt |
| H | Übertragungswert BSAV | BSAV-Betrag |
| I | Übertragungswert Pensionen (alt) | Pensionsbetrag |
| J | Summe | Gesamtbetrag und Kontrolle |

Die Spalten F und G werden nicht in die erzeugten ARE-Blätter übernommen.

Aus `Gesellschaften` werden verwendet:

| Spalte | Bedeutung |
|---|---|
| D | LTRG |
| E | ARE |
| F | Gesellschaftsname |

## Vorzeichenlogik

Jeder Übertritt wird aus zwei Blickwinkeln betrachtet:

- **LTRG neu** erhält den Betrag: positive Darstellung.
- **LTRG alt** gibt den Betrag ab: negative Darstellung.

Beispiel: Ein Betrag von 10.000 Euro wird von LTRG 3103 nach LTRG 100 übertragen.

- Blatt LTRG 0100: `+10.000`
- Blatt LTRG 3103: `-10.000`

BSAV, Pensionen und Summe erhalten jeweils dasselbe Richtungs-Vorzeichen.

## Gruppierung

Innerhalb eines ARE-Blatts werden die Übertritte nach Gegen-Gesellschaft gruppiert. Jeder Abschnitt enthält:

1. Gesellschaftsüberschrift mit ARE und LTRG
2. Spaltenüberschriften
3. einzelne Übertritte
4. Zwischensumme für Pensionen, BSAV und Summe

## Sortierung

- Auf dem zentralen Blatt LTRG 0100 werden Gegen-Gesellschaften numerisch nach LTRG sortiert.
- Auf den übrigen Blättern stehen Gruppen mit positiven Positionen zuerst.
- Innerhalb eines Abschnitts stehen positive Positionen vor negativen oder Nullpositionen.

## Nullbeträge

Ein Übertritt mit Gesamtsumme `0` wird auf der Empfängerseite standardmäßig nicht als Detailzeile dargestellt. Auf der Abgeberseite bleibt er berücksichtigt. Dieses Verhalten entspricht dem analysierten Zielbeispiel.

Im VBA-Modul und im VBS ist dies über folgende Konstante dokumentiert:

```vb
INCLUDE_ZERO_ON_RECEIVER_SIDE = False
```

## Kontrolllogik

`H4` berechnet den Nettosaldo der jeweiligen LTRG direkt aus `Übersicht`:

```text
Summe aller Beträge mit LTRG neu
minus
Summe aller Beträge mit LTRG alt
```

`I4` vergleicht diesen Nettosaldo mit den erzeugten Abschnittssummen. Das erwartete Ergebnis ist `0`.

- `0`: grüne Markierung
- Abweichung: rote Markierung
