# Technischer Ablauf

## VBS-Variante

1. Microsoft Excel wird über COM-Automatisierung gestartet.
2. Der Nutzer wählt eine XLSM- oder XLSX-Datei aus.
3. Die Quelle wird schreibgeschützt geöffnet.
4. Mit `SaveCopyAs` wird eine neue Ausgabedatei im ursprünglichen Excel-Dateiformat angelegt.
5. Die Quelle wird geschlossen.
6. Die Ausgabekopie wird bearbeitbar geöffnet.
7. Vorhandene automatische ARE-Blätter werden in der Kopie gelöscht.
8. Quell- und Stammdaten werden in den Arbeitsspeicher eingelesen.
9. Die LTRG-Zuordnungen werden validiert.
10. Die ARE-Blätter werden aufgebaut und formatiert.
11. Excel berechnet alle Formeln neu.
12. Die Ausgabedatei wird gespeichert und bleibt geöffnet.

Die VBS-Variante importiert kein VBA-Modul in die Arbeitsmappe. Deshalb ist die Excel-Einstellung **„Zugriff auf das VBA-Projektobjektmodell vertrauen“** nicht erforderlich.

## VBA-Variante

Das VBA-Modul arbeitet mit `ThisWorkbook`. Es verarbeitet daher genau die Arbeitsmappe, in die das Modul importiert wurde.

Zur Beschleunigung werden während der Verarbeitung vorübergehend deaktiviert:

- Bildschirmaktualisierung
- Ereignisse
- Warnmeldungen
- automatische Berechnung

Nach Abschluss oder Fehler werden die ursprünglichen Excel-Einstellungen wiederhergestellt.

## Datenhaltung

Die Übertrittsdaten werden als zweidimensionales Array eingelesen. Gesellschaften, Ziel-LTRG und Gruppen werden über `Scripting.Dictionary` verwaltet. Dadurch werden viele langsame Einzelzugriffe auf Zellen vermieden.

## Formeln statt festgeschriebener Kontrollwerte

Zwischensummen und Kontrollfelder werden als Excel-Formeln geschrieben. Änderungen an den Quelldaten nach der Erzeugung aktualisieren die Detailzeilen nicht automatisch, die vorhandenen Kontrollformeln können sich jedoch neu berechnen.

Für eine vollständig aktualisierte Ausgabe muss der Generator erneut ausgeführt werden.


## VBScript-Kompatibilität

Der externe Starter verwendet keine Funktionen, die ausschließlich in Excel-VBA existieren. Excel-Fehlerwerte werden über `VarType(value) = 10` erkannt. Während des Laufs wird außerdem eine Phasenbezeichnung aktualisiert; sie wird im Fehlerdialog zusammen mit Fehlernummer, Beschreibung und Quelle ausgegeben.


## Robustes Einlesen ab Version 1.0.5

Der VBS-Starter übernimmt den Datenblock nicht mehr direkt über `Range.Value2` als COM-SAFEARRAY. Stattdessen wird jede relevante Zelle mit einer abgesicherten Leseroutine verarbeitet und anschließend in einem internen zweidimensionalen Array gespeichert. Dadurch beeinflussen Excel-Fehlerwerte oder ungewöhnliche COM-Variant-Typen nicht mehr den gesamten Import.

Die letzte Datenzeile wird innerhalb des verwendeten Bereichs anhand der Spalten A bis D ermittelt. Zusätzlich protokolliert `ARE_Generator_Diagnose.log` die ausgeführten Phasen.



## Formatierungsphase ab Version 1.0.6

Nach dem Schreiben der Detail- und Summenzeilen wird jedes erzeugte ARE-Blatt in ein einheitliches Berichtslayout überführt:

1. Alle Standardfarbflächen und Tabellenraster werden entfernt.
2. Titel, Erläuterungen, Abschnittsüberschriften, Tabellenköpfe, Detailzeilen und Zwischensummen erhalten getrennte Formatregeln.
3. Die Betragsspalten D:F verwenden eine schwarze Tausenderdarstellung; negative Werte werden nicht farbig hervorgehoben.
4. Der Druckbereich endet nach Spalte F.
5. Der Kontrollbereich H:J bleibt in der Arbeitsmappe sichtbar, wird aber nicht gedruckt.
6. Die Blattansicht wird auf Seitenumbruchvorschau und 58 % Zoom gesetzt.

Die Formatierung verändert keine fachlichen Werte oder Gruppierungsregeln.
