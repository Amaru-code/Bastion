# Einzelübertritte ARE Automatisierung

**Version 1.0.6**

Dieses Projekt erzeugt aus einer bestehenden XLSM- oder XLSX-Datei automatisch die gesellschaftsbezogenen **ARE-Blätter** für Einzelübertritte.

## Schnellstart

1. Den gesamten Projektordner entpacken.
2. `ARE_Generator_starten.vbs` doppelklicken.
3. Die zu verarbeitende `.xlsm`- oder `.xlsx`-Datei auswählen.
4. Das Tool erstellt neben der Quelldatei eine neue Datei mit dem Zusatz `_ARE_Auswertung` und behält die Dateiendung der Quelle bei.
5. Die erzeugte Datei bleibt nach Abschluss in Excel geöffnet.

Die Quelldatei wird bei der VBS-Ausführung **nicht verändert**.

## Alternative Ausführung direkt in Excel

Im Ordner `macro` liegt das Modul `modAREGenerator.bas`.

1. XLSM-Datei öffnen.
2. `Alt + F11` drücken.
3. Im VBA-Editor `Datei > Datei importieren` wählen.
4. `macro/modAREGenerator.bas` importieren.
5. `Alt + F8` drücken.
6. `Erstelle_ARE_Blaetter` starten.

Bei der direkten VBA-Ausführung wird die aktuell geöffnete Arbeitsmappe verarbeitet. Bereits erzeugte Blätter mit dem Namensmuster `ARE ... (LTRG ...)` werden darin gelöscht und neu aufgebaut.

## Projektstruktur

```text
Einzeluebertritte_ARE_Automatisierung/
├── ARE_Generator_starten.vbs
├── README.md
├── VERSION.txt
├── CHANGELOG.md
├── macro/
│   └── modAREGenerator.bas
└── docs/
    ├── 01_Bedienung.md
    ├── 02_Fachlogik.md
    ├── 03_Technischer_Ablauf.md
    ├── 04_Datenanforderungen.md
    ├── 05_Grenzen_und_Nicht_Ziele.md
    ├── 06_Fehlersuche.md
    ├── 07_Abgleich_Input_Output.md
    └── 08_Formatierung.md
```

## Voraussetzungen

- Windows
- Microsoft Excel Desktop
- Eingabedatei im Format `.xlsm` oder `.xlsx`
- Blätter `Übersicht` und `Gesellschaften` im erwarteten Aufbau
- Schreibrecht im Ordner der ausgewählten Excel-Datei

Weitere Details stehen im Ordner `docs`.

## Formatierung in Version 1.0.6

Die erzeugten ARE-Blätter verwenden jetzt das kompakte Layout des gelieferten Referenzbildes:

- weiße Flächen und schwarze Schrift statt blauer beziehungsweise grüner Farbflächen
- Arial als Berichtsschrift
- kompakte Spaltenbreiten und Zeilenhöhen
- kräftig umrahmte Abschnittsüberschriften
- farbfreie Tabellenköpfe
- keine vollständigen Zellraster in den Detailbereichen
- schwarze negative Beträge
- Druckbereich ausschließlich A:F
- Kontrollbereich H:J außerhalb des Ausdrucks
- gespeicherte Seitenumbruchvorschau mit 58 % Zoom

Die Datenlogik aus Version 1.0.5 bleibt unverändert. Version 1.0.6 ändert ausschließlich Darstellung, Druckbereich und gespeicherte Blattansicht.
