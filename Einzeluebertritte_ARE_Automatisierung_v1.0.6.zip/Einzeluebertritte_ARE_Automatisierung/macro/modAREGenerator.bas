Attribute VB_Name = "modAREGenerator"
Option Explicit

Private Const SHEET_OVERVIEW As String = "�bersicht"
Private Const SHEET_COMPANIES As String = "Gesellschaften"
Private Const GENERATED_PREFIX As String = "ARE "
Private Const FIRST_DATA_ROW As Long = 3
Private Const CENTRAL_LTRG As Long = 100

' Entspricht dem gelieferten Final-Beispiel:
' Ein �bertritt mit Summe 0 wird auf der Empf�ngerseite nicht dargestellt,
' auf der Abgeberseite aber weiterhin ber�cksichtigt.
Private Const INCLUDE_ZERO_ON_RECEIVER_SIDE As Boolean = False

Public Sub Erstelle_ARE_Blaetter()

    Dim wb As Workbook
    Dim wsOverview As Worksheet
    Dim wsCompanies As Worksheet
    Dim companies As Object
    Dim targetLtrgs As Object
    Dim transferData As Variant
    Dim targetKeys As Variant
    Dim lastTransferRow As Long
    Dim i As Long
    Dim oldCalculation As XlCalculation
    Dim oldScreenUpdating As Boolean
    Dim oldEnableEvents As Boolean
    Dim oldDisplayAlerts As Boolean
    Dim errorDescription As String

    Set wb = ThisWorkbook

    oldCalculation = Application.Calculation
    oldScreenUpdating = Application.ScreenUpdating
    oldEnableEvents = Application.EnableEvents
    oldDisplayAlerts = Application.DisplayAlerts

    On Error GoTo Fehler

    Application.ScreenUpdating = False
    Application.EnableEvents = False
    Application.DisplayAlerts = False
    Application.Calculation = xlCalculationManual
    Application.StatusBar = "ARE-Bl�tter werden vorbereitet ..."

    Set wsOverview = GetWorksheetOrNothing(wb, SHEET_OVERVIEW)
    Set wsCompanies = GetWorksheetOrNothing(wb, SHEET_COMPANIES)

    If wsOverview Is Nothing Then
        Err.Raise vbObjectError + 1000, , _
                  "Das Blatt '" & SHEET_OVERVIEW & "' wurde nicht gefunden."
    End If

    If wsCompanies Is Nothing Then
        Err.Raise vbObjectError + 1001, , _
                  "Das Blatt '" & SHEET_COMPANIES & "' wurde nicht gefunden."
    End If

    ValidateOverviewLayout wsOverview

    lastTransferRow = LastTransferRow(wsOverview)
    If lastTransferRow < FIRST_DATA_ROW Then
        Err.Raise vbObjectError + 1002, , _
                  "Im Blatt '" & SHEET_OVERVIEW & "' wurden keine �bertritte gefunden."
    End If

    transferData = wsOverview.Range( _
        wsOverview.Cells(FIRST_DATA_ROW, 1), _
        wsOverview.Cells(lastTransferRow, 10) _
    ).Value2

    Set companies = LoadCompanies(wsCompanies)
    Set targetLtrgs = BuildTargetLtrgs(transferData)

    ValidateCompanyAssignments targetLtrgs, companies

    DeleteGeneratedSheets wb

    targetKeys = targetLtrgs.Keys
    SortNumericKeys targetKeys

    For i = LBound(targetKeys) To UBound(targetKeys)
        Application.StatusBar = _
            "ARE-Blatt f�r LTRG " & FormatLtrg(CLng(targetKeys(i))) & " wird erstellt ..."
        CreateARESheet wb, wsOverview, companies, transferData, CLng(targetKeys(i))
    Next i

    Application.Calculation = xlCalculationAutomatic
    Application.CalculateFull

    Application.StatusBar = False
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.Calculation = oldCalculation

    MsgBox targetLtrgs.Count & _
           " ARE-Bl�tter wurden erfolgreich erstellt." & vbCrLf & vbCrLf & _
           "Die Bl�tter '" & SHEET_OVERVIEW & "', 'CHECK' und '" & _
           SHEET_COMPANIES & "' wurden nicht ver�ndert.", _
           vbInformation, "ARE-Auswertung fertig"

    Exit Sub

Fehler:
    errorDescription = Err.Description
    On Error Resume Next
    Application.StatusBar = False
    Application.ScreenUpdating = oldScreenUpdating
    Application.EnableEvents = oldEnableEvents
    Application.DisplayAlerts = oldDisplayAlerts
    Application.Calculation = oldCalculation
    On Error GoTo 0

    MsgBox "Die ARE-Bl�tter konnten nicht erstellt werden." & vbCrLf & vbCrLf & _
           "Fehler: " & errorDescription, _
           vbCritical, "ARE-Auswertung"
End Sub

Public Sub Loesche_ARE_Blaetter()
    Dim oldDisplayAlerts As Boolean
    Dim errorDescription As String

    oldDisplayAlerts = Application.DisplayAlerts
    On Error GoTo Fehler

    Application.DisplayAlerts = False
    DeleteGeneratedSheets ThisWorkbook
    Application.DisplayAlerts = oldDisplayAlerts

    MsgBox "Alle automatisch erzeugten ARE-Bl�tter wurden gel�scht.", _
           vbInformation, "ARE-Auswertung"
    Exit Sub

Fehler:
    errorDescription = Err.Description
    Application.DisplayAlerts = oldDisplayAlerts
    MsgBox "Die ARE-Bl�tter konnten nicht gel�scht werden." & vbCrLf & _
           errorDescription, vbCritical, "ARE-Auswertung"
End Sub

Private Sub CreateARESheet(ByVal wb As Workbook, _
                           ByVal wsOverview As Worksheet, _
                           ByVal companies As Object, _
                           ByRef transferData As Variant, _
                           ByVal targetLtrg As Long)

    Dim ws As Worksheet
    Dim groups As Object
    Dim targetInfo As Variant
    Dim counterpartyInfo As Variant
    Dim groupKeys As Variant
    Dim rowsInGroup As Collection
    Dim descriptor As Variant
    Dim targetKey As String
    Dim counterpartyKey As String
    Dim targetName As String
    Dim targetShortName As String
    Dim sheetName As String
    Dim newLtrg As Long
    Dim oldLtrg As Long
    Dim rowIndex As Long
    Dim sourceIndex As Long
    Dim direction As Long
    Dim signedPension As Double
    Dim signedBsav As Double
    Dim signedTotal As Double
    Dim currentRow As Long
    Dim sectionRow As Long
    Dim headerRow As Long
    Dim dataStartRow As Long
    Dim dataEndRow As Long
    Dim subtotalRow As Long
    Dim subtotalRefs As String
    Dim pass As Long
    Dim i As Long
    Dim j As Long
    Dim amount As Double
    Dim shouldWrite As Boolean
    Dim overviewNameEscaped As String

    targetKey = CStr(targetLtrg)
    targetInfo = companies(targetKey)
    targetName = CStr(targetInfo(1))
    targetShortName = ShortCompanyName(targetName)

    sheetName = BuildSheetName(targetLtrg, targetInfo(0))
    If wb.ProtectStructure Then
        Err.Raise vbObjectError + 2030, "ARE Generator", _
                  "Die Struktur der Arbeitsmappe ist gesch�tzt. " & _
                  "Bitte den Strukturschutz aufheben und das Makro erneut starten."
    End If

    Set ws = wb.Worksheets.Add
    On Error Resume Next
    ws.Move After:=wb.Worksheets(wb.Worksheets.Count)
    On Error GoTo 0
    ws.Name = sheetName

    Set groups = CreateObject("Scripting.Dictionary")
    groups.CompareMode = vbTextCompare

    For i = LBound(transferData, 1) To UBound(transferData, 1)

        If TryGetLong(transferData(i, 2), newLtrg) And _
           TryGetLong(transferData(i, 4), oldLtrg) Then

            If newLtrg <> oldLtrg Then
                amount = NzNumber(transferData(i, 10))

                If newLtrg = targetLtrg Then
                    If amount <> 0 Or INCLUDE_ZERO_ON_RECEIVER_SIDE Then
                        AddGroupRecord groups, CStr(oldLtrg), i, 1
                    End If
                End If

                If oldLtrg = targetLtrg Then
                    AddGroupRecord groups, CStr(newLtrg), i, -1
                End If
            End If
        End If
    Next i

    ' Kopfbereich
    ws.Range("A1:F1").Merge
    ws.Range("A3:F3").Merge
    ws.Range("A4:F4").Merge

    ws.Range("A1").Value = "�bertragene R�ckstellungen bei Einzel�bertritten"
    ws.Range("A3").Value = _
        "Positive Betr�ge erh�lt die " & targetShortName & _
        " von der genannten Gesellschaft,"
    ws.Range("A4").Value = _
        "negative Betr�ge gibt die " & targetShortName & _
        " an die genannte Gesellschaft ab."

    ws.Range("H1").Value = "CHECK"
    ws.Range("I1").Value = "ORZ, OK"
    ws.Range("H2").Value = targetLtrg
    ws.Range("I2").Value = targetInfo(0)
    ws.Range("J2").Value = targetName
    ws.Range("H3").Value = "CHECK"

    overviewNameEscaped = Replace(wsOverview.Name, "'", "''")
    ws.Range("H4").Formula = _
        "=SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$B:$B,$H$2)-" & _
        "SUMIFS('" & overviewNameEscaped & "'!$J:$J," & _
        "'" & overviewNameEscaped & "'!$D:$D,$H$2)"

    currentRow = 7

    If groups.Count > 0 Then
        groupKeys = groups.Keys
        SortGroupKeys groupKeys, groups, transferData, targetLtrg

        For i = LBound(groupKeys) To UBound(groupKeys)

            counterpartyKey = CStr(groupKeys(i))
            counterpartyInfo = companies(counterpartyKey)
            Set rowsInGroup = groups(counterpartyKey)

            sectionRow = currentRow
            headerRow = sectionRow + 1
            dataStartRow = headerRow + 1

            ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6)).Merge
            ws.Cells(sectionRow, 1).Value = _
                ShortCompanyName(CStr(counterpartyInfo(1))) & _
                " (ARE " & DisplayValue(counterpartyInfo(0)) & _
                ", LTRG " & FormatLtrg(CLng(counterpartyKey)) & ")"

            ws.Cells(sectionRow, 8).Value = CLng(counterpartyKey)
            ws.Cells(sectionRow, 9).Value = counterpartyInfo(0)
            ws.Cells(sectionRow, 10).Value = CStr(counterpartyInfo(1))

            ws.Cells(headerRow, 1).Value = "PNR" & vbLf
            ws.Cells(headerRow, 2).Value = "alte PNR" & vbLf
            ws.Cells(headerRow, 3).Value = "�bertritt" & vbLf
            ws.Cells(headerRow, 4).Value = "Pensionen (alt)" & vbLf & "(Euro)"
            ws.Cells(headerRow, 5).Value = "BSAV" & vbLf & "(Euro)"
            ws.Cells(headerRow, 6).Value = "Summe" & vbLf & "(Euro)"

            currentRow = dataStartRow

            ' Positive Positionen zuerst, anschlie�end negative bzw. Nullpositionen.
            For pass = 1 To 2
                For j = 1 To rowsInGroup.Count

                    descriptor = rowsInGroup.Item(j)
                    sourceIndex = CLng(descriptor(0))
                    direction = CLng(descriptor(1))
                    signedTotal = direction * NzNumber(transferData(sourceIndex, 10))

                    shouldWrite = _
                        (pass = 1 And signedTotal > 0) Or _
                        (pass = 2 And signedTotal <= 0)

                    If shouldWrite Then
                        signedPension = direction * NzNumber(transferData(sourceIndex, 9))
                        signedBsav = direction * NzNumber(transferData(sourceIndex, 8))

                        ws.Cells(currentRow, 1).Value = transferData(sourceIndex, 1)
                        ws.Cells(currentRow, 2).Value = transferData(sourceIndex, 3)
                        ws.Cells(currentRow, 3).Value = transferData(sourceIndex, 5)
                        ws.Cells(currentRow, 4).Value = signedPension
                        ws.Cells(currentRow, 5).Value = signedBsav
                        ws.Cells(currentRow, 6).Value = signedTotal

                        currentRow = currentRow + 1
                    End If
                Next j
            Next pass

            dataEndRow = currentRow - 1
            subtotalRow = currentRow

            ws.Cells(subtotalRow, 4).Formula = _
                "=SUM(D" & dataStartRow & ":D" & dataEndRow & ")"
            ws.Cells(subtotalRow, 5).Formula = _
                "=SUM(E" & dataStartRow & ":E" & dataEndRow & ")"
            ws.Cells(subtotalRow, 6).Formula = _
                "=SUM(F" & dataStartRow & ":F" & dataEndRow & ")"

            subtotalRefs = subtotalRefs & "," & _
                           ws.Cells(subtotalRow, 6).Address(False, False)

            FormatSection ws, sectionRow, headerRow, _
                          dataStartRow, dataEndRow, subtotalRow

            currentRow = subtotalRow + 2
        Next i
    End If

    If Len(subtotalRefs) > 0 Then
        ws.Range("I4").Formula = _
            "=H4-SUM(" & Mid$(subtotalRefs, 2) & ")"
    Else
        ws.Range("I4").Formula = "=H4"
    End If

    FormatARESheet ws, currentRow - 1
End Sub

Private Function LoadCompanies(ByVal ws As Worksheet) As Object
    Dim dict As Object
    Dim lastRow As Long
    Dim r As Long
    Dim ltrg As Long
    Dim companyName As String

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    lastRow = ws.Cells(ws.Rows.Count, 4).End(xlUp).Row

    For r = 2 To lastRow
        If TryGetLong(ws.Cells(r, 4).Value2, ltrg) Then
            companyName = CStr(ws.Cells(r, 6).Value)

            If Len(Trim$(companyName)) > 0 Then
                dict(CStr(ltrg)) = Array(ws.Cells(r, 5).Value2, companyName)
            End If
        End If
    Next r

    If dict.Count = 0 Then
        Err.Raise vbObjectError + 1010, , _
                  "Im Blatt '" & SHEET_COMPANIES & _
                  "' wurden keine Gesellschaften gefunden."
    End If

    Set LoadCompanies = dict
End Function

Private Function BuildTargetLtrgs(ByRef transferData As Variant) As Object
    Dim dict As Object
    Dim i As Long
    Dim ltrg As Long

    Set dict = CreateObject("Scripting.Dictionary")
    dict.CompareMode = vbTextCompare

    For i = LBound(transferData, 1) To UBound(transferData, 1)
        If TryGetLong(transferData(i, 2), ltrg) Then
            dict(CStr(ltrg)) = True
        End If

        If TryGetLong(transferData(i, 4), ltrg) Then
            dict(CStr(ltrg)) = True
        End If
    Next i

    Set BuildTargetLtrgs = dict
End Function

Private Sub ValidateCompanyAssignments(ByVal targetLtrgs As Object, _
                                       ByVal companies As Object)
    Dim key As Variant
    Dim missing As String

    For Each key In targetLtrgs.Keys
        If Not companies.Exists(CStr(key)) Then
            missing = missing & vbCrLf & "� LTRG " & FormatLtrg(CLng(key))
        End If
    Next key

    If Len(missing) > 0 Then
        Err.Raise vbObjectError + 1011, , _
                  "F�r folgende LTRG fehlt eine Zuordnung im Blatt '" & _
                  SHEET_COMPANIES & "':" & missing
    End If
End Sub

Private Sub AddGroupRecord(ByVal groups As Object, _
                           ByVal counterpartyKey As String, _
                           ByVal sourceIndex As Long, _
                           ByVal direction As Long)
    Dim rowsInGroup As Collection

    If Not groups.Exists(counterpartyKey) Then
        Set rowsInGroup = New Collection
        groups.Add counterpartyKey, rowsInGroup
    Else
        Set rowsInGroup = groups(counterpartyKey)
    End If

    rowsInGroup.Add Array(sourceIndex, direction)
End Sub

Private Sub SortGroupKeys(ByRef keys As Variant, _
                          ByVal groups As Object, _
                          ByRef transferData As Variant, _
                          ByVal targetLtrg As Long)
    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If GroupKeyComesAfter(CStr(keys(i)), CStr(keys(j)), _
                                  groups, transferData, targetLtrg) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Function GroupKeyComesAfter(ByVal firstKey As String, _
                                    ByVal secondKey As String, _
                                    ByVal groups As Object, _
                                    ByRef transferData As Variant, _
                                    ByVal targetLtrg As Long) As Boolean
    Dim firstHasPositive As Boolean
    Dim secondHasPositive As Boolean
    Dim firstRows As Collection
    Dim secondRows As Collection

    ' Das gelieferte Final-Beispiel sortiert das zentrale Blatt LTRG 0100
    ' rein nach LTRG. Bei den �brigen Bl�ttern stehen positive Gruppen zuerst.
    If targetLtrg = CENTRAL_LTRG Then
        GroupKeyComesAfter = CLng(firstKey) > CLng(secondKey)
        Exit Function
    End If

    Set firstRows = groups(firstKey)
    Set secondRows = groups(secondKey)

    firstHasPositive = GroupHasPositive(firstRows, transferData)
    secondHasPositive = GroupHasPositive(secondRows, transferData)

    If firstHasPositive <> secondHasPositive Then
        GroupKeyComesAfter = (Not firstHasPositive And secondHasPositive)
    Else
        GroupKeyComesAfter = CLng(firstKey) > CLng(secondKey)
    End If
End Function

Private Function GroupHasPositive(ByVal rowsInGroup As Collection, _
                                  ByRef transferData As Variant) As Boolean
    Dim descriptor As Variant
    Dim i As Long
    Dim sourceIndex As Long
    Dim direction As Long

    For i = 1 To rowsInGroup.Count
        descriptor = rowsInGroup.Item(i)
        sourceIndex = CLng(descriptor(0))
        direction = CLng(descriptor(1))

        If direction * NzNumber(transferData(sourceIndex, 10)) > 0 Then
            GroupHasPositive = True
            Exit Function
        End If
    Next i
End Function

Private Sub SortNumericKeys(ByRef keys As Variant)
    Dim i As Long
    Dim j As Long
    Dim temp As Variant

    If UBound(keys) <= LBound(keys) Then Exit Sub

    For i = LBound(keys) To UBound(keys) - 1
        For j = i + 1 To UBound(keys)
            If CLng(keys(i)) > CLng(keys(j)) Then
                temp = keys(i)
                keys(i) = keys(j)
                keys(j) = temp
            End If
        Next j
    Next i
End Sub

Private Sub FormatARESheet(ByVal ws As Worksheet, ByVal lastContentRow As Long)

    Dim maxRow As Long

    maxRow = Application.Max(lastContentRow, 4)

    ' Kompakte, farbfreie Darstellung wie im gelieferten Zielbeispiel.
    With ws.Cells
        .Font.Name = "Arial"
        .Font.Size = 10
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .VerticalAlignment = xlCenter
        .Interior.Pattern = xlNone
    End With

    With ws.Range("A1:F1")
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = True
        .Font.Size = 12
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(1).RowHeight = 20

    With ws.Range("A3:F4")
        .Interior.Pattern = xlNone
        .Font.Size = 9
        .Font.Bold = False
        .Font.Italic = False
        .HorizontalAlignment = xlLeft
        .VerticalAlignment = xlCenter
        .WrapText = False
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(3).RowHeight = 15
    ws.Rows(4).RowHeight = 15

    ' Kontrollbereich H:J au�erhalb des Druckbereichs.
    With ws.Range("H1:J" & maxRow)
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = False
        .Font.Italic = False
        .Borders.LineStyle = xlNone
    End With

    ws.Range("H4:I4").NumberFormat = "#,##0;-#,##0"
    ws.Range("I4").FormatConditions.Delete

    ws.Columns("A").ColumnWidth = 12.5
    ws.Columns("B").ColumnWidth = 12.5
    ws.Columns("C").ColumnWidth = 11.5
    ws.Columns("D").ColumnWidth = 14
    ws.Columns("E").ColumnWidth = 12
    ws.Columns("F").ColumnWidth = 12
    ws.Columns("G").ColumnWidth = 3
    ws.Columns("H").ColumnWidth = 9
    ws.Columns("I").ColumnWidth = 9
    ws.Columns("J").ColumnWidth = 40

    ws.Columns("A:B").NumberFormat = "0"
    ws.Columns("C").NumberFormat = "dd.mm.yyyy"
    ws.Columns("D:F").NumberFormat = "#,##0;-#,##0"
    ws.Columns("H").NumberFormat = "0"

    ws.Range("A1:J" & maxRow).WrapText = False

    With ws.PageSetup
        .Orientation = xlLandscape
        .Zoom = False
        .FitToPagesWide = 1
        .FitToPagesTall = False
        .LeftMargin = Application.CentimetersToPoints(0.8)
        .RightMargin = Application.CentimetersToPoints(0.8)
        .TopMargin = Application.CentimetersToPoints(1)
        .BottomMargin = Application.CentimetersToPoints(1)
        .PrintArea = "$A$1:$F$" & maxRow
    End With

    On Error Resume Next
    ws.Activate
    Application.ActiveWindow.View = xlPageBreakPreview
    Application.ActiveWindow.Zoom = 58
    Application.ActiveWindow.DisplayGridlines = True
    Err.Clear
    On Error GoTo 0
End Sub

Private Sub FormatSection(ByVal ws As Worksheet, _
                          ByVal sectionRow As Long, _
                          ByVal headerRow As Long, _
                          ByVal dataStartRow As Long, _
                          ByVal dataEndRow As Long, _
                          ByVal subtotalRow As Long)

    With ws.Range(ws.Cells(sectionRow, 1), ws.Cells(sectionRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .Borders.LineStyle = xlContinuous
        .Borders.Weight = xlMedium
    End With
    ws.Rows(sectionRow).RowHeight = 18

    With ws.Range(ws.Cells(sectionRow, 8), ws.Cells(sectionRow, 10))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = False
        .Borders.LineStyle = xlNone
    End With

    With ws.Range(ws.Cells(headerRow, 1), ws.Cells(headerRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = True
        .Font.Size = 10
        .HorizontalAlignment = xlCenter
        .VerticalAlignment = xlCenter
        .WrapText = True
        .Borders.LineStyle = xlNone
    End With
    ws.Rows(headerRow).RowHeight = 30

    If dataEndRow >= dataStartRow Then
        With ws.Range(ws.Cells(dataStartRow, 1), ws.Cells(dataEndRow, 6))
            .Interior.Pattern = xlNone
            .Font.Color = RGB(0, 0, 0)
            .Font.Bold = True
            .Borders.LineStyle = xlNone
        End With

        ws.Range(ws.Cells(dataStartRow, 1), _
                 ws.Cells(dataEndRow, 3)).HorizontalAlignment = xlCenter
        ws.Range(ws.Cells(dataStartRow, 4), _
                 ws.Cells(dataEndRow, 6)).HorizontalAlignment = xlRight
        ws.Rows(dataStartRow & ":" & dataEndRow).RowHeight = 15
    End If

    With ws.Range(ws.Cells(subtotalRow, 4), ws.Cells(subtotalRow, 6))
        .Interior.Pattern = xlNone
        .Font.Color = RGB(0, 0, 0)
        .Font.Bold = True
        .Borders.LineStyle = xlNone
        .Borders(xlEdgeTop).LineStyle = xlContinuous
        .Borders(xlEdgeTop).Weight = xlThin
    End With
    ws.Rows(subtotalRow).RowHeight = 15
End Sub

Private Sub ValidateOverviewLayout(ByVal ws As Worksheet)
    If LCase$(Trim$(CStr(ws.Cells(2, 1).Value))) <> "pnr neu" Or _
       LCase$(Trim$(CStr(ws.Cells(2, 2).Value))) <> "ltrg neu" Or _
       LCase$(Trim$(CStr(ws.Cells(2, 3).Value))) <> "pnr alt" Or _
       LCase$(Trim$(CStr(ws.Cells(2, 4).Value))) <> "ltrg alt" Then

        Err.Raise vbObjectError + 1020, , _
                  "Die Spalten A bis D im Blatt '" & SHEET_OVERVIEW & _
                  "' entsprechen nicht dem erwarteten Aufbau."
    End If
End Sub

Private Function LastTransferRow(ByVal ws As Worksheet) As Long
    Dim lastCell As Range

    Set lastCell = ws.Range("A:D").Find( _
        What:="*", _
        After:=ws.Range("A1"), _
        LookIn:=xlValues, _
        LookAt:=xlPart, _
        SearchOrder:=xlByRows, _
        SearchDirection:=xlPrevious, _
        MatchCase:=False _
    )

    If lastCell Is Nothing Then
        LastTransferRow = 0
    Else
        LastTransferRow = lastCell.Row
    End If
End Function

Private Function GetWorksheetOrNothing(ByVal wb As Workbook, _
                                       ByVal sheetName As String) As Worksheet
    On Error Resume Next
    Set GetWorksheetOrNothing = wb.Worksheets(sheetName)
    On Error GoTo 0
End Function

Private Sub DeleteGeneratedSheets(ByVal wb As Workbook)
    Dim i As Long
    Dim sheetName As String

    For i = wb.Worksheets.Count To 1 Step -1
        sheetName = wb.Worksheets(i).Name

        If Left$(sheetName, Len(GENERATED_PREFIX)) = GENERATED_PREFIX And _
           InStr(1, sheetName, "(LTRG ", vbTextCompare) > 0 Then
            wb.Worksheets(i).Delete
        End If
    Next i
End Sub

Private Function BuildSheetName(ByVal ltrg As Long, _
                                ByVal areValue As Variant) As String
    BuildSheetName = SafeSheetName( _
        "ARE " & DisplayValue(areValue) & _
        " (LTRG " & FormatLtrg(ltrg) & ")" _
    )
End Function

Private Function SafeSheetName(ByVal value As String) As String
    Dim forbidden As Variant
    Dim item As Variant

    forbidden = Array("\", "/", ":", "*", "?", "[", "]")

    For Each item In forbidden
        value = Replace(value, CStr(item), "-")
    Next item

    value = Trim$(value)
    If Len(value) = 0 Then value = "ARE-Auswertung"
    If Len(value) > 31 Then value = Left$(value, 31)

    SafeSheetName = value
End Function

Private Function FormatLtrg(ByVal ltrg As Long) As String
    FormatLtrg = Format$(ltrg, "0000")
End Function

Private Function ShortCompanyName(ByVal fullName As String) As String
    Dim commaPosition As Long

    fullName = Trim$(fullName)
    commaPosition = InStr(1, fullName, ",", vbTextCompare)

    If commaPosition > 0 Then
        ShortCompanyName = Trim$(Left$(fullName, commaPosition - 1))
    Else
        ShortCompanyName = fullName
    End If
End Function

Private Function DisplayValue(ByVal value As Variant) As String
    If IsError(value) Or IsEmpty(value) Or Len(Trim$(CStr(value))) = 0 Then
        DisplayValue = "n.v."
    Else
        DisplayValue = Trim$(CStr(value))
    End If
End Function

Private Function NzNumber(ByVal value As Variant) As Double
    If IsError(value) Or IsEmpty(value) Or Len(Trim$(CStr(value))) = 0 Then
        NzNumber = 0
    ElseIf IsNumeric(value) Then
        NzNumber = CDbl(value)
    Else
        NzNumber = 0
    End If
End Function

Private Function TryGetLong(ByVal value As Variant, ByRef result As Long) As Boolean
    If IsError(value) Or IsEmpty(value) Then Exit Function
    If Len(Trim$(CStr(value))) = 0 Then Exit Function
    If Not IsNumeric(value) Then Exit Function

    result = CLng(value)
    TryGetLong = True
End Function
