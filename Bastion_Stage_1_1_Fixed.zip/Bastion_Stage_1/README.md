# Bastion – Stage 1.1

## Start

1. ZIP vollständig entpacken.
2. `Start_Game.bat` doppelklicken.
3. Alternativ `Start_Game.ps1` ausführen.

Der Starter öffnet ausdrücklich Microsoft Edge oder Google Chrome, damit eine `.html`-Zuordnung zu VS Code nicht stört.

## Behobener Fehler

Stage 1 verwendete ES-Module. Browser blockieren Modulimporte häufig beim direkten Öffnen über `file://`. Stage 1.1 verwendet deshalb ein gebündeltes klassisches JavaScript und benötigt weiterhin keinen Server, Node.js oder npm.

## Steuerung

- Eigene Burg anklicken.
- Direkt verbundenes Ziel anklicken.
- 25 %, 50 % oder 75 % der Soldaten senden.
- Eigene Gebäude können für 15 Gold verbessert werden.
